import { pgTable, serial, integer, text, numeric, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const contestStatusEnum = pgEnum("contest_status", ["open", "judging", "completed", "closed"]);

export const contestsTable = pgTable("contests", {
  id: serial("id").primaryKey(),
  hostId: integer("host_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  brief: text("brief").notNull(),
  category: text("category").notNull(),
  prizeAmount: numeric("prize_amount", { precision: 10, scale: 2 }).notNull(),
  deadline: timestamp("deadline").notNull(),
  status: contestStatusEnum("status").notNull().default("open"),
  submissionCount: integer("submission_count").notNull().default(0),
  winnerId: integer("winner_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const contestSubmissionsTable = pgTable("contest_submissions", {
  id: serial("id").primaryKey(),
  contestId: integer("contest_id").notNull().references(() => contestsTable.id, { onDelete: "cascade" }),
  creatorId: integer("creator_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  fileUrl: text("file_url"),
  previewUrl: text("preview_url"),
  isWinner: boolean("is_winner").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertContestSchema = createInsertSchema(contestsTable).omit({ id: true, createdAt: true, submissionCount: true, winnerId: true });
export type InsertContest = z.infer<typeof insertContestSchema>;
export type Contest = typeof contestsTable.$inferSelect;

export const insertContestSubmissionSchema = createInsertSchema(contestSubmissionsTable).omit({ id: true, createdAt: true, isWinner: true });
export type InsertContestSubmission = z.infer<typeof insertContestSubmissionSchema>;
export type ContestSubmission = typeof contestSubmissionsTable.$inferSelect;
