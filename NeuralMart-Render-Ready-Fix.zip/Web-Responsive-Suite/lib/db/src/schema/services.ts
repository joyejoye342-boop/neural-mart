import { pgTable, serial, integer, text, numeric, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const servicesTable = pgTable("services", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  previewImageUrl: text("preview_image_url"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  // Basic tier
  basicName: text("basic_name").notNull().default("Basic"),
  basicDescription: text("basic_description").notNull().default(""),
  basicPrice: numeric("basic_price", { precision: 10, scale: 2 }).notNull(),
  basicDeliveryDays: integer("basic_delivery_days").notNull().default(3),
  basicRevisions: integer("basic_revisions").notNull().default(1),
  basicFeatures: jsonb("basic_features").$type<string[]>().notNull().default([]),
  // Standard tier
  standardName: text("standard_name"),
  standardDescription: text("standard_description"),
  standardPrice: numeric("standard_price", { precision: 10, scale: 2 }),
  standardDeliveryDays: integer("standard_delivery_days"),
  standardRevisions: integer("standard_revisions"),
  standardFeatures: jsonb("standard_features").$type<string[]>().notNull().default([]),
  // Premium tier
  premiumName: text("premium_name"),
  premiumDescription: text("premium_description"),
  premiumPrice: numeric("premium_price", { precision: 10, scale: 2 }),
  premiumDeliveryDays: integer("premium_delivery_days"),
  premiumRevisions: integer("premium_revisions"),
  premiumFeatures: jsonb("premium_features").$type<string[]>().notNull().default([]),
  rating: numeric("rating", { precision: 3, scale: 2 }).notNull().default("5.0"),
  reviewCount: integer("review_count").notNull().default(0),
  salesCount: integer("sales_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertServiceSchema = createInsertSchema(servicesTable).omit({ id: true, createdAt: true, salesCount: true, rating: true, reviewCount: true });
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof servicesTable.$inferSelect;
