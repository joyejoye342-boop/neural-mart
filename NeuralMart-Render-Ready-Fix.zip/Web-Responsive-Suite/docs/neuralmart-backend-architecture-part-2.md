# NeuralMart — Backend Architecture
## Part 2 of 3: Transactions, Communication & Platform Services

**Document version:** 1.0  
**Depends on:** Part 1 (`docs/neuralmart-backend-architecture-part-1.md`), Prompts #1–#36, and the approved NeuralMart Order, Chat-Commerce, Paywalled Delivery, and Database architectures  
**Continues in:** Part 3 — cross-cutting API contracts, reliability, security operations, observability, deployment, and backend roadmap  
**Scope:** Sections 13–24  
**Implementation status:** Architecture specification only; no production code is specified here

---

## 0. Continuity and Implementation Rules

This part defines backend behavior for transaction, communication, and platform-service modules. It extends Part 1; it does not replace its modular-monolith approach or the approved product/data architecture.

### 0.1 Established boundaries

| Concern | Authoritative owner |
|---|---|
| Commercial lifecycle and valid order transitions | Universal Order module |
| Payment authorization, capture, refund, and provider references | Payment module |
| Money movement, balances, seller earnings, fees, holds, and withdrawals | Wallet/Ledger module |
| Exclusive rights and their transfer history | Ownership module |
| Fulfillment submissions and revisions | Delivery/Revision module |
| Technical file retrieval permission | AccessGrant/Entitlement module |
| Conversation and message history | Chat-Commerce module |
| Search results, feeds, counters, and analytics aggregates | Rebuildable projections |
| Staff decisions and access to sensitive operations | Admin/Moderation module with audit records |

The Order may expose summary statuses and stable references for a unified user experience, but a summary must not become a competing source of truth for a specialist domain.

### 0.2 Shared backend contract

Every state-changing operation follows this sequence:

1. Authenticate the actor and establish account/session status.
2. Authorize the actor for the resource, role, and requested action.
3. Validate current authoritative records and applicable policy/version.
4. Apply a domain command with a scoped idempotency key.
5. Commit related operational records in a database transaction when they share a consistency boundary.
6. Append an audit/timeline record and transactional outbox event in that commit.
7. Process external effects asynchronously with retries and reconciliation.
8. Return the committed state, or a clear `pending`/`reconciling` state when an external or asynchronous step remains.

Clients may request actions. They do not set payment, order, ownership, entitlement, payout, badge, or moderation truth.

### 0.3 API naming

The operation names below are conceptual commands and queries, not a required REST, GraphQL, RPC, or framework design. Part 3 should settle the transport/API conventions while preserving these domain contracts.

---

# 13. Central Order Engine

## 13.1 Responsibilities

The Order module owns the universal commercial lifecycle for:

- digital product orders;
- exclusive product or project purchases;
- service orders;
- custom Chat orders;
- project contract orders;
- contest prize orders;
- paid file delivery orders.

It coordinates type-specific extensions and references, but it does not own the payment ledger, file bytes, file-access policy, conversation messages, or exclusive ownership history.

## 13.2 Data ownership and relationships

The Order module owns:

- `Order` and `OrderItem`;
- immutable purchased/contracted terms snapshot;
- `OrderTimelineEvent`;
- type-specific Order extension records where a type requires durable fields;
- cancellation request/decision references and universal lifecycle timestamps;
- current summary dimensions needed by Order Centers.

It references:

- buyer and seller Users;
- Product/ProductVersion/ProductLicense, Service/ServicePackage, Project/Proposal, Contest/Entry/Winner, Offer, and Conversation;
- Payment and financial references;
- Delivery, Revision, AccessGrant, and Ownership;
- Review and Dispute case references;
- notification and analytics event identifiers.

Specialist modules remain authoritative for their own records. For example, Order may show `paymentStatus: Paid`, but only verified Payment records establish that status.

## 13.3 Supported order types

| Order type | Origin and authoritative source | Fulfillment/access behavior |
|---|---|---|
| `digital_product` | Product checkout | Payment creates a purchase Order and a license-scoped entitlement |
| `exclusive_product` | Exclusive catalog checkout | Payment validation and Ownership lock/Order linkage occur under the Sell Once invariant |
| `exclusive_project` | Exclusive project checkout | Same unique-ownership rule; Order records the sale and Ownership records the rights transfer |
| `service` | Service package checkout | Creator acceptance/work, requirements, delivery, revisions, and approval as the package requires |
| `project_contract` | Accepted proposal and final terms | Project scope is snapshotted; proposal history remains; Order controls fulfillment |
| `custom_chat_order` | Accepted versioned Offer | Offer terms are snapshotted; payment and Order are explicit structured operations |
| `contest_prize` | Contest winner and funded prize | Winner, prize Order, required delivery, rights, and payout gates remain separate |
| `paid_file_delivery` | Locked-file/PaymentRequest flow | Order, confirmed payment, entitlement, and AccessGrant govern the unlock |

`orderOrigin`, `orderType`, and `fulfillmentMode` are separate concepts. A paid file delivery can originate in Chat without making Chat the transaction owner.

## 13.4 Conceptual operations

**Queries**

- `GetOrder(orderId, actorContext)`
- `ListOrders(participantId, roleView, filters, cursor)`
- `GetOrderTimeline(orderId, actorContext)`
- `GetOrderNextActions(orderId, actorContext)`

**Commands**

- `CreatePendingOrder(source, termsSnapshot, idempotencyKey)`
- `ConfirmPayment(orderId, verifiedPaymentReference)`
- `AcceptOrder(orderId)`
- `StartWork(orderId)`
- `SubmitDelivery(orderId, deliveryId)`
- `RequestRevision(orderId, deliveryVersionId, request)`
- `ApproveDelivery(orderId, deliveryVersionId)`
- `CompleteOrder(orderId, completionReason)`
- `RequestCancellation(orderId, reason)`
- `RecordCancellationDecision(orderId, decision)`
- `RequestRefund(orderId, amount, reason)`
- `OpenOrderDispute(orderId, claimReference)`
- `RecordDisputeResolution(orderId, resolutionReference)`

These are authorized actions with transition guards, not generic arbitrary status updates.

## 13.5 Order creation and transition rules

- Create a durable pending Order before or as part of checkout, according to the source flow; do not wait until after payment in a way that risks an untraceable charge.
- Snapshot title, seller/buyer, price, currency, fees, scope, due date/timezone, license/rights, revision terms, and applicable policy version.
- Require a valid source reference and one permitted Order type.
- Enforce unique idempotency/source keys so retrying creation returns the same Order.
- Validate transitions against the current state, order type, actor, and policy.
- Do not compress payment, fulfillment, delivery/access, ownership, revision, refund, dispute, and payout into one status field.
- Payment confirmation is not order completion.
- A Chat message such as “approved” or “paid” is not an Order command.
- Cancellation and refund are distinct decisions with distinct records.
- Completed Orders remain addressable for receipts, reviews, access history, and support.
- An ordinary refund does not silently relist an exclusive item or erase ownership history.

## 13.6 Transaction boundaries and event interactions

For same-database state changes, use one transaction for the Order transition, its timeline event, related local records, and outbox event.

External payment-provider calls are not part of a PostgreSQL transaction. Use a pending payment/order state, verified provider response, idempotent finalization, and reconciliation. Order events include, as applicable:

- `OrderCreated`
- `PaymentConfirmed`
- `OrderAccepted`
- `WorkStarted`
- `DeliverySubmitted`
- `RevisionRequested`
- `DeliveryApproved`
- `OrderCompleted`
- `CancellationRequested` / `OrderCancelled`
- `RefundRequested` / `RefundRecorded`
- `OrderDisputed` / `DisputeResolved`
- `OwnershipTransferred`

Notification, search, analytics, and Chat system-message consumers process these events from the outbox and must deduplicate them.

## 13.7 Failure cases and recovery

- **Repeated create/confirm command:** return the original result using the same idempotency scope.
- **Payment callback before a client response:** finalize from the trusted callback; subsequent client polling returns current state.
- **External provider timeout:** keep payment/order `pending` or `reconciling`; query the provider before retrying or compensating.
- **Invalid or stale transition:** reject without changing authoritative state; return current state and allowed next actions.
- **Outbox/notification failure:** keep the committed Order; retry side effects without rolling back the transaction.
- **Order-linked specialist record unavailable:** do not claim fulfillment is complete; retain a recoverable state and surface support/reconciliation path.

## 13.8 Security requirements

- Enforce buyer/seller/admin access for every query and command.
- Bind Order access to the authenticated participant or explicitly authorized staff case.
- Do not trust client-supplied price, fee, role, ownership, payment, or completion values.
- Expose only a safe payment failure reason; retain provider details in restricted records.
- Log material transitions and staff access without exposing private files or message contents to ordinary users.

---

# 14. Payment & Wallet Backend

## 14.1 Responsibilities

Payment and Wallet are collaborating modules with a strict boundary:

- **Payment** manages provider payment attempts, authorization/capture, verified callbacks, refunds at the provider, and provider references.
- **Wallet/Ledger** records all financial consequences in immutable balanced journal entries, and owns balances, holds, SellerEarnings, PlatformFees, withdrawal requests, and payout accounting.

The same User has one wallet per applicable currency/account policy; buying and selling do not create separate wallets.

## 14.2 Data ownership

Payment owns:

- `Payment`, `PaymentAttempt`, `PaymentReference`, verified webhook/event records, provider status, and refund-provider references.

Wallet/Ledger owns:

- `Wallet`, immutable `FinancialTransaction`/journal, `LedgerEntry`, balance projections, `SellerEarning`, `PlatformFee`, `Withdrawal`, and payout/hold accounting.

Order owns the commercial terms and Order lifecycle. The Order may display financial summaries, but the ledger is authoritative for money movement.

## 14.3 Conceptual operations

- `CreatePaymentAttempt(orderId, amountSnapshot, currency, source, idempotencyKey)`
- `GetCheckoutStatus(paymentId, actorContext)`
- `ConfirmProviderEvent(provider, verifiedEvent)`
- `CaptureAuthorizedPayment(paymentId)`
- `PostPaymentJournal(paymentId, allocationSnapshot)`
- `RequestRefund(orderId, amount, reason, idempotencyKey)`
- `ProcessProviderRefund(refundId)`
- `ReconcilePayment(providerReference)`
- `GetWalletSummary(userId, currency)`
- `ListWalletTransactions(userId, cursor)`
- `ReserveWithdrawal(userId, amount, destinationReference, idempotencyKey)`
- `ReleaseSellerEarning(earningId, eligibilityReference)`
- `ReconcileWallet(walletId, period)`

Raw payment-card data is not an input to NeuralMart storage. Use provider-hosted/tokenized payment instruments.

## 14.4 Payment initiation and confirmation

1. Load the pending Order and immutable amount/currency snapshot.
2. Revalidate buyer eligibility, order state, and payment source.
3. Create a scoped idempotent PaymentAttempt.
4. Request provider authorization/capture using provider idempotency support.
5. Treat the client redirect/result as informational only.
6. Verify callback signature and provider/event identity, or query provider status.
7. In a database transaction, record the verified state, link Payment to Order, create the appropriate balanced financial journal/allocation records, and append outbox/timeline events.
8. Ask the Order/Ownership/Access modules to complete their authorized transitions.
9. Return success only when authoritative local state commits; otherwise return a clear pending/reconciling state.

Unique provider references and scoped idempotency keys prevent duplicate capture and duplicate journal posting.

## 14.5 Ledger and earnings rules

- Record currency amounts in integer minor units; never use floating-point values for money.
- Use balanced double-entry journals or an equivalent auditable accounting model.
- Never edit or delete posted ledger entries. Correct them with explicit reversing/adjusting journals linked to the original.
- Derive available, pending, held, reserved, and withdrawable balances from ledger entries; cached balance columns are rebuildable projections.
- Preserve the fee policy/version and allocation snapshot used for each Order.
- `SellerEarning` is a settlement allocation, not itself a wallet balance or journal entry.
- Do not create seller earnings from an unconfirmed payment.
- Keep contest prize funding/hold distinct from the winner's SellerEarning until winner and rights/order gates are satisfied.
- A withdrawal reserves eligible funds atomically before calling a payout provider. A failed payout releases or reverses that reservation by journal entry.

## 14.6 Refund and dispute interactions

A refund command must validate the authorized actor, Order/payment state, remaining refundable amount, prior refund allocations, dispute holds, and policy. Once approved:

- record an idempotent refund allocation against the original Payment;
- request provider refund and verify the result;
- post linked buyer, seller-earning, and platform-fee reversal journals as appropriate;
- update Order refund summary through its command;
- communicate access/entitlement consequences to Delivery/Access;
- preserve exclusive ownership unless an explicit authorized ownership-reversal workflow is invoked.

A dispute may freeze seller payout, but it does not itself create a refund or mutate ledger entries.

## 14.7 Financial consistency and failures

Strong consistency is required for:

- Payment-to-Order association;
- provider-event deduplication;
- ledger posting;
- fee and earning allocations;
- withdrawal reservation;
- refund amount allocation;
- contest prize funding/hold;
- ownership purchase settlement.

Failure handling:

- **Invalid webhook:** reject and record a security-safe verification result; do not settle.
- **Duplicate webhook:** acknowledge idempotently without duplicate posting.
- **Provider timeout/unknown outcome:** reconcile by provider reference; do not blindly create another charge.
- **Payment confirmed, ledger/order finalization delayed:** retain a recoverable `reconciling` state and retry locally; never ask the buyer to pay again.
- **Refund provider failed:** retain a failed/pending refund record and retry or escalate; do not claim refunded.
- **Withdrawal provider failed:** preserve the withdrawal failure and safely release reserved funds using a compensating journal.
- **Journal invariant failure:** abort the local financial transaction and alert operators; do not partially post a financial result.

## 14.8 Security and audit requirements

- Verify provider signatures against configured provider credentials; never log secret material.
- Keep provider tokens and payout destinations tokenized/provider-managed.
- Restrict raw provider payloads and identity/payment evidence to least-privilege staff.
- Audit every manual adjustment, refund override, hold, and payout release with actor, reason, references, and before/after state.
- Never expose a mutable balance as a financial proof; user-visible balance is a ledger-derived view.

---

# 15. Chat-Commerce

## 15.1 Responsibilities and data ownership

Chat-Commerce owns:

- `Conversation`, `ConversationParticipant`, `ConversationLink`;
- `Message`, `MessageAttachment`, read cursors, mute/archive state;
- versioned `Offer` records and offer responses;
- `PaymentRequest` as a request/action record;
- structured message references to Order, Delivery, LockedFile, Revision, and Support/Dispute.

It does not own payment state, Order status, Delivery completion, AccessGrant, Ownership, refund, or payout truth.

## 15.2 Conceptual operations

- `StartConversation(context, recipient)`
- `ListConversations(actor, filters, cursor)`
- `GetConversation(conversationId, actor)`
- `SendMessage(conversationId, bodyOrStructuredReference, idempotencyKey)`
- `AttachMedia(messageId, mediaId, purpose)`
- `MarkRead(conversationId, lastSeenMessageId)`
- `CreateOffer(conversationId, offerTerms)`
- `ReviseOffer(offerId, newOfferVersion)`
- `AcceptOffer(offerId, versionId)`
- `DeclineOffer(offerId, versionId)`
- `CreatePaymentRequest(offerOrOrderReference, amountSnapshot)`
- `LinkOrder(conversationId, orderId, relationshipKind)`

Each operation rechecks participant membership, account restrictions, linked-object permissions, and current context.

## 15.3 Conversation and order linkage

- A conversation may exist before a transaction.
- A post-order link associates the existing conversation with the Order; earlier messages are not copied, discarded, or rewritten.
- Context changes are recorded as `ConversationLink`/context history with effective time and relationship kind.
- Keep unrelated orders/projects in distinct contexts unless an explicit product rule links them.
- MVP supports one buyer and one creator in ordinary commercial threads. Additional team/support participants require explicit membership roles and scoped permissions.

## 15.4 Offer and payment rules

- An OfferVersion snapshots scope, deliverables, price, currency, deadline, revisions, rights/license, payment terms, add-ons, and expiry.
- Accepted versions are immutable. Changes produce a new version or an explicit add-on/new Offer.
- Acceptance expresses agreement; it is not proof of payment or commencement.
- Acceptance invokes the Payment/Order application command. Chat cannot directly create a successful payment state.
- PaymentRequest identifies amount, payer/payee, reason, expiration, and optional Order reference; it is not a ledger entry.
- A creator cannot use an active service/project Order to introduce an unrelated charge without a buyer-accepted Offer/add-on path.

## 15.5 Events and failures

Chat may display read-only system messages for events such as `OfferAccepted`, `PaymentConfirmed`, `OrderStarted`, `DeliverySubmitted`, `RevisionRequested`, `OrderCompleted`, `RefundRecorded`, and `DisputeOpened`. These are materialized from committed domain events, have a system actor/type, and cannot be edited as ordinary text.

- **Message retry:** message idempotency prevents duplicate sends.
- **Offer expiry/revision race:** lock or compare the active version/status before accepting; only one valid response commits.
- **Order command fails after offer acceptance:** retain accepted Offer; show payment/order pending state and allow safe retry without double charge.
- **Notification or system-message delivery fails:** retry projection from the outbox; authoritative Offer/Order state remains correct.
- **Participant removed/blocked/restricted:** deny new actions according to safety policy while preserving historical references and evidence.

## 15.6 Security and privacy

- Only participants and explicitly scoped support staff can read a conversation.
- Every attachment access uses Media/AccessGrant authorization, not a message URL.
- Restrict staff visibility to assigned support/dispute cases and record each access.
- Apply spam/rate limits, block/report/mute controls, and safe-link/file protections.
- Do not expose private project, purchase, or buyer identity context to unrelated users.
- Analytics events must not contain message bodies or attachment contents.

---

# 16. Paywalled File Backend

## 16.1 Responsibilities and authoritative records

The paywalled-file workflow coordinates:

```text
Upload → Scan/Ready → Lock → Checkout → Verified Payment
→ Order/Entitlement → AccessGrant → Authorized access/download
```

Media owns the file metadata and storage reference. Order owns the commercial lifecycle. Payment/Wallet own money. Delivery/Access owns entitlement and retrieval permission. Chat renders the locked card and links to these records.

## 16.2 Conceptual operations

- `CreateLockedDelivery(conversationId, fileIds, previewIds, terms, expiry)`
- `GetLockedDelivery(deliveryId, actor)`
- `StartUnlockCheckout(deliveryId, idempotencyKey)`
- `ConfirmUnlockPayment(verifiedPaymentReference)`
- `ProvisionAccessGrant(orderId, deliveryVersionId, buyerId)`
- `AuthorizeFileAccess(mediaId, requestedAction, actor)`
- `RecordDownload(accessGrantId, resultMetadata)`
- `RevokeAccess(orderId, reasonReference)`

## 16.3 Lock and unlock rules

- Keep original files in private storage. Previews are separate Media objects, and may be watermarked, reduced, or partial.
- A locked card snapshots the displayed title, file manifest, size/type, preview, price, currency, license, order/source relationship, and applicable terms.
- Files must reach a safe, approved upload state before becoming buyer-visible.
- Access is unavailable while the item is locked, payment is pending/failed, or the grant is absent, expired, revoked, or blocked.
- After a trusted payment confirmation, provision Order/entitlement/access idempotently. Repeated callbacks may not create multiple grants or orders.
- Every retrieval request checks the current authenticated user, participant/recipient relationship, payment and Order state, entitlement/Ownership, file inclusion and version, scan status, license/access scope, expiration, refund/dispute status, and revocation.
- Issue a short-lived URL or stream only after the server authorization check. A signed URL is a transport mechanism, not the entitlement record.
- Download records are audit/support signals, not proof that a buyer consumed or used a file.

## 16.4 Transaction and event interactions

Where records share PostgreSQL, Order, payment linkage, entitlement, AccessGrant, access-state summary, timeline, and outbox updates commit in one transaction after payment verification. If a downstream storage/CDN action is required, record a pending state and use retryable provisioning; never ask for a second payment because unlock provisioning is delayed.

Relevant events: `LockedDeliveryCreated`, `PaymentConfirmed`, `EntitlementGranted`, `AccessGrantCreated`, `DownloadAuthorized`, `AccessRevoked`, `RefundRecorded`, `DisputeOpened`.

## 16.5 Failure cases

- **Payment fails/expires:** no active entitlement or grant; locked file remains private.
- **Payment succeeds, grant creation fails:** keep paid Order in `unlocking`/reconciling; retry the grant; show a clear “preparing files” state; support may issue a policy-approved compensating refund if access cannot be restored.
- **Refund after access:** record refund and apply the explicit access/license policy; invalidate future links/grants where required. The platform cannot retrieve a lawful prior download.
- **Dispute:** preserve file hashes, versions, timeline, and access history; access behavior follows the case policy and may be temporarily held or revoked for safety/fraud.
- **Expired URL:** issue a fresh URL only after a new authorization check.

## 16.6 Security requirements

- Never expose permanent public URLs for originals or source files.
- Do not rely on hidden UI controls, unguessable object keys, or CORS as access control.
- Scope grants to user, Order/OrderItem, file/version, action, and optional expiry.
- Keep preview and original object keys separate.
- Rate-limit download grants and log suspicious access patterns without treating one retry as abuse.

---

# 17. File & Media Processing

## 17.1 Responsibilities and ownership

The Media module owns:

- upload authorization and upload-session state;
- `Media` metadata and private object-storage references;
- validation, scan, transformation, preview, and thumbnail job state;
- typed references to posts, products, services, project attachments, contest entries, Chat attachments, DeliveryFiles, and LockedFiles.

Object storage owns binary bytes. Relational metadata owns identity, status, ownership, checksum, visibility, and access policy. A Media reference does not itself grant access.

## 17.2 Conceptual operations

- `InitiateUpload(owner, purpose, declaredMetadata)`
- `CompleteUpload(uploadId, objectReference, observedMetadata)`
- `GetUploadStatus(uploadId, actor)`
- `ProcessMedia(mediaId, processingProfile)`
- `AttachMedia(mediaId, typedParent, role)`
- `RequestMediaAccess(mediaId, action, actor)`
- `DeleteOrQuarantineMedia(mediaId, reason)`

Direct client-to-object-storage upload is allowed only to a short-lived, narrowly scoped quarantine location. The client cannot choose a public final path or assign a trusted scan/visibility state.

## 17.3 Processing pipeline

```text
Upload initiated
→ Bytes received in private quarantine
→ Storage metadata and checksum verified
→ Actual type inspected (not filename only)
→ Size/count/duration limits checked
→ Malware/archive safety scan
→ Safe metadata extracted
→ Thumbnail/preview/transcode generated as allowed
→ Final private/public derivative location assigned
→ Ready, rejected, or manual-review state
```

Required controls include:

- allowlisted types by purpose;
- declared and observed MIME/type comparison;
- magic-byte/content inspection;
- configurable byte, duration, page, file-count, and archive-expansion limits;
- malware scanning and sandboxing of risky parsers/converters;
- safe generated filenames/object keys;
- metadata stripping where appropriate for public images;
- checksum/hash storage for integrity and evidence;
- upload completion verification against storage rather than client claims.

## 17.4 Media states and business rules

Recommended state family:

```text
initiated → uploaded/quarantined → scanning → processing
→ ready | rejected | manual_review
→ archived/deleted under retention policy
```

- Only `ready` assets may be published, delivered, indexed, or exposed to buyers, subject to the specific visibility/access rule.
- A failed/rejected upload remains inaccessible and may be retried via a new controlled upload.
- Preview derivatives are separate objects; producing a preview must not accidentally expose source layers or originals.
- Replacing a product or delivery file creates a new version/reference; preserve historical Order-linked bytes/metadata as required for receipts and disputes.
- Deletion checks active Order, Ownership, dispute, and retention references. A user delete request may hide content first and enqueue safe deletion/retention work rather than break a transaction.
- Orphaned storage objects are found through reconciliation and removed only when no valid Media record or retention hold references them.

## 17.5 Storage and CDN policy

- **Private originals:** private object storage; never directly public or indexed by a public CDN.
- **Protected previews and paid files:** private storage with server authorization and short-lived asset/action-scoped signed access, or an authorized streaming/download gateway.
- **Public derivatives:** only explicitly public, moderation-approved thumbnails/previews may use CDN caching.
- **CDN invalidation:** moderation removal, deletion, privacy change, or rights change emits a purge/revalidation job. Sensitive/private items are not made safe by CDN invalidation alone.
- Storage credentials remain server-side. Upload/download credentials are temporary, scoped, and not written to analytics or logs.

## 17.6 Events, failures, and security

Events: `UploadInitiated`, `UploadCompleted`, `MediaScanPassed`, `MediaScanRejected`, `MediaReady`, `PreviewGenerated`, `MediaAttached`, `MediaQuarantined`, `MediaDeleted`.

- **Incomplete multipart upload:** expire the session and clean staged bytes.
- **Object/metadata mismatch:** quarantine and reject; do not attach.
- **Scanner/transcoder outage:** retain private `processing` state, retry safely, and do not publish.
- **Malware or unsafe content:** quarantine; block all user access and inform the owner with a safe reason.
- **Transformation failure:** retain the original privately if policy permits, but do not claim a missing required preview/thumbnail is ready.
- **Storage unavailable:** surface retryable status; do not lose database references or create public fallbacks.
- Protect parsers against archive bombs, path traversal, polyglot files, resource exhaustion, and unsafe external references.

---

# 18. Review & Reputation

## 18.1 Responsibilities and data ownership

Trust & Reputation owns:

- `Review`, `Rating`, review eligibility records/projections, review moderation state, and creator/buyer/service/product reputation summaries.
- immutable links from each review to its author, target, Order, OrderItem/context, and eligibility evidence.

Order owns completion and the reference to review activity. Analytics may summarize review data but cannot establish eligibility or reputation truth.

## 18.2 Eligibility rules

A review is eligible only when:

- the authenticated author is a participant in the qualifying Order;
- the Order type supports that review direction/context;
- the Order reached the approved completion/access condition for that type;
- payment and transaction provenance are valid;
- no ineligible test/admin/fraud condition applies;
- the author has not already used the unique review allowance for that Order, target, and context.

Previously approved eligible examples include completed product/exclusive project/service/custom Chat/paid-file orders and contest prize relationships where review is supported. Failed payments, unfulfilled cancellations, unverified message-only interactions, and ordinary fully refunded transactions are not eligible unless an explicit policy says otherwise.

The review prompt may follow product/file access, approved or auto-completed service/project delivery, or contest-prize completion. Review window duration is policy-configured, disclosed, and snapshotted for the Order; do not hard-code an unapproved duration.

## 18.3 Conceptual operations

- `GetReviewEligibility(orderId, actor)`
- `SubmitReview(orderId, target, context, rating, text, idempotencyKey)`
- `EditReview(reviewId, permittedChanges)`
- `ReportReview(reviewId, reason)`
- `ModerateReview(reviewId, decision, reason)`
- `RecomputeReputation(targetId, sourceVersion)`

Buyer reviews the seller/product/service where supported. Seller/buyer reviews are allowed only in order contexts that explicitly support mutual feedback; one party’s action must not expose or modify the other party’s review.

## 18.4 Integrity and effects

- Enforce database uniqueness for the permitted author + Order + target/context review.
- Updates, where policy permits, edit the existing record and preserve edit/moderation history; do not create duplicate purchase reviews.
- Mark as “Verified purchase/client” only from the authoritative Order relationship.
- Reject reviews from creators about their own listing or from unrelated accounts.
- Detect suspicious self-dealing, circular transactions, review exchanges, and coordinated manipulation; do not automatically treat every correlated account as fraudulent.
- Keep ratings distinct from written reviews and review eligibility.
- Reputation projections use eligible, verified, moderated reviews and settled/completed activity; cancelled, refunded, fake, or unresolved transaction events do not count as positive performance.
- Changes in reviews may trigger badge/reputation reevaluation but must not directly alter a badge from an unverified client payload.

## 18.5 Events, failure, and security

Events: `ReviewEligibilityOpened`, `ReviewSubmitted`, `ReviewEdited`, `ReviewReported`, `ReviewModerated`, `ReputationRecomputed`.

- **Duplicate submit/retry:** return the existing review or idempotent result.
- **Order completion changes after submission:** preserve review evidence and apply policy moderation/status; do not erase it.
- **Reputation job failure:** retain the review; retry projection; public summary can show a clearly stale/last-updated value rather than fabricate a new score.
- **Abuse/report:** preserve original, submitter, edit history, and moderation action.
- Restrict private buyer performance details and exact financial activity. Public review display follows privacy/moderation rules.

---

# 19. Badge System

## 19.1 Responsibilities and data ownership

Trust & Reputation owns:

- `BadgeDefinition`, versioned eligibility configuration, `UserBadge`, `BadgeProgress`, `BadgeHistory`, and visibility state.
- Current level/specialty/buyer-trust badge projections derived from verified source data.

Badges are not static labels on Profile or client-editable fields. Existing badge architecture remains: sustained reliability tiers, specialty/achievement badges, and optional buyer trust badges; creator badges reward reliable outcomes rather than raw activity volume.

## 19.2 Eligibility inputs

Inputs may include verified:

- completed/settled eligible orders or projects;
- ratings from eligible reviews;
- on-time delivery adjusted for verified buyer-caused delay;
- qualifying response behavior;
- upheld or unresolved creator-caused disputes rather than every opened dispute;
- finalized contest wins;
- policy-compliant identity/verification evidence.

Thresholds, rolling windows, public visibility, and grace periods are versioned and configurable. The approved badge criteria remain owned by the Badge System; this backend specification does not invent new numeric thresholds.

## 19.3 Conceptual operations

- `GetBadgeSummary(userId, visibilityContext)`
- `GetBadgeProgress(userId, actor)`
- `EvaluateBadgeEligibility(userId, definitionVersion)`
- `AwardBadge(userId, badgeDefinition, evidenceSet)`
- `SuspendOrDemoteBadge(userId, badge, reason, reviewReference)`
- `ReinstateBadge(userId, badge, evidenceSet)`
- `RebuildBadgeProjection(userId, sourceVersion)`

## 19.4 Award, demotion, and visibility rules

- Create a history row for award, level change, suspension, demotion, expiry, and reinstatement; never overwrite prior awards as if they did not happen.
- Reevaluate on material domain events and on a scheduled cadence for rolling windows.
- A single poor review does not automatically demote a creator. Apply the approved grace/warning process for ordinary performance changes.
- Fraud, manipulated reviews/transactions, identity misrepresentation, safety issues, and serious policy violations can suspend badge benefits immediately through an audited action.
- Suspending a badge/perk does not delete prior achievement history.
- Public presentation follows context-specific density: compact evidence in feed/chat/search, fuller explanation on profiles/dashboard, and private progress only to the account holder/staff as authorized.
- Badges may affect capped eligibility/perks where previously approved; they never override relevance, safety, marketplace fit, user preference, or policy restrictions.

## 19.5 Events, failure, and security

Events: `EligibleActivityCommitted`, `ReviewModerated`, `DisputeResolved`, `ContestWinFinalized`, `VerificationChanged`, `BadgeProgressChanged`, `BadgeAwarded`, `BadgeSuspended`, `BadgeDemoted`, `BadgeReinstated`.

- **Delayed event/rebuild:** derive from authoritative Orders, Reviews, Contest results, and moderation records; do not award from analytics counters alone.
- **Conflicting/out-of-order events:** version inputs and make recomputation idempotent.
- **Bad rule rollout:** retain definition versions and history; staff can roll forward with corrected policy while preserving what was shown at the time.
- Keep risk evidence and unpublished progress private; audit manual awards/overrides.

---

# 20. Notification Backend

## 20.1 Responsibilities and data ownership

Notifications owns:

- material event-to-notification mapping;
- persisted in-app `Notification`;
- per-recipient read state;
- per-channel `NotificationDelivery` attempts;
- `NotificationPreference`, quiet-hour and digest settings;
- deduplication, grouping, retry, and delivery outcomes.

The source module owns the event and current state. Notification text and deep links reference that state and do not become transaction truth.

## 20.2 Event sources and priorities

Consume committed outbox events for:

- Order/payment/delivery/revision/refund/dispute/deadline changes;
- Chat messages and structured Offers;
- project/proposal/contest activity;
- wallet/withdrawal events;
- badge/reputation changes;
- account/security and platform notices.

Priority is action-oriented:

1. Security or required account action.
2. Payment, order, delivery, deadline, refund, or dispute action.
3. Direct Chat/Offer activity.
4. Project, contest, badge, or social information.

Generate notifications from material state changes, not every row update. Group related low-priority activity by recipient/context; do not send a push for every Chat system event.

## 20.3 Conceptual operations

- `CreateNotificationFromEvent(eventId, recipient, templateVersion)`
- `ListNotifications(recipient, cursor, readFilter)`
- `MarkNotificationRead(notificationId, actor)`
- `UpdateNotificationPreferences(actor, preferences)`
- `DeliverNotification(notificationId, channel)`
- `RetryNotificationDelivery(deliveryId)`
- `CreateDigest(recipient, timeWindow)`

The in-app record is the durable user-facing inbox. Push and email are separate delivery channels.

## 20.4 Deduplication and preference rules

- Use a deterministic deduplication key from source event, recipient, notification type, and relevant aggregation window.
- Deduplicate retries independently per channel; a failed email does not create a second in-app notification.
- Respect channel and category preferences, quiet hours, mute/archive state, locale, and digest rules.
- Required security notices and legally required transaction/account notices follow their defined override policy; preference controls must not silently suppress essential in-app records.
- Combine repeated deadline reminders using order/recipient/reminder-window keys.
- Notification deep links must be access-controlled after navigation; possession of a notification ID grants no access.
- Keep templates versioned and avoid exposing message bodies, protected file names, sensitive payment details, or private participant information in lock-screen previews.

## 20.5 Failures, events, and security

- **Provider outage/bounce:** retry with exponential backoff and jitter; record provider response safely; stop after configured attempts and surface operational failure.
- **Duplicate/out-of-order event:** dedupe and check source event version before creating or changing a notification.
- **Invalid preference/locale:** use a safe in-app fallback and flag configuration errors; do not block the source transaction.
- **Flood risk:** per-user/per-context rate limits, grouping, digests, and high-priority exceptions.
- **Provider accepts but callback is lost:** delivery state is reconciled or marked unknown; do not endlessly resend without dedupe.
- Restrict delivery logs and contact destinations; do not log full rendered sensitive content or provider secrets.

---

# 21. Background Jobs & Queues

## 21.1 Responsibilities

Background workers handle work that should not extend a mobile request or occur inside a critical financial/order transaction:

- media scanning, transformation, thumbnailing, and cleanup;
- notification delivery and digest generation;
- analytics ingestion and aggregation;
- search indexing and feed candidate updates;
- badge/reputation recomputation;
- payment, refund, withdrawal, ownership/access, and contest-prize reconciliation;
- deadline reminders, auto-completion checks, and archival/deletion workflows.

At MVP, use the simplest durable worker/queue mechanism compatible with the project and operational environment. The architecture requires reliability semantics, not a specific broker.

The background-work infrastructure owns job execution metadata: job/outbox delivery state, attempts, schedules, leases, processed-event deduplication, and dead-letter state. The originating domain module owns the meaning and authoritative outcome of its event; its outbox record is written in the same transaction as its domain change. A queue message is never a replacement for the source record.

Conceptual operations:

- `EnqueueCommittedEvent(outboxEventId)`
- `ClaimJob(workerIdentity, queue, lease)`
- `ExecuteJob(jobId)`
- `RetryJob(jobId, retryClass)`
- `MarkJobComplete(jobId, resultReference)`
- `MarkJobFailed(jobId, safeFailureCode)`
- `ReplayFailedJob(jobId, auditedOperatorContext)`

## 21.2 Durable job and event behavior

- Write important domain events to a transactional outbox in the same PostgreSQL transaction as the state change.
- A dispatcher claims outbox records safely and publishes/enqueues them; consumers persist a deduplication/processed marker.
- Jobs carry stable entity IDs, event/version IDs, correlation IDs, attempt count, and a bounded payload. Avoid embedding secrets, full payment data, message bodies, or file bytes.
- A job may execute more than once. Handlers must be idempotent.
- Use bounded retries with exponential backoff and jitter, then a dead-letter/failed state for operator review and controlled replay.
- Preserve ordering only where the domain requires it; use aggregate/entity sequence/version checks rather than assuming global queue order.
- Distinguish retryable failures, permanent validation failures, stale commands, and unknown external outcomes.

## 21.3 Job classes and priority

| Class | Examples | Priority/handling |
|---|---|---|
| Critical reconciliation | Payment confirmation, refund, payout, exclusive ownership, access grant | Durable, high priority, alert on exhaustion, safe manual replay |
| User-action timing | Deadline reminders, auto-completion eligibility | Schedule by policy/version; recheck current state before acting |
| Media safety | Scan, transcode, preview generation | Quarantine until passed; resource-limited workers |
| User communication | Push/email/in-app delivery, digest | Retry/dedupe; never blocks committed transaction |
| Derived projections | Search, feed candidates, counters, analytics, badges | Rebuildable, versioned, lower priority than source transactions |
| Retention/cleanup | Expired temporary uploads, archival, deletion | Verify references and legal holds before destructive work |

## 21.4 Failure and operational controls

- **Worker crash after side effect but before acknowledgement:** retry with idempotency and provider/source references.
- **Poison job:** move to a failed/dead-letter state after bounded retries; alert by severity and permit audited replay after correction.
- **Outbox backlog:** monitor age and count; prioritize transaction-critical events; apply backpressure to noncritical projections.
- **Duplicate/late job:** compare source version and current state, then no-op or reconcile safely.
- **Long-running media job:** use checkpoints/progress and resource limits; do not hold a database transaction open.
- **Queue outage:** continue accepting only operations whose source state can be committed durably; defer safe side effects; reject or return pending for workflows that cannot maintain their invariant without the worker.

## 21.5 Security requirements

- Workers use dedicated service identities with narrow, task-specific permissions; a media worker does not inherit payment or account-admin authority.
- Job payloads contain references rather than secrets, full payment data, message bodies, identity documents, or file bytes.
- Restrict queue, outbox, dead-letter, and replay access to authorized operators; audit manual replay and payload inspection.
- Validate job signatures/source event identity where jobs cross a trust boundary, and recheck current authorization/state before destructive or financial actions.
- Scrub sensitive values from logs and dead-letter records; enforce retention and deletion policy for failed jobs.

---

# 22. Search Backend

## 22.1 Responsibilities and replaceable design

Search provides discovery for:

- creators;
- services;
- products;
- projects;
- contests;
- posts.

Search is a projection of public, eligible source records. PostgreSQL remains the operational source of truth. Keep a replaceable Search interface so MVP PostgreSQL text search can later be backed by a dedicated search engine without changing source entities or transaction commands.

## 22.2 Conceptual operations

- `SearchCreators(query, filters, sort, cursor, actorContext)`
- `SearchServices(query, filters, sort, cursor, actorContext)`
- `SearchProducts(query, filters, sort, cursor, actorContext)`
- `SearchProjects(query, filters, sort, cursor, actorContext)`
- `SearchContests(query, filters, sort, cursor, actorContext)`
- `SearchPosts(query, filters, sort, cursor, actorContext)`
- `IndexSourceEntity(entityType, entityId, sourceVersion)`
- `RemoveFromSearch(entityType, entityId, reason, sourceVersion)`

Queries apply authenticated visibility, blocks/mutes, role/context, availability, policy state, and current listing state. Search is not authorization; source-level permission and eligibility are rechecked before returning sensitive actions or content.

## 22.3 Search documents and relevance

Documents may contain only purpose-approved public fields:

- entity ID/type and source version;
- public title, description, category, tags/skills, and public media reference;
- public creator profile summary and verified trust signals;
- current public price/budget/prize, deadline, availability, and status;
- publication/update time;
- coarse aggregate relevance features.

Exclude private messages, buyer identity, private project details, unpublished drafts, internal risk flags, exact earnings, personal verification material, and protected file metadata.

Ranking should combine, with capped influence:

- text/category/skill relevance;
- requested filters, price/budget, location/availability where supported;
- freshness and deadline fit;
- verified review quality and relevant trust evidence;
- quality/performance signals;
- user-selected sort and consented personalization.

Badges or popularity alone must not outrank category fit, relevance, safety, or user preference. Do not expose a listing solely because it has a high stale score.

## 22.4 Indexing and consistency rules

- Source modules emit committed outbox changes for publish, edit, archive, moderation, sale, availability, and deletion.
- Index workers process versions idempotently; older events may not overwrite newer documents.
- Store searchable eligibility/status summaries as rebuildable projections.
- Recheck current visibility, block, moderation, availability, and sold-exclusive state when serving results or opening the result.
- An exclusive product/project with committed Ownership must not appear as available for purchase; it may appear only in a historically appropriate, non-purchasable context.
- Search results use cursor pagination and stable sort keys where possible.

## 22.5 Failures and security

- **Index delayed:** use a short-lived pending state or query the source database for recent changes; do not report sold/removed content as currently purchasable.
- **Search provider outage:** fall back to a bounded PostgreSQL query for essential MVP discovery or return a clear retryable search error; never bypass visibility rules.
- **Stale document:** validate source version/state before action; refresh asynchronously.
- **Bad/abusive query:** validate size/operators, rate-limit, escape query syntax, and prevent expensive unrestricted scans.
- **Moderation/delete event:** remove/tombstone promptly and enqueue provider deletion; cache invalidation follows. Sensitive source data is never left exposed because an index lags.

---

# 23. Analytics Backend

## 23.1 Responsibilities and data ownership

Analytics owns event ingestion, validation, deduplication, attribution, aggregation, and metric projections. It consumes:

- low-latency interaction events: impressions, views, clicks, profile visits, follows, saves, product/project/service/contest views, and Chat leads;
- material domain events: purchases, Payments, Orders, proposal submissions, contest entries, delivery/completion, refunds, and conversions.

Operational records remain authoritative for Users, Orders, Payment, Wallet/Ledger, Ownership, Delivery, Reviews, and proposals/entries. Analytics never authorizes a purchase, access grant, payout, badge award, or order transition.

## 23.2 Event envelope and conceptual operations

An `AnalyticsEvent` uses a versioned envelope:

- stable event ID and event type;
- schema version;
- actor User ID or pseudonymous/anonymous session reference where appropriate;
- target entity type/ID and source surface/feed;
- server event time and ingestion time;
- client event time only as untrusted diagnostic context;
- session/device class/app version limited to product need;
- source/referrer/campaign and attribution chain;
- rank position/experiment context where appropriate;
- bounded, non-sensitive properties;
- deduplication key and correlation/Order reference when applicable.

Conceptual operations:

- `IngestInteractionEvents(batch)`
- `RecordCommittedDomainEvent(outboxEvent)`
- `DeduplicateAndValidate(event)`
- `AggregateMetrics(window, dimensions, schemaVersion)`
- `GetAnalyticsProjection(owner, metricSet, range)`
- `RebuildAnalyticsProjection(sourceWindow, version)`

Impressions and clicks may be batched/asynchronous. Purchase, payment, completed-order, ownership, and refund facts should originate from server-committed domain events, not client tracking.

## 23.3 Attribution and separation

- Keep first/last source and relevant session chain where policy permits.
- A click, Chat lead, proposal view, or impression is not a purchase conversion.
- Attribute conversions through server-side Order/payment references and an explicit conversion window/rule.
- Keep project proposal, contest participation, product purchase, and service conversion funnels distinct.
- Financial dashboards reconcile against ledger entries; analytics provides trends, not accounting totals.
- Analytics failures must never roll back or delay payment, Order, Ownership, AccessGrant, or refund commits.

## 23.4 Consumers

Events and aggregates may feed:

- Creator Analytics and Bid Insights;
- Creator and Buyer Dashboard summaries;
- Financial Dashboard trends reconciled to Wallet/Ledger;
- Admin marketplace health and operations;
- future recommendation/ranking features.

Personalization and recommendations remain derived, consent-aware, and subordinate to visibility, blocks, safety, availability, and fairness rules.

## 23.5 Failure, privacy, and security

- **Duplicate client events:** dedupe using event ID/session-target-time policy; tolerate at-least-once delivery.
- **Malformed or unknown schema:** quarantine/reject with bounded diagnostics; retain schema version and do not block the client’s primary action.
- **Out-of-order event:** use server occurrence time and source sequence/version; rebuild aggregates when necessary.
- **Attribution unavailable:** mark unknown rather than fabricating a source.
- **Analytics destination outage:** persist/queue or drop only noncritical interaction signals according to documented retention policy; transactional outbox events are retried.
- Collect only necessary data; never ingest passwords, payment credentials, raw message bodies, file contents/names, identity documents, or unnecessary precise device/location data.
- Apply access controls, retention limits, aggregation/pseudonymization, consent/privacy rules, and separation from security/audit logs.

---

# 24. Admin & Moderation

## 24.1 Responsibilities and data ownership

Admin & Moderation owns:

- staff authorization scopes and case assignment;
- `Report`, `ModerationAction`, `UserRestriction`, and `ContentRestriction`;
- staff access/audit records;
- review, appeal, and operational case references;
- safe commands into the owning domain modules.

It can act across Users, Posts, Products, Services, Projects, Contests, Orders, Payments, Disputes, files, messages, and Badges. It does not create parallel copies of their state or replace the standalone Dispute System.

## 24.2 Conceptual operations

- `SearchAdminSubject(entityType, scopedQuery)`
- `GetModerationCase(caseId, staffContext)`
- `CreateReport(target, category, evidenceReferences)`
- `ApplyContentRestriction(target, restriction, reason, expiry)`
- `ApplyUserRestriction(userId, restriction, reason, expiry)`
- `RemoveRestriction(restrictionId, reason)`
- `RequestDomainAction(caseId, domainCommand, reason)`
- `RecordStaffAccess(caseId, resource, purpose)`
- `EscalateToDisputeSystem(orderId, claimReference)`
- `RecordAppeal(relatedActionId, appeal)`

Financial or Order outcomes use the Payment/Wallet or Order command API; staff never directly edit their tables or patch a status string.

## 24.3 Moderation targets and consequences

Reports may target:

- a user/profile;
- Post or Media;
- Product/Service/Project/Contest;
- Proposal/Entry where policy permits;
- Message/Conversation;
- Order or transaction concern;
- Review or Badge.

Actions may:

- hide or remove a public projection while preserving source/audit history;
- quarantine Media or block access;
- suspend a listing or user capability;
- restrict new orders, messages, proposals, or withdrawals under policy;
- preserve transaction/delivery evidence;
- refer an Order issue to the Dispute System;
- start a refund/hold/access-restriction command through the responsible domain.

Actions use explicit scope, reason, start/end time, evidence/case reference, affected entities, actor, and appeal/review status. A user restriction does not delete Users, Orders, financial records, messages, or ownership history.

## 24.4 Sensitive operations and authorization

- Separate staff roles and capabilities for content moderation, support, financial review, dispute adjudication, and system administration.
- Apply least privilege, case-based access, explicit purpose, and step-up authentication for high-risk operations.
- Restrict viewing of private messages/files and identity/financial evidence to assigned cases; every sensitive read is audited.
- High-risk actions—manual refund, payout release/hold override, account recovery override, badge override, access to protected files, ownership reversal, or permanent content removal—require a reason and appropriate approval/dual control as platform policy defines.
- Admin access is not an implicit ability to perform any domain action.
- Keep internal notes, risk signals, evidence, and staff decisions private from users except what policy/appeal rules require to disclose.

## 24.5 Events, failures, and auditability

Events: `ReportCreated`, `ContentRestricted`, `UserRestricted`, `RestrictionExpired`, `CaseAssigned`, `StaffResourceAccessed`, `DomainActionRequested`, `AppealSubmitted`, `CaseEscalated`.

- **Unauthorized staff request:** deny, record security audit, and alert where appropriate.
- **Domain command rejected:** do not force a status change; preserve the case and return the current state/reason.
- **Partial moderation action:** write restriction and outbox event transactionally where possible; retry projections and CDN/search removal.
- **Admin tool outage:** do not create an unlogged workaround; queue only a safely retryable case operation.
- **Mistaken action:** use an explicit reversal/restoration action with linked audit history, never delete the original action.

Audit entries are append-only, timestamped, attributable to staff/service identities, and protected from routine staff edits. Logs must avoid storing secrets and unnecessary personal data.

---

## Cross-Module Event and Reliability Summary

The MVP uses PostgreSQL transactions and a transactional outbox for changes that must be durably published. Domain handlers own transitions; projections and external channels consume committed events.

```text
Command
→ domain validation and authorization
→ authoritative PostgreSQL change
→ timeline/audit record + outbox event in same commit
→ idempotent worker
→ provider, notification, search, analytics, badge, or CDN effect
→ result/reconciliation state
```

Global requirements:

- Payment, ledger, Order, exclusive Ownership, refund, withdrawal, and protected access are server-authoritative.
- Use idempotency keys and uniqueness constraints for retriable state changes; a timeout is an unknown result, not proof of failure.
- Keep operational source records separate from caches, search, feed, and analytics projections.
- External effects use verified references, bounded retries, reconciliation, and explicit compensation—not silent rollback of committed facts.
- Preserve immutable commercial terms, ledger history, ownership transfers, Delivery versions, material timeline events, and staff actions.
- Any pending state must explain what is unresolved and prevent an unsafe duplicate action.

---

## Handoff Summary for Part 3

Part 3 should finish Prompt #37 by defining:

1. Shared API/command/query conventions, response and error contracts, pagination, and versioning.
2. Cross-cutting authentication/authorization enforcement, rate limits, abuse controls, secrets handling, and data privacy.
3. Observability: structured logs, metrics, traces, transaction reconciliation alerts, and operational dashboards.
4. Deployment and migration practices for the modular monolith, workers, object storage, and external providers.
5. Testing strategy for state machines, idempotency, concurrency, payment callbacks, ownership races, protected files, and recovery.
6. MVP/V2/scale evolution, service extraction gates, and operational runbooks.

Part 3 must preserve the module ownership, authoritative data boundaries, event/outbox semantics, and failure-recovery rules established in Parts 1 and 2.
