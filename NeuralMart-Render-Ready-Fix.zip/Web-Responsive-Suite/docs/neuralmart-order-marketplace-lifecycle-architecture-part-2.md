# NeuralMart — Order & Marketplace Lifecycle Architecture
## Part 2 of 5: Transaction Workflows and Marketplace Availability

**Document version:** 1.0  
**Depends on:** `docs/neuralmart-order-marketplace-lifecycle-architecture-part-1.md`  
**Scope:** Type-specific transaction workflows for products, exclusive projects, services, chat orders, paid file deliveries, and availability

---

## 0. Continuity Rules from Part 1

Part 2 extends these decisions without changing them:

1. NeuralMart uses one universal Order aggregate with type-specific extensions.
2. Payment, fulfillment, ownership, revision, refund, dispute, and payout are separate status dimensions.
3. The server is the source of truth for price, availability, ownership, payment, and access.
4. Every order preserves an immutable snapshot of the purchased terms.
5. Chat is a commerce surface, not the financial system of record.
6. Exclusive ownership is reserved atomically and permanently recorded.
7. Status transitions are auditable and safe to retry.
8. Buyer and seller views reference the same order and transaction state.

---

## 1. Digital Product Order

### 1.1 Product transaction definition

A Digital Product Order is a purchase of an existing, versioned digital product under a defined license.

Typical products:

- AI reels
- Thumbnail packs
- Graphics
- Video assets
- Templates
- Prompt packs
- Source files
- Creative bundles

This flow is self-serve. A seller does not normally need to accept the order after payment.

### 1.2 Canonical flow

```text
Product
→ Buy
→ Confirm license and price
→ Payment
→ Order created
→ Entitlement created
→ File access granted
→ Download or open
→ Completion
→ Verified review
```

### 1.3 Selection and checkout

The buyer reviews:

- Product title
- Creator
- Product version
- Included files
- Compatibility
- Price and currency
- License/usage terms
- Update policy
- Refund terms

The final CTA must describe the outcome:

```text
Buy and download
```

or:

```text
Buy and unlock
```

The server recalculates the price and confirms that:

- the product is purchasable;
- the product is not archived or policy-blocked;
- the selected license is valid;
- the requested version is available;
- the buyer is eligible;
- the buyer is not purchasing their own product where prohibited;
- the payment attempt has not already completed.

### 1.4 Instant delivery

After confirmed payment:

```text
Payment confirmed
→ Product order created or activated
→ Product entitlement created
→ Secure access grant created
→ Order marked Delivered
→ Buyer can download
```

Instant delivery does not mean that the file is publicly exposed. It means the buyer can access it without creator acceptance or a manual fulfillment step.

The creator receives a system event:

```text
Product sold
```

The buyer receives:

- order number;
- receipt;
- product access;
- license summary;
- update eligibility;
- support/refund route.

### 1.5 File access

Original product files:

- remain in private storage;
- are never served from a public listing URL;
- require an active entitlement;
- use short-lived authorized access links;
- may be downloaded again from Purchases/Orders;
- record access/download events.

The product page changes from:

```text
Buy now
```

to:

```text
Owned · Download
```

### 1.6 Download permissions

Download permission requires:

1. Authenticated buyer identity.
2. Matching active entitlement.
3. Valid order/payment state.
4. License not revoked.
5. Asset included in the purchased version.
6. No access block from refund, fraud, or policy action.

Creator access:

- The creator can access their own source/delivery files through Creator Management.
- Creator access is not granted through the buyer entitlement.
- A creator cannot use the public buyer download endpoint as their asset-management tool.

Admin/support access:

- Limited to authorized support or moderation workflows.
- Audited.
- Not exposed as a normal buyer download.

### 1.7 Purchase history

The buyer can find the order in:

- Orders;
- Menu → Purchases;
- Buyer Dashboard → Purchased Products;
- Product detail;
- Chat, if the product was purchased through chat.

Purchase history shows:

- Product title and creator
- Purchased version
- License
- Purchase date
- Order number
- Download/access state
- Updates
- Refund/dispute state
- Receipt

### 1.8 License and usage information

The purchased license is snapshotted into the order and entitlement.

It includes, where applicable:

- Personal or commercial use
- Number of seats/users
- Client-work permission
- Modification permission
- Source-file rights
- Attribution requirements
- Resale/redistribution restrictions
- AI training/model-input restrictions
- Exclusive/non-exclusive status

The creator can change the license for future buyers, but cannot rewrite the buyer's purchased license.

### 1.9 Completion

For an ordinary instant product:

```text
Paid
→ Delivered
→ Completed
```

Completion may occur immediately after:

- entitlement creation;
- access grant;
- receipt generation;
- successful delivery event.

The buyer may still request support or a refund after completion. Completion does not erase post-completion refund or dispute overlays.

### 1.10 Refund handling

Refund rules are shown before payment.

Possible reasons:

- Duplicate charge
- File unavailable or corrupted
- Product materially not as described
- License mismatch
- Unauthorized content concern
- Creator/platform failure
- Buyer change of mind, where policy permits

On approved refund:

```text
Order refund recorded
→ Entitlement marked refunded
→ Future access links invalidated
→ License access revoked where policy permits
→ Seller pending earnings reduced or reversed
→ Audit event and receipt update created
```

Files already downloaded cannot be retrieved. A refund does not delete the historical purchase record.

### 1.11 Seller earnings

Product earnings follow the universal ledger:

```text
Buyer debit
→ Platform fee
→ Seller pending earnings
→ Seller eligible/released earnings
```

For low-risk digital products, seller earnings may become eligible shortly after payment. A short reserve may apply for new sellers, high-risk purchases, unusual download activity, refunds, or disputes.

### 1.12 Verified purchase

A product review is verified only when:

- payment was confirmed;
- the order was not fully reversed;
- the buyer received an entitlement or access;
- the reviewer is the actual buyer;
- the order is not a test/admin transaction.

The review displays:

```text
Verified purchase
```

if the review remains tied to a valid completed order.

### 1.13 Post-payment access

Access remains available through the purchased entitlement according to:

- product update policy;
- purchased license;
- refund/revocation state;
- platform safety/policy rules.

When a new eligible product version is released:

```text
Version 1.2 available
```

The buyer can access it without creating a new order when the original update policy includes it.

---

## 2. Exclusive Creator Project Purchase

### 2.1 Transaction definition

An Exclusive Project Purchase transfers the defined ownership/license rights for a pre-made creator project to one buyer under the Sell Once model.

Once successfully purchased:

```text
Project becomes Sold
→ Buy Now is disabled
→ Duplicate purchases are prevented
→ Ownership is permanently recorded
→ Profile shows Sold/Locked
```

### 2.2 Canonical flow

```text
Available Project
→ Buy Now
→ Availability validation
→ Payment authorization
→ Atomic ownership assignment
→ Project becomes Sold/Locked
→ Payment capture/confirmation
→ Order and ownership receipt
→ Delivery/access
→ Completion
```

### 2.3 Availability validation

Before payment authorization, validate:

- project is published and eligible;
- project is not Draft, Paused, Archived, Expired, or Sold;
- project has not already been reserved by a completed transaction;
- project owner is permitted to sell it;
- buyer is not the creator;
- price and license terms are current;
- required source/delivery files are ready;
- buyer has not already purchased it.

A temporary internal checkout reservation may exist during payment processing. It is not a permanent public marketplace state.

### 2.4 Payment validation

Validate:

- buyer session;
- payment method or wallet balance;
- current price;
- currency;
- taxes/fees;
- idempotency key;
- fraud/risk checks;
- no duplicate successful payment attempt.

The client must not submit the final amount as authoritative.

### 2.5 Exact point of unavailability

The project becomes unavailable to all other buyers at the commit point where these operations succeed together:

```text
Ownership record inserted
+
Project availability changed to Sold/Locked
```

That atomic commit is the exact point at which the project becomes permanently unavailable for a second purchase.

Payment authorization alone does not make the project permanently sold.

A public buyer-facing success state must not be shown until the ownership assignment and Sold/Locked update are durable.

### 2.6 Atomic ownership assignment

The backend transaction must:

1. Lock the project availability record.
2. Re-read its current state.
3. Confirm that it is still available.
4. Confirm no ownership record exists.
5. Create the order snapshot.
6. Create the unique ownership record.
7. Mark the project Sold/Locked.
8. Record the creator sale event.
9. Record the buyer entitlement/ownership.
10. Commit.

The data model must enforce one successful exclusive ownership record per project, not merely rely on an application-level availability check.

### 2.7 Sold status and Buy Now lock

After the ownership commit:

- project availability is `Sold`;
- content status includes `Sold · Locked`;
- Buy Now is removed or disabled;
- checkout endpoints reject new purchases;
- discovery deprioritizes it from available listings;
- the buyer sees `Owned · Open project`;
- the creator sees `Sold · View order`;
- the public profile retains the project as historical proof.

The Sold/Locked badge should explain:

```text
This project has been purchased and is no longer available.
```

### 2.8 Duplicate purchase prevention

Prevent duplicates at multiple layers:

- unique active ownership constraint;
- row-level availability lock;
- idempotent payment attempt;
- buyer entitlement lookup;
- server-side Sold-state validation;
- checkout expiration;
- duplicate payment detection.

UI state is informative only. A direct API request against a Sold project must fail.

### 2.9 Ownership records

The buyer ownership record includes:

- Buyer
- Seller
- Project
- Order
- Purchased version
- Rights/license
- Ownership transfer timestamp
- Access status
- Refund/dispute state
- Source/delivery access

The creator sale record includes:

- Project
- Buyer
- Order
- Gross price
- Platform fee
- Seller earnings
- Sold timestamp
- Ownership state

### 2.10 Failure recovery

#### Payment fails before ownership assignment

```text
Payment failed
→ No ownership record
→ Project remains Available
→ No seller earnings
→ No buyer access
```

The buyer can retry with a new or same idempotent attempt.

#### Payment succeeds but order creation fails

The payment confirmation handler retries order creation using the same idempotency key.

The system must not:

- create a second charge;
- show a second order;
- unlock files without an order;
- mark the project sold without a durable ownership record.

If order creation cannot be recovered:

```text
Payment held/confirmed
→ Reconciliation queue
→ Order and ownership repair
or
→ Compensating void/refund
```

The buyer receives:

```text
Payment received. We are confirming ownership securely.
```

#### Ownership assignment fails

If the unique ownership constraint or transaction validation fails:

- rollback the order/ownership transaction;
- do not mark the project sold;
- void the payment authorization or issue an automatic refund;
- notify the buyer that the project was no longer available;
- preserve the failure audit event.

If another buyer won the race, the losing buyer never receives ownership.

#### Transaction times out

Do not assume failure from a client timeout.

```text
Client timeout
→ Query payment/order status by idempotency key
→ Retry server confirmation safely
→ Reconcile ownership and payment
```

The buyer sees one of:

- Purchase confirmed
- Payment still processing
- Project unavailable and payment reversed

Never ask the buyer to pay again until the original attempt is resolved.

### 2.11 Refund implications

Because Sell Once promises permanent exclusivity:

- a refund does not automatically relist the project;
- the original ownership event remains in historical records;
- the buyer's access/license may be revoked;
- the creator's earnings may be reversed;
- re-listing requires an explicit authorized reversal process;
- a second buyer cannot purchase through ordinary marketplace controls.

---

## 3. Service Order

### 3.1 Transaction definition

A Service Order purchases a defined service package or approved scoped service from a creator.

It creates a fulfillment relationship rather than an instant asset entitlement.

### 3.2 Canonical flow

```text
Service
→ Choose package
→ Add add-ons, if any
→ Provide requirements
→ Confirm scope and license
→ Payment
→ Order created
→ Creator acceptance or automatic start
→ Requirements complete
→ Work in progress
→ Delivery
→ Revision or approval
→ Completion
→ Review and payout release
```

### 3.3 Service requirements

The service defines required inputs before or immediately after payment:

- Brief or desired outcome
- Text/copy
- Brand assets
- Dimensions
- Examples/references
- Required format
- Access/permissions
- Language
- Audience
- Deadline constraints

Each requirement has a state:

```text
Not requested
→ Requested
→ Submitted
→ Accepted
→ Needs clarification
```

The delivery clock starts when the required information is accepted, not merely when the buyer clicks Buy.

### 3.4 Estimated delivery time

The order records:

- Package delivery duration
- Business/calendar day convention
- Creator timezone
- Estimated delivery date
- Requirement-completion timestamp
- Current due date
- Approved extension, if any

The buyer sees:

```text
Estimated delivery: April 18
Starts after all required information is accepted
```

Extensions require a visible reason and buyer acknowledgement where the policy requires it.

### 3.5 Creator acceptance

Acceptance behavior depends on the service:

#### Automatic start

Use when:

- package is clearly defined;
- creator availability is current;
- requirements are complete;
- service is accepting orders.

#### Creator acceptance

Use when:

- service is capacity-limited;
- custom requirements need review;
- the creator can reject incompatible work;
- the package requires a start-date confirmation.

Seller rejection after payment leads to:

```text
Cancelled
→ Refund or payment release
```

### 3.6 Milestones

Milestones are optional and should be used when:

- the project is too large for one delivery;
- payment is divided by measurable stages;
- buyer approval is needed between stages;
- the service explicitly offers milestone work.

Each milestone has:

- scope;
- amount;
- due date;
- deliverables;
- acceptance rule;
- revision allowance;
- payment/payout state.

Milestone completion does not necessarily complete the parent order.

### 3.7 Work and processing

The creator can update:

- In Progress
- Waiting for buyer information
- Paused with reason
- At risk of missing deadline
- Ready for delivery

The buyer sees meaningful status changes, not internal task noise.

### 3.8 Delivery

Delivery is submitted through the order workspace and may include:

- Files
- Links
- Preview
- Delivery note
- Version number
- Included deliverables checklist
- Usage/license reminder

The delivery event is recorded against the order, not only in a chat message.

### 3.9 Revisions

The buyer can request an included revision when:

- the request changes an agreed deliverable;
- the request is within package scope;
- the revision allowance remains;
- the request is within the review/revision window.

Revision flow:

```text
Delivered
→ Revision Requested
→ In Progress
→ Delivered
```

New deliverables, changed goals, or extra formats become:

- an add-on;
- a new custom offer;
- or a new project.

### 3.10 Buyer approval

The buyer can:

- Approve delivery
- Request revision
- Report incomplete/mismatched delivery
- Open dispute

Approval records:

- buyer identity;
- timestamp;
- delivery version;
- remaining revision count;
- payout eligibility transition.

### 3.11 Automatic completion

If the buyer does not respond after delivery:

1. Send reminder.
2. Show review deadline.
3. Send final notice.
4. Auto-complete after the disclosed review window if no dispute or revision request exists.

Auto-completion must not:

- erase a previously submitted dispute;
- mark an incomplete delivery as approved when the buyer has raised a valid issue;
- remove evidence;
- silently change the purchased scope.

### 3.12 Cancellation and refund

Cancellation policy depends on the stage:

| Stage | Typical outcome |
|---|---|
| Before requirements | Cancel/refund under policy |
| Requirements submitted, work not started | Review creator costs and refund policy |
| In progress | Partial refund or dispute review |
| Delivered | Revision, dispute, or policy-based refund |
| Completed | Post-completion refund/dispute policy |

Seller rejection is not treated as buyer fault.

### 3.13 Review and seller earnings

A verified service review is available after:

- buyer approval;
- auto-completion;
- or dispute resolution that closes as fulfilled.

Seller earnings are:

```text
Payment confirmed
→ Pending/held earnings
→ Completion or review-window eligibility
→ Released earnings
```

Disputes and refunds can delay, reduce, or reverse release.

---

## 4. Custom Chat Order

### 4.1 Transaction definition

A Custom Chat Order begins as an ordinary conversation and becomes a paid commercial relationship only through a structured offer.

Plain-text messages are not sufficient to create an order.

### 4.2 Canonical flow

```text
Chat
→ Structured Offer
→ Buyer Accepts
→ Payment
→ Order Created
→ Work
→ Delivery
→ Revision or Approval
→ Completion
```

### 4.3 Custom offer card

The offer card contains:

- Offer title
- Creator/seller
- Buyer
- Scope
- Deliverables
- Price
- Currency
- Deadline
- Start conditions
- Revision count
- Usage/license terms
- Attached files or references
- Milestones, if any
- Expiration date
- Refund/cancellation terms
- Linked product/service/project, if any

### 4.4 Buyer acceptance

The buyer sees:

```text
Accept offer
Pay and start order
```

Before acceptance, the buyer can:

- Ask a question
- Request a change
- Decline
- Let the offer expire

Acceptance freezes the commercial snapshot. Material changes create a new offer version rather than editing the accepted offer.

### 4.5 Payment CTA

Use an explicit CTA:

```text
Accept and pay $450
```

The checkout confirms:

- exact scope;
- delivery date;
- revisions;
- license;
- files;
- refund terms;
- seller;
- payment source.

### 4.6 Order linking

After payment:

- create a Custom Chat Order;
- link it to the conversation;
- link it to the accepted offer;
- show a pinned order context header;
- preserve all pre-order discussion;
- emit an order-created system message.

The chat remains useful:

#### Before order

- discovery;
- questions;
- reference exchange;
- scope negotiation.

#### During order

- requirements;
- progress updates;
- previews;
- delivery;
- revisions;
- payment/milestone actions.

#### After order

- support;
- approved file access;
- repeat order;
- related service/product offer;
- review prompt;

### 4.7 Offer expiration

When an offer expires:

- it cannot be accepted;
- its price and scope cannot be used for a new order;
- attached private files remain protected;
- the creator can duplicate it into a new offer;
- the buyer can request a refreshed offer.

An accepted offer does not expire merely because work takes longer; the order's deadline and extension policy apply instead.

### 4.8 Attached files

Before payment:

- references may be viewable according to sender permissions;
- paid deliverables remain locked;
- previews use the paywalled delivery rules;
- original source files remain private.

After payment:

- files included in the order become available according to entitlement;
- delivery versions remain auditable;
- access can be revoked or restricted after approved refund/dispute resolution.

### 4.9 Completion

Use the same service/project completion rules when work is involved:

- buyer approval;
- automatic completion after the review window;
- dispute resolution;
- payout release.

For an instant custom file delivery, the order may complete after:

- payment;
- access grant;
- delivery event;
- disclosed review window.

---

## 5. Paid File Delivery Order

### 5.1 Transaction definition

A Paid File Delivery Order sells one or more protected files through a chat or order context.

It may be:

- a standalone custom asset;
- a project milestone;
- a service delivery;
- a product unlock;
- an add-on;
- a final source-file handoff.

### 5.2 Canonical flow

```text
Creator prepares file
→ Safe preview generated or selected
→ Locked delivery card sent
→ Buyer reviews price/license/scope
→ Payment
→ Order created or updated
→ Entitlement/access grant created
→ File unlocks
→ Download/access history recorded
→ Completion/review
```

### 5.3 Preview

Preview may be:

- watermarked;
- reduced resolution;
- shortened;
- sample pages/frames;
- partial bundle;
- file tree;
- no preview other than metadata.

Preview assets are separate from original delivery assets.

### 5.4 File unlock

Before payment:

```text
Locked
```

After confirmed payment:

```text
Paid
→ Unlocking
→ Available
```

The buyer receives short-lived authorized access only after:

- payment is confirmed;
- order exists;
- entitlement is active;
- delivery item is included;
- no refund/dispute block applies.

### 5.5 Download permissions and history

Each access request records:

- buyer;
- delivery item;
- order;
- timestamp;
- access type;
- download/open result;
- version;
- revocation state.

The buyer can reopen purchased files from Orders/Purchases. The original delivery URL is never the permanent access method.

### 5.6 Ownership and license

The order snapshots:

- file version;
- license;
- commercial/personal use;
- seats;
- client work;
- source-file rights;
- redistribution limits;
- exclusive/non-exclusive state.

File access and legal ownership are separate:

```text
Access grant = technical ability to retrieve
License/ownership = permitted use of the asset
```

### 5.7 Refund consequences

If payment is refunded:

- order refund state is recorded;
- future access links are invalidated where policy allows;
- entitlement/license may be revoked;
- seller pending earnings are reversed;
- chat system event records the change;
- downloaded copies cannot be technically retrieved.

During a dispute, access remains governed by the documented dispute policy. Support may preserve access temporarily or revoke it for fraud/safety reasons.

### 5.8 Seller earnings

```text
Payment confirmed
→ Seller pending earnings
→ Delivery/review/dispute gate
→ Released earnings
```

For a low-risk instant file, release may be fast. For custom work or high-risk transactions, retain a hold until completion or review-window expiry.

---

## 6. Marketplace Availability Framework

### 6.1 Shared availability states

Use a simple public availability framework:

```text
Draft
Available
Paused
Unavailable
Sold
Archived
Expired
```

These are listing/marketplace states. They are separate from order status.

For example:

```text
Product availability: Available
Order status: Completed
```

or:

```text
Project availability: Sold
Order status: Delivered
```

### 6.2 State meanings

| Availability | Meaning | Public discovery | Can new purchase start? |
|---|---|---:|---:|
| Draft | Not ready for public marketplace | No | No |
| Available | Eligible for discovery and transaction | Yes | Yes |
| Paused | Temporarily hidden or not accepting new orders | Usually no | No |
| Unavailable | Temporarily cannot fulfill or access | Optional label | No |
| Sold | Exclusive ownership transferred | Historical only | No |
| Archived | Removed from active catalog | No, except history | No |
| Expired | Time-bound listing/offer/deadline ended | Usually no | No |

### 6.3 Digital products

Allowed states:

```text
Draft → Available
Available ↔ Paused
Available ↔ Unavailable
Available → Archived
Available → Expired, if time-bound
```

Products can return to Available when:

- a creator unpauses them;
- a file issue is fixed;
- moderation clears them;
- a time-bound listing is renewed;
- an archived product is deliberately republished.

Non-exclusive products do not become Sold merely because one buyer purchases them.

Exclusive products follow:

```text
Available → Sold
```

and do not return to Available through ordinary creator actions.

### 6.4 Exclusive projects

Allowed before purchase:

```text
Draft → Available
Available ↔ Paused
Available ↔ Unavailable
Available → Archived
Available → Expired, if time-bound
```

After successful ownership transfer:

```text
Available → Sold
```

Sold is terminal for ordinary marketplace availability.

An authorized ownership reversal may change the historical ownership/access state, but must not silently relist the project. Re-listing is a deliberate platform-controlled action with an audit reason.

### 6.5 Services

Services use:

```text
Draft → Available
Available ↔ Paused
Available ↔ Unavailable
Available → Archived
Available → Expired, if offer/package is time-bound
```

Services do not normally use Sold. They can remain Available while active orders exist, subject to capacity.

An `Out of capacity` presentation maps to `Unavailable`, while existing orders continue.

A service can return to Available when:

- the creator reopens orders;
- capacity is restored;
- required updates are completed;
- a temporary pause ends.

### 6.6 Custom orders

Custom orders are not normally marketplace listings.

The structured offer has:

```text
Draft
→ Sent
→ Accepted
→ Expired
or
→ Declined
```

The order itself uses the universal lifecycle after payment.

A declined/expired offer can be replaced by a new offer. The old accepted offer cannot return to an editable Available state.

### 6.7 Contests

Contests need more specific operational states, but their public availability can map to the shared framework:

| Contest lifecycle | Availability mapping |
|---|---|
| Draft/Funding/Moderation | Draft or Unavailable |
| Open | Available |
| Closed/Judging | Unavailable |
| Winner Selected/Payout Processing | Unavailable |
| Completed | Archived/history |
| Cancelled | Archived or Unavailable |
| Disputed | Unavailable |

An Open contest can close permanently at its deadline. Reopening is allowed only if the published rules and platform policy permit it, with a new schedule and clear notice.

The funded prize is not a normal product inventory item. Its availability is governed by contest state and funding.

### 6.8 Project opportunities

Project opportunities use:

```text
Draft → Available
Available ↔ Paused
Available → Expired
Available → Archived
```

They become unavailable when:

- the proposal deadline passes;
- the buyer pauses intake;
- the project is cancelled;
- a contract is accepted and the opportunity closes;
- the buyer selects a creator and no longer wants competing proposals.

An expired opportunity can return to Available only if:

- no proposal/contract has been accepted;
- the buyer explicitly extends or republishes it;
- the new deadline is visible;
- the scope has not been misrepresented.

### 6.9 Internal reservation versus public availability

Payment and checkout may require an internal transient reservation:

```text
Available
→ Checkout reservation
→ Available if payment fails/expires
or
→ Sold/Unavailable after success
```

This is not a replacement for the public framework. It prevents races during a short transaction window.

Reservations must:

- expire automatically;
- be owned by a payment attempt;
- not transfer ownership;
- not create seller earnings;
- be released after failure/timeout;
- be reconciled after payment callbacks.

---

## 7. Cross-Workflow Reviews and Verification

### Verified purchase review eligibility

Eligible:

- Completed digital product order
- Completed exclusive project purchase
- Completed service order
- Completed custom chat order
- Completed paid file delivery
- Completed contest prize relationship where reviews are supported

Not eligible:

- Failed payment
- Cancelled before fulfillment
- Fully refunded order, unless policy explicitly allows a historical review
- Test/admin order
- Unverified message-only interaction

### Review timing

Review prompts appear after:

- access is granted for products/files;
- delivery is approved or auto-completed for services/projects;
- contest prize/order is completed.

Reviews remain connected to the order even if the listing is later archived.

---

## 8. Cross-Workflow Earnings Rules

All transaction types use the same seller earnings concepts:

```text
Gross buyer payment
→ Fees
→ Pending seller earnings
→ Eligible/released seller earnings
→ Withdrawal
```

Release timing varies by risk and fulfillment:

| Transaction | Typical release gate |
|---|---|
| Digital product | Payment/access plus short risk hold |
| Exclusive project | Payment and ownership commit |
| Service | Completion or review-window expiry |
| Custom chat | Delivery/approval or review-window expiry |
| Contest prize | Winner and rights/payout gates |
| Paid file delivery | Payment/access; longer hold for custom work |

Refunds, disputes, and chargebacks can reduce or reverse pending/released earnings according to policy.

---

## 9. Cross-Workflow Failure Principles

Every workflow must follow these rules:

1. A payment attempt can be retried without duplicate order creation.
2. A client timeout does not imply transaction failure.
3. An order can be reconciled from payment and audit references.
4. No file access is granted without entitlement.
5. No ownership transfers without a durable ownership record.
6. No seller earnings are created from an unconfirmed payment.
7. Availability is enforced by backend constraints and transactions.
8. Refunds do not delete order history.
9. Disputes preserve evidence and state transitions.
10. Active orders retain their purchased terms after listing edits.

## Final rule

Each NeuralMart commerce surface can have a different user experience, but every successful transaction must end with the same guarantees: a durable order, an immutable commercial snapshot, verified payment, type-correct fulfillment, auditable access or ownership, and a clear path to completion, review, refund, or dispute.
