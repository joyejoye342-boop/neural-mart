# NeuralMart — Complete Settings System

**Document version:** 1.0  
**Scope:** Account, profile, security, privacy, notifications, money, content, locale, linked accounts, and legal settings.  
**Entry point:** Menu / Control Center → Settings

---

## 0. Settings Philosophy

NeuralMart settings should help a user answer one question quickly:

> **“What do I want to change, and where is the safest place to change it?”**

Settings are not a second dashboard and should not expose every internal platform option. The system uses:

1. **A short settings landing page** with eight clear categories.
2. **Focused subpages** with related controls grouped by user intent.
3. **Searchable destinations and controls** for users who know what they need.
4. **Role-aware visibility** so Buyers are not shown creator payout controls and Creators are not shown irrelevant buyer settings.
5. **Explicit confirmation for security, payment, visibility, and destructive changes.**

The structure is inspired by familiar social-app settings, but adapted for a marketplace where identity, public reputation, private data, money, and business capability all need separate trust boundaries.

---

## 1. Settings Entry and Route Tree

The canonical entry is:

```text
Menu / Control Center
  → Settings
  → /settings
```

### Recommended route tree

```text
/settings
├── /account
│   ├── /identity
│   ├── /email
│   ├── /phone
│   ├── /role
│   └── /danger-zone
├── /profile
│   ├── /public-profile
│   ├── /portfolio
│   ├── /creator
│   └── /visibility
├── /security
│   ├── /password
│   ├── /sessions
│   ├── /two-step
│   └── /recovery
├── /privacy
│   ├── /profile-visibility
│   ├── /messaging
│   ├── /activity
│   └── /blocking
├── /notifications
│   ├── /in-app
│   ├── /email
│   ├── /push
│   └── /quiet-hours
├── /payments
│   ├── /wallet
│   ├── /methods
│   ├── /payouts
│   ├── /payment-sharing
│   └── /history
├── /content
│   ├── /feed
│   ├── /recommendations
│   ├── /media-autoplay
│   └── /saved
├── /preferences
│   ├── /language
│   ├── /currency
│   ├── /appearance
│   └── /accessibility
├── /linked-accounts
│   ├── /social
│   ├── /portfolio
│   └── /payment
└── /legal
    ├── /terms
    ├── /privacy
    ├── /payments
    ├── /creator-rules
    ├── /contest-rules
    └── /licensing
```

Routes can be implemented incrementally, but this hierarchy should remain stable so links, search results, and help articles do not need to change as settings mature.

---

## 2. Settings Landing Page

### 2.1 First-screen layout

```text
┌────────────────────────────────────────────┐
│ Settings                                   │
│ Manage your account, work, and preferences  │
├────────────────────────────────────────────┤
│ [⌕ Search settings                     ]   │
├────────────────────────────────────────────┤
│ ACCOUNT                                    │
│ Account & identity                    ›    │
│ Profile & portfolio                   ›    │
│ Security                              ›    │
├────────────────────────────────────────────┤
│ EXPERIENCE                                │
│ Privacy & visibility                   ›   │
│ Notifications                         ›   │
│ Content preferences                   ›   │
│ Language, currency & appearance       ›   │
├────────────────────────────────────────────┤
│ MONEY                                     │
│ Payment & payout settings              ›  │
├────────────────────────────────────────────┤
│ CONNECTIONS                               │
│ Linked accounts                         ›  │
├────────────────────────────────────────────┤
│ TRUST & LEGAL                             │
│ Policies and agreements                 ›  │
└────────────────────────────────────────────┘
```

### 2.2 Landing page rules

- Use one list of categories, not a grid of fifteen tiles.
- Show a short helper line only when it adds decision value.
- Show action-needed indicators, such as `Payout method missing` or `Security review recommended`, without exposing sensitive values.
- Do not show individual toggles on the landing page except a truly universal preference such as `Dark mode`.
- Keep Sign out outside Settings at the bottom of Menu.
- Keep account deletion inside `Account & identity → Danger zone`, never beside ordinary settings.

### 2.3 Category ordering

The order is based on frequency and risk:

1. Account and identity
2. Profile and portfolio
3. Security
4. Privacy and visibility
5. Notifications
6. Content preferences
7. Language, currency, and appearance
8. Payment and payout
9. Linked accounts
10. Policies and agreements

Money is important, but it gets its own section after the everyday experience controls so the page does not feel like a banking app.

---

## 3. Account Settings

### Purpose

Manage the private account identity used for authentication, recovery, role capabilities, and account lifecycle.

### Pages and subpages

```text
Account & identity
├── Personal account information
├── Email address
├── Phone number
├── Role and capabilities
└── Danger zone
```

### Important controls

#### Personal account information

- Display name
- Legal name, if required for payments or verification
- Date of birth, only when legally required
- Account ID/help reference, read-only
- Account creation date, read-only

#### Email and phone

- Change email
- Verify email
- Add/change phone
- Verify phone
- Recovery contact

Changing email or phone requires current-session verification and confirmation through the new channel.

#### Role and capabilities

For Buyer:

- `Become a Creator`
- Explain what Creator capability unlocks
- Start creator onboarding

For Creator/Both:

- Creator profile status
- Accepting work toggle
- Pause Creator activity
- Creator onboarding completion

For Both:

- Show `Buying` and `Selling` capabilities as status, not as separate accounts.
- Offer a preference for the default dashboard context.
- Never silently change the stored role from a settings toggle.

#### Danger zone

- Deactivate account
- Request account export
- Permanently delete account

Destructive actions require a dedicated page, current-password or recent-auth confirmation, an explanation of retained transaction records, and a final typed confirmation for permanent deletion.

### Roles

All roles need account identity, email, security recovery, and danger-zone controls. Role/capability settings vary:

- Buyer: creator upgrade
- Creator: creator activity/presence
- Both: pause creator capability and default context
- Admin: staff account controls handled separately from marketplace settings

---

## 4. Profile Settings

### Purpose

Control the public identity that buyers, creators, clients, and followers see.

### Pages and subpages

```text
Profile & portfolio
├── Public profile
├── Portfolio
├── Creator profile
└── Profile visibility
```

### Important controls

#### Public profile

- Display name
- Avatar
- Cover image
- Bio
- Location, optional and approximate
- Pronouns, optional
- Public contact preference
- Profile URL/handle, when supported

#### Portfolio

- Featured work order
- Hide/show individual posts
- Featured product
- Featured service
- Portfolio introduction
- Public sold-work history

Sold exclusive projects remain visible in a Creator's portfolio with a `Sold · Locked` badge. Profile settings may control whether sold work appears in the portfolio, but the default should keep it visible because it provides credibility and sales history.

#### Creator profile

Creator/Both-only:

- Primary category
- Skills
- Experience level
- Services offered
- Accepting work status
- Typical response time
- Portfolio links
- Public availability

#### Profile visibility

- Public profile on/off
- Show creator listings
- Show follower/following lists
- Show completed work count
- Show ratings/reviews
- Allow profile indexing by search engines, when public profiles are launched

### Roles

- Buyer: basic profile and privacy controls; public creator profile is not enabled by default.
- Creator: full public profile, portfolio, skills, and listing controls.
- Both: all profile controls.
- Admin: staff profile is separate from public marketplace identity.

### Simplification

Profile editing uses a preview-first layout:

```text
[Public profile preview]
[Edit identity]
[Edit portfolio]
[Edit Creator details]
```

Do not make users navigate through settings to understand what is public. Every public control should include `Preview as others see it`.

---

## 5. Password and Security

### Purpose

Protect login access, sessions, payment actions, and high-risk account changes.

### Pages and subpages

```text
Security
├── Password
├── Active sessions
├── Two-step verification
└── Recovery and verification
```

### Important controls

#### Password

- Change password
- Show password strength
- Require current password
- Sign out other sessions after change
- Link to Forgot Password recovery

Never reveal whether an entered password is correct before submitting the form. Use generic recovery messaging to avoid account enumeration.

#### Active sessions

Show:

- Device/browser
- Approximate location
- Last active time
- Current-session label
- Revoke individual session
- Sign out all other sessions

Do not show raw session IDs.

#### Two-step verification

Future-ready controls:

- Enable/disable 2FA
- Authenticator app
- Recovery codes
- Trusted devices
- Require verification for payout changes

If 2FA is not available yet, the page should say `Coming soon` only if the product has a documented roadmap; otherwise omit the dead control.

#### Recovery and verification

- Verified email status
- Verified phone status
- Identity verification status when payments require it
- Recovery codes
- Account recovery contact

### High-risk action policy

Require recent authentication for:

- Changing email
- Changing phone
- Changing password
- Adding/removing payout methods
- Changing payment methods
- Withdrawing funds
- Disabling security controls
- Deleting the account

### Roles

All roles require password and session controls. Creators/Both have additional payout-protection requirements. Admin accounts require stronger staff security policies and should not use marketplace financial settings as a substitute for staff access controls.

---

## 6. Privacy Settings

### Purpose

Let users control who can discover, contact, follow, and view activity associated with their account.

### Pages and subpages

```text
Privacy & visibility
├── Profile visibility
├── Messaging and contact
├── Activity visibility
└── Blocking and restricted users
```

### Important controls

#### Profile visibility

- Public / authenticated users only / private
- Allow profile discovery in Explore
- Show profile in search results
- Show public portfolio
- Show sold work in portfolio
- Show follower/following lists

Creator profiles should remain public by default because discoverability is part of the marketplace value, but creators can pause or hide their storefront without deleting historical records.

#### Messaging and contact

- Who can message me: anyone / followed users / buyers with an active project / nobody
- Allow payment requests in chat
- Allow creator contact from profile
- Message request filtering

#### Activity visibility

- Show online/active status
- Show liked or saved activity
- Show recent work activity
- Show purchase history publicly: always off by default
- Show contest participation: off by default unless explicitly made public

#### Blocking and restricted users

- Block user
- Unblock user
- Restricted accounts list
- Report a user

Blocking should prevent messaging, following, profile interaction, and feed recommendations as appropriate.

### Roles

All roles need privacy settings. Creators/Both need additional controls for storefront, listings, portfolio, availability, and follower visibility. Buyers need controls for project identity, company information, and public brief visibility.

### Simplification

Use plain-language questions instead of policy terminology:

```text
Who can message you?
Who can find your profile?
What can people see about your work?
```

Each setting should include a one-line impact explanation and a link to the relevant policy only when needed.

---

## 7. Notification Settings

### Purpose

Give users control over attention without allowing them to accidentally disable critical financial, security, or work events.

### Pages and subpages

```text
Notifications
├── In-app notifications
├── Email notifications
├── Push notifications
└── Quiet hours
```

### Notification categories

| Category | Examples | Can fully disable? |
|---|---|---:|
| Security | New login, password change, suspicious activity | No |
| Payments | Purchase, payout, failed payment, withdrawal | No for transactional events |
| Work | New proposal, order, delivery, project update | Yes |
| Contests | New entry, judging, winner, deadline | Yes |
| Social | Likes, comments, follows, mentions | Yes |
| Recommendations | Suggested creator, product, or project | Yes |
| Platform | Product updates, announcements | Yes |

### Important controls

Each category has channels:

```text
In-app   [on/off]
Email    [on/off]
Push     [on/off]
```

Critical transactional notifications remain enabled in at least one secure channel. Users may reduce noise, but should not lose payment receipts, security alerts, withdrawal outcomes, or contest-winner notices.

Additional controls:

- Batch social notifications
- Send daily digest
- Email frequency
- Push preview content
- Quiet hours
- Notification sound/vibration
- Mark all as read

### Roles

- Buyer: project, order, payment, support, social settings
- Creator: proposal, order, payout, contest, social, availability settings
- Both: all applicable categories
- Admin: separate staff notification policy

### Simplification

Default to three presets:

```text
Recommended
Quiet
Custom
```

`Recommended` protects critical notifications and enables useful work alerts. `Quiet` reduces social and recommendation noise while keeping account, payment, and security alerts. `Custom` exposes the full matrix.

---

## 8. Payment, Wallet, and Payout Settings

### Purpose

Separate funding the wallet, spending, receiving earnings, and withdrawing funds so users understand what each method does.

### Pages and subpages

```text
Payment & payout settings
├── Wallet preferences
├── Payment methods
├── Payout methods
├── Payment sharing
├── Payout schedule
└── Transaction history
```

### Wallet preferences

- Default funding source
- Low-balance reminders
- Spending confirmation preference
- Wallet activity link
- Financial dashboard link

Never show full account numbers or sensitive payment data in settings lists.

### Payment methods

Buyer/Creator/Both:

- Add payment method
- Set default payment method
- Remove payment method
- Verify payment method
- View supported payment types

Payment-method changes require recent authentication. Removing the only valid method should explain the impact on active purchases or payment requests.

### Payout methods

Creator/Both:

- Add payout method
- Set default payout destination
- Verify payout method
- Remove payout method
- View payout eligibility
- View payout holds or verification issues

Payout destinations should be masked, for example:

```text
Bank account ···· 4821
Verified · Default
```

### Payment sharing

- Create secure payment request
- Default payment-request expiry
- Payment-request notifications
- View active shared requests
- Revoke an unpaid request

Payment sharing must never expose raw banking details. Requests are generated and tracked by NeuralMart.

### Payout schedule

Creator/Both:

- Instant/standard payout option, if supported
- Minimum payout threshold
- Payout notification preference
- Tax/identity verification status

Do not present unsupported payout options. A missing integration should be represented as a clear setup state, not a fake control.

### Transaction history

Transaction history is a dedicated searchable page, not a long table embedded in Settings:

- Filter by purchase, earning, payout, refund, fee, contest prize
- Filter by date
- Search by order or project
- Open receipt/detail
- Export statement, when supported

### Roles

| Tool | Buyer | Creator | Both | Admin |
|---|---|---|---|---|
| Payment methods | Yes | Yes | Yes | Staff policy |
| Add funds | Yes | Yes | Yes | No |
| Payout methods | No | Yes | Yes | No |
| Withdraw settings | No | Yes | Yes | No |
| Payment sharing | Yes | Yes | Yes | Support-only |
| Transaction history | Yes | Yes | Yes | Audit system |

---

## 9. Content Preferences

### Purpose

Tune what appears in feeds without turning the Home page into a filter-heavy control panel.

### Pages and subpages

```text
Content preferences
├── Feed preferences
├── Recommendations
├── Media autoplay
└── Saved content
```

### Important controls

#### Feed preferences

- Show more/less of a category
- Mute a topic
- Prefer followed creators
- Default feed context for Both users
- Reset feed preferences

The Showcase Feed remains universal by default. Preferences tune ranking; they do not remove access to major feature hubs.

#### Recommendations

- Creator recommendations on/off
- Product recommendations on/off
- Service recommendations on/off
- Opportunity recommendations on/off
- Personalized ranking on/off, when supported

Critical work opportunities and direct account notifications should not be hidden by recommendation settings.

#### Media autoplay

- Autoplay on Wi-Fi
- Autoplay on mobile data
- Never autoplay
- Autoplay muted

Default: muted autoplay on Wi-Fi only, subject to browser/device support.

#### Saved content

Saved content is a destination rather than a set of complicated controls:

- Saved posts
- Saved products
- Saved services
- Saved projects
- Saved contests

Offer `Clear saved items` only on the dedicated Saved page, with confirmation.

### Roles

All roles use feed and media preferences. Creators/Both receive opportunity recommendations; Buyers receive creator/product/service recommendations.

---

## 10. Language, Currency, Appearance, and Accessibility

### Purpose

Control how NeuralMart looks and formats information without changing account identity or payment ledger history.

### Pages and subpages

```text
Language, currency & appearance
├── Language
├── Currency and number format
├── Theme and appearance
└── Accessibility
```

### Important controls

#### Language

- Interface language
- Content translation preference, when supported
- Date format
- First day of week

#### Currency

- Display currency
- Number format
- Price conversion disclaimer

Important rule: changing display currency must not change the wallet ledger or transaction settlement currency. Receipts should show the original transaction currency and the display conversion used.

#### Appearance

- Dark / light / system theme
- Reduce motion
- Compact / comfortable density
- High contrast, when supported

NeuralMart remains dark-mode-first, but users can choose system or light mode.

#### Accessibility

- Text size
- Reduced motion
- Contrast preference
- Screen-reader-friendly controls
- Captions for video
- Keyboard navigation help

### Roles

All roles use these settings. Admin may have separate staff accessibility preferences.

---

## 11. Linked Account Management

### Purpose

Manage external identities and services that help users sign in, publish portfolio links, or complete payments.

### Pages and subpages

```text
Linked accounts
├── Sign-in accounts
├── Portfolio and social links
└── Payment connections
```

### Sign-in accounts

Future-ready:

- Google/Apple or other approved sign-in providers
- Add provider
- Remove provider
- Set primary sign-in method

Never allow a user to remove their only usable sign-in/recovery method without first adding another verified method.

### Portfolio and social links

Creator/Both:

- Behance
- Dribbble
- GitHub
- Personal website
- YouTube/Vimeo
- Instagram or other approved portfolio networks

Controls:

- Connect/disconnect
- Display on public profile
- Refresh link preview
- Set link title

These links are public profile data, not authentication connections, and should be visually separated from sign-in accounts.

### Payment connections

Creator/Both:

- Connected payout provider
- Verification state
- Reauthorize
- Disconnect

Buyers may have funding connections instead of payout connections. Each connection should display its purpose:

```text
Used for funding purchases
Used for receiving payouts
Used for sign-in
```

### Roles

- Buyer: sign-in and approved profile/funding connections
- Creator: sign-in, portfolio, payout connections
- Both: all applicable connection types
- Admin: staff identity connections are separate from marketplace connections

---

## 12. Legal and Policy Access

### Purpose

Make agreements and operating rules easy to find without mixing them with everyday preferences.

### Pages and subpages

```text
Policies and agreements
├── Terms of Service
├── Privacy Policy
├── Payments, fees, and refunds
├── Creator and marketplace rules
├── Contest rules
├── Ownership and licensing
├── Community guidelines
└── Agreement history
```

### Important controls and content

- Read policy documents
- View last-updated date
- View effective date
- View agreement version accepted
- Download/print policy
- View required action when a policy changes

Some policies are read-only. When a new version requires acceptance, show a clearly labeled required-review state:

```text
Action needed
Review updated Payments and Refunds policy
[Review and accept]
```

Do not hide required legal acceptance in a generic notification.

### Roles

All roles need Terms, Privacy, Payments, Community, and Ownership/Licensing access. Creator/Both users additionally need Creator Rules and Contest Rules surfaced prominently. Admin policies are managed through the staff system.

---

## 13. Search Design

### Search scope

Settings search indexes:

- Category pages
- Subpages
- Individual setting labels
- Common synonyms
- Role-specific destinations
- Action-needed states

It does not search marketplace content. Marketplace search remains in the global app-bar search.

### Search examples

| Query | Result |
|---|---|
| `email` | Change email |
| `login` | Password, Active sessions |
| `2fa` | Two-step verification |
| `who can message me` | Messaging and contact |
| `hide profile` | Profile visibility |
| `quiet` | Quiet hours, Notification presets |
| `card` | Payment methods |
| `payout` | Payout methods, Payout schedule |
| `withdraw` | Withdrawal settings |
| `language` | Language |
| `money format` | Currency and number format |
| `portfolio link` | Linked portfolio accounts |
| `terms` | Terms of Service |
| `ownership` | Ownership and licensing |

### Search result anatomy

```text
[icon] Payout methods
      Add or manage where your earnings are sent
      Money · Creator/Both
```

### Search behavior

- Show recent searches when empty.
- Start after two characters.
- Rank exact title matches before aliases.
- Respect role-based visibility.
- Show action-needed destinations first when relevant.
- Support keyboard navigation on desktop.
- Support escape-to-close and back navigation on mobile.
- Navigate directly to the focused subpage.

### Searchable setting registry

Use a small structured registry rather than searching arbitrary UI text:

```ts
type SettingDestination = {
  id: string;
  title: string;
  aliases: string[];
  description: string;
  category: string;
  href: string;
  roles: string[];
  risk: 'low' | 'medium' | 'high';
  requiresRecentAuth?: boolean;
};
```

The registry powers search, help links, role filtering, analytics, and deep links consistently.

---

## 14. Simplicity and Safety Rules

### Progressive disclosure

Show the common setting first. Place advanced controls behind a focused subpage or expandable `More options` area.

Examples:

- Notification landing page shows presets; custom channel matrix is one tap deeper.
- Payment landing page shows methods and payout status; verification details open separately.
- Privacy landing page shows three plain-language questions; advanced blocking controls are deeper.

### One decision per page

Each subpage should have one dominant purpose:

- Change password
- Manage sessions
- Manage payout methods
- Choose notification preset
- Control profile visibility

Do not combine password, 2FA, active sessions, and recovery into one long form.

### Save behavior

- Toggles save immediately and show a brief confirmation.
- Text forms use explicit `Save changes`.
- Unsaved changes trigger a leave confirmation.
- Failed saves preserve user input and show an inline error near the affected control.
- Optimistic UI is not appropriate for security, payment, payout, or destructive changes.

### Risk levels

| Risk | Examples | Confirmation |
|---|---|---|
| Low | Theme, autoplay, density | Immediate save |
| Medium | Profile visibility, notifications, linked portfolio | Save + visible confirmation |
| High | Email, password, payment method, payout method | Recent authentication |
| Destructive | Account deletion, disconnecting only sign-in method | Multi-step confirmation |

### Status communication

Use short explicit labels:

- `Verified`
- `Needs attention`
- `Pending`
- `Not connected`
- `Paused`
- `Default`

Never communicate security, payout, or visibility status through color alone.

---

## 15. Role-Based Visibility Strategy

The settings shell is the same for every user. Role changes which destinations are visible and which helper states are shown.

| Category | Buyer | Creator | Both | Admin |
|---|---|---|---|---|
| Account | Full | Full | Full | Staff version |
| Profile | Basic public profile | Full creator profile | Full creator + buyer | Staff profile |
| Security | Full | Full | Full | Stronger staff policy |
| Privacy | Full | Full creator visibility | Full | Staff privacy |
| Notifications | Buyer events | Creator events | Both | Admin events |
| Content | Creator discovery | Showcase + opportunities | Both | No consumer personalization |
| Payments | Funding and spending | Funding, earnings, payout | Both | Separate finance audit |
| Linked accounts | Sign-in/funding/profile | Sign-in/portfolio/payout | All applicable | Staff identity |
| Legal | Core policies | Core + creator/contest rules | All | Staff policies |

### Avoiding role confusion

- Use capability labels such as `Creator tools` rather than separate Buyer Settings and Creator Settings.
- For Both users, group creator-only controls under `Creator profile` and `Payouts`, not under a global “switch mode” menu.
- If a Buyer selects a Creator-only setting from search, show `Become a Creator` with a clear explanation rather than a dead end.
- Never hide a setting after a user has configured it without explaining where it moved.

---

## 16. Mobile and Desktop Layout

### Mobile

- `/settings` is a full page with a sticky title/back bar.
- Categories are full-width rows with 52–60px height.
- Subpages use one-column forms.
- Destructive actions use bottom-sheet confirmation.
- Search can expand into a full-screen settings search.
- Keep labels readable; do not use icon-only settings rows.

### Desktop

Use a two-pane layout for deeper settings:

```text
┌──────────────────────┬────────────────────────────────┐
│ Settings categories  │ Selected category              │
│                      │                                │
│ Account              │ Profile & portfolio            │
│ Profile              │ [controls and explanation]     │
│ Security             │                                │
│ Privacy              │                                │
│ Notifications        │                                │
│ Payments             │                                │
└──────────────────────┴────────────────────────────────┘
```

The selected category is reflected in the URL so pages can be deep-linked and refreshed safely.

---

## 17. Loading, Error, and Recovery States

- Load the settings index independently from wallet/payment summaries.
- A wallet or payout API failure must not block profile, privacy, or appearance settings.
- Show skeleton rows that match the final category structure.
- Preserve form values on failed saves.
- Provide `Retry` for failed account status requests.
- If a setting is unavailable because of role, show an explanation and an eligible next step.
- If a session expires during a high-risk change, discard no entered form data until the user has been informed.

---

## 18. Analytics and Audit Requirements

Track settings outcomes, not sensitive values:

- Settings category opened
- Search query category, not raw sensitive query text where avoidable
- Toggle changed
- Form save succeeded/failed
- Security challenge started/completed
- Payment/payout method added/removed
- Policy viewed/accepted
- Account export/deletion requested

Audit server-side:

- Password/email/phone changes
- Session revocations
- Payment and payout method changes
- Role/capability changes
- Privacy visibility changes
- Policy acceptance
- Account deletion requests

Never log passwords, payment credentials, recovery codes, raw account numbers, or authentication tokens.

---

## 19. Final Settings Blueprint

```text
SETTINGS

[Search settings]

ACCOUNT
  Account & identity
  Profile & portfolio
  Security

EXPERIENCE
  Privacy & visibility
  Notifications
  Content preferences
  Language, currency & appearance

MONEY
  Payment & payout settings

CONNECTIONS
  Linked accounts

TRUST & LEGAL
  Policies and agreements
```

### Final product rules

1. The Settings landing page contains categories, not dozens of toggles.
2. Every category has a focused subpage and one dominant purpose.
3. Search finds both pages and common setting names.
4. Financial controls are clearly split into payment, wallet, payout, and history.
5. Security-sensitive changes require recent authentication.
6. Public profile settings explain exactly what others can see.
7. Notification presets protect critical financial and security alerts.
8. Both users share one account and wallet; capability settings are additive.
9. Policies are easy to find and versioned, but do not clutter everyday settings.
10. Account deletion is isolated from sign out and ordinary preferences.

NeuralMart settings should feel calm, findable, and trustworthy: common changes are one or two taps away, advanced controls are searchable, and high-risk actions are deliberate rather than accidental.
