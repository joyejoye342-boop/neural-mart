# NeuralMart — Product & Service Discovery Architecture

**Document version:** 1.0  
**Scope:** Discovery of digital products, services, creators, and related Showcase content  
**Primary surfaces:** Global search · Products marketplace · Services marketplace · Showcase Feed · Public creator profiles

---

## 0. Discovery Goal

NeuralMart discovery should help a buyer move from inspiration to a confident action:

```text
See something useful
→ Understand the creator
→ Compare relevant products/services
→ Buy, book, message, or start a project
```

Product and service discovery must remain visual and fast. Search and marketplaces add decision support, while the Showcase Feed creates desire and context.

---

## 1. Category Structure

NeuralMart uses three layers:

```text
Intent
→ Primary category
→ Skills, formats, and constraints
```

### 1.1 Intent

The first discovery choice is often what the buyer wants to do:

- Find a creator
- Buy a digital product
- Book a service
- Browse inspiration
- Start a project

Search can infer intent from the query, but the user can always switch result tabs.

### 1.2 Primary categories

Use a compact top-level taxonomy:

1. **Design & Visual**
   - Branding
   - Logos
   - Graphics
   - Thumbnails
   - Illustration
   - UI/UX
   - Presentations

2. **Video & Motion**
   - Reels
   - Video editing
   - Motion graphics
   - Animation
   - Video assets
   - 3D

3. **Writing & Content**
   - Copywriting
   - Scripts
   - Social content
   - Technical writing
   - Editing
   - Translation

4. **Audio & Music**
   - Music
   - Sound design
   - Voiceover
   - Podcast assets
   - Audio editing

5. **Web & Product**
   - Websites
   - No-code
   - App/UI assets
   - Product design
   - Automation

6. **Marketing & Growth**
   - Social campaigns
   - Ads
   - SEO
   - Strategy
   - Launch assets

7. **AI & Automation**
   - Prompt packs
   - AI workflows
   - AI video
   - AI image systems
   - Agents and automations

8. **Business & Learning**
   - Templates
   - Presentations
   - Research
   - Courses
   - Coaching
   - Professional documents

### 1.3 Product and service facets

Categories are shared, but facets change by object type.

#### Product facets

- File format
- Application compatibility
- License
- Asset count
- Delivery type
- Editable/non-editable
- Version/update policy
- Price

#### Service facets

- Package starting price
- Delivery time
- Revision count
- Availability
- Experience/category
- Language/timezone
- Commercial usage
- Creator level
- Rating/review count

#### Shared facets

- Tags/skills
- Creator level
- Verified identity
- Rating
- Price
- Freshness
- Popularity
- Saved state

### 1.4 Taxonomy rules

- Each product/service has one primary category.
- Up to three secondary categories.
- Up to ten curated skill/format tags.
- Free-form tags are normalized into known search terms.
- Category names remain user-friendly; internal taxonomy can be richer.
- A product or service cannot appear in unrelated categories only to gain reach.

---

## 2. Search Behavior

### 2.1 Global search

The app-bar search searches:

- Creators
- Products
- Services
- Showcase posts
- Projects/opportunities when relevant

Search results use tabs:

```text
All · Creators · Products · Services · Showcase
```

Projects and contests have a separate Opportunities destination so the global search does not turn into a confusing procurement feed.

### 2.2 Search suggestions

After two characters, show:

- matching creators;
- product/service titles;
- category suggestions;
- skill/tag suggestions;
- recent searches;
- trending category suggestion.

Example:

```text
branding
Branding services
Brand identity products
Branding creators
```

### 2.3 Query understanding

Normalize:

- spelling and plurals;
- common synonyms;
- software names;
- file formats;
- intent words such as `buy`, `template`, `hire`, `service`, or `designer`.

Examples:

```text
“youtube cover” → Thumbnails
“editable pitch deck” → Templates + Presentations
“hire motion designer” → Services + Creators
“AI reel pack” → Products + Video & Motion + AI
```

### 2.4 Results structure

The All tab is visual and grouped:

```text
Top creators
Products
Services
Showcase work
```

Each group has a small preview row and `See all`.

Dedicated result pages use a filter-first layout:

```text
Search results
[query] [filters] [sort]

[visual card] [visual card] [visual card]
```

### 2.5 Search ranking

```text
Query/category fit
→ Availability or purchase readiness
→ Quality and verified trust
→ Visual/content relevance
→ Freshness
→ Conversion/engagement signal
→ Creator diversity
```

Do not rank only by sales or follower count. New, relevant creators should receive exploration opportunities.

### 2.6 Search states

#### No query

Show:

- recent searches;
- recommended categories;
- trending products/services;
- followed creators.

#### No results

Show:

- corrected query;
- nearby categories;
- related creators;
- `Post a project` action.

#### Search with strong intent

If the query indicates hiring:

```text
Looking to hire?
[Browse services] [Find creators] [Post a project]
```

Do not block ordinary browsing with an interstitial.

---

## 3. Recommendation Blocks

Recommendation blocks are clearly labeled editorial modules, not disguised organic posts.

### Buyer-facing blocks

#### Recommended for you

Based on:

- saves;
- viewed categories;
- opened products/services;
- previous purchases;
- followed creators.

#### Because you viewed...

Related products, services, and creators based on recent intent.

#### Match your project

Appears after a buyer posts or drafts a project:

```text
Creators and services that match your project
```

#### Complete your toolkit

Related products or services:

```text
You viewed a thumbnail pack
Try these video assets and reel templates
```

#### Trending in your category

Shows velocity and quality, not just lifetime volume.

#### Creators to explore

A small set of relevant creators with compact trust signals.

### Creator/general-audience blocks

- New work from followed creators
- Rising creators in your interests
- Related Showcase work
- Products used by creators in your category
- Services with current availability

### Recommendation placement

- After a natural content group, not before the first organic card.
- Maximum one recommendation block per 8–12 feed items.
- Two cards on mobile; three or four on desktop.
- Always labeled with a reason.
- Avoid repeating the same creator/product within a short session.

---

## 4. Feed Placement Strategy

### Showcase Feed

Products and services appear as commercial cards among creator work:

- Product Showcase Card
- Service Card
- Promotional Creator Post
- Case Study
- Reel/video with linked offer

The card has one commercial CTA and remains visually consistent with the shared card shell.

### Products marketplace

Products use a visual grid:

- cover image;
- price;
- type;
- file/license summary;
- creator;
- rating/sales;
- purchase state.

Sort and filters are stronger because the buyer has shopping intent.

### Services marketplace

Services use package-oriented cards:

- creator;
- service promise;
- starting price;
- delivery time;
- revisions;
- rating;
- availability;
- proof sample.

### Public profile

Profile visibility follows the established five-tab system:

```text
Overview · Showcase · Services · Products · Reviews
```

The Overview highlights one featured offer. Services and products appear in their dedicated tabs. Showcase posts create proof and discovery but do not replace the structured listings.

### Project context

When a buyer is creating a project:

- show matching creators;
- show related services;
- show relevant products;
- preserve the buyer's project draft;
- allow `Invite creator` or `Attach to project`.

Do not mix product/service recommendations into the creator-facing Opportunities Feed unless directly relevant to an opportunity.

---

## 5. Creator Profile Visibility Strategy

### Overview

Show:

- featured/pinned work;
- one featured service;
- one featured product;
- availability;
- compact trust evidence;
- current level and up to three badges.

### Showcase

Filters:

```text
All · Reels · Graphics · Thumbnails · Case studies
```

Posts can link to related products/services.

### Services

Show only active, purchasable/bookable services by default. Owners can see drafts and paused listings privately.

### Products

Show:

- active products;
- owned state for the current buyer;
- Sold · Locked for exclusive products;
- archived/withdrawn history only where useful.

### Search/profile rules

- Inactive listings do not appear in search.
- Paused services may show `Currently unavailable` only when the creator opts in.
- Sold exclusive products remain as historical proof but cannot be purchased.
- Empty commercial tabs are hidden from visitors and visible to owners for setup.

---

## 6. Trending and Recommended Logic

### Trending score

Use short-window velocity with quality safeguards:

```text
Recent qualified views
→ Saves and profile visits
→ Product/service clicks
→ Purchases/bookings
→ Repeat engagement
→ Rating/reliability
→ Freshness
```

Use decay so old products do not dominate forever.

### Quality safeguards

- Minimum exposure before declaring a trend.
- Deduplicate creator self-views.
- Exclude suspicious traffic.
- Separate paid promotion from organic trending.
- Penalize high refund/dispute signals where meaningful.
- Do not rank a listing highly if it is unavailable.
- Cap repeated impressions from one creator.

### New creator discovery

Reserve a controlled exploration share for:

- new creators with complete profiles;
- relevant new products/services;
- high-quality work with limited history.

This is not a random boost. It is an exploration slot constrained by category fit and policy eligibility.

### Explanation labels

Use plain-language reasons:

- `Popular in Branding`
- `Because you saved 3 templates`
- `New from a creator you follow`
- `Available this week`
- `Trending among UI/UX buyers`

---

## 7. Keeping Discovery Visual and Fast

### Visual rules

- Use strong cover media on products and services.
- Keep cards image-first with concise metadata.
- Use stable aspect ratios to prevent layout shifts.
- Use one primary CTA.
- Keep description previews to two or three lines.
- Use compact trust signals near the decision.
- Avoid dense marketplace tables in the feed.

### Performance rules

- Lazy-load below-the-fold media.
- Serve responsive thumbnails.
- Use poster images before video playback.
- Do not autoplay sound.
- Prefetch the next page of results only when network conditions allow.
- Cache category and creator metadata.
- Use skeleton cards that match final dimensions.
- Keep search suggestions lightweight.
- Preserve scroll position when returning from detail.

### Mobile

- Horizontal category chips.
- Bottom-sheet filters.
- Two-column product/service grids only in marketplace hubs.
- Single-column visual feed.
- Fixed, accessible CTA targets.
- No nested horizontal carousels inside cards unless the user explicitly opens a gallery.

## Final rule

Discovery should feel visual first and commercially clear second: show the work, make the creator credible, expose the relevant offer, and keep the path to buy, book, message, or start a project short.
