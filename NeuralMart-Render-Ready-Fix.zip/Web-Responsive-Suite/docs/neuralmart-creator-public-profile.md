# NeuralMart — Creator Public Profile Architecture

**Document version:** 1.0  
**Scope:** Public creator profile, portfolio, trust surface, marketplace storefront, and conversion paths.  
**Primary route:** `/creators/:id`

---

## 0. Product Definition

The creator profile is NeuralMart's most important trust-and-conversion page. It must work as both:

- a familiar social profile that users can browse, follow, and return to;
- a professional storefront where buyers can evaluate capability, reliability, services, products, and reputation.

The profile should answer within the first screen:

1. Who is this creator?
2. What do they make or offer?
3. Can I trust them?
4. What is the next action I can take?

The current profile foundation already includes cover image, avatar, bio, category, rating, followers, badges, skills, Showcase, and Products. This architecture extends it with Services, Reviews, Featured Work, availability, business proof, and better buyer CTAs.

Pure Buyer accounts should not render as empty creator storefronts. `/creators/:id` is for Creator/Both profiles; a Buyer-only identity should return a clear not-found or redirect state.

---

## 1. Profile Structure

```text
PUBLIC CREATOR PROFILE
│
├── Profile header
│   ├── Cover image
│   ├── Avatar and verification
│   ├── Name, category, location/links
│   ├── Availability and response signal
│   ├── Stats and credibility summary
│   └── Primary/secondary CTAs
│
├── Profile navigation
│   ├── Overview
│   ├── Showcase
│   ├── Services
│   ├── Products
│   └── Reviews
│
├── Overview tab
│   ├── Featured work
│   ├── About and specialties
│   ├── Featured service/product
│   ├── Credibility block
│   ├── Availability
│   └── Recent showcase
│
├── Showcase tab
│   ├── Pinned work
│   ├── Reels/video
│   ├── Graphics and thumbnails
│   ├── Case studies
│   └── Promotional posts
│
├── Services tab
│   ├── Service cards
│   ├── Packages
│   ├── Delivery expectations
│   └── Book/contact actions
│
├── Products tab
│   ├── Product cards
│   ├── Ownership state
│   └── Buy/view actions
│
└── Reviews tab
    ├── Rating summary
    ├── Rating distribution
    ├── Review filters
    └── Review list
```

### Profile navigation rules

- Use five tabs maximum.
- `Overview` is the default.
- Hide empty tabs rather than showing tabs with no content.
- Keep profile tabs stable between Creator-only and Both accounts.
- Do not create separate “Buyer profile” and “Creator profile” tabs for a Both user.

---

## 2. Profile Header

### Desktop layout

```text
┌──────────────────────────────────────────────────────────────┐
│                       COVER IMAGE                            │
│                                                              │
│  [Avatar]                                                    │
├──────────────────────────────────────────────────────────────┤
│  Maya Johnson                         [Follow] [Message]      │
│  Brand identity designer · Dhaka      [Hire / Book] [•••]    │
│  ✓ Verified creator  ·  Available  ·  Responds in < 4h       │
│                                                              │
│  4.9 ★ (42 reviews)  ·  28 completed orders  ·  1.2k follows │
│                                                              │
│  I help early-stage teams build clear, confident brands...   │
│  [Branding] [UI/UX] [Pitch decks]                            │
├──────────────────────────────────────────────────────────────┤
│  Overview   Showcase   Services   Products   Reviews          │
└──────────────────────────────────────────────────────────────┘
```

### Mobile layout

```text
┌───────────────────────────────┐
│          COVER IMAGE           │
│       [Avatar overlapping]     │
├───────────────────────────────┤
│ Maya Johnson          [•••]    │
│ Brand identity designer       │
│ ✓ Verified · Available        │
│                               │
│ 4.9 ★ 42 reviews · 28 jobs   │
│                               │
│ I help early-stage teams...   │
│                               │
│ [Follow] [Message] [Hire]     │
├───────────────────────────────┤
│ Overview Showcase Services... │
└───────────────────────────────┘
```

### Header content rules

- Cover image is optional; use a creator-specific gradient fallback.
- Avatar must remain visually dominant and overlap the cover.
- Name is the strongest text element.
- Category is plain-language, not an internal role label.
- Verification is earned and explained on tap.
- Availability is shown only when active and current.
- Do not show private earnings, wallet balance, buyer history, or purchase history.
- Location is optional and may be approximate.
- External portfolio links appear in the expanded About section, not as competing header buttons.

---

## 3. Identity and Credibility Blocks

### 3.1 Identity block

Shows:

- Display name
- Optional handle
- Primary category
- Short positioning statement
- Location or timezone, optional
- Public portfolio links
- Member-since date

### 3.2 Trust block

Show only verified, meaningful signals:

```text
4.9 ★
42 reviews
28 completed orders
Responds in under 4 hours
100% completion
```

Potential signals:

- Identity verified
- Payment/payout verified, when appropriate to expose
- Completed orders
- Completed projects
- Completion rate
- Response time
- Repeat buyer rate, once statistically meaningful
- Creator badges

Do not show an empty `5.0 rating` as if it were established reputation. Use `New creator` or `No reviews yet`.

### 3.3 Skills block

- 3–8 skills
- Category
- Specialty tags
- Tools/software only when useful to buyer decision-making

Keep skills in a compact wrap row. The full skill list belongs in the About expansion or Explore filters.

### 3.4 Availability block

```text
Available for work
Accepting 1–2 projects in April
Typical response under 4 hours
[Message about a project]
```

If unavailable:

```text
Not currently accepting new work
[Follow creator]
```

An unavailable creator can still sell active products unless the specific listing is paused.

---

## 4. Profile CTAs

### Viewer actions

| Viewer/context | Primary CTA | Secondary actions |
|---|---|---|
| Buyer viewing available service creator | `Hire` or `Book a service` | Message, Follow, Save |
| Buyer viewing product-focused creator | `View products` | Buy from product cards, Message, Follow |
| Buyer viewing freelancer | `Start a project` or `Message` | Follow, Save |
| Creator viewing another creator | `View services` | Follow, Message, Save |
| Both viewing another creator | Contextual Hire/Buy | Follow, Message, Save |
| Own profile | `Edit profile` | Manage listings, share profile |

### CTA priority

1. A specific transaction CTA when there is a clear offer: `Book`, `Buy`, or `Hire`.
2. `Message` for custom work or unclear scope.
3. `Follow` for social relationship.
4. `Save` as a quiet secondary action.

Never show five equal-weight filled buttons. Use one primary CTA, one outlined secondary CTA, and icon/ghost actions for Follow and Save.

### Sticky mobile CTA

On long profiles, a compact bottom action bar may appear after the user scrolls past the header:

```text
[Avatar + Name]              [Message] [Hire]
```

It should hide when the original header CTA is visible and reappear after the user scrolls into content.

---

## 5. Overview Tab

The Overview is a conversion-oriented summary, not a second full feed.

### Priority order

1. Featured work
2. Primary service/product offering
3. About and specialties
4. Credibility summary
5. Availability
6. Recent showcase
7. Reviews preview

### Recommended overview layout

```text
FEATURED WORK
[large pinned work] [small work] [small work]
[View all showcase →]

WHAT I DO
Short positioning statement
[skills and categories]

SERVICES
[Featured service card]
[View all services →]

CREDIBILITY
4.9 ★ · 42 reviews · 28 completed orders
Response time · Completion rate · Badges

PRODUCTS
[Product card] [Product card]
[View all products →]

REVIEWS
[Most helpful review]
[View all reviews →]
```

Do not show every service, product, post, badge, and review on Overview. The Overview's job is to help the buyer decide whether to continue.

---

## 6. Public Showcase Feed

### Purpose

Let the profile feel socially browseable while preserving professional context.

### Content types

- Graphic and thumbnail showcases
- Reels and video work
- Portfolio updates
- Case studies
- Product/service promotions
- Availability announcements

Buyer project requests and private client work should not appear in the creator's public showcase unless the creator explicitly publishes them as public case studies.

### Showcase card behavior

Use the shared feed-card system:

- author header is compact because the user is already on the creator's profile;
- content is image/video-first;
- social actions remain available;
- linked product/service CTA is visible;
- cards support pinned status;
- sold exclusive work can remain visible with a `Sold · Locked` label where appropriate.

### Showcase sorting

Default:

1. Pinned work
2. Featured work
3. Recent published content

Optional filters:

- All
- Images
- Reels
- Case studies
- Product/service promotions

Do not add a social `For You` algorithm inside an individual profile. The user is already viewing one creator's work; chronological and curated order is more understandable.

---

## 7. Featured and Pinned Work

### Creator controls

Creators can:

- pin up to three showcase posts;
- select one featured work item;
- reorder featured work;
- feature one service and one product on Overview;
- unpin without deleting;
- mark a work item as a case study;
- optionally add a client/project credit.

### Display rules

- Pinned work appears first in Showcase and in the Overview Featured Work block.
- A small `Pinned` label is enough; do not use a large announcement banner.
- Pinned work cannot duplicate the same item in the top three positions.
- If a pinned product is sold and exclusive, keep it visible with `Sold · Locked`; do not replace it automatically with a misleading Buy button.
- If a service or product is paused, show its status and offer another featured item if available.

### Featured work quality guidance

Creators should see optional guidance:

```text
Choose work that shows your strongest skill, a clear outcome,
and the kind of project you want next.
```

This guidance belongs in profile editing, not on the visitor's profile.

---

## 8. Services Tab

### Purpose

Make the creator's bookable work easy to compare and purchase.

### Service card content

- Service title
- Cover image
- Category
- Starting price
- Delivery estimate
- Rating/review count
- Availability state
- `View service` or `Book now`

### Visibility rules

- Active services appear first.
- Paused services remain visible to the owner but are hidden or clearly unavailable to visitors.
- Services with no reviews show `New` rather than an inflated trust signal.
- The creator may feature one service on Overview.
- Buyers can filter or sort services only inside the Services tab or Market hub, not through a dense header filter.

### Custom hiring path

If the creator has no active services but is accepting custom work, show:

```text
Open to custom projects
[Start a conversation]
```

This gives freelancer-heavy creators a conversion path without forcing them to invent a packaged service.

---

## 9. Products Tab

### Purpose

Show the creator's digital products as a storefront while keeping profile browsing simple.

### Product card content

- Cover
- Title
- Price
- Category
- Sales/review signal
- Ownership state
- `Buy now`, `View product`, `Owned`, or `Sold · Locked`

### Ownership and history

- Available exclusive products show `Available · Exclusive ownership`.
- Sold exclusive products stay in the creator's portfolio/storefront with `Sold · Locked`.
- Buyers never receive a purchase CTA for sold exclusive items.
- Public sales counts can be shown; buyer identities and private transaction details cannot.

### Empty state

```text
No products listed yet.
Explore this creator's services or showcase work.
```

Do not show a large empty marketplace grid if the creator is primarily service-based.

---

## 10. Reviews and Ratings

### Placement

Show a compact rating summary in the header and a fuller review preview on Overview. The complete review system gets its own `Reviews` tab.

### Header summary

```text
4.9 ★
42 reviews
```

Tapping it opens Reviews.

### Reviews tab

```text
4.9 ★ overall
42 verified reviews

[All] [Services] [Products] [Projects]

[review card]
Reviewer name · verified purchase/order
Rating · date
What they said
Service/product context
```

### Trust rules

- Label reviews as verified only when linked to a completed order/project.
- Show the purchased service/product context.
- Allow creators to respond publicly, but not edit reviews.
- Show review distribution only when enough reviews exist to be meaningful.
- Do not display buyer private information.
- Add moderation/report actions to reviews.

### Freelancer credibility

Project completion, delivery reliability, proposal success, and response time may appear in the credibility block. They should not be inferred from a small number of orders.

---

## 11. Contest and Project Credibility

These are credibility signals, not primary profile tabs.

### Useful public signals

- Completed projects
- Contest wins
- Contest finalist badges
- Number of accepted proposals
- Public case studies
- Repeat client signal
- Relevant creator badges

### Placement

Use a compact `Track record` block in Overview:

```text
TRACK RECORD
28 projects completed
3 contest wins
12 repeat clients
```

Only show signals that are verified and statistically meaningful. Do not reveal private project briefs, buyer names, proposal rates, or earnings without permission.

### Contest/project history

If the creator chooses to expose it, show a filtered `Achievements` strip within Overview or Showcase. Do not add separate top-level tabs for every activity type.

---

## 12. Profile Variants

The profile shell stays the same. The default content emphasis changes based on the creator's activity and configured capabilities.

### Creator-only account

Typical positioning: sells products, services, and creative work.

Header emphasis:

- Showcase work
- Services
- Products
- Creator badges
- Rating and sales

Overview order:

1. Featured work
2. Featured service/product
3. Credibility
4. Recent showcase

Primary CTA:

- `Book a service` when active service exists;
- otherwise `View products`;
- otherwise `Follow` plus `Message`.

### Freelancer-heavy account

Typical positioning: takes custom projects and proposals more than selling catalog products.

Header emphasis:

- Category and specialties
- Availability
- Response time
- Completion rate
- Completed project history

Overview order:

1. Availability
2. Featured case study
3. `Open to custom projects`
4. Track record
5. Services, if any
6. Reviews

Primary CTA:

- `Start a project` or `Message about a project`.

Do not force a freelancer-heavy creator to lead with a product catalog.

### Hybrid creator/freelancer account

Typical positioning: publishes work, sells packaged services/products, and accepts custom engagements.

Header emphasis:

- Creator identity and category
- Availability
- One featured service or custom-project CTA
- Trust summary

Overview order:

1. Featured work
2. Featured service
3. Custom project availability
4. Products
5. Track record and reviews

Primary CTA:

- `Hire` or `Book`, based on the strongest active offer.
- `Message` remains the secondary path for custom work.

Do not show a global Buyer/Creator mode switch on the public profile. The profile is one coherent professional identity.

---

## 13. Owner View vs Visitor View

### Visitor view

- Follow
- Message
- Hire/Book/Buy
- Save
- Share
- Report

### Owner view

- Edit profile
- Manage featured work
- Manage services/products
- View profile analytics
- Preview public profile
- Share profile

Owner-only metrics such as profile views, conversion rate, earnings, and proposal analytics belong behind the owner dashboard and should never leak into public profile layout.

---

## 14. Mobile and Desktop Behavior

### Mobile

- Cover height approximately 180–220px.
- Avatar overlaps cover by 48–64px.
- Header actions wrap into one primary row.
- Tabs are horizontally scrollable with five items maximum.
- Overview sections remain single-column.
- Services/products use one-column cards or a compact horizontal row.
- Showcase media uses stable aspect ratios and lazy loading.
- Sticky Message/Hire bar may appear after scrolling past the header.

### Desktop

- Cover expands to a wider 5xl content frame.
- Header can use a two-column layout: identity/credibility left, featured offer/actions right.
- Tabs remain visible below the header.
- Overview can use a main content column plus a narrower credibility/offering rail.
- Showcase remains a readable feed width; do not stretch social posts across the entire viewport.

---

## 15. Privacy, Safety, and Performance

- Public profile data must be explicitly marked public in profile settings.
- Never expose wallet balance, earnings, buyer purchase history, private messages, or private client information.
- Allow profile/report/block actions through the overflow menu.
- If a creator pauses Creator activity, hide active listings and availability while preserving historical work and reviews.
- Lazy-load Reviews, Products, Services, and long Showcase content below the fold.
- Reserve cover, avatar, and media dimensions to prevent layout shifts.
- A failed Services or Reviews request must not blank the entire profile.
- Unauthenticated public preview should be supported in a future public-profile phase; purchase, follow, and message actions can prompt login with a return URL.

---

## 16. Final Profile Blueprint

```text
CREATOR PROFILE

[Cover]
[Avatar] Maya Johnson                  [•••]
        Brand identity designer
        ✓ Verified · Available · Responds in < 4h
        4.9 ★ 42 reviews · 28 completed orders
        [Message] [Hire] [Follow]

Overview  Showcase  Services  Products  Reviews

FEATURED WORK
[Pinned hero] [Pinned work] [Pinned work]

WHAT I DO
Positioning statement · skills · specialties

FEATURED SERVICE
[Service card] [Book now]

TRACK RECORD
Completed work · contest wins · badges · response signal

RECENT SHOWCASE
[social work cards]

REVIEWS
[review preview] [View all reviews →]
```

## Final product rule

The public profile should feel like a creator's social home, but behave like a trusted professional storefront. Social content earns interest; featured work proves taste; services and products create conversion; reviews and track record reduce risk; the header makes the next action obvious.
