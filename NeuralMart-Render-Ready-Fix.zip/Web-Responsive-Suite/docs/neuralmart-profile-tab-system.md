# NeuralMart — Creator Profile Tab System

**Document version:** 1.0  
**Scope:** Public creator profile navigation, content grouping, tab behavior, and MVP boundaries.  
**Primary route:** `/creators/:id`

---

## 0. Decision Summary

The public creator profile should have **five maximum top-level tabs**:

```text
Overview · Showcase · Services · Products · Reviews
```

The proposed tabs `Reels`, `Thumbnails`, `Graphics`, `About`, `Badges`, `Contests Won`, and `Portfolio` should not become additional top-level tabs. They are either:

- filters within Showcase;
- sections within Overview;
- trust details inside Reviews or the credibility block;
- a dedicated dashboard concern rather than public profile navigation.

This keeps the profile socially browseable without creating a tab bar that reads like a file browser.

---

## 1. Final Recommended Tabs

### 1. Overview

The decision page. It gives buyers the strongest proof and clearest next action without requiring them to browse every section.

Contains:

- Featured/pinned work
- Short About section
- Primary services and products
- Availability
- Trust and credibility summary
- Badges preview
- Contest/project achievements preview
- Recent showcase preview
- Review preview

### 2. Showcase

The creator's public social/portfolio feed.

Contains:

- All published showcase posts
- Reels and videos
- Thumbnails
- Graphics
- Case studies
- Portfolio updates
- Product/service promotions
- Availability posts

Inside Showcase, use filters rather than tabs:

```text
All · Reels · Graphics · Thumbnails · Case studies
```

The filter row is optional and only appears when there are enough posts to make filtering useful.

### 3. Services

The creator's bookable work.

Contains:

- Active services
- Package cards
- Starting prices
- Delivery timelines
- Revision/package details
- Ratings and reviews per service
- Availability state

The tab should be hidden from visitors when the creator has no active services. Owners can still see it with an empty-state prompt to create a service.

### 4. Products

The creator's digital products and exclusive assets.

Contains:

- Available products
- Sold exclusive products
- Owned/purchased state for the current viewer
- Price
- Sales/review signals
- Product category

Sold exclusive projects stay visible with `Sold · Locked` so the creator retains a credible public history.

### 5. Reviews

The creator's verified marketplace reputation.

Contains:

- Overall rating
- Review count
- Rating distribution
- Verified review list
- Review filters by service/product/project
- Creator responses

If there are no reviews, the tab can remain available for a completed creator profile and show `No reviews yet`, but it should not display an empty 5-star score.

---

## 2. What Does Not Become a Top-Level Tab

| Proposed section | Final location | Reason |
|---|---|---|
| All / Feed | Showcase → `All` filter | “Showcase” explains the destination; `All` is a view state |
| Reels | Showcase filter | A media type, not a separate creator business area |
| Thumbnails | Showcase filter | A visual subtype |
| Graphics | Showcase filter | A visual subtype |
| Portfolio | Overview + Showcase | Portfolio is the whole public work system |
| About | Overview section | Identity context belongs before the work feed |
| Badges | Overview preview + trust detail | Badges support credibility; they should not split navigation |
| Contests won | Overview track record | An achievement signal, not a primary browsing destination |

### Optional future expansion

If a creator has a very large public body of work, the Showcase filter row can add:

```text
All · Reels · Graphics · Thumbnails · Case studies · Collections
```

`Collections` should be introduced before creating more tabs.

---

## 3. MVP Tab Scope

### Essential for MVP

1. **Overview**
2. **Showcase**
3. **Services**
4. **Products**
5. **Reviews**

This is the smallest complete profile for a marketplace creator:

- Overview explains who they are.
- Showcase proves creative ability.
- Services create a hiring path.
- Products create a purchase path.
- Reviews reduce marketplace risk.

### MVP content requirements

#### Overview

- Header identity
- Featured work
- Bio/About
- Skills
- Availability
- Trust summary
- Featured service/product

#### Showcase

- Images/graphics
- Thumbnails
- Text/case-study posts
- Pinned content
- Basic type filtering

#### Services

- Service title
- Description
- Starting price
- Delivery time
- Package link
- Book/contact CTA

#### Products

- Product image
- Title
- Description
- Price
- Ownership state
- Buy/view CTA

#### Reviews

- Rating summary
- Verified review list
- Review count
- No-review state

### Advanced later

- Collections
- Public project case studies
- Contest achievement history
- Advanced portfolio filters
- Skill-specific review filters
- Video/reel-only discovery mode
- Profile-specific recommendations

---

## 4. Content Ownership by Tab

### Overview content rules

Overview is curated, not exhaustive. It should show:

- maximum three featured work items;
- one featured service;
- one featured product;
- one or two credibility blocks;
- one review preview;
- four to six recent Showcase items.

Everything else links to the relevant tab.

### Showcase content rules

Showcase is chronological/curated creator content. It includes:

- visual work;
- reels;
- thumbnails;
- graphics;
- case studies;
- announcements;
- linked product/service promotion.

Do not place private client briefs, proposal history, buyer information, or unpublished work here.

### Services content rules

Services should be scannable and transactional:

- one clear value proposition per card;
- price and delivery visible;
- package details behind the detail page;
- reviews connected to the relevant service;
- unavailable state when paused.

### Products content rules

Products should be storefront-oriented:

- image-first card;
- price visible;
- product category;
- sales/review signal;
- available, owned, or sold state.

### Reviews content rules

Reviews are verified marketplace evidence, not social comments. Each review should show:

- reviewer identity or privacy-safe label;
- completed order/project relationship;
- rating;
- date;
- service/product context;
- creator response when available.

---

## 5. Tab Selection and Deep Links

Recommended URL structure:

```text
/creators/:id
/creators/:id/showcase
/creators/:id/services
/creators/:id/products
/creators/:id/reviews
```

Showcase filters can use query parameters:

```text
/creators/:id/showcase?type=reel
/creators/:id/showcase?type=graphic
/creators/:id/showcase?type=case-study
```

Deep links should open the correct tab and preserve the selected filter when navigating back.

### Default tab logic

- First visit: `Overview`
- Shared link to a post: `Showcase`
- Shared service link: `Services`
- Shared product link: `Products`
- Shared review link: `Reviews`
- Owner preview: last selected tab may be remembered locally

---

## 6. How to Avoid Tab Overload

1. Keep five maximum top-level tabs.
2. Use filters for media types.
3. Put About, Badges, and achievements into Overview.
4. Hide empty commercial tabs for visitors.
5. Do not create tabs for every creator activity type.
6. Use `View all` links inside Overview sections.
7. Keep Reviews separate because it has a distinct trust job.
8. Use collections before adding more tabs.
9. Never show Buyer-side settings or private dashboard sections on a public profile.
10. Keep tab labels short and familiar.

The navigation should answer “what can I browse or buy here?” rather than “which database tables exist for this creator?”

---

## 7. Mobile-First Behavior

### Mobile tab bar

```text
┌─────────────────────────────────────┐
│ Overview Showcase Services Products │
│ Reviews →                           │
└─────────────────────────────────────┘
```

- Horizontal scroll, never a wrapped two-line tab grid.
- Active tab uses primary text and a 2px underline.
- Tab bar can become sticky below the profile header.
- Minimum 44px tap height.
- Preserve scroll position per tab when practical.

### Showcase filters

Use a second horizontal chip row only inside Showcase:

```text
[All] [Reels] [Graphics] [Thumbnails] [Case studies]
```

Do not display both a dense tab row and a dense filter row at the same time above the profile header. The profile header should collapse before the tab bar becomes sticky.

### Services and Products

- Use one-column cards on narrow mobile screens.
- Use horizontal compact cards only in Overview previews.
- Keep the primary CTA full width.
- Do not turn the public profile into a marketplace grid with tiny cards.

### Reviews

- Rating summary remains at the top.
- Rating distribution can collapse behind `See breakdown`.
- Reviews load in pages/infinite scroll.
- Filter chips scroll horizontally.

### Empty tabs

For visitors:

- hide empty Services or Products tabs;
- keep Reviews if the creator is established or has a meaningful review state;
- keep Showcase even when it is empty because it is the core profile surface.

For owners:

- show empty tabs with useful setup actions such as `Add your first service`.

---

## 8. Role and Profile-Type Behavior

The tabs remain the same for Creator-only and Both users. The content emphasis changes:

| Profile type | Default emphasis | Primary tab CTA |
|---|---|---|
| Creator-only | Showcase + Services/Products | Book, Buy, or Follow |
| Freelancer-heavy | Overview + Showcase + Reviews | Start project / Message |
| Hybrid Creator/Freelancer | Overview + Services + Showcase | Hire / Book |
| Buyer-only | No creator profile | Redirect or not-found |

Both users do not receive separate “Buyer profile” and “Creator profile” tabs. Their public profile represents their Creator capability.

---

## Final Tab System

```text
Overview
  Featured work · About · credibility · achievements · featured offer

Showcase
  All · Reels · Graphics · Thumbnails · Case studies

Services
  Bookable work and packages

Products
  Digital products and ownership state

Reviews
  Verified marketplace reputation
```
