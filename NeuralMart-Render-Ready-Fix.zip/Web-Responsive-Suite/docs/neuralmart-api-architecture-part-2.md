# NeuralMart — API Architecture & Contract Design
## Part 2 of 3: Marketplace Transactions, Communication & Platform APIs

**Document version:** 1.0  
**Depends on:** NeuralMart architecture from Prompts #1–#37 and API Architecture Part 1  
**Continues:** `docs/neuralmart-api-architecture-part-1.md`  
**Continues in:** Part 3 — Search/Analytics completion, Events/Webhooks, Admin/Support, Security, and final API governance  
**Scope:** Sections 15–29  
**Implementation status:** API architecture and contract specification only; no production code

---

## 0. Continuity with Part 1

This Part extends the Part 1 contract; it does not establish a second API or a new source of truth.

- Canonical client routes remain under `/api/v1`; existing unversioned paths remain temporary compatibility adapters to the same implementation.
- Use Part 1's `data`/`meta` success envelope, Problem Details-style error envelope (including the additive broad `category` and stable specific `code`), opaque IDs, camelCase fields, `snake_case` enum values, UTC timestamps, minor-unit money, cursor pagination, `ETag`/`resourceVersion`, and `Idempotency-Key`.
- Named commands perform state transitions. Clients cannot `PATCH` a status to mark payment, delivery, ownership, completion, review, or badge state.
- Authenticate and authorize every request against the current resource, participant, policy, and state. Capability or active-context labels are never sufficient by themselves.
- Payment, Order, Wallet/Ledger, Ownership, Delivery/Access, Chat, Review, Badge, Notification, and Search retain the module ownership and source-of-truth boundaries established in Prompts #1–#37.
- Cross-domain endpoint shortcuts are facades over the owning domain command. They must not duplicate business rules or persist parallel state.
- All examples omit `meta.requestId` only where noted; actual responses always include the Part 1 success envelope.

### 0.1 Transaction and retry conventions for this Part

Use the Part 1 idempotency rules for checkout, order creation, offer acceptance, contest winner finalization, wallet deposits/withdrawals, refunds, file unlocks, and other money/ownership-changing commands. Retry a timed-out command with the same key or query the original resource; do not start a second transaction.

Use `If-Match` with the returned `ETag` or `resourceVersion` for mutable proposals, contests, entries, offers, and deliveries. A stale write returns `409 RESOURCE_VERSION_CONFLICT`.

When an operation changes multiple operational records in PostgreSQL, commit them in one transaction when they share the established consistency boundary. Append the timeline/audit record and transactional outbox event in that same commit. Provider, notification, indexing, and analytics work is asynchronous and retryable.

---

# 15. Proposal / Bid APIs

Proposals are creator-authored offers for a direct project or hiring request. They are not contest entries, product orders, or a public creator rank. Proposal acceptance/selection follows Part 1's `POST /api/v1/projects/{projectId}/selection`; it does not silently create a paid contract.

## 15.1 Submit a proposal

### `POST /api/v1/projects/{projectId}/proposals`

**Permission:** Authenticated Creator capability; project must be open, visible to this creator, and accept proposals. Invite-only projects require a valid invitation. The Buyer who owns the project cannot bid on it.

**Request**

```json
{
  "price": { "amountMinor": 120000, "currency": "USD" },
  "estimatedDeliveryDays": 7,
  "earliestStartAt": "2026-11-02T00:00:00Z",
  "pitch": "I would start by aligning the visual system with your launch audience.",
  "deliverables": [
    { "title": "Brand direction", "description": "One approved direction" },
    { "title": "Final export pack", "description": "Web and social formats" }
  ],
  "scopeAssumptions": ["Buyer supplies final copy before production."],
  "revisionRounds": 2,
  "portfolioReferences": [
    {
      "type": "post",
      "id": "post_opaque_id",
      "relevanceNote": "This project used a similar visual system."
    }
  ],
  "attachmentMediaIds": ["media_opaque_id"]
}
```

**Response:** `201 Created`; returns `proposalId`, `projectId`, `creatorId`, `status: "submitted"`, current `versionId`, immutable submitted terms, `submittedAt`, and the Part 1 response envelope.

**Validation:** Price must be positive and use the project's accepted currency; timeline/start date must be valid; pitch must meet the published length rules; referenced portfolio items must be visible to the Buyer; attachments must be uploaded, scanned, and authorized for proposal use. MVP allows one active proposal per creator/project. A proposal cannot be submitted to a Contest.

Errors include `401 AUTHENTICATION_REQUIRED`, `403 CREATOR_CAPABILITY_REQUIRED`, `403 INVITATION_REQUIRED`, `404 PROJECT_NOT_FOUND`, `409 PROJECT_CLOSED`, `409 ACTIVE_PROPOSAL_EXISTS`, `409 RESOURCE_VERSION_CONFLICT`, `422 PRICE_INVALID`, `422 TIMELINE_INVALID`, `422 PITCH_TOO_SHORT`, `422 PORTFOLIO_REFERENCE_UNAVAILABLE`, `422 ATTACHMENT_NOT_READY`, and `429 PROPOSAL_RATE_LIMITED`.

## 15.2 Retrieve and list proposals

- `GET /api/v1/projects/{projectId}/proposals` — project owner only; cursor-paginated buyer inbox. Supports `status`, `shortlisted`, and `sort=newest|price_asc|delivery_soonest|fit` where an explainable fit projection exists.
- `GET /api/v1/proposals/{proposalId}` — creator owner or project owner; returns the authorized current version and permitted history.
- `GET /api/v1/me/proposals?status=...` — current Creator's own proposal pipeline.

Responses use the standard envelope. Each list item includes a compact creator/proposal card, terms, `status`, `currentVersionId`, `submittedAt`, and actor-appropriate `actions`; private notes and internal ranking signals are never included in creator responses.

## 15.3 Edit or withdraw

### `PATCH /api/v1/proposals/{proposalId}`

**Permission:** Proposal creator only. Project must still allow proposal changes and no final selection may be committed.

The patch may update pitch, price, timeline, deliverables, scope assumptions, revision count, portfolio references, and attachments. It creates a new immutable proposal version and preserves the prior version. Send `If-Match`; response returns the new `versionId`, current terms, status, and `updatedAt`.

Errors include `403 NOT_PROPOSAL_OWNER`, `409 PROJECT_CLOSED`, `409 PROPOSAL_NOT_EDITABLE`, `409 RESOURCE_VERSION_CONFLICT`, and the relevant `422` field errors.

### `POST /api/v1/proposals/{proposalId}/withdraw`

**Permission:** Proposal creator only. Allowed while the Project is open and before final selection; a withdrawn Proposal is retained in history and cannot be confused with a rejection.

Optional request: `{ "reasonCode": "availability_changed" }`. Response returns `status: "withdrawn"` and `withdrawnAt`. Retried requests are idempotent. Errors: `404 PROPOSAL_NOT_FOUND`, `409 PROPOSAL_ALREADY_FINAL`, `409 PROJECT_CLOSED`.

## 15.4 Shortlist, reject, and compare

- `PUT /api/v1/projects/{projectId}/shortlist/{proposalId}` — project owner; idempotently adds a private shortlist relationship. Optional body: `{ "privateNote": "Strong sample fit" }`. Returns `shortlisted: true`; the private note is visible only to authorized project collaborators.
- `DELETE /api/v1/projects/{projectId}/shortlist/{proposalId}` — project owner; removes the relationship without deleting Proposal history.
- `POST /api/v1/proposals/{proposalId}/reject` — project owner; optional `{ "reasonCode": "scope_mismatch" }`; returns `status: "declined"` and timestamp. A final selected Proposal cannot be rejected through this route.
- `GET /api/v1/projects/{projectId}/proposals/compare?ids={id1},{id2}` — project owner; accepts only proposals belonging to this Project and returns a compact comparison of price, timeline, start date, deliverables, revisions, relevant samples, and public trust summaries. It does not return private data, expose an automatic decision score, or select a creator.

Reject and shortlist actions are concurrency-checked against the Project and Proposal versions. A shortlist is not selection, a contract, or a payment commitment.

## 15.5 Accept/select a proposal

Use the existing Part 1 endpoint:

### `POST /api/v1/projects/{projectId}/selection`

**Permission:** Project owner. The request contains `proposalId` and `proposalVersionId`. It records the selected version and returns a `selectionId`, `status: "awaiting_contract_confirmation"`, and linked `conversationId`.

This is the buyer's formal selection/acceptance of the Proposal for next-step negotiation, not permission to begin work or proof of payment. The selected terms are snapshotted. Final mutually agreed terms are accepted through a versioned Chat Offer; verified payment and the Order engine then activate the Project Contract Order. Do not add a second Proposal acceptance mutation with divergent semantics.

The existing `409 SELECTION_ALREADY_IN_PROGRESS` and `422 PROPOSAL_NOT_ELIGIBLE` rules from Part 1 remain in force. The selection command is idempotent and uses a project lock/version check.

---

# 16. Contest APIs

Contest APIs own the Contest lifecycle and judging workflow. Prize money is held and paid by Payment/Wallet; a Contest prize is represented by the universal Order system. Contest is distinct from Project/Proposal.

## 16.1 Create and edit

### `POST /api/v1/contests`

**Permission:** Authenticated Buyer capability; account and contest must pass policy/eligibility checks.

**Request**

```json
{
  "title": "Logo design challenge",
  "brief": "Create a flexible identity system for a new learning brand.",
  "categoryId": "category_opaque_id",
  "skillIds": ["skill_opaque_id"],
  "deliverables": [{ "title": "Primary logo", "format": "SVG and PNG" }],
  "judgingCriteria": [
    { "name": "Brand fit", "weight": 40 },
    { "name": "Originality", "weight": 35 },
    { "name": "Usability", "weight": 25 }
  ],
  "entryDeadline": "2026-11-20T18:00:00Z",
  "timeZone": "Asia/Dhaka",
  "judgingEndsAt": "2026-11-27T18:00:00Z",
  "prizes": [{ "place": 1, "amount": { "amountMinor": 50000, "currency": "USD" } }],
  "rightsTermsId": "rights_terms_opaque_id",
  "visibility": "public",
  "entryRules": { "maxEntriesPerCreator": 1, "allowUpdatesUntilDeadline": true }
}
```

**Response:** `201 Created`, Contest in `draft`, with `contestId`, `resourceVersion`, `createdAt`, and required next steps such as funding and moderation.

### `PATCH /api/v1/contests/{contestId}`

Host only. Edits draft or policy-permitted pre-open fields with `If-Match`. Once entries open, prize, criteria, rights, winner allocation, and deadlines cannot be silently changed. Any exceptional amendment requires explicit platform policy, creator notice/consent as applicable, and a new versioned terms record.

## 16.2 Publish and close entries

### `POST /api/v1/contests/{contestId}/publish`

Host only. Requires complete brief, valid future deadline/timezone, judging schedule, weights totaling 100, published rights and feedback terms, a funded prize hold, and policy review. The command can return `202 Accepted` with `status: "pending_funding"` or `"pending_moderation"`; it returns `open` or `scheduled` only after required gates pass. Contest is not discoverable or enterable while funding/moderation is pending.

### `POST /api/v1/contests/{contestId}/close-entries`

Host command when the contest rules permit early closure; otherwise the scheduled deadline closes entries automatically. The command validates state and records a timeline event, then moves to `closed_for_entries`/`judging`. It does not cancel the Contest or release the prize.

**Publish/close errors:** `403 NOT_CONTEST_HOST`, `404 CONTEST_NOT_FOUND`, `409 CONTEST_NOT_EDITABLE`, `409 PRIZE_NOT_FUNDED`, `409 CONTEST_ALREADY_CLOSED`, `422 BRIEF_INCOMPLETE`, `422 DEADLINE_INVALID`, `422 RIGHTS_TERMS_REQUIRED`, `422 JUDGING_CRITERIA_INVALID`, `422 PRIZE_ALLOCATION_INVALID`, `429 CONTEST_ACTION_RATE_LIMITED`.

## 16.3 Shortlist and winner selection

Shortlisting is private host workflow and never promises a prize:

- `PUT /api/v1/contests/{contestId}/shortlist/{entryId}` — host only; optional private note/criteria score; returns `shortlisted`.
- `DELETE /api/v1/contests/{contestId}/shortlist/{entryId}` — host only; removes only the shortlist relation.

### `POST /api/v1/contests/{contestId}/winner-selections`

Host only. Request lists eligible `entryId`s and prize place assignments that exactly match the published winner count/allocation. Creates a private, non-final selection proposal; does not yet publish a winner or release funds.

### `POST /api/v1/contests/{contestId}/winner-selections/{selectionId}/finalize`

Host only, scoped to this Contest. Requires funded prize, closed entry period, judging state, valid winner allocation, no active safety hold, and any required criteria completion. The transaction atomically records winners, changes Contest to `winner_selected`, changes selected entries to `winner` and other eligible entries to `not_selected`, reserves each prize, and creates/links the Contest Prize Order(s). `Idempotency-Key` is required.

Winner selection is final subject to the published dispute policy. A repeated finalize call returns the same result. Concurrent finalizations return `409 WINNER_SELECTION_ALREADY_FINALIZED`.

## 16.4 Finalize winner and complete Contest

Winner confirmation, rights confirmation, prize payment, and any required ownership transfer are separate Order/Payment/Ownership state transitions. The Contest API exposes:

- `GET /api/v1/contests/{contestId}/winner-selections/{selectionId}` — host, winner, or permitted participant; returns only the visibility-appropriate result and next action.
- `POST /api/v1/contest-prize-orders/{orderId}/winner-confirmation` — selected winner confirms the published terms/rights requirement; Order participant permission applies.
- `GET /api/v1/contests/{contestId}` — shows `prize_processing` or `completed` only from authoritative Order, payout, and ownership results.

Contest completion is a system transition, not a host-editable status. It occurs after required prize Orders have completed, winner confirmation/rights transfer has succeeded, and any applicable dispute/safety hold is resolved. The internal completion command is idempotent and emits a Contest timeline event. There is no public `PATCH status=completed`.

Contest errors include `403 CONTEST_PARTICIPANT_REQUIRED`, `404 CONTEST_NOT_FOUND`, `409 CONTEST_NOT_READY_FOR_JUDGING`, `409 WINNER_SELECTION_NOT_FINALIZABLE`, `409 PRIZE_ORDER_NOT_COMPLETE`, `409 RIGHTS_TRANSFER_PENDING`, `409 CONTEST_ON_HOLD`, and `422 WINNER_ALLOCATION_MISMATCH`.

---

# 17. Contest Entry APIs

Contest Entry records and files remain distinct from Proposal records. Original work stays creator-owned unless a published, eligible winner transfer is completed.

## 17.1 Create and submit an entry

- `POST /api/v1/contests/{contestId}/entries` — eligible Creator creates a private draft. MVP defaults to one entry per creator per Contest unless published rules allow more.
- `GET /api/v1/contests/{contestId}/entries` — host-only judging list after the entry period; visibility and blind-judging rules apply.
- `GET /api/v1/entries/{entryId}` — creator owner or authorized host; public result visibility follows Contest settings.

Draft request:

```json
{
  "title": "Learning identity concept",
  "creatorNote": "The concept uses a modular mark that works at small sizes.",
  "mediaIds": ["media_preview_opaque_id", "media_support_opaque_id"],
  "portfolioReferences": [{ "type": "post", "id": "post_opaque_id" }],
  "originalityConfirmed": true,
  "rulesAccepted": true
}
```

Files must be uploaded using Part 1 Media APIs with the `contest_entry` purpose, scanned and ready before submission. Source files remain private unless the published Contest terms require a winner delivery.

### `POST /api/v1/entries/{entryId}/submit`

Creator owner. Requires Contest open, before the exact deadline, complete mandatory fields/files, explicit originality and rules acceptance, and a current entry version. Returns `status: "submitted"`, `submittedAt`, and version ID. This command is idempotent.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 CREATOR_NOT_ELIGIBLE`, `403 ENTRY_NOT_OWNER`, `404 CONTEST_NOT_FOUND`, `409 CONTEST_NOT_OPEN`, `409 ENTRY_LIMIT_REACHED`, `409 ENTRY_ALREADY_SUBMITTED`, `422 ORIGINALITY_CONFIRMATION_REQUIRED`, `422 RULES_ACCEPTANCE_REQUIRED`, `422 ENTRY_FILE_NOT_READY`, `422 ENTRY_CONTENT_INVALID`, `429 ENTRY_RATE_LIMITED`.

## 17.2 Preview, update, and withdraw

- `GET /api/v1/entries/{entryId}/preview` — Creator owner or authorized Contest host; returns only permitted, scanned preview rendition and a short-lived URL/stream authorization. It never returns a permanent original-file URL.
- `PATCH /api/v1/entries/{entryId}` — Creator owner; creates a new immutable version with a creator note and file manifest. Permitted only before the deadline when Contest rules allow updates. Send `If-Match`.
- `POST /api/v1/entries/{entryId}/withdraw` — Creator owner; allowed only in the policy-defined entry window, normally before judging. It preserves entry/version history and withdraws eligibility; it does not delete files or grant Host rights.

After the entry deadline, judging locks ordinary edits. A finalist/winner revision is possible only if the published Contest rules explicitly define it; use the structured Contest revision command and deadlines, not a replacement upload or Chat message.

## 17.3 Host status and private feedback

Host actions use the Contest shortlist and winner-selection endpoints in Section 16. Entry status values include `draft`, `submitted`, `shortlisted`, `finalist`, `winner`, `not_selected`, `withdrawn`, and `disqualified`. A user cannot directly patch status.

The host may retrieve feedback/criteria data only for entries in the host's Contest. A creator sees only their own status and feedback permitted by the published feedback policy. Blind judging hides identity from the host until a permitted reveal transition.

Errors: `403 NOT_CONTEST_HOST`, `403 ENTRY_NOT_VISIBLE`, `404 ENTRY_NOT_FOUND`, `409 ENTRY_LOCKED_FOR_JUDGING`, `409 RESOURCE_VERSION_CONFLICT`, `422 MEDIA_NOT_AUTHORIZED`, `422 MEDIA_SCAN_PENDING`, `422 UPDATE_NOT_ALLOWED`, `429 PREVIEW_RATE_LIMITED`.

---

# 18. Order APIs

The universal Order remains the commercial source of truth across Digital Product, Exclusive Project, Service, Project Contract, Custom Chat, Contest Prize, and Paid File Delivery types. Payment, fulfillment, delivery/access, ownership, revision, refund, dispute, and payout are separate status dimensions; do not flatten them into one client-editable status.

## 18.1 Create and retrieve an Order

### `POST /api/v1/orders`

Authenticated Buyer capability or a permitted system command. Used for an accepted Offer/PaymentRequest or another source that has no more specific checkout route. Product, Service, and Exclusive Project checkout endpoints from Part 1 delegate to this same Order engine; clients must not create a second Order for the same checkout.

Request uses a typed source reference, not client-supplied seller, price, fee, or successful payment status:

```json
{
  "source": { "type": "accepted_offer", "id": "offer_version_opaque_id" },
  "conversationId": "conversation_opaque_id",
  "buyerRequirements": { "brief": "Use the supplied copy and existing wordmark." }
}
```

The server loads accepted, immutable terms and computes the amount/currency/fees. It creates or returns the one idempotent Order in `pending_payment` (or the appropriate no-payment state only where policy allows), with a payment attempt/next action. Response is `201` for a new Order or `200` for an idempotent replay; use `202` if provider/creation reconciliation is pending.

### `GET /api/v1/orders/{orderId}`

Only Buyer, Seller, explicitly authorized participant, or scoped support/admin may view. Returns the authorized Order summary, item/terms snapshot, participant roles, payment/fulfillment/delivery/ownership/revision/refund/dispute/payout dimensions, deadline, timeline, Delivery references, linked Conversation, and eligible actions. Internal fraud notes, provider secrets, other users' private data, and admin-only evidence are excluded.

### `GET /api/v1/orders?side=buyer|seller&status=...&type=...`

Authenticated. Lists only the current actor's Orders, cursor-paginated and filterable by lifecycle bucket, type, and date. `side` is a view selector, not authority to access another user's orders.

## 18.2 Order commands and permitted transitions

| Command | Endpoint | Actor and effect |
|---|---|---|
| Accept | `POST /api/v1/orders/{orderId}/accept` | Seller accepts an eligible paid Service/Project/Custom Order where acceptance is required; returns `accepted` |
| Start | `POST /api/v1/orders/{orderId}/start` | Seller starts accepted fulfillment; validates requirements and start window |
| Deliver | `POST /api/v1/orders/{orderId}/deliveries` | Seller creates a Delivery draft; final submission is Section 22 |
| Request revision | `POST /api/v1/orders/{orderId}/revisions` | Buyer requests an in-scope revision during review window; consumes an allowed round only after validation |
| Approve delivery | `POST /api/v1/orders/{orderId}/approve` | Buyer approves a reviewable Delivery/version; records approval and starts completion/payout/review consequences |
| Cancel | `POST /api/v1/orders/{orderId}/cancellations` | Buyer or Seller requests cancellation; immediate result only when policy permits, otherwise `cancellation_requested` |
| Request refund | `POST /api/v1/orders/{orderId}/refund-requests` | Buyer submits amount/reason/evidence references; records request, not a completed refund |
| Open dispute | `POST /api/v1/orders/{orderId}/disputes` | Buyer or Seller opens the Order-level dispute integration; creates a case reference and dispute overlay |
| Timeline | `GET /api/v1/orders/{orderId}/timeline` | Order participant; returns visibility-filtered chronological events |

All POST transitions require an `Idempotency-Key` when they can create a record or cause a financial/lifecycle effect. Server checks current state under transaction/lock or `resourceVersion`, writes the Order/timeline/outbox changes atomically, then emits asynchronous notifications/analytics.

`POST /api/v1/orders/{orderId}/complete` is not a normal client operation. Completion follows buyer approval, permitted auto-completion, or authorized dispute resolution. No client may directly set `completed`.

## 18.3 Order contracts and errors

Example refund request:

```json
{
  "amount": { "amountMinor": 2500, "currency": "USD" },
  "reasonCode": "delivery_not_as_described",
  "message": "The delivered files are missing the agreed source format.",
  "evidenceReferences": ["media_opaque_id", "message_opaque_id"]
}
```

Response returns the request ID, `status: "requested"`, amount, `createdAt`, and next action; it does not state that funds are refunded.

Common errors: `401 AUTHENTICATION_REQUIRED`, `403 ORDER_PARTICIPANT_REQUIRED`, `404 ORDER_NOT_FOUND`, `409 ORDER_STATE_CONFLICT`, `409 PAYMENT_NOT_CONFIRMED`, `409 DELIVERY_NOT_REVIEWABLE`, `409 REVISION_LIMIT_REACHED`, `409 REVIEW_WINDOW_CLOSED`, `409 CANCELLATION_NOT_ALLOWED`, `409 REFUND_ALREADY_PENDING`, `409 DISPUTE_ALREADY_OPEN`, `409 RESOURCE_VERSION_CONFLICT`, `422 AMOUNT_EXCEEDS_REFUNDABLE`, `422 REASON_REQUIRED`, `422 EVIDENCE_NOT_AUTHORIZED`, `429 ORDER_ACTION_RATE_LIMITED`.

For asynchronous transitions, return `202` and the authoritative pending resource. A timeout/retry cannot create a duplicate Order, revision, cancellation, refund request, or dispute.

---

# 19. Chat APIs

Chat owns conversation membership, messages, attachments-as-references, read cursors, and ephemeral presence. It does not own payment, Order state, delivery completion, ownership, or access grants.

## 19.1 Conversations and history

- `GET /api/v1/conversations?cursor=...&contextType=...` — authenticated; returns only conversations where the actor is a current participant.
- `POST /api/v1/conversations` — authenticated; creates or returns an existing permitted thread for a typed context.

Request:

```json
{
  "participantUserId": "user_opaque_id",
  "context": { "type": "project", "id": "project_opaque_id" },
  "initialMessage": "I have a question about the delivery timeline."
}
```

Response `201` or idempotent `200` includes `conversationId`, participant summary, `contextLinks`, last-message preview, and `createdAt`. The server checks context visibility, allowed contact rules, blocks, and rate limits. Arbitrary user-to-user conversation creation may be restricted to reduce spam.

- `GET /api/v1/conversations/{conversationId}` — participants only.
- `GET /api/v1/conversations/{conversationId}/messages?cursor=...&limit=...` — participants only; cursor is stable by creation sequence, not client timestamp.

## 19.2 Send, edit, delete, read, and attachments

### `POST /api/v1/conversations/{conversationId}/messages`

Participant only. Request contains one of `text`, `structuredReference`, or an authorized `attachmentMediaIds` list; cannot be empty. Message send is idempotent with a client-generated message key/`Idempotency-Key`.

Example:

```json
{
  "text": "I uploaded the first delivery version.",
  "attachmentMediaIds": ["media_opaque_id"],
  "clientMessageId": "client_message_opaque_id"
}
```

Response `201` includes server `messageId`, `createdAt`, normalized content, attachment metadata safe for the recipient, and delivery/read state. Push/realtime fan-out follows asynchronously.

- `PATCH /api/v1/messages/{messageId}` — sender only; edits ordinary text within the configured edit window, with edit history/moderation retention. Never edits system events, offer/payment/order references, or attachments in a way that changes their authorization.
- `DELETE /api/v1/messages/{messageId}` — sender only; soft-deletes/redacts only when policy allows; preserves required dispute/audit evidence. A deletion placeholder is returned when history continuity is necessary.
- `PUT /api/v1/conversations/{conversationId}/read-state` — participant only; body `{ "lastReadMessageId": "message_opaque_id" }`; advances the user's read cursor monotonically and is idempotent.
- `POST /api/v1/conversations/{conversationId}/attachments` — creates/associates a message attachment from already uploaded and scanned Media. Protected file access is always checked through Section 21.

## 19.3 Realtime, typing, presence, and Order linking

Realtime delivery may use WebSocket/SSE after authenticated connection setup. REST remains the durable source for message history and conversation membership.

- `POST /api/v1/conversations/{conversationId}/realtime-ticket` — participant only; returns a short-lived, conversation-scoped connection ticket. Do not put long-lived session tokens in WebSocket query strings.
- Typing/presence events are ephemeral, short-lived, rate-limited, and not persisted as transaction state. If realtime is unavailable, message send/read APIs continue to work.
- `POST /api/v1/conversations/{conversationId}/order-links` — participant with permission on the Order; body `{ "orderId": "...", "relationshipKind": "fulfillment" }`. Links the existing conversation to the Order without copying, deleting, or rewriting previous messages. The server verifies that both conversation and Order share authorized participants and the declared context.
- `GET /api/v1/conversations/{conversationId}/order-links` — participants; returns permitted Order summaries.

Errors include `401 AUTHENTICATION_REQUIRED`, `403 CONVERSATION_PARTICIPANT_REQUIRED`, `403 MESSAGE_NOT_EDITABLE`, `404 CONVERSATION_NOT_FOUND`, `409 CONTEXT_LINK_CONFLICT`, `409 MESSAGE_EDIT_WINDOW_CLOSED`, `413 MESSAGE_ATTACHMENT_LIMIT_EXCEEDED`, `422 MESSAGE_EMPTY`, `422 ATTACHMENT_NOT_READY`, `429 MESSAGE_RATE_LIMITED`.

---

# 20. Chat-Commerce APIs

Chat-commerce preserves a single conversation history while adding typed, versioned Offer and PaymentRequest records. Chat text is never interpreted as binding price/payment state.

## 20.1 Create, send, revise, accept, reject, and expire an Offer

- `POST /api/v1/conversations/{conversationId}/offers` — authorized Seller/Creator participant creates a draft Offer.
- `POST /api/v1/offers/{offerId}/send` — sender sends the current immutable Offer version to the Buyer.
- `POST /api/v1/offers/{offerId}/versions` — sender creates a new explicit version; the previous version remains auditable.
- `POST /api/v1/offers/{offerId}/accept` — Buyer participant accepts a specific `versionId`.
- `POST /api/v1/offers/{offerId}/reject` — Buyer participant rejects a specific active version with optional reason code.
- Expiration is system-driven at `expiresAt`; `GET /api/v1/offers/{offerId}` returns current state and version history to participants.

Offer request:

```json
{
  "title": "Short-form video package",
  "scope": "Three edited vertical videos using buyer-supplied footage.",
  "deliverables": [{ "title": "Edited videos", "quantity": 3 }],
  "price": { "amountMinor": 9000, "currency": "USD" },
  "deliveryDueAt": "2026-11-12T18:00:00Z",
  "revisionTerms": { "includedRounds": 1 },
  "rightsTermsId": "license_terms_opaque_id",
  "expiresAt": "2026-10-28T18:00:00Z"
}
```

Response includes `offerId`, `versionId`, `status`, immutable terms snapshot, conversation ID, expiry, and response deadline. Only the recipient can accept/reject the current sent version. Editing after send creates a new version and invalidates the prior pending acceptance target.

Acceptance means agreement to the version; it is not payment confirmation, an active Order, or work-start permission. It invokes the central Order/checkout command. An accepted Offer cannot be edited; changes require a new Offer version or an explicit add-on path.

## 20.2 Payment requests and custom Order creation

- `POST /api/v1/offers/{offerId}/payment-requests` — participant with authority over the accepted Offer creates a payment request for its exact terms.
- `POST /api/v1/payment-requests/{paymentRequestId}/checkout` — Buyer starts an idempotent payment attempt.
- `GET /api/v1/payment-requests/{paymentRequestId}` — participants; returns payment-request state and linked Order/Payment IDs when created.

PaymentRequest fields are derived from the accepted Offer or an existing Order/add-on; a client cannot raise the amount beyond accepted terms. A PaymentRequest is not a Payment, ledger entry, or Order status.

For custom chat orders, `POST /api/v1/orders` with `source.type: "accepted_offer"` creates/reuses the pending universal Order and snapshots the accepted Offer version. After trusted payment confirmation, the Payment module marks payment paid and the Order transitions under the Order engine. Existing conversation messages stay unchanged; structured system messages may be appended from committed events.

Errors: `403 OFFER_PARTICIPANT_REQUIRED`, `404 OFFER_NOT_FOUND`, `409 OFFER_NOT_SENT`, `409 OFFER_EXPIRED`, `409 OFFER_VERSION_STALE`, `409 OFFER_ALREADY_RESPONDED`, `409 PAYMENT_REQUEST_ALREADY_ACTIVE`, `409 TERMS_MISMATCH`, `422 PRICE_INVALID`, `422 EXPIRES_AT_INVALID`, `429 OFFER_ACTION_RATE_LIMITED`.

The Offer acceptance, pending Order creation, and idempotency record must be consistent; provider payment is reconciled separately through the Payment module. If payment initiation fails, retain the accepted Offer and the pending/retryable Order without charging twice.

---

# 21. Paywalled File APIs

Original files are private. Previews are separate Media records. Every preview/original access checks current user, Order/payment/entitlement, file-version scope, scan state, refund/dispute/revocation state, and expiry. An object-storage URL is not an entitlement.

## 21.1 Upload and lock a file

Use Part 1 `POST /api/v1/media/uploads` for original and preview upload intents with distinct purposes such as `locked_delivery_original` and `locked_delivery_preview`. The server issues scoped upload permission; files are scanned and marked ready before becoming buyer-visible.

### `POST /api/v1/conversations/{conversationId}/locked-files`

Authorized file owner/Seller participant. Request references only ready Media owned by the actor and includes safe display terms:

```json
{
  "originalMediaId": "media_original_opaque_id",
  "previewMediaIds": ["media_preview_opaque_id"],
  "title": "Editable social template pack",
  "price": { "amountMinor": 2400, "currency": "USD" },
  "licenseTermsId": "license_terms_opaque_id",
  "expiresAt": "2026-11-30T00:00:00Z"
}
```

Response `201` returns `lockedFileId`, `status: "locked"`, safe preview metadata, immutable price/license snapshot, and a structured message reference. It never returns original file paths or storage keys.

## 21.2 Attach, check, unlock, download, and history

- `POST /api/v1/orders/{orderId}/locked-files` — authorized Seller attaches a ready file manifest to an eligible paid-delivery Order. Ownership and scope are checked; response returns an Order-linked `lockedFileId`.
- `GET /api/v1/locked-files/{lockedFileId}` — only owner, eligible Buyer, or scoped staff; returns status and safe preview metadata.
- `POST /api/v1/locked-files/{lockedFileId}/checkout` — Buyer begins/reuses an idempotent checkout. It delegates to Order/Payment and returns pending Order/Payment references. It does not unlock.
- `GET /api/v1/locked-files/{lockedFileId}/access` — authenticated caller receives only an access decision (`available`, `locked`, `expired`, or `revoked`) and safe next step; does not expose storage credentials.
- `POST /api/v1/media/{mediaId}/access` — authenticated caller requests a specific action such as `preview` or `download`, with `orderId` and optional `deliveryVersionId`. If permitted, returns a short-lived URL or authorized stream reference plus `expiresAt`. Authorization is repeated for each request/refresh.
- `GET /api/v1/me/download-history?cursor=...` — lists only the current user's authorized download events and safe file/Order summaries.

Trusted `PAYMENT_CONFIRMED` processing creates/reuses the Order entitlement and AccessGrant; there is no client-side “unlock” command. Grant provisioning may return/retain `unlocking` while retrying; never ask the Buyer to pay again.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 FILE_ACCESS_DENIED`, `404 FILE_NOT_FOUND`, `409 PAYMENT_NOT_CONFIRMED`, `409 ENTITLEMENT_NOT_READY`, `409 ACCESS_REVOKED`, `409 FILE_VERSION_NOT_IN_ORDER`, `410 ACCESS_EXPIRED`, `422 MEDIA_SCAN_PENDING`, `429 DOWNLOAD_RATE_LIMITED`.

---

# 22. Delivery APIs

Delivery is a versioned Order fulfillment record; its files are private Media references. A Chat message may point to a Delivery but cannot submit, approve, or consume a revision.

## 22.1 Create and submit delivery

### `POST /api/v1/orders/{orderId}/deliveries`

**Permission:** Seller participant; Order must be paid/accepted/in progress and type must support fulfillment delivery.

Request:

```json
{
  "note": "The first brand kit version is ready for review.",
  "fileMediaIds": ["media_delivery_opaque_id"],
  "previewMediaIds": ["media_preview_opaque_id"],
  "licenseTermsId": "license_terms_opaque_id"
}
```

Creates a draft delivery/version; response includes `deliveryId`, `versionId`, `status: "draft"`, files as safe metadata, `createdAt`, and resource version.

- `GET /api/v1/orders/{orderId}/deliveries` — Order participants; returns only authorized versions/files.
- `GET /api/v1/deliveries/{deliveryId}` — Order participants; returns delivery note, version history, access policy, review deadline, and actor-appropriate actions.
- `POST /api/v1/deliveries/{deliveryId}/versions` — Seller creates a new version when a revision is in progress or policy permits an update. Existing versions remain immutable.
- `POST /api/v1/deliveries/{deliveryId}/submit` — Seller submits a complete ready version for Buyer review. Records `submittedAt`, `reviewDueAt`, and Order timeline event; duplicate submission is idempotent.

Validation requires file ownership/authorization, completed malware scan, supported file type/size, license/rights compatibility, and delivery completeness for the Order type. Original files remain private until the linked Order entitles access.

## 22.2 Buyer review and resubmission

- `POST /api/v1/orders/{orderId}/revisions` — canonical Buyer revision request; body includes `deliveryId`, `deliveryVersionId`, `reasonCode`, `message`, and requested changes. In-scope and within the review window/remaining allowance; creates a structured Revision record.
- Seller responds by `POST /api/v1/revisions/{revisionId}/respond` with `responseCode` and an optional message. A revised delivery is a new DeliveryVersion, submitted through `/deliveries/{deliveryId}/submit`.
- `POST /api/v1/orders/{orderId}/approve` — canonical Buyer approval of a submitted `deliveryVersionId`; validates Order and Delivery state, records approval, and initiates completion/payout/review consequences.

There is no separate delivery `approve` mutation; the Order approval command is authoritative and keeps the Part 1 `/orders/{orderId}/approve` route.

Errors: `403 ORDER_PARTICIPANT_REQUIRED`, `404 DELIVERY_NOT_FOUND`, `409 ORDER_NOT_DELIVERABLE`, `409 DELIVERY_ALREADY_SUBMITTED`, `409 REVISION_NOT_OPEN`, `409 REVIEW_WINDOW_CLOSED`, `409 RESOURCE_VERSION_CONFLICT`, `422 DELIVERY_FILE_NOT_READY`, `422 FILE_TYPE_NOT_ALLOWED`, `422 DELIVERY_VERSION_REQUIRED`, `422 APPROVAL_VERSION_MISMATCH`.

---

# 23. Wallet APIs

Wallet is a ledger-backed view of money owed, held, released, reserved, or withdrawable. Clients can request operations but cannot write balances. Payment-method tokens are provider references; NeuralMart does not collect or store raw card numbers or security codes.

## 23.1 Balance, history, earnings, and fees

- `GET /api/v1/wallet` — authenticated current user; returns balances by currency: `available`, `pending`, `reserved`, `withdrawable`, `currency`, and `asOf`. Values are derived from immutable ledger entries; any cached summary is rebuildable.
- `GET /api/v1/wallet/transactions?cursor=...&type=...` — own cursor-paginated transaction history with status, amount, currency, reference type/ID, and timestamps. No other user's ledger is exposed.
- `GET /api/v1/wallet/earnings?cursor=...` — creator's own gross sale, platform fee, adjustments, pending/held/released earnings, and linked Order summaries.
- `GET /api/v1/orders/{orderId}/financial-breakdown` — Order participant; returns the immutable price/fee/tax/refund/payout breakdown visible to that actor.

Response amounts always use `{ "amountMinor": integer, "currency": "..." }`. Platform fee is a line item in the Order/ledger snapshot; a client cannot choose or modify the fee.

## 23.2 Add funds and payment methods

If account top-ups are enabled in the applicable market:

- `POST /api/v1/wallet/fundings` — authenticated; request includes amount/currency and an approved `paymentMethodId`; `Idempotency-Key` required. Creates a pending Payment intent, not a balance increase.
- `GET /api/v1/wallet/fundings/{fundingId}` — returns `pending`, `confirmed`, `failed`, or `reconciling`.
- `GET /api/v1/payment-methods` — lists provider-backed method summaries for current user; no raw payment credentials.
- `POST /api/v1/payment-method-setup` — creates a provider-hosted setup session and returns a short-lived next action.
- `DELETE /api/v1/payment-methods/{paymentMethodId}` — detaches a method if it is not required by a pending transaction or legal retention rule.

Only verified provider confirmation creates a ledger credit. Wallet top-up is not assumed to be an MVP requirement; if disabled, the routes return `404 FEATURE_NOT_AVAILABLE` without implying that checkout payment is unavailable.

## 23.3 Withdrawals

- `POST /api/v1/wallet/withdrawals` — authenticated creator with eligible payout account; request `{ "amount": { "amountMinor": 10000, "currency": "USD" }, "payoutMethodId": "payout_method_opaque_id" }`; `Idempotency-Key` required.
- `GET /api/v1/wallet/withdrawals?cursor=...` — own history.
- `GET /api/v1/wallet/withdrawals/{withdrawalId}` — owner or scoped staff; returns status, amount, fee, destination summary, and timestamps.
- `POST /api/v1/wallet/withdrawals/{withdrawalId}/cancel` — owner only while provider processing has not become irreversible; idempotent.

The server atomically checks available balance, places a withdrawal hold/ledger reservation, and creates the Withdrawal. It never trusts a client balance. Provider payout completion/reversal updates the ledger through verified callbacks/reconciliation.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 WALLET_OWNER_REQUIRED`, `403 PAYOUT_VERIFICATION_REQUIRED`, `404 WALLET_NOT_FOUND`, `409 INSUFFICIENT_AVAILABLE_BALANCE`, `409 WITHDRAWAL_NOT_CANCELLABLE`, `409 CURRENCY_MISMATCH`, `422 AMOUNT_BELOW_MINIMUM`, `422 PAYOUT_METHOD_INVALID`, `429 WITHDRAWAL_RATE_LIMITED`.

---

# 24. Payment APIs

Payment answers whether funds were authorized, captured, failed, or refunded. Wallet/Ledger records answer what is owed/held/released. Order records the commercial agreement. These states reference one another but do not substitute for one another.

## 24.1 Initiate checkout and inspect status

- `POST /api/v1/checkouts` — authenticated Buyer capability; request references an existing pending Order and approved payment method. Resource-specific product, exclusive-project, service, and Offer checkout routes from Part 1 delegate to the same checkout command.

```json
{
  "orderId": "order_opaque_id",
  "paymentMethodId": "payment_method_opaque_id",
  "returnUrl": "https://app.example/checkout/return"
}
```

Returns `202` with `paymentId`, `orderId`, `paymentStatus: "pending"`, provider-safe `nextAction`, and `expiresAt`. It does not return `paid` based on a redirect or client assertion. Repeating with the same key returns the same payment attempt.

- `GET /api/v1/payments/{paymentId}` — payer or authorized Order participant; returns safe state and next action, not provider credentials or private risk details.
- `POST /api/v1/payments/{paymentId}/verify` — payer may request a server-side status refresh using the stored provider reference. The server queries/verifies the provider; request cannot include `{ "status": "paid" }`. Returns `200` for verified final state or `202` for `pending`/`reconciling`.

## 24.2 Confirmation, failure, and webhook processing

Payment success is authoritative only after a verified provider callback or server-to-server provider status query. The consumer client return/redirect is informational and can only prompt a status refresh.

`POST /api/v1/webhooks/{provider}` is server-to-server, not consumer-session authenticated. Part 3 defines the shared signature, replay, event envelope, and provider-version details. The handler must validate the provider signature/event identity, deduplicate by provider event ID, verify amount/currency/reference, and process idempotently.

On verified success, in one operational transaction where supported, record Payment state, link it to Order, create balanced ledger allocations/fees/earnings/entitlement or ownership reservation as required, append the Order timeline event, and write an outbox event. If a cross-system step cannot commit immediately, return/retain `reconciling` and retry; do not show purchase success prematurely.

Payment failure is represented on the Payment attempt (`failed`/`expired`); the Order remains retryable or transitions according to its type/policy. No access/ownership grant occurs for failed, pending, or unverified payment.

## 24.3 Refund commands

- Buyer-facing request: `POST /api/v1/orders/{orderId}/refund-requests` (Section 18).
- Financial execution: `POST /api/v1/payments/{paymentId}/refunds` is restricted to the authorized Order/Payment service command or scoped staff workflow; clients cannot call it as an ordinary Buyer/Seller action.

Request:

```json
{
  "orderId": "order_opaque_id",
  "refundRequestId": "refund_request_opaque_id",
  "amount": { "amountMinor": 2500, "currency": "USD" },
  "reasonCode": "approved_order_resolution"
}
```

Requires `Idempotency-Key`; checks refundable amount, payment capture, prior refunds, dispute/cancellation decision, currency, and access/ownership consequences. Returns `202` while provider processing is pending. A verified refund callback creates the immutable refund and ledger reversal; access, ownership, Order status, and payout treatment follow the established policy. Never equate refund request accepted with money returned.

Common errors: `401 AUTHENTICATION_REQUIRED`, `403 PAYMENT_PARTICIPANT_REQUIRED`, `404 PAYMENT_NOT_FOUND`, `409 PAYMENT_NOT_READY`, `409 PAYMENT_ALREADY_FINAL`, `409 PAYMENT_AMOUNT_MISMATCH`, `409 REFUND_NOT_APPROVED`, `409 REFUND_EXCEEDS_CAPTURED_AMOUNT`, `422 PAYMENT_METHOD_UNAVAILABLE`, `422 CURRENCY_NOT_SUPPORTED`, `429 PAYMENT_ATTEMPT_RATE_LIMITED`.

---

# 25. Ownership APIs

Ownership is a permanent, auditable record tied to the source asset, Order, seller, buyer, and acquisition/transfer event. A Sold/Locked listing cannot become Available because of a stale cache, payment retry, or client request.

## 25.1 Verify, retrieve, and list ownership

- `GET /api/v1/me/ownership?cursor=...&status=...` — authenticated; current user's ownership records.
- `GET /api/v1/me/ownership/history?cursor=...` — current user's acquisition/transfer history.
- `GET /api/v1/ownership/{ownershipId}` — current owner, seller/Buyer on the linked Order, or scoped staff; private party details are minimized.
- `GET /api/v1/ownership/verify?assetType=exclusive_project&assetId={id}` — authenticated; verifies whether the current actor has the active ownership entitlement. Response includes boolean `owns`, `ownershipId` only when authorized, and `ownershipStatus`.
- `GET /api/v1/exclusive-projects/{projectId}/availability` — Part 1 public/status endpoint; returns `available`, `checkout_pending`, or `sold`/`locked`, without disclosing private Buyer identity.

Purchase history is derived from Orders/Ownership history, not a separately mutable purchase flag.

## 25.2 Transfer where explicitly permitted

Normal Sell Once ownership is permanent and has no user-initiated resale/transfer endpoint in MVP. Contest winner transfer is initiated by finalized contest/prize Order. An authorized legal, safety, or support correction is a restricted, audited platform command; it requires reason code, evidence/case reference, old/new owner, source Order/Contest, and idempotency. It creates a new OwnershipHistory event rather than rewriting the original record.

Where a future product explicitly permits a user-initiated transfer:

- `POST /api/v1/ownership/{ownershipId}/transfers` — current owner plus policy/recipient eligibility; requires confirmation by all required parties and any new Order/payment. Request cannot directly set owner or mark a transfer complete.
- `GET /api/v1/ownership/{ownershipId}/transfers/{transferId}` — authorized parties.

The server locks the asset/Ownership and enforces unique active ownership. Successful transfer, source Order linkage, buyer/seller references, audit history, and Sold/Locked presentation update atomically. Failures leave the previous ownership authoritative or a clearly pending, recoverable transfer; never create two active owners.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 OWNERSHIP_PARTICIPANT_REQUIRED`, `404 OWNERSHIP_NOT_FOUND`, `409 ASSET_NOT_AVAILABLE`, `409 OWNERSHIP_ALREADY_TRANSFERRED`, `409 TRANSFER_NOT_PERMITTED`, `409 TRANSFER_PENDING`, `422 TRANSFER_RECIPIENT_INVALID`.

---

# 26. Review & Rating APIs

Reviews are linked to verified, eligible completed Orders and permitted OrderItems/targets. Ratings and written reviews remain distinct; reputation summaries are derived and never client-set.

## 26.1 Eligibility and submission

- `GET /api/v1/orders/{orderId}/review-eligibility` — Order participant; returns eligible target, allowed review direction, `eligible`, `reasonCode` if not eligible, `opensAt`, `closesAt`, and current submission state.
- `POST /api/v1/orders/{orderId}/reviews` — eligible participant; `Idempotency-Key` required.

Request:

```json
{
  "target": { "type": "creator", "id": "user_opaque_id" },
  "rating": 5,
  "categoryRatings": { "quality": 5, "communication": 5, "timeliness": 4 },
  "text": "The delivered assets matched the agreed brief.",
  "contextTags": ["clear_communication"]
}
```

Eligibility requires a completed Order, confirmed payment, legitimate Buyer/Seller participation, valid policy outcome, review window open, and no full fraud/invalid-purchase reversal. The window begins at the applicable event (product/file access, buyer approval, auto-completion, contest completion, or fulfilled dispute resolution); exact `closesAt` is returned by the API according to the relevant policy/Order terms.

Only one review per eligible direction and Order/target is allowed. If policy permits editing within the review window, use `PATCH /api/v1/reviews/{reviewId}` with `If-Match`; retain revisions and do not allow edits in reaction to seeing the other party's rating.

Buyer reviews target the purchased creator/product/service context. Seller reviews of a Buyer are enabled only for interactive fulfillment types: services, project contracts, custom chat Orders, contest prize work, and paid file delivery with custom fulfillment. They are not normally shown for instant digital product purchases. Reciprocal reviews are held until both parties submit or the review window closes to reduce retaliation.

## 26.2 Retrieve reviews and summaries

- `GET /api/v1/reviews?targetType=creator&targetId=...&cursor=...` — public approved reviews only, with privacy and moderation filters.
- `GET /api/v1/creators/{creatorId}/rating-summary` — public aggregate rating/count and verified-order breakdown.
- `GET /api/v1/marketplace/products/{productId}/reviews` and `/marketplace/services/{serviceId}/reviews` — approved target-specific reviews.
- `GET /api/v1/reviews/{reviewId}` — public only when approved/visible; author can view their own pending/moderated review.

Public review representation includes `verifiedOrder: true`, target type, order type/context, rating, permitted text/tags, and submitted date; it omits private order IDs unless policy allows an owner-facing view. Reviews are never accepted without the server-created eligibility record and a unique Order/direction constraint.

Errors: `403 REVIEW_NOT_ELIGIBLE`, `404 ORDER_NOT_FOUND`, `409 ORDER_NOT_COMPLETED`, `409 REVIEW_WINDOW_CLOSED`, `409 REVIEW_ALREADY_SUBMITTED`, `409 REVIEW_TARGET_MISMATCH`, `409 RESOURCE_VERSION_CONFLICT`, `422 RATING_OUT_OF_RANGE`, `422 REVIEW_TEXT_INVALID`, `422 REVIEW_CONTENT_RESTRICTED`, `429 REVIEW_RATE_LIMITED`.

---

# 27. Badge APIs

Badges are computed/awarded by the Trust module from verified outcomes, not editable profile labels. Reputation and badge progression are distinct from one another.

- `GET /api/v1/me/badges` — authenticated; earned badges, level, visibility, awarded/updated time, and current state.
- `GET /api/v1/me/badges/progress` — authenticated; progress summaries and eligibility reasons safe for the current user. Sensitive fraud/risk rules are not exposed.
- `GET /api/v1/me/badges/history?cursor=...` — authenticated; awards, upgrades, holds, demotions, and revocations with reason categories and timestamps.
- `GET /api/v1/badges/{badgeId}` — public definition, levels, display rules, and high-level eligibility criteria.
- `GET /api/v1/users/{userId}/badges` — public earned badges only when the user has visibility enabled; never reveals private progress.

No public API assigns or edits a badge. New awards, progression, and demotion are triggered by committed Order/review/verification/safety events and processed asynchronously with an auditable BadgeHistory record. Responses may indicate `evaluationStatus: "updating"` while a projection is refreshing, but must not show an uncommitted badge as earned.

Errors: `401 AUTHENTICATION_REQUIRED`, `404 BADGE_NOT_FOUND`, `404 USER_NOT_FOUND`, `403 BADGE_PROGRESS_PRIVATE`, `429 BADGE_QUERY_RATE_LIMITED`.

---

# 28. Notification APIs

Notifications are delivery projections of committed domain events, not the source of truth. Notifications may cover Orders, Chat, Projects, Contests, Payments, Badges, and Security; high-priority financial/security/deadline events cannot be silently suppressed by unrelated preference settings.

## 28.1 Inbox, unread state, and read commands

- `GET /api/v1/notifications?cursor=...&unreadOnly=true&type=order` — authenticated; returns only the current user's notification records.
- `GET /api/v1/notifications/unread-count` — authenticated; returns `{ "count": 3, "asOf": "..." }`.
- `PUT /api/v1/notifications/{notificationId}/read` — recipient only; idempotently marks one notification read.
- `POST /api/v1/notifications/read-all` — authenticated; marks eligible notifications read up to an optional cursor/watermark, not notifications arriving afterward.

Each notification has `notificationId`, `type`, safe `title`/`body`, typed `resource` reference, `createdAt`, `readAt`, `priority`, and in-app deep link. The client must fetch the linked resource through its API; notification payloads do not contain private financial, message, or file data.

## 28.2 Preferences and channels

- `GET /api/v1/notification-preferences` — authenticated; returns per-category channel preferences for in-app, push, and email.
- `PATCH /api/v1/notification-preferences` — authenticated; updates allowed preferences with `If-Match`.

Security events and legally/operationally required payment/order notices may be mandatory in at least one channel. Product policy defines exact mandatory types; users may not opt out of critical account-security notices. Preference changes do not erase existing notifications.

## 28.3 Delivery and reliability rules

Domain event/outbox processing creates notifications asynchronously. Deduplicate by recipient + event + notification type/resource; coalesce repetitive low-priority events and apply per-recipient rate limits. Do not delay critical transaction results while a push/email provider is unavailable. Failed external delivery retries and is visible in `NotificationDelivery` status to authorized operations; in-app state remains available.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 NOT_NOTIFICATION_RECIPIENT`, `404 NOTIFICATION_NOT_FOUND`, `409 RESOURCE_VERSION_CONFLICT`, `422 PREFERENCE_NOT_ALLOWED`, `429 NOTIFICATION_ACTION_RATE_LIMITED`.

---

# 29. Unified Search APIs

Search supports creators, products, services, posts, projects, and contests using replaceable search infrastructure. Search results are projections for discovery, not an authorization or transaction decision. Source modules recheck visibility, availability, eligibility, and current price when the user opens or acts on a result.

## 29.1 Search endpoint

### `GET /api/v1/search`

**Permission:** Public for public resources; optional authentication can personalize safe ranking. Private/unlisted/invite-only resources appear only to eligible users and never leak through facets, counts, snippets, or autocomplete.

Query parameters:

- `q` — normalized keyword (required for general search; bounded length).
- `types` — comma-separated `creator,product,service,post,project,contest`.
- `categoryId`, `skillIds`, `badgeId`.
- `priceMinMinor`, `priceMaxMinor`, `currency` — only for purchasable products/services or explicitly budgeted Projects/Contests.
- `ratingMin` — only for rated public targets.
- `availableOnly=true` — only where availability is meaningful.
- `sort=relevance|newest|popular|price_asc|price_desc|rating`.
- `cursor`, `limit` — opaque keyset pagination, Part 1 bounds.

Example:

```text
GET /api/v1/search?q=brand%20designer&types=creator,service,project&categoryId=category_opaque_id&ratingMin=4&sort=relevance&limit=20
```

Response uses a compact heterogeneous list:

```json
{
  "data": {
    "items": [
      {
        "type": "service",
        "id": "service_opaque_id",
        "title": "Brand identity starter",
        "thumbnail": { "mediaId": "media_opaque_id", "url": "short_lived_or_public_url" },
        "creator": { "userId": "user_opaque_id", "displayName": "Maya" },
        "priceFrom": { "amountMinor": 8000, "currency": "USD" },
        "ratingSummary": { "average": 4.8, "count": 21 },
        "availability": "available",
        "badges": [{ "id": "badge_opaque_id", "label": "Reliable Seller" }],
        "publishedAt": "2026-10-10T10:00:00Z"
      }
    ],
    "nextCursor": null,
    "facets": {
      "types": [{ "value": "service", "count": 8 }],
      "categories": [{ "id": "category_opaque_id", "count": 5 }]
    }
  },
  "meta": { "requestId": "req_opaque_id", "hasMore": false }
}
```

Only public or actor-authorized data is included. Do not return private seller metrics, buyer identities, unpublished posts, hidden contest entries, raw relevance/risk scores, or protected source-file URLs. Facet counts must be visibility-filtered.

## 29.2 Sorting, filters, and ranking

Default `relevance` blends textual/category fit with policy-approved quality, freshness, availability, and trust signals; it must not reduce ranking to price or badge level. `popular` uses bounded engagement/purchase signals with abuse filtering. `rating` uses a minimum-evidence policy and stable tie-breakers. Price sort is valid only when the selected result types have comparable price semantics; unsupported combinations return `422 SEARCH_SORT_NOT_SUPPORTED`.

Typed filters that do not apply to a requested type are ignored only when unambiguous; otherwise return a field-level `422 FILTER_NOT_APPLICABLE`. Cursor tokens are bound to query, filters, result types, and sort.

## 29.3 Search consistency and errors

Search may be eventually consistent for newly published/edited content or cached facets. It must exclude known-unavailable/sold exclusive listings promptly and revalidate from source before checkout. Search never guarantees that a project/contest is still open or a service is still available.

Errors: `400 QUERY_INVALID`, `422 SEARCH_TYPE_INVALID`, `422 FILTER_INVALID`, `422 FILTER_NOT_APPLICABLE`, `422 SEARCH_SORT_NOT_SUPPORTED`, `429 SEARCH_RATE_LIMITED`, `503 SEARCH_TEMPORARILY_UNAVAILABLE`.

If the search index is unavailable, return a safe retryable error or a supported database-backed fallback for limited queries; do not return stale private records or bypass visibility filtering.

---

## Part 2 Consistency Rules for Part 3

1. Continue `/api/v1` and Part 1's response/error envelopes and field conventions. Do not introduce a second API surface for transaction state.
2. All state-changing endpoints are named commands with participant/resource/state authorization.
3. Payment success is verified server-to-server; provider callbacks are deduplicated and reconciled. Client redirects and status fields are never proof of payment.
4. Universal Order remains authoritative for the commercial lifecycle; Payment, Wallet/Ledger, Delivery/Access, Ownership, Chat, Review, Dispute, Badge, Notification, and Search each own their defined state.
5. Transactional commands use idempotency and database consistency for Order creation, payment linkage, refunds, withdrawals, exclusive ownership, contest winner finalization, entitlements, and access grants.
6. Exclusive Sell Once ownership is permanently recorded; only explicit, authorized transfer processes can change the active owner.
7. Every protected file request rechecks entitlement, payment/order state, file/version scope, and revocation/expiry. Never reveal permanent storage URLs for originals.
8. Analytics, notifications, badges, and search are projections from committed domain events; they cannot mutate financial or ownership truth.
9. Proposal selection remains distinct from Offer acceptance, Order creation, and payment. Contest Entries remain distinct from Proposals.
10. Part 3 should consolidate webhooks/events, search/analytics governance, support/report/admin contracts, rate limits, error conventions, audit/security, and cross-client API lifecycle without changing the endpoints or semantics above.

---

## Handoff Summary for Part 3

Part 3 should complete the same API specification and define:

- shared event and provider webhook contracts, signature/replay verification, event IDs, retries, and reconciliation;
- analytics ingestion and authorized summary APIs;
- support, report, moderation, and scoped Admin routes;
- consistent rate-limit, abuse, audit, error, and API security contracts;
- client compatibility/deprecation details and a complete API domain map.

The Part 3 design must preserve all order/payment/ownership/file/chat/review/notification/search contracts in Sections 15–29 and the Part 1 `/api/v1` baseline.
