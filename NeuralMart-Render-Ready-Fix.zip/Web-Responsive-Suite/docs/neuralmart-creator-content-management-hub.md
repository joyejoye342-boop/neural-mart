# NeuralMart — Creator Content Management Hub

**Document version:** 1.0  
**Route:** `/dashboard/creator/content`  
**Audience:** Creator and Both accounts

---

## 0. Hub Definition

The Content Hub manages everything a creator publishes or prepares for publication:

- Reels and videos
- Thumbnails and graphics
- Portfolio/showcase posts
- Digital products
- Service-linked promotional posts
- Drafts
- Archived content
- Pinned and promoted content
- Source files and reusable assets

It is not a raw file browser. Every item has a publishing purpose, a lifecycle state, an owner, and a measurable outcome.

---

## 1. Content Architecture

### Route tree

```text
/dashboard/creator/content
├── /published
├── /drafts
├── /scheduled
├── /archived
├── /assets
├── /pinned
├── /promoted
└── /:id
    ├── /edit
    ├── /duplicate
    └── /analytics
```

### Content types

| Type | Canonical object | Examples |
|---|---|---|
| Reel/video | Post | Motion design, edit, animation |
| Thumbnail | Post | YouTube thumbnail, campaign thumbnail |
| Graphic | Post | Illustration, brand graphic, UI visual |
| Case study | Post | Before/after, process, outcome |
| Digital product | Product | Template, asset pack, course/tool |
| Service post | Post linked to Service | Service announcement or offer |
| Availability post | Post | Open-for-work update |

Digital products and services remain their own commerce entities. The Content Hub can manage their promotional surfaces and linked media without collapsing them into ordinary posts.

---

## 2. Hub Layout

```text
┌────────────────────────────────────────────────────────────┐
│ Content                                  [Create content]  │
│ Publish, organize, and understand your work                 │
├────────────────────────────────────────────────────────────┤
│ [Published] [Drafts] [Scheduled] [Archived] [Assets]       │
├────────────────────────────────────────────────────────────┤
│ [Search content] [Type ▾] [Status ▾] [Sort ▾] [Filters]    │
├────────────────────────────────────────────────────────────┤
│ [thumbnail] Title                 Published · 1,240 views  │
│            Graphic · Pinned       86 saves                 │
│            [Edit] [Analytics] [•••]                         │
└────────────────────────────────────────────────────────────┘
```

### Desktop

- Table/list view by default for management.
- Optional grid view for visual browsing.
- Right-side detail drawer for quick inspection.

### Mobile

- Card/list view only.
- Filters open in a bottom sheet.
- Actions live in a row overflow menu.
- Create button is sticky or floating only inside the Content Hub.

---

## 3. Content States

### Base lifecycle

```text
Draft
→ Ready to publish
→ Published
→ Archived
```

### Optional states

- Scheduled
- Pinned
- Promoted
- Paused
- Needs changes
- Rejected
- Sold · Locked, for exclusive products
- Deleted/removed, retained only where policy requires

### State meanings

| State | Meaning | Public? |
|---|---|---:|
| Draft | Saved but not public | No |
| Ready to publish | Validated and ready | No |
| Scheduled | Queued for a future date | No |
| Published | Visible on profile/feed | Yes |
| Pinned | Published and prioritized by creator | Yes |
| Promoted | Published with approved promotion placement | Yes, labeled |
| Paused | Temporarily unavailable | Usually no |
| Needs changes | Validation/moderation issue | No |
| Archived | Removed from active profile without deletion | No |
| Sold · Locked | Exclusive product ownership transferred | Yes |

Pinned and promoted are modifiers on Published content, not separate permanent content types.

---

## 4. Create and Edit Flows

### Create flow

```text
Choose content type
→ Add media or select asset
→ Add title/caption/category
→ Link product/service, optional
→ Preview
→ Save draft or publish
```

### Type-specific fields

#### Reel/video

- Video file
- Poster/thumbnail
- Caption
- Duration
- Category
- Captions/alt text
- Optional linked service/product

#### Thumbnail/graphic

- Image or gallery
- Caption/title
- Category
- Alt text
- Optional client/project credit

#### Digital product

- Preview media
- Product title/description
- Price
- Category/tags
- Delivery file(s)
- Ownership model
- Publish state

#### Service post

- Caption
- Promotional media
- Linked service
- Optional offer/availability message
- CTA inherited from service

### Edit rules

- Published edits show a preview and explicit `Save changes`.
- Changes to product files, price, ownership, or service packages require a stronger confirmation.
- Editing a pinned item preserves its pinned state unless the creator removes it.
- Editing does not reset lifetime analytics.
- If moderation is required after a material edit, show `Under review` rather than silently hiding the item.

---

## 5. Duplicate, Archive, and Delete Flows

### Duplicate

`Duplicate` creates a new Draft with:

- copied media references;
- copied caption/title;
- copied category/tags;
- copied linked-object suggestion;
- new analytics identity.

It must not copy published status, pin status, promotion status, ownership state, or reviews.

### Archive

```text
More → Archive
→ Confirm
→ Remove from public surfaces
→ Preserve analytics and history
```

Archived content can be restored as Draft or republished after review.

### Delete

Delete is for content the creator no longer needs. It is separate from Archive and warns that:

- public content disappears;
- links may stop working;
- analytics remain in aggregate where required;
- sold/fulfilled transaction records cannot be deleted from platform history.

For exclusive sold products, deletion is not allowed if it would remove the buyer's ownership record. The item becomes `Sold · Locked` or Archived according to policy.

---

## 6. Pinned and Promoted Content

### Pinned

- Up to three pinned Showcase items.
- One featured item may appear on the public profile Overview.
- Pinning changes order, not analytics or eligibility.
- Owners can reorder or unpin.

### Promoted

Promoted content is an advanced feature and must be labeled:

```text
Promoted
```

Rules:

- Promotion requires content to be published and policy-compliant.
- Promotion cannot bypass moderation.
- Relevance and quality still control placement.
- Promotion analytics are separated from organic analytics.
- A creator cannot promote sold, paused, or misleading items.

MVP can support pinning and defer paid promotion.

---

## 7. Drafts and Asset Handling

### Drafts

Draft list shows:

- content type;
- title or generated placeholder;
- last edited time;
- completion status;
- missing required fields;
- `Continue editing`.

Example:

```text
Untitled service showcase
Draft · 65% complete
Missing: linked service and cover image
[Continue editing]
```

### Source Asset Library

An optional `/assets` area stores reusable creator-owned source files:

- originals;
- exported media;
- thumbnails/posters;
- logos/fonts;
- product delivery files;
- project reference files.

Controls:

- upload;
- rename;
- tag;
- preview;
- replace;
- delete unused asset;
- attach to content.

### Asset safety

- Source assets are private unless attached to a published object.
- Product delivery files are access-controlled separately from public preview media.
- Show file type, size, dimensions, duration, and upload status.
- Virus/malware scanning is required for downloadable files.
- Do not silently overwrite an asset referenced by a published product; create a new version or require explicit replacement confirmation.

Source asset handling can be advanced if storage is not ready for MVP. MVP may allow direct upload per content item.

---

## 8. Filters and Sorting

### Filters

- Type: All, Reel, Thumbnail, Graphic, Case study, Product, Service post
- Status: Draft, Published, Scheduled, Archived, Needs changes
- Linked object: None, Product, Service
- Visibility modifier: Pinned, Promoted
- Date created
- Last edited

### Sort

- Recently edited
- Recently published
- Most viewed
- Most saved
- Most clicked
- Most purchased
- Highest conversion
- Alphabetical

### Saved views

Advanced:

- `Needs publishing`
- `Top performers`
- `Pinned work`
- `Needs changes`
- `Commercial content`

Avoid a filter maze on mobile. Show the active filter count and provide `Clear all`.

---

## 9. Performance per Content Item

Every published item may show a compact performance summary:

```text
Fintech onboarding case study
Graphic · Published 8 days ago
1,240 impressions · 86 saves · 12 profile visits
3 chats · 1 service booking
[View insights]
```

### MVP metrics

- Impressions/views
- Likes
- Comments
- Saves
- Profile visits
- Linked product/service clicks

### Advanced metrics

- Follows
- Chat leads
- Purchases/orders
- Revenue attributed
- Repeat buyer relationship
- Conversion rate
- Organic versus promoted split
- Performance by audience segment

Metrics must show the selected period and attribution definition. A view is not a sale, and a sale may have multiple content touchpoints.

---

## 10. Content Hub MVP vs Advanced

### MVP

- Published/draft/archived tabs
- Create/edit/delete
- Reels, thumbnails, graphics, case studies
- Digital product and service links
- Pin up to three items
- Basic filters/sorting
- Basic per-item performance
- Direct file upload

### Advanced

- Scheduled publishing
- Asset library
- Collections
- Content duplication
- Promotion management
- Versioned product files
- Bulk archive
- Saved views
- Attribution analytics
- Templates and reusable content

## Final rule

The Content Hub should make the creator's work library feel organized and alive: every item has a clear state, a clear next action, and a clear relationship to audience or business outcomes.
