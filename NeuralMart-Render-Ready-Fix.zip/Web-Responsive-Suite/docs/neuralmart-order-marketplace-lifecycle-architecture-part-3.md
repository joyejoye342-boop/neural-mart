# NeuralMart — Order & Marketplace Lifecycle Architecture
## Part 3 of 5: Contracts, Contest Orders, Delivery, Revisions, Cancellations, and Refunds

**Document version:** 1.0  
**Depends on:** Parts 1 and 2  
**Scope:** Project contracts, contest winner orders, universal delivery, revisions, cancellations, and refunds

---

## 0. Continuity Rules

This specification extends the existing architecture:

- One universal Order aggregate remains the system of record.
- Project contracts, contest prizes, services, chat orders, and file deliveries use type-specific extensions.
- Payment, delivery, ownership, revision, refund, dispute, and payout remain separate dimensions.
- Chat is a communication and commerce surface, not a replacement for order or wallet records.
- Exclusive project ownership is assigned atomically and is not silently reversed by a normal refund.
- Active orders preserve the terms purchased at checkout or accepted offer.
- Reviews are tied to verified order history.
- All important transitions are auditable and idempotent.

---

## 1. Project Contract Flow

### 1.1 Definition

A Project Contract is the formal order created when a buyer selects a creator's proposal for a direct project.

It turns a proposal conversation into an enforceable NeuralMart commercial relationship with:

- final price;
- final deadline;
- final scope;
- deliverables;
- assumptions;
- revisions;
- usage rights;
- payment schedule;
- delivery and approval rules.

The project itself remains the buyer's project record. The accepted proposal and contract/order preserve the selected creator's commercial commitment.

### 1.2 Canonical flow

```text
Project
→ Proposal
→ Shortlist
→ Negotiation
→ Selection
→ Final offer/contract
→ Buyer confirmation
→ Payment
→ Project Contract Order
→ Work
→ Delivery
→ Approval/revision
→ Completion
→ Review and payout
```

### 1.3 Proposal acceptance

The buyer can accept a proposal only when:

- the project is still open for selection;
- the proposal is not withdrawn or expired;
- the creator is eligible;
- the proposal version is current;
- the buyer has permission to select;
- the project has not already produced another active contract;
- any required clarifications are resolved.

Selection is not the same as payment. It creates a finalization step:

```text
Proposal selected
→ Final terms review
→ Buyer confirms contract
→ Payment
```

For projects with immediate fixed payment, the finalization and checkout may appear in one flow, but the system still records both selection and payment.

### 1.4 Final price

The final price is the amount in the accepted proposal version or final negotiated offer.

It must include:

- total project price;
- currency;
- milestone amounts, if applicable;
- platform fee treatment;
- taxes or buyer-visible charges;
- add-ons included;
- payment schedule;
- refund/cancellation terms.

The project budget is informational after selection. The accepted proposal/contract amount becomes authoritative.

Price changes after acceptance require:

```text
Change request
→ New contract/offer version
→ Buyer confirmation
→ Updated payment/remaining balance
```

Neither party can silently edit the original accepted price.

### 1.5 Final deadline

The contract records:

- start date;
- expected final delivery date;
- milestone dates;
- buyer dependency dates;
- revision turnaround;
- approved extension dates;
- timezone.

The final deadline must distinguish:

```text
Creator working time
vs.
Buyer dependency time
```

If the buyer has not supplied required information, the order may enter `Awaiting Buyer` and the delivery clock may pause according to the disclosed contract terms.

### 1.6 Final scope

The final scope is a structured snapshot containing:

- outcome;
- deliverables;
- formats;
- quantities;
- included concepts/variants;
- revision rounds;
- source-file status;
- usage/license rights;
- exclusions;
- assumptions;
- dependencies;
- out-of-scope change policy.

Example:

```text
Included:
• 1 logo direction
• Final logo system
• Social avatar exports
• Figma source file
• 2 revision rounds

Not included:
• Website implementation
• Additional brand guidelines
• New campaign concepts
```

### 1.7 Scope confirmation

Before payment, both sides see:

```text
Final project contract
Price: $1,200
Delivery: 7 days after approved requirements
Revisions: 2 rounds
Source files: Included
Usage: Commercial use for buyer brand
```

The buyer confirms:

- price;
- scope;
- deadline;
- payment schedule;
- revisions;
- usage rights;
- cancellation/refund rules.

The creator's accepted proposal version is also preserved.

### 1.8 Contract/order creation

After the required payment succeeds:

1. Create a universal Order with type `project_contract`.
2. Attach the selected project.
3. Attach the accepted proposal version.
4. Store the contract snapshot.
5. Create milestones, if defined.
6. Create the initial payment/ledger records.
7. Link the order to the project conversation.
8. Mark the proposal accepted.
9. Close or update competing proposal states.
10. Notify buyer and creator.

The order becomes the source of truth for fulfillment. The proposal remains the origin and negotiation history.

### 1.9 Milestone support

Each milestone has:

- title;
- scope;
- amount;
- due date;
- required inputs;
- delivery;
- approval rule;
- revision allowance;
- payment state;
- payout state.

Milestone flow:

```text
Milestone funded or authorized
→ Work
→ Milestone delivery
→ Buyer approval/revision
→ Milestone completed
→ Payout eligibility
→ Next milestone
```

The parent project contract completes only when all required milestones are complete or the contract is otherwise resolved.

### 1.10 Communication

The accepted project conversation becomes an order-linked thread with:

- pinned project/order header;
- final scope;
- deadline;
- milestone status;
- requirements checklist;
- delivery history;
- revision actions;
- payment actions;
- dispute/support entry point.

Ordinary messages remain useful for context, but material commercial changes must use structured change requests or offer versions.

### 1.11 Delivery

The creator delivers through the order workspace:

- files;
- previews;
- links;
- notes;
- version number;
- completion checklist;
- license reminder.

A delivery is not complete because a message was sent. The system records a formal delivery event against the relevant milestone or order.

### 1.12 Buyer approval

The buyer can:

- approve delivery;
- request an included revision;
- report incomplete delivery;
- request a scope change;
- open a dispute.

Approval records:

- buyer;
- delivery version;
- timestamp;
- milestone/order;
- remaining revisions;
- payout transition.

### 1.13 Completion and review

The project contract completes when:

- all required milestones are approved;
- the buyer approves the final delivery;
- the review window expires without a valid revision/dispute;
- or a dispute resolution closes the work as fulfilled.

After completion:

- verified review becomes eligible;
- creator earnings become eligible for release;
- project history records the selected creator and outcome;
- buyer can repeat the order or start a related project.

---

## 2. Contest Winner Order Flow

### 2.1 Definition

A Contest Prize Order is the universal Order created when a host selects a contest winner and the funded prize becomes payable to that winner.

It is not a project proposal and does not convert all entrants into sellers.

### 2.2 Canonical flow

```text
Contest
→ Entries
→ Shortlist
→ Finalists
→ Winner selection
→ Winner confirmation
→ Prize order
→ Final delivery/rights confirmation
→ Prize release
→ Ownership/usage transfer, if applicable
→ Completion
```

### 2.3 Winner confirmation

Before winner selection:

- contest funding is verified;
- winner count and prize allocation are fixed;
- judging criteria are complete;
- required finalist work is resolved;
- rights terms are visible;
- host confirms the selection.

Winner selection atomically records:

```text
Contest → Winner selected
Winning entry → Winner
Other finalist entries → Not selected
Prize allocation → Reserved for winner
```

### 2.4 Winner acceptance

The winner receives:

- winner notification;
- prize amount;
- delivery requirements;
- rights/ownership terms;
- source-file requirements;
- acceptance deadline;
- dispute/fallback policy.

The winner can:

- accept;
- decline;
- ask a clarification question;
- submit required final assets;
- report a contest-rule issue.

If the winner does not respond:

- send reminders;
- show the acceptance deadline;
- invoke the pre-published fallback rule;
- move to the next finalist, reopen selection, or cancel/refund as specified.

The host cannot invent a new fallback after the fact.

### 2.5 Prize order creation

When the winner is selected or accepts, depending on contest policy:

1. Create a `contest_prize` Order.
2. Link host as buyer.
3. Link winning creator as seller.
4. Link contest and winning entry.
5. Snapshot prize, rights, deliverables, and schedule.
6. Link the funded prize hold.
7. Create any required delivery or rights records.
8. Create the winner transaction-history record.
9. Notify host and winner.

The host does not pay the winner through an informal chat message. The funded prize and order/ledger records control release.

### 2.6 Prize payment

The prize may already be funded before contest opening. In that case:

```text
Contest prize hold
→ Winner order created
→ Winner confirmation and delivery gates
→ Prize release
→ Seller earnings
```

If the contest uses a later payment step, the same universal payment validation and idempotency rules apply.

The advertised prize remains the creator-facing amount. Platform fees are disclosed separately.

### 2.7 Ownership transfer

Ownership or usage rights transfer only when the published contest rules say so.

Possible rules:

- winner receives usage rights after payout;
- host receives full ownership after source delivery and payout;
- winner grants a defined commercial license;
- winner retains copyright while host receives usage rights;
- no rights transfer until a separate contract.

The order snapshots the selected rights. Non-winning work remains with the creators unless separately purchased or licensed.

### 2.8 Final delivery

The winner submits:

- final asset;
- source files, if required;
- required formats;
- documentation;
- usage/rights confirmation;
- delivery note.

The host can:

- approve;
- request the bounded published revision;
- report missing requirements;
- open a dispute.

Extra work outside the contest rules becomes a separate paid project/order.

### 2.9 Dispute integration

A dispute may concern:

- winner selection;
- rights interpretation;
- missing source files;
- non-payment;
- host misuse;
- creator non-delivery;
- plagiarism or originality;
- safety or policy issues.

The contest, entry, prize order, chat, and funding records remain linked.

During dispute:

- prize funds remain held;
- payout may pause;
- source files remain protected;
- non-winning entries remain unused;
- evidence and judging records are preserved;
- platform support determines the resolution path.

### 2.10 Contest completion

A contest is complete when:

- winner has been confirmed;
- required final delivery exists;
- rights requirements are satisfied;
- prize has been released or resolved;
- dispute window is closed;
- contest result is recorded.

The contest order may complete after the contest record, but both must maintain linked status and audit events.

### 2.11 Creator records

The winning creator receives:

- contest result history;
- winner transaction history;
- earnings record;
- verified contest achievement where applicable;
- portfolio attribution, if the creator permits it;
- linked Showcase/project record, if published.

The creator may show:

```text
Contest winner
Prize paid
```

only after the relevant payout and rights state is confirmed.

---

## 3. Universal Delivery Architecture

### 3.1 Delivery definition

A delivery is a versioned, order-linked transfer of value from seller to buyer.

Supported delivery forms:

- Digital files
- Source files
- Previews
- Links
- Custom assets
- Project deliverables
- Service outputs
- Contest deliverables
- Access credentials or permissions only when safely supported

The delivery record is separate from the chat message, payment transaction, and file storage object.

### 3.2 Delivery object

Every formal delivery includes:

- Delivery ID
- Order ID
- Milestone ID, if applicable
- Sender
- Recipient
- Delivery title
- Delivery note
- Version
- Items
- Preview references
- Access policy
- License/rights summary
- Delivery timestamp
- Review deadline
- Current delivery status
- Replacement/supersession reference

### 3.3 Upload flow

```text
Choose delivery
→ Upload/select asset
→ Virus/malware scan
→ Validate file type/size
→ Generate metadata
→ Generate preview/thumbnail
→ Assign access policy
→ Review delivery contents
→ Send/submit delivery
```

The seller sees:

- file names;
- size;
- type;
- scan state;
- preview;
- recipient;
- order/milestone;
- license;
- lock state.

The buyer sees only what the access policy allows.

### 3.4 File security

Original assets:

- live in private storage;
- have no public permanent delivery URL;
- are accessed through server-authorized short-lived links;
- are scoped to buyer, order, item, and action;
- are checked again when access is requested;
- have access/download events recorded.

Previews:

- are separate assets;
- may be watermarked;
- may be reduced quality;
- do not expose hidden source layers;
- do not become original files after a UI toggle.

The system scans uploads before making them available.

### 3.5 Access control

Before granting original-file access, verify:

1. User identity.
2. Order participation or entitlement.
3. Payment confirmation.
4. Delivery item inclusion.
5. License/access state.
6. Refund/dispute state.
7. File safety state.
8. Any expiration or revocation rule.

Access grant and legal ownership remain distinct:

```text
Access grant = technical retrieval permission
Ownership/license = permitted use
```

### 3.6 Post-payment access

After payment and entitlement activation:

```text
Locked or pending
→ Available
→ Download/open
```

The buyer can access from:

- chat;
- order detail;
- Purchases;
- product detail;
- project/service workspace.

All surfaces use the same order and entitlement authorization.

### 3.7 Versioning

Each delivery version includes:

- version number;
- created timestamp;
- creator/sender;
- changed files;
- change note;
- preview;
- access state;
- supersedes reference.

Examples:

```text
v1.0 Initial delivery
v1.1 Corrected export
v2.0 Scope-approved major revision
```

Replacing a file does not delete the previous version from the audit record.

The buyer's access to an updated version depends on:

- the order terms;
- revision policy;
- product update policy;
- ownership/license;
- refund/dispute state.

### 3.8 Download and access history

Record:

- who accessed;
- item/version;
- action;
- timestamp;
- result;
- revocation state.

The buyer sees useful history:

```text
Downloaded v1.1 · Apr 18
```

Support sees the detailed audit trail.

### 3.9 Delivery timestamp

`Delivered at` is recorded when:

- the seller submits the formal delivery;
- the system validates its required items;
- the buyer is notified;
- the delivery is accessible or properly locked pending payment.

For a paywalled delivery:

- delivery may be submitted while locked;
- the buyer-facing delivery timestamp exists;
- the review clock begins according to the payment/access policy, not before the buyer can reasonably access the paid asset.

### 3.10 Replacement and re-delivery

Use replacement when:

- file is corrupted;
- wrong format was sent;
- a required item is missing;
- a revision is approved;
- a source file is added under scope;
- a contest winner must correct a final asset.

Replacement flow:

```text
Existing delivery
→ Seller creates replacement/version
→ Buyer is notified
→ Buyer reviews new version
→ Old version retained for history
```

Replacement does not automatically reset revision count or extend the deadline unless the policy says it does.

### 3.11 External links

External links must:

- be labeled as external;
- preserve the seller's responsibility for the promised delivery;
- avoid exposing private credentials;
- be replaceable;
- be checked for access where possible;
- remain attached to the delivery version.

NeuralMart should not ask creators to share passwords or private tokens in delivery records or chat.

---

## 4. Revision System

### 4.1 Revision definition

A revision changes an agreed deliverable within the purchased scope.

It does not mean:

- a new deliverable;
- a new creative direction;
- unlimited changes;
- a second project;
- work outside the selected package.

### 4.2 Simple revision states

```text
No revision available
Revision available
Revision requested
Seller reviewing
Revision in progress
Revised delivery sent
Revision accepted
Revision declined/out of scope
```

These are revision dimensions on the order, not replacements for the primary order status.

### 4.3 Allowed revision configuration

Every revisable order states:

- included rounds;
- what counts as one round;
- request deadline;
- seller response expectation;
- delivery turnaround;
- included file/format changes;
- out-of-scope rule.

Simple buyer-facing language:

```text
2 revision rounds included
One round can include a grouped list of changes to the agreed deliverable.
New deliverables require a new offer.
```

### 4.4 Revision request

The buyer submits:

- selected delivery version;
- reason/category;
- grouped change request;
- optional attachment/reference;
- confirmation that the request is within scope.

Suggested reasons:

- Does not match brief
- Missing included item
- Formatting/export issue
- Small content correction
- Agreed style adjustment
- Other

The request is timestamped and consumes a revision round only when accepted as an in-scope revision.

### 4.5 Seller response

The seller can:

- accept and start revision;
- ask a clarification question;
- deliver a corrected version;
- explain that the request is out of scope;
- propose a paid add-on;
- escalate a scope disagreement.

The seller cannot silently mark a valid in-scope request as complete without responding.

### 4.6 Revised delivery

Every revised delivery:

- receives a new version;
- references the prior delivery;
- states what changed;
- updates remaining revision count;
- preserves the original files;
- restarts the buyer review period only for the revised scope where policy permits.

### 4.7 Revision history

The order shows:

```text
Delivery v1.0
→ Buyer requested revision 1
→ Seller delivered v1.1
→ Buyer approved
```

Support and dispute teams can inspect:

- request text;
- attachments;
- seller response;
- delivery versions;
- timestamps;
- scope decision.

### 4.8 Limited revisions

Default for services, custom orders, and project contracts:

- defined finite rounds;
- visible remaining count;
- out-of-scope work requires new pricing.

When revisions are exhausted:

```text
Revision status: Exhausted
```

The buyer can still report incomplete or materially non-conforming delivery. Exhaustion does not allow the seller to deliver something unrelated to the contract.

### 4.9 Unlimited revisions

Unlimited revisions may be offered only when:

- the service explicitly says unlimited;
- the scope remains bounded;
- a reasonable review/request window exists;
- the creator can pause or renegotiate unreasonable scope expansion;
- the listing explains what “unlimited” does not include.

Unlimited does not mean:

- unlimited new concepts;
- unlimited deliverables;
- indefinite open-ended work;
- transfer of unrelated source files.

### 4.10 Type-specific revision rules

#### Digital products

No ordinary revisions. Product file corrections or updates are handled as:

- product version update;
- replacement delivery;
- support correction.

#### Exclusive projects

Revisions apply only if the purchased listing explicitly includes them. Any revision must preserve the Sell Once ownership model.

#### Services

Use package revision count and delivery window.

#### Custom chat orders

Use the accepted offer's revision terms. Plain-text requests cannot add unlimited revisions.

#### Project contracts

Use contract-wide or milestone-specific revision terms.

#### Contests

Only finalist/winner revisions published in the contest rules are included. Extra work becomes a separate paid order.

#### Paid file deliveries

Usually no revision unless linked to a service/project/milestone or explicitly sold as revisable.

---

## 5. Cancellation System

### 5.1 Cancellation definition

Cancellation ends a transaction before its obligations are fully completed. It is different from:

- refund, which reverses money;
- dispute, which reviews a disagreement;
- expiry, which ends an uncompleted time-bound action;
- rejection, which may occur before order creation.

Cancellation records:

- actor;
- reason;
- stage;
- timestamp;
- payment state;
- availability effect;
- ownership effect;
- refund decision;
- evidence.

### 5.2 Universal cancellation reasons

Use a short standardized list:

- Buyer changed plans
- Seller unavailable
- Missing requirements
- Outside scope
- Duplicate order
- Payment issue
- Deadline conflict
- Policy/safety concern
- Mutual agreement
- Platform/system issue
- Other with explanation

### 5.3 Digital products

Before payment:

- buyer can leave checkout;
- no order is created or pending attempt expires;
- product remains Available.

After payment:

- ordinary cancellation is usually not available because access may be instant;
- buyer uses refund/support policy;
- seller cannot cancel a completed sale to remove the buyer's entitlement.

If the product is removed for policy or safety:

- access may be restricted;
- affected buyers receive notice;
- refund/credit follows policy;
- order history remains.

Availability:

- product generally remains Available after each purchase;
- non-exclusive product does not become Sold.

### 5.4 Exclusive projects

Before successful ownership transfer:

- buyer may cancel pending checkout;
- payment authorization is released;
- project remains Available.

After ownership transfer:

- buyer cannot use ordinary cancellation to make the project Available again;
- a refund may reverse payment and revoke access under policy;
- Sold/Locked history remains;
- relisting requires explicit authorized reversal.

The creator cannot cancel merely because another buyer offered more after sale.

### 5.5 Services

Who can cancel:

- buyer within the disclosed pre-work window;
- creator before acceptance or before work starts when permitted;
- either party by mutual agreement;
- platform/support for policy, safety, or material failure.

Before requirements/work:

- cancellation is usually simpler;
- refund is assessed under the listing policy.

After work starts:

- cancellation requires stage-aware review;
- completed work may support partial payment;
- seller costs and delivered value are considered;
- dispute may replace automatic cancellation.

Existing service availability is not changed by cancelling one order unless the creator's capacity changes.

### 5.6 Custom orders

Before offer acceptance:

- either party can decline;
- offer expires without an order;
- no seller earnings or buyer ownership.

After payment:

- cancellation follows the accepted offer terms;
- creator cannot cancel to avoid a poor review or deadline without consequence;
- buyer cannot cancel after receiving completed custom work without the refund policy applying;
- a scope disagreement can become a dispute.

### 5.7 Project contracts

Before payment:

- selection can be withdrawn or contract can expire;
- proposal returns to its prior history state;
- no project contract order is active.

After payment and before work:

- mutual cancellation or policy-based cancellation;
- refund/remaining milestone handling;
- project may reopen only if the buyer explicitly republishes it.

After work begins:

- cancel by mutual agreement;
- cancel for material seller failure;
- cancel for buyer failure to provide dependencies;
- escalate disputed work to support.

Accepted proposals and paid work remain in history even when the project is cancelled.

### 5.8 Contest transactions

Cancellation depends on contest state:

#### Before entries open

- host may cancel;
- prize hold is released/refunded under policy;
- no creator entry rights are affected.

#### After entries open

- host cancellation requires a stated policy reason;
- submitted entries remain creator-owned;
- host cannot use entries;
- creator compensation/refund outcome follows the published rules and platform policy;
- repeated cancellation may affect host trust.

#### After winner selection

- ordinary host cancellation is not allowed;
- winner order enters dispute or support review;
- prize remains held until resolved;
- ownership/rights do not transfer through an informal cancellation.

### 5.9 Paid file delivery

Before payment:

- creator can withdraw the locked delivery;
- buyer can ignore or cancel checkout;
- file remains inaccessible;
- no entitlement exists.

After payment but before access:

- system failure or creator withdrawal may trigger refund;
- access remains locked until resolution.

After access:

- use refund/dispute policy;
- do not erase evidence or transaction history;
- access may be revoked after approved refund.

### 5.10 Automatic cancellation

Automatic cancellation can occur when:

- payment attempt expires;
- offer expires before acceptance;
- creator fails to accept within a disclosed window;
- required buyer information is not supplied after reminders;
- service remains unavailable;
- safety/moderation blocks fulfillment;
- contest funding fails before opening.

Automatic cancellation must:

- notify both sides;
- explain the reason;
- update payment/refund state;
- release reservations;
- record availability effect;
- preserve audit history.

### 5.11 Buyer inactivity

The system should use reminders before action:

```text
Requirement needed
→ Reminder
→ Final reminder
→ Pause/expiry/cancellation under policy
```

Buyer inactivity must not automatically punish the seller if the seller is waiting for required information.

### 5.12 Seller inactivity

The system should:

- show missed milestones/deadlines;
- notify seller;
- notify buyer;
- offer extension or cancellation;
- allow dispute/refund request;
- affect reliability analytics;
- protect buyer payment according to hold policy.

### 5.13 Effect on statuses

Cancellation generally sets:

```text
primaryStatus: Cancelled
```

and separately updates:

- payment status;
- refund status;
- delivery status;
- ownership status;
- payout status;
- availability.

Cancellation never deletes the order.

---

## 6. Refund System

### 6.1 Refund definition

A refund reverses some or all of the buyer's payment according to eligibility, evidence, policy, or platform intervention.

Refunds are financial events linked to:

- order;
- payment transaction;
- wallet ledger;
- seller earnings;
- platform fee;
- delivery/access;
- ownership/license;
- dispute, when applicable.

### 6.2 Canonical flow

```text
Refund Request
→ Eligibility check
→ Review
→ Decision
→ Payment/wallet reversal
→ Order/refund update
→ Access/ownership consequence
→ Notifications and receipt update
```

### 6.3 Refund request

The requester selects:

- order;
- reason;
- amount requested;
- affected delivery/item;
- description;
- evidence;
- preferred resolution.

The platform immediately records the request but does not assume approval.

### 6.4 Automatic refunds

Automatic refunds are appropriate for:

- duplicate successful payment;
- payment captured but order creation definitively failed;
- payment captured after a transaction lost an availability race;
- failed ownership assignment;
- creator/system cancellation before work/access;
- contest funding failure before opening;
- payment confirmed but secure delivery cannot be created;
- repeated technical payment error.

Automatic refunds are idempotent and linked to the original payment attempt.

### 6.5 Manual refunds

Manual review is appropriate for:

- delivered work disagreement;
- partial completion;
- scope mismatch;
- file not as described;
- buyer or seller inactivity;
- service cancellation after work started;
- contest cancellation after entries;
- rights/ownership disputes;
- fraud or safety concerns.

Support/admin decisions must include:

- reviewer;
- decision reason;
- amount;
- evidence considered;
- access/ownership consequence;
- seller/platform fee treatment.

### 6.6 Full refunds

A full refund returns the eligible buyer total or applicable amount and reverses associated financial entries.

Full refund usually means:

- buyer payment reversed;
- seller pending earnings removed;
- released seller earnings recovered where policy permits;
- platform fee reversed or adjusted;
- access revoked where policy permits;
- order refund status set to `Refunded`;
- transaction history retained.

### 6.7 Partial refunds

Partial refunds are appropriate when:

- some milestones were completed;
- some files were accepted;
- some scope was delivered;
- one item in a bundle was missing;
- a service was late but substantially fulfilled;
- a negotiated resolution is reached.

The refund records:

- original total;
- amount refunded;
- remaining seller earnings;
- affected order item/milestone;
- buyer and seller notification;
- revised financial state.

### 6.8 Non-refundable or limited-refund transactions

A transaction may be non-refundable or limited only when:

- the restriction is shown before payment;
- it is lawful and policy-compliant;
- it does not remove remedies for fraud, unauthorized charge, non-delivery, or material misrepresentation;
- support/dispute escalation remains available.

Examples that may have limited change-of-mind refunds:

- instantly downloaded digital products;
- accessed source files;
- exclusive projects after ownership transfer;
- completed custom assets.

Non-refundable does not mean:

- no support;
- no correction for corrupted files;
- no remedy for fraud;
- no dispute process;
- no platform intervention.

### 6.9 Seller approval

Seller approval may be requested for:

- voluntary goodwill refund;
- mutual service cancellation;
- partial scope settlement;
- correction/replacement agreement.

Seller approval is not required for:

- duplicate charge;
- unauthorized transaction;
- system failure;
- platform safety action;
- legal/chargeback response;
- failed ownership assignment;
- material non-delivery where policy authorizes intervention.

The seller cannot block a valid platform refund solely by refusing to click approve.

### 6.10 Platform/admin intervention

Platform/admin can act when:

- evidence is contradictory;
- a user is unresponsive;
- safety/fraud risk exists;
- a payment processor reverses funds;
- a contest or ownership dispute requires preservation;
- the transaction violates policy;
- a technical failure created inconsistent state.

Admin actions are audited and visible at the appropriate level.

### 6.11 Digital product refund consequences

When a product refund is approved:

- entitlement is marked refunded;
- future downloads are blocked where policy permits;
- update access may be revoked;
- downloaded files cannot be retrieved;
- seller earnings are adjusted;
- product sales analytics distinguish gross sales from net sales.

### 6.12 Exclusive project refund consequences

Because Sell Once permanently records exclusivity:

- payment can be refunded;
- buyer access/license may be revoked;
- seller earnings can be reversed;
- the original ownership event remains in history;
- the project does not automatically return to Available;
- a second buyer cannot purchase through ordinary flow.

If NeuralMart ever reopens the project, it requires:

- authorized ownership-reversal decision;
- recorded reason;
- rights/entitlement resolution;
- explicit new listing action;
- new availability and price snapshot.

### 6.13 Service/project refund consequences

For services and project contracts:

- incomplete milestones may be refunded;
- completed accepted milestones may remain payable;
- pending seller earnings may be reduced;
- delivered files may remain evidence;
- access to final licensed assets follows the resolution;
- future work stops unless the contract is resumed.

### 6.14 Contest refund consequences

Contest refund treatment depends on contest state:

- before opening: prize hold may be returned to host;
- after entries: creator rights remain protected and compensation follows published policy;
- after winner selection: prize remains held during dispute;
- after payout: reversal requires dispute, fraud, or rights resolution;
- non-winning entries are never acquired merely because a refund occurs.

### 6.15 Paid file delivery refund consequences

On approved refund:

- order refund state updates;
- entitlement/license may be revoked;
- future access links invalidated;
- download events retained;
- seller earnings reversed or reduced;
- chat shows a system event;
- downloaded files cannot be technically recalled.

### 6.16 Financial/Wallet synchronization

Every refund must produce linked financial records:

```text
Original buyer payment
→ Refund transaction
→ Buyer wallet/processor reversal
→ Seller earnings adjustment
→ Platform fee adjustment
→ Order refund state
```

The wallet must not be updated independently of the order/refund record.

Required invariants:

1. A refund cannot exceed the captured amount.
2. Repeating the refund callback cannot refund twice.
3. Partial refunds sum to no more than the original paid amount.
4. Seller earnings reflect the net settled amount.
5. Platform fees follow the applied refund policy.
6. Receipt and order history show the updated financial state.
7. Chargebacks and external reversals reconcile to the same order.

### 6.17 Refund state and order state

Refund does not erase the primary lifecycle:

```text
primaryStatus: Completed
refundStatus: Partially Refunded
```

or:

```text
primaryStatus: Cancelled
refundStatus: Refunded
```

This keeps the order understandable and supports accurate analytics.

---

## 7. Cross-System Operational Rules

### 7.1 Source of truth

| Concern | Source of truth |
|---|---|
| Commercial terms | Accepted offer/order snapshot |
| Payment | Payment transaction |
| Buyer/seller ledger | Financial ledger/wallet |
| File access | Entitlement/access grant |
| Ownership | Ownership record |
| Delivery | Delivery/version record |
| Revision | Revision record |
| Refund | Refund record |
| Dispute | Dispute record |
| Conversation context | Chat/order link |
| Marketplace visibility | Listing availability state |

### 7.2 No silent deletion

Do not delete:

- completed orders;
- delivery versions;
- revision requests;
- refund decisions;
- contest winner records;
- ownership transfers;
- wallet transactions;
- dispute evidence.

Archive or restrict visibility instead.

### 7.3 Completion is not erasure

An order can be completed and later:

- reviewed;
- refunded;
- disputed;
- partially reversed;
- subject to access revocation.

The original completion event remains.

## Final rule

NeuralMart should turn selection into a durable contract, turn every deliverable into a versioned and permissioned record, and treat cancellation/refund as auditable financial and ownership transitions—not as destructive deletion or a reset of marketplace history.
