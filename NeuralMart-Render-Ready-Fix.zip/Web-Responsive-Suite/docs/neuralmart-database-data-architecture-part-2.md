# NeuralMart — Database & Data Architecture
## Part 2 of 3: Ownership, Orders, Finance, Chat-Commerce, Delivery, Trust, and Platform Operations

**Document version:** 1.0  
**Depends on:** `docs/neuralmart-database-data-architecture-part-1.md`  
**Continues in:** Part 3 — Analytics storage, indexing, security operations, retention, migrations, reliability, and backend data access  
**Scope:** Ownership, universal orders, financial records, chat-commerce, protected delivery, revisions, reviews, reputation, notifications, search, settings, support, policy, integrity, lifecycle, and sensitive data

---

## 0. Continuity Rules from Part 1

Part 2 extends the relational-first hybrid architecture:

```text
PostgreSQL
→ Operational and transactional truth

Object storage
→ Binary file bytes

Search, cache, queues, analytics
→ Supporting and rebuildable systems
```

The following decisions remain unchanged:

- One User identity can have Buyer and Creator capabilities.
- Profile and role-specific extensions do not create duplicate identities.
- Products, Services, Projects, Contests, Posts, and Orders remain separate domain concepts.
- There is one universal Order aggregate with type-specific extensions.
- Chat is a commerce surface, not the source of truth for money or order state.
- Wallet/ledger records are the source of truth for money movement.
- Delivery and entitlement records are the source of truth for protected file access.
- Ownership records are the source of truth for exclusive ownership.
- Feed/search/analytics records are projections or discovery aids, not replacements for source records.
- Historical financial, ownership, order, dispute, and policy records are preserved.

---

# 15. Exclusive Ownership Data Model

## 15.1 Ownership definition

`Ownership` is the durable record that represents exclusive rights or ownership transferred through a successful transaction.

It is separate from:

- Product listing ownership;
- Project authorship;
- file upload ownership;
- buyer access entitlement;
- payment status;
- Order status;
- public Sold/Locked presentation.

The Order records the commercial event. Ownership records the durable right.

## 15.2 Ownership record

Conceptual fields:

- Ownership ID;
- owned object type;
- Product or Project reference;
- buyer/owner User reference;
- previous creator/seller User reference;
- source Order reference;
- source OrderItem reference, when applicable;
- acquisition date;
- effective transfer date;
- ownership status;
- rights/license snapshot;
- access status;
- transfer method;
- transfer reason;
- current ownership indicator;
- reversal/reference to a later ownership event;
- created/updated timestamps.

Supported owned object types:

```text
exclusive_product
exclusive_project
contest_entry
contest_deliverable
custom_asset
```

Only explicitly eligible objects may create an Ownership record.

## 15.3 Ownership status

```text
Reserved
Pending Transfer
Transferred
Locked/Sold
Suspended
Reversed by Authorized Process
Disputed
```

`Reserved` is provisional. `Transferred` and `Locked/Sold` represent committed outcomes.

## 15.4 Ownership history

Do not overwrite the previous owner when ownership changes.

Use:

```text
Ownership
→ OwnershipTransfer
→ OwnershipEvent
```

`OwnershipTransfer` records:

- prior owner;
- new owner;
- actor/system;
- source Order;
- transfer reason;
- rights transferred;
- effective date;
- authorization/reference;
- resulting status.

For Sell Once objects, there is normally one successful transfer. Any later reversal requires a distinct authorized event and must preserve the original sale.

## 15.5 Relationship

The canonical exclusive relationship is:

```text
Project/Product
→ Order
→ OrderItem
→ Ownership
→ Buyer/Owner
```

The seller/creator is preserved on the Order and Ownership record even after transfer.

The buyer receives:

- ownership record;
- rights/license snapshot;
- protected file access;
- receipt and transaction history.

## 15.6 Availability enforcement

Availability must not depend only on a mutable `isAvailable` flag.

Availability is derived from:

- listing/project status;
- policy/moderation status;
- seller authorization;
- successful current Ownership existence;
- active reservation state;
- active order/purchase state;
- exclusive availability rules.

The source object may maintain a denormalized status such as `sold_locked` for fast reads, but the backend rechecks the Ownership and order constraints.

## 15.7 Database guarantees

For an exclusive Product or Project:

- ownership object type and object ID must be valid;
- only one current successful Ownership may exist;
- only one successful exclusive Order may exist;
- the source object cannot transition back to Available through an ordinary refund;
- a successful Ownership and Sold/Locked source update must commit atomically;
- historical ownership events are append-only.

Recommended invariant:

```text
One current transferred ownership
per exclusive object
```

Implement with a database uniqueness rule over the exclusive object reference and current committed ownership state, plus transaction locking during purchase.

## 15.8 Contest ownership transfer

Contest-winning work can transfer rights only when:

- the contest rules defined the rights;
- the winner is selected;
- prize/order requirements are satisfied;
- final delivery is accepted or the contract allows transfer earlier;
- the required payment/prize state is confirmed;
- ownership transfer is authorized.

The relationship is:

```text
Contest
→ ContestEntry
→ ContestWinner
→ ContestPrize Order
→ ContestOwnership
→ Ownership
```

Non-winning entries remain creator-owned unless separately licensed or purchased.

---

# 16. Order Data Model

## 16.1 Universal Order

`Order` is the universal commercial lifecycle record.

Core fields:

- Order ID;
- public order number;
- order type;
- order origin;
- fulfillment mode;
- buyer User;
- seller/creator User;
- optional buyer organization/team;
- optional creator team/agency;
- source Product/Service/Project/Contest/Conversation/Offer references;
- immutable commercial snapshot;
- currency and amounts;
- primary OrderStatus;
- payment status summary;
- fulfillment status summary;
- delivery status summary;
- ownership status summary;
- revision status summary;
- refund status summary;
- dispute status summary;
- payout status summary;
- created/accepted/started/delivered/completed/cancelled timestamps;
- current next-action summary;
- idempotency/reference fields;
- created/updated timestamps.

The Order stores current summaries for fast reads. Specialized records remain authoritative for their domains.

## 16.2 OrderItem

An Order may contain one or more `OrderItem` records.

OrderItem represents a purchased or contracted component:

- product version;
- product license;
- service package;
- project milestone;
- contest prize;
- paid file delivery;
- custom deliverable;
- add-on;
- source-file unlock;
- ownership transfer component.

Fields:

- OrderItem ID;
- Order;
- item type;
- source object reference;
- quantity where relevant;
- title snapshot;
- description/scope snapshot;
- unit amount;
- total amount;
- currency;
- tax/fee allocation;
- fulfillment status;
- delivery requirement;
- ownership/access requirement;
- created timestamp.

OrderItem prevents the core Order from becoming a product-specific or service-specific table while preserving line-level fulfillment and accounting.

## 16.3 Order type extensions

Use one extension table per type only when the type needs additional durable fields:

```text
Order
├── DigitalProductOrder
├── ExclusiveProjectOrder
├── ServiceOrder
├── CustomChatOrder
├── ProjectContractOrder
├── ContestPrizeOrder
└── PaidFileDeliveryOrder
```

Each extension has:

- one-to-one Order reference;
- type-specific source references;
- type-specific state;
- type-specific snapshot;
- no duplicated payment/wallet/refund logic.

## 16.4 Supported order types

### Digital Product Order

References:

- Product;
- ProductVersion;
- ProductLicense;
- ProductPurchase;
- entitlement/access grant.

Normally has instant fulfillment and no seller acceptance.

### Exclusive Project Purchase

References:

- Project;
- exclusive asset/project;
- Ownership;
- buyer access;
- Sold/Locked source state.

Ownership locking and Order creation are transactionally coordinated.

### Service Order

References:

- Service;
- ServicePackage;
- purchased requirements;
- ServiceOrder extension;
- Delivery and Revision records.

### Custom Chat Order

References:

- Conversation;
- Offer;
- accepted OfferVersion;
- PaymentRequest where applicable;
- Delivery and Revision records.

### Project Contract Order

References:

- Project;
- selected ProjectProposal;
- accepted ProposalVersion;
- ProjectContract;
- optional milestones;
- Delivery and Revision records.

### Contest Prize Order

References:

- Contest;
- ContestEntry;
- ContestWinner;
- ContestPrize;
- ContestOwnership where applicable;
- winner delivery.

### Paid File Delivery Order

References:

- Conversation;
- Offer or PaymentRequest;
- LockedFile;
- Delivery;
- entitlement/access grant;
- DownloadRecord.

## 16.5 OrderStatus

Primary status:

```text
Draft
Pending Payment
Paid
Accepted
In Progress
Awaiting Buyer
Awaiting Delivery
Delivered
Revision Requested
Approved
Completed
Cancelled
Expired
```

Overlay statuses:

- payment;
- fulfillment;
- delivery/access;
- ownership;
- revision;
- refund;
- dispute;
- payout.

Do not compress these dimensions into one status field.

## 16.6 Delivery

`Delivery` is linked to an Order and optionally an OrderItem or milestone.

It represents a creator or seller fulfillment submission and owns:

- delivery status;
- delivery note;
- review deadline;
- current version;
- sender/recipient;
- access state;
- completion relationship.

The detailed Delivery model appears in Section 20.

## 16.7 Revision

`Revision` is linked to an Order and usually to a Delivery/version.

It records:

- included/allowed count;
- request;
- response;
- replacement delivery;
- acceptance;
- limit outcome.

The detailed Revision model appears in Section 21.

## 16.8 Cancellation

`Cancellation` records:

- Order;
- requested by;
- actor role;
- reason;
- eligibility decision;
- stage;
- effective timestamp;
- refund relationship;
- delivery/access consequence;
- ownership consequence;
- final decision.

Cancellation does not delete or replace the Order.

## 16.9 Refund

`Refund` records:

- Order;
- Payment;
- requested/approved amount;
- currency;
- reason;
- actor/system;
- refund method;
- status;
- provider reference;
- wallet/ledger entries;
- access/ownership consequence;
- timestamps.

Partial refunds are represented as separate refund allocations or refund items, not by rewriting the original paid amount.

## 16.10 Dispute

`Dispute` is an order-linked integration reference for the future standalone Dispute System.

The Order-facing record includes:

- Order;
- case reference;
- opened by;
- dispute status;
- hold flags;
- claim category;
- buyer/seller response state;
- resolution reference;
- refund/access/ownership consequence references.

Detailed adjudication evidence belongs to the future Dispute System. The Order stores references and lifecycle impact.

## 16.11 Completion

Completion is represented by:

- Order completed timestamp/status;
- completion event/timeline record;
- approved delivery/version;
- payout transition;
- review eligibility;
- access/ownership state;
- completion actor (`buyer`, `system`, `admin`, or rule-based auto-completion).

Completion must not be inferred only from a missing deadline or a Chat message.

## 16.12 Order relationships

```text
User
├── buyer Orders
└── seller Orders

Order
├── OrderItems
├── one type-specific extension
├── Payments
├── Ledger/Transaction references
├── Deliveries
├── Revisions
├── Cancellations
├── Refunds
├── Dispute reference
├── Reviews
├── Conversations
├── Ownership records
└── Timeline events
```

Strong foreign-key integrity is required for the Order, OrderItem, Payment, Refund, Delivery, Ownership, and Review relationships.

---

# 17. Financial Data Model

## 17.1 Financial architecture

Use:

```text
Payment
→ PaymentReference
→ FinancialTransaction/Journal
→ WalletLedgerEntry
→ SellerEarning / PlatformFee
→ Withdrawal or Refund
```

Do not use a mutable wallet balance as the only financial source of truth.

## 17.2 Wallet

`Wallet` represents a user's platform financial account.

Fields:

- Wallet ID;
- User;
- currency;
- wallet status;
- available balance summary;
- pending balance summary;
- held balance summary;
- ledger version/reconciliation marker;
- created/updated timestamps.

The balance summaries are cached projections of ledger entries.

There is one wallet per User/currency/account policy, not separate buyer and seller wallets.

## 17.3 Balance

Balance may be represented as:

- a cached Wallet balance projection;
- a period/currency summary;
- a balance bucket.

Buckets may include:

```text
available
pending
held
reserved
withdrawable
```

No balance bucket is authoritative without the underlying ledger.

## 17.4 Transaction and ledger

`Transaction` should mean a financial journal transaction, not merely a provider callback.

Use a double-entry or balanced journal model:

```text
FinancialTransaction
├── TransactionReference
├── Debit LedgerEntry
└── Credit LedgerEntry
```

Each LedgerEntry contains:

- ledger entry ID;
- journal transaction;
- wallet/account;
- debit/credit direction;
- amount in minor units;
- currency;
- account bucket;
- source type/reference;
- effective timestamp;
- reversal/reference;
- immutable description.

The sum of entries in a financial journal transaction must balance according to the platform's accounting model.

## 17.5 Payment

`Payment` represents the payment lifecycle:

- Payment ID;
- Order;
- buyer;
- amount/currency;
- payment state;
- provider;
- authorization reference;
- capture reference;
- payment attempt count;
- idempotency key;
- failure reason safe for display;
- paid timestamp;
- receipt reference;
- created/updated timestamps.

Payment credentials and raw card details do not belong in this record.

## 17.6 PaymentReference

`PaymentReference` stores opaque external references:

- provider name;
- provider payment intent/reference;
- authorization ID;
- capture ID;
- refund ID;
- webhook/event ID;
- provider status;
- received timestamp;
- reconciliation state.

External references must be unique in the appropriate provider scope to prevent duplicate processing.

## 17.7 SellerEarning

`SellerEarning` represents the seller's economic share of an Order or OrderItem.

Fields:

- SellerEarning ID;
- seller User;
- Order/OrderItem;
- gross amount;
- platform fee allocation;
- payment fee allocation;
- refund/chargeback allocation;
- pending amount;
- eligible amount;
- released amount;
- reversed amount;
- earning status;
- release conditions;
- created/updated timestamps.

SellerEarning is not the same as a Wallet ledger entry. It is a settlement allocation that produces ledger entries when funds move.

## 17.8 PlatformFee

`PlatformFee` records:

- Order/OrderItem;
- fee policy/version;
- fee type;
- amount/currency;
- payer/allocation;
- tax treatment where applicable;
- financial transaction reference;
- created timestamp.

Historical fee calculations are preserved even when platform policy changes.

## 17.9 Withdrawal

`Withdrawal` records a creator's request to move eligible funds out:

- Withdrawal ID;
- User/Wallet;
- requested amount/currency;
- eligibility snapshot;
- destination reference;
- status;
- provider reference;
- hold/risk review state;
- failure reason;
- completed timestamp;
- reversal reference.

Withdrawal destination details should be tokenized/provider-managed where possible.

## 17.10 Refund

Refund connects:

```text
Refund
→ Payment
→ FinancialTransaction
→ Buyer Wallet/Payment reversal
→ SellerEarning reversal
→ PlatformFee reversal
→ Access/Ownership consequence
```

Refunds must be idempotent and allocation-aware.

## 17.11 Financial relationship

```text
Payment
→ Order
→ FinancialTransaction
→ LedgerEntry
→ Buyer wallet debit
→ Seller earning allocation
→ Platform fee allocation
→ Seller wallet pending credit
→ Withdrawal
```

For a refund:

```text
Refund
→ Payment reversal
→ Buyer credit/refund
→ Seller earning reversal
→ Platform fee reversal
→ Access/ownership policy action
```

## 17.12 Financial consistency requirements

Strong transactional consistency is required for:

- payment-to-Order association;
- idempotent payment capture;
- ledger journal creation;
- SellerEarning allocation;
- PlatformFee allocation;
- withdrawal reservation;
- refund allocation;
- payout release;
- contest prize funding;
- exclusive ownership purchase.

External payment provider calls cannot always be in one database transaction. Use:

- idempotency keys;
- provider references;
- pending/reconciliation states;
- transactional outbox/events;
- compensating actions;
- periodic reconciliation.

Never mark a payment, earning, withdrawal, or refund complete solely because a client request returned successfully.

---

# 18. Chat-Commerce Data Model

## 18.1 Conversation

`Conversation` is a participant and context-linked communication thread.

Fields:

- Conversation ID;
- context type;
- source Product/Service/Project/Contest/Offer/Order/Support reference;
- title/subject;
- status;
- moderation/safety state;
- primary order reference where applicable;
- created/updated timestamps;
- archived/muted state.

A conversation can begin before an Order exists.

## 18.2 ConversationParticipant

Fields:

- ConversationParticipant ID;
- Conversation;
- User;
- participant role;
- joined timestamp;
- left/removed timestamp;
- permission state;
- unread/read cursor;
- notification preference.

Participants are explicit so buyer, creator, team member, collaborator, and support roles remain auditable.

## 18.3 Message

`Message` contains:

- Message ID;
- Conversation;
- author;
- message type;
- body or structured payload;
- reply/reference message;
- moderation state;
- created/edited/deleted timestamps.

Message types:

```text
text
system_event
offer
payment_request
delivery_reference
locked_file
order_reference
revision_reference
approval_request
support_reference
```

Structured messages reference authoritative records rather than copying their full state.

## 18.4 MessageAttachment

MessageAttachment connects a Message to Media:

- attachment purpose;
- preview/access state;
- upload status;
- visibility;
- created timestamp.

A Chat attachment is not automatically a buyer entitlement. The message context and access rules determine what the participant may view.

## 18.5 Offer

`Offer` represents a structured commercial proposal:

- Offer ID;
- Conversation;
- sender/recipient;
- source Product/Service/Project/Order context;
- current OfferVersion;
- status;
- expiration;
- accepted/rejected/withdrawn timestamp.

`OfferVersion` preserves:

- price;
- currency;
- scope;
- deliverables;
- deadline;
- revisions;
- rights;
- payment terms;
- add-ons;
- created timestamp.

An accepted Offer does not by itself mean payment succeeded or fulfillment began.

## 18.6 PaymentRequest

`PaymentRequest` is a structured request to pay:

- Offer/Conversation;
- buyer;
- seller;
- amount/currency;
- purpose;
- Order reference once created;
- Payment reference;
- status;
- expiration;
- idempotency key.

PaymentRequest is not the financial ledger. It is the action/request layer.

## 18.7 LockedFile

`LockedFile` represents a protected file or delivery preview presented in Chat:

- LockedFile ID;
- Conversation/Message;
- owner/sender;
- buyer/recipient;
- Media or DeliveryFile;
- safe preview Media;
- required Offer/Payment/Order;
- lock status;
- entitlement/access state;
- expiration;
- created timestamp.

The original file remains governed by Media, Delivery, Entitlement, and AccessGrant records.

## 18.8 DeliveryReference and OrderReference

`DeliveryReference` points from Chat to a Delivery/DeliveryVersion.

`OrderReference` points from Chat to an Order and records:

- relationship kind (`pre_order`, `active_order`, `support`, `post_order`);
- created timestamp;
- actor/system;
- visibility.

## 18.9 Chat-to-commerce sequence

```text
Conversation
→ structured Offer
→ buyer acceptance
→ PaymentRequest
→ Payment
→ universal Order
→ Delivery/LockedFile
→ AccessGrant
→ approval/revision/completion
```

The original pre-order messages remain in the same or linked context. Later OrderReference records associate the conversation with the Order without deleting or rewriting earlier messages.

## 18.10 Conversation transition

Use a `ConversationLink` or context-history record:

- conversation;
- linked context type/reference;
- relationship kind;
- effective-from/effective-until;
- created by;
- created timestamp.

This allows:

```text
Product inquiry
→ Offer negotiation
→ Order fulfillment
→ Post-order support
```

without creating an unrelated duplicate thread or losing history.

Chat cannot independently:

- confirm payment;
- unlock a file;
- transfer ownership;
- mark an Order complete;
- release payout;
- approve a refund.

Those actions use structured commands against authoritative records.

---

# 19. Paywalled File Data Model

## 19.1 Paywall sequence

```text
Upload
→ Private file metadata
→ Safe preview/LockedFile
→ Payment or accepted Order
→ Entitlement/AccessGrant
→ Authorized unlock
→ Download/open history
```

## 19.2 Records

Required relationships:

```text
Media
→ LockedFile
→ Preview Media
→ Order/OrderItem
→ Payment
→ AccessGrant
→ DownloadRecord
```

`LockedFile` stores:

- file owner;
- intended buyer/recipient;
- original Media;
- safe preview;
- required payment/order;
- lock status;
- access policy.

## 19.3 AccessGrant

`AccessGrant` represents permission to open/download a protected file.

Fields:

- AccessGrant ID;
- User;
- Media or DeliveryFile;
- Order/OrderItem;
- Ownership/entitlement reference;
- grant reason;
- scope;
- granted timestamp;
- expires timestamp if applicable;
- revoked timestamp;
- revocation reason;
- current status.

Grant reason examples:

```text
paid_product_entitlement
exclusive_ownership
active_order_delivery
approved_support_access
creator_owner_access
```

## 19.4 Secure access check

Every protected access request verifies:

1. authenticated User;
2. matching AccessGrant/Ownership/creator authorization;
3. valid Order/payment state;
4. no refund, dispute, fraud, or policy block;
5. file belongs to the purchased version/delivery;
6. grant has not expired or been revoked.

The service then issues a short-lived authorized URL or streams through an access-controlled endpoint.

## 19.5 DownloadRecord

`DownloadRecord` records:

- User;
- Media/DeliveryFile;
- Order/AccessGrant;
- timestamp;
- result status;
- client/device metadata limited to security needs;
- bytes/range where useful;
- revocation or policy context.

Download history is an audit signal, not proof that a file was successfully used.

## 19.6 Payment failure and unlock failure

If payment fails:

- no AccessGrant is created;
- LockedFile remains locked;
- failed Payment remains recorded.

If payment succeeds but access creation fails:

- Order/payment enters recoverable pending state;
- an idempotent access-provisioning job retries;
- the buyer sees a pending unlock state;
- support/reconciliation can issue a safe compensating refund if access cannot be granted.

---

# 20. Delivery Data Model

## 20.1 Delivery

`Delivery` is the universal fulfillment container linked to an Order or OrderItem.

Fields:

- Delivery ID;
- Order;
- OrderItem/milestone reference;
- sender/seller;
- recipient/buyer;
- delivery type;
- status;
- delivery note;
- review deadline;
- submitted timestamp;
- approved timestamp;
- completed timestamp;
- current DeliveryVersion;
- access policy;
- created/updated timestamps.

Delivery types:

```text
digital_files
source_files
preview
link
custom_assets
project_deliverable
contest_deliverable
service_output
paid_file_delivery
```

## 20.2 DeliveryVersion

Every material delivery submission is versioned.

Fields:

- DeliveryVersion ID;
- Delivery;
- version number;
- submitted by;
- note;
- status;
- submitted timestamp;
- accepted timestamp;
- replaced timestamp;
- replacement reason;
- checksum/manifest reference;
- review deadline.

Replacing a file creates a new version. It does not delete the prior version.

## 20.3 DeliveryFile

`DeliveryFile` connects a DeliveryVersion to Media:

- DeliveryFile ID;
- DeliveryVersion;
- Media;
- file role;
- display order;
- preview/full state;
- source-file state;
- access level;
- included/license scope;
- created timestamp.

File roles:

```text
preview
final
source
documentation
license
reference
```

## 20.4 AccessGrant

Delivery files use AccessGrant records as defined in Section 19.

Access depends on:

- Order participant relationship;
- payment/entitlement;
- ownership;
- delivery state;
- dispute/refund policy;
- file role.

## 20.5 DownloadRecord

Every protected delivery download/open action can create a DownloadRecord.

This supports:

- buyer download history;
- creator delivery/access support;
- security investigation;
- dispute evidence;
- access revocation analysis.

## 20.6 Delivery ownership

Delivery submission responsibility belongs to the seller/creator or authorized participant. File ownership may remain with the creator or transfer according to the Order/license/Ownership rules.

Delivery does not itself transfer ownership.

## 20.7 Delivery timestamps

Store:

- created;
- submitted;
- viewed;
- downloaded/opened;
- revision requested;
- replaced;
- approved;
- completed;
- access revoked.

Viewed/downloaded timestamps are activity evidence, not automatic approval unless policy explicitly defines auto-completion.

---

# 21. Revision Data Model

## 21.1 Revision

`Revision` is a structured request to change an agreed delivery within the purchased scope.

Fields:

- Revision ID;
- Order;
- OrderItem/milestone;
- source Delivery/DeliveryVersion;
- requester/buyer;
- seller/creator;
- revision number;
- reason/category;
- requested changes;
- scope classification;
- status;
- seller response;
- due date;
- completed DeliveryVersion;
- created/updated timestamps.

## 21.2 Revision statuses

```text
Available
Requested
Seller Reviewing
Accepted/In Progress
Clarification Needed
Delivered
Buyer Accepted
Declined as Out of Scope
Cancelled
Exhausted
```

## 21.3 Revision limits

Order terms store:

- included revision count;
- used count;
- remaining count;
- revision mode;
- revision deadline.

Revision mode:

```text
none
limited
unlimited
custom
```

For unlimited revisions, the database does not use a finite remaining count. It still records all requests, time windows, scope decisions, and status history to prevent abuse and preserve evidence.

## 21.4 Revision relationship

```text
Order
→ Delivery
→ Buyer Revision Request
→ Seller Response
→ Revised DeliveryVersion
→ Buyer Acceptance
```

The seller cannot consume a revision without a valid Order allowance or explicit out-of-scope agreement.

## 21.5 Out-of-scope changes

If a request is outside scope:

- mark it `out_of_scope` or `declined_as_out_of_scope`;
- preserve the buyer request;
- allow a new Offer/add-on/custom Order;
- do not silently increment revision count;
- link any new Order to the original Order as follow-on work.

---

# 22. Review & Rating Data Model

## 22.1 Review

`Review` is an order-linked written assessment.

Fields:

- Review ID;
- related Order;
- author User;
- target User where applicable;
- target object type/reference;
- review context;
- verified status;
- status;
- body;
- submitted timestamp;
- editable-until timestamp;
- moderation state;
- response reference;
- created/updated timestamps.

## 22.2 ReviewAuthor and ReviewTarget

Do not create duplicate identity records named ReviewAuthor/ReviewTarget.

Use:

- `Review.authorUserId`;
- `Review.targetUserId`;
- optional typed target bridge for Product, Service, Project, or Contest.

If a review can address both a creator and a Product/Service:

```text
Review
├── ReviewTargetUser
└── ReviewTargetObject
```

Each target relationship has a target type and target reference with referential integrity through typed tables where possible.

## 22.3 Rating

`Rating` is the structured numeric/category component of a Review.

Fields:

- Rating ID;
- Review;
- overall score;
- category scores;
- delivery/quality/communication dimensions;
- created/updated timestamps.

Rating should not exist without a valid Review.

## 22.4 Review eligibility

Review eligibility requires:

- valid participant relationship;
- eligible completed Order;
- payment/order not invalidated by fraud;
- review window open;
- reviewer has not used the allowed review slot.

## 22.5 Duplicate prevention

Recommended uniqueness:

```text
one active review
per Order
per author
per target
per review context
```

Editing updates the same Review within the allowed window. A new review is not created for every edit.

If business rules allow separate reviews for milestone and final delivery, the uniqueness key includes an explicit review context or milestone reference.

## 22.6 Review effects

Reviews and Ratings may contribute to:

- creator Reputation;
- Service-specific reputation;
- Product rating;
- verified purchase trust;
- BadgeProgress;
- marketplace ranking signals.

They do not directly mutate a public score in an untraceable way. Aggregates must be recalculable from eligible Review/Rating records.

---

# 23. Badge & Reputation Data Model

## 23.1 BadgeDefinition

Defines:

- badge ID;
- key/name;
- description;
- category;
- display rules;
- eligibility policy version;
- evidence requirements;
- public/private visibility;
- active/retired state.

## 23.2 BadgeLevel

Defines progression:

- badge;
- level;
- threshold;
- benefits/perks reference;
- demotion rule;
- display label;
- effective dates.

## 23.3 UserBadge

Represents an assigned badge:

- User;
- BadgeDefinition;
- current BadgeLevel;
- earned state;
- earned timestamp;
- current status;
- evidence period;
- visibility;
- demoted/revoked timestamp;
- calculation version.

The profile displays a projection of UserBadge. It is not the only badge record.

## 23.4 BadgeProgress

Tracks current progress:

- User;
- BadgeDefinition/Level;
- metric key;
- current value;
- required value;
- period;
- progress status;
- last calculated timestamp;
- calculation source/version.

## 23.5 BadgeHistory

Append-only records:

- awarded;
- upgraded;
- demoted;
- revoked;
- restored;
- reason/evidence reference;
- actor/system;
- timestamp.

## 23.6 ReputationScore

Reputation is a derived, context-aware summary:

- User/CreatorProfile;
- context (`creator`, `service`, `product`, `project`);
- score;
- confidence/sample size;
- rating count;
- completed order count;
- reliability indicators;
- calculation version;
- calculated timestamp.

Do not store one unexplained mutable `reputationScore` as the only truth.

## 23.7 Demotion and eligibility

Badge calculations use:

- verified completed orders;
- ratings/reviews;
- on-time delivery;
- cancellations;
- refunds;
- disputes;
- repeat buyer outcomes;
- safety/fraud restrictions.

Normal performance decline should support gradual demotion. Safety/fraud restrictions may trigger immediate suspension or revocation according to policy.

---

# 24. Notification Data Model

## 24.1 Notification

`Notification` is an in-app user-facing event record.

Fields:

- Notification ID;
- recipient User;
- NotificationType;
- source entity type/reference;
- source event reference;
- title/body;
- action route/deep link;
- priority;
- context (`buyer`, `creator`, `system`);
- deduplication key;
- created timestamp;
- expiry timestamp;
- current state.

## 24.2 NotificationType

Types include:

```text
order
chat
project
contest
financial
badge
system
support
security
```

Subtypes should identify material events:

- payment success/failure;
- delivery received;
- revision requested;
- refund decision;
- dispute response needed;
- new proposal;
- contest deadline;
- payout released;
- badge earned.

## 24.3 NotificationPreference

Preferences define:

- notification type;
- channel;
- enabled/disabled;
- quiet hours;
- context;
- urgency override;
- updated timestamp.

## 24.4 NotificationDelivery

Represents a channel attempt:

- Notification;
- channel (`in_app`, `push`, `email`, `sms` where supported);
- provider/reference;
- status;
- attempt count;
- sent/delivered/failed timestamp;
- failure reason;
- retry state.

## 24.5 NotificationReadState

Use per-user read state:

- Notification;
- recipient;
- read timestamp;
- dismissed timestamp;
- action completed timestamp.

Grouped notifications may reference a common source event or grouping key.

## 24.6 Notification rules

Notifications should be:

- generated from authoritative events;
- deduplicated;
- grouped by Order/Conversation/Project;
- actionable;
- context-labeled for Both users;
- quiet for low-value activity;
- retained long enough for the user to understand the event.

Notification delivery failure must not roll back the Order or Payment transaction.

---

# 25. Search & Discovery Data

## 25.1 Searchable entities

At minimum:

- CreatorProfile;
- Profile/creator handle;
- Service;
- ServicePackage summary;
- Product;
- ProductCategory;
- Project;
- Contest;
- Post;
- selected public portfolio/case study content.

Orders, private messages, private buyer attachments, financial records, and dispute evidence are not public discovery documents.

## 25.2 PostgreSQL indexing

Start with relational indexes for:

- active/published status;
- creator/category;
- product/service/project/contest category;
- created/published timestamps;
- price/budget/prize;
- deadline;
- visibility;
- text search where volume allows;
- ownership/availability;
- feed eligibility;
- user relationships.

Use composite indexes based on actual query patterns, such as:

```text
status + publishedAt
creatorId + status
categoryId + status
visibility + createdAt
deadline + status
```

## 25.3 Dedicated search engine

Add a dedicated search index when requirements exceed database search:

- typo tolerance;
- autocomplete;
- faceted filtering;
- relevance ranking;
- synonym support;
- large catalog scale;
- semantic or vector search;
- personalized ranking.

Search documents should include:

- source ID/type;
- searchable text;
- public profile/listing metadata;
- category/skill facets;
- ranking features;
- indexed status;
- source version;
- updated timestamp.

## 25.4 Search consistency

PostgreSQL remains authoritative. Search updates happen through an outbox or change-event process.

When the index is stale:

- a new listing may appear late;
- a removed listing must be removed or blocked at read time;
- access/security checks still run against PostgreSQL;
- search results never grant permission or ownership.

## 25.5 Ranking and recommendations

The data model supports future ranking through:

- content freshness;
- quality/reputation signals;
- category/skill relevance;
- availability;
- price/budget fit;
- engagement;
- conversion;
- creator diversity;
- buyer intent;
- repeat behavior.

Recommendation output is a derived candidate/ranking layer. It must not mutate the source Post, Product, Service, Project, or Contest records.

---

# 26. Settings & Account Data Model

## 26.1 Modular settings

Use one Settings/Preference aggregate with focused modules, not one unstructured profile blob.

```text
User
├── AccountSettings
├── PrivacySettings
├── NotificationSettings
├── SecuritySettings
├── PaymentSettings
├── PayoutSettings
├── ContentPreferences
├── LanguageCurrencyPreferences
└── LinkedAccounts
```

Each module may be a one-to-one table or versioned preference record depending on access/security needs.

## 26.2 AccountSettings

Contains:

- display/account defaults;
- active context;
- onboarding state;
- deactivation request state;
- profile discoverability;
- creator pause preference;
- time/date presentation preference.

## 26.3 PrivacySettings

Contains:

- public profile visibility;
- follower/message permissions;
- activity visibility;
- order/review display choices;
- personalized recommendation preference;
- data export/deletion preference;
- blocked users reference through Block records.

## 26.4 NotificationSettings

References NotificationPreference records for:

- order;
- chat;
- projects;
- contests;
- finance;
- badges;
- system;
- marketing where applicable.

## 26.5 SecuritySettings

Contains:

- security event preferences;
- session management references;
- multi-factor status reference;
- login alerts;
- account recovery state.

Secrets and authentication credentials remain in managed authentication systems.

## 26.6 PaymentSettings

Contains safe references:

- preferred payment method token/reference;
- billing address reference;
- receipt preferences;
- tax profile reference where needed.

Do not store raw card/bank credentials.

## 26.7 PayoutSettings

Contains:

- payout eligibility state;
- payout provider/account token;
- payout currency;
- payout schedule;
- verification status;
- withdrawal limits/holds.

Sensitive payout destination data should remain provider-tokenized.

## 26.8 ContentPreferences

Contains:

- categories;
- skills;
- followed topics;
- feed preferences;
- language/content safety preferences;
- recommendation exclusions.

It must not override hard privacy, block, moderation, or policy rules.

## 26.9 Language/CurrencyPreferences

Contains:

- display language;
- locale;
- timezone;
- display currency;
- number/date formatting.

Stored financial amounts retain their original transaction currency.

## 26.10 LinkedAccounts

Stores:

- provider;
- external subject/reference;
- purpose;
- verification state;
- linked timestamp;
- unlink timestamp.

Never store provider access tokens unless the integration security design explicitly requires secure encrypted storage and rotation.

## 26.11 Menu/Control Center

Settings are searchable by destination/category:

```text
Account
Privacy
Security
Buying
Selling
Payments
Payouts
Notifications
Content
Language and currency
Support and policies
```

The Menu is a navigation layer over modular settings, not a separate data model.

---

# 27. Support, Reports & Moderation Data

## 27.1 SupportTicket

`SupportTicket` contains:

- Ticket ID;
- requester User;
- category;
- priority;
- status;
- assigned team/agent;
- source context;
- linked Order/Payment/Delivery/Conversation/Project/Contest reference;
- SLA timestamps;
- resolution summary;
- created/updated/closed timestamps.

Support tickets are separate from ordinary Chat conversations, though they may link to one.

## 27.2 TicketMessage

Contains:

- ticket;
- author/agent;
- body;
- attachments;
- internal/public visibility;
- created timestamp;
- moderation/security state.

Internal notes are never exposed through the buyer/creator conversation automatically.

## 27.3 Report

`Report` records a user complaint or safety report:

- Report ID;
- reporter User;
- target type/reference;
- category;
- description;
- evidence references;
- status;
- severity;
- assigned reviewer;
- resolution;
- created/updated timestamps.

Supported targets:

- User;
- Post;
- Product;
- Service;
- Project;
- Contest;
- Message;
- Conversation;
- Order;
- Delivery/File;
- Review.

## 27.4 ReportTarget

Use typed target relationships or a controlled target-reference layer. Core targets should use foreign-key-backed tables where possible.

Do not allow a report to become invalid just because the target is later hidden; preserve the target reference and a historical snapshot sufficient for review.

## 27.5 ModerationAction

Contains:

- action ID;
- actor/admin/service;
- target;
- action type;
- reason/policy reference;
- duration;
- effective timestamp;
- expiry timestamp;
- appeal/reference;
- created timestamp.

Actions:

```text
hide
limit
remove_from_feed
unpublish
quarantine_file
restrict_account
pause_listing
freeze_payout
revoke_access
remove_review
```

## 27.6 UserRestriction

Contains:

- User;
- restriction type;
- scope;
- reason;
- start/end;
- actor;
- appeal state;
- active status.

Restriction scopes may include:

- login;
- buying;
- selling;
- publishing;
- messaging;
- payout;
- contest participation;
- file access.

## 27.7 ContentRestriction

Applies to Post/Product/Service/Project/Contest/Media/Delivery:

- target;
- restriction status;
- reason;
- moderation policy version;
- effective period;
- appeal state.

## 27.8 Moderation and historical records

Moderation should change visibility, availability, access, or permissions through an explicit action. It should not hard-delete:

- completed orders;
- payment records;
- ownership;
- financial ledger entries;
- dispute evidence;
- legal/compliance records;
- required audit events.

---

# 28. Policy & Compliance Data

## 28.1 PolicyVersion

Defines:

- policy ID/key;
- version;
- policy type;
- content/reference;
- effective-from timestamp;
- retired timestamp;
- locale;
- required audience;
- created/approved metadata.

Policy types:

```text
terms_of_service
privacy_policy
marketplace_rules
seller_terms
buyer_terms
contest_rules
license_terms
refund_policy
community_guidelines
```

## 28.2 PolicyAcceptance

`PolicyAcceptance` records a user's acceptance event:

- acceptance ID;
- User;
- PolicyVersion;
- acceptance type;
- timestamp;
- source surface;
- IP/device/audit metadata as legally appropriate;
- withdrawal/expiry state if applicable.

## 28.3 UserPolicyAcceptance

If compatibility or reporting requires a separate relationship table:

```text
UserPolicyAcceptance
→ User
→ PolicyVersion
→ PolicyAcceptance
```

Do not overwrite a prior acceptance when a policy changes.

## 28.4 Terms acceptance

At purchase/order/contest/product publication, preserve the relevant accepted policy/license versions in the commercial snapshot:

- buyer terms version;
- seller terms version;
- product license version;
- contest rules version;
- refund/cancellation policy version.

A later policy update does not rewrite the historical Order.

## 28.5 Compliance retention

Acceptance records may need longer retention than ordinary profile data. Retention depends on applicable law and platform policy, but deletion workflows must not erase required proof that terms were accepted for a historical transaction.

---

# 29. Relationships & Referential Integrity

## 29.1 Identity relationships

```text
User 1 ── 1 Profile
User 1 ── many UserRole/UserCapability
Profile 1 ── 0/1 CreatorProfile
Profile 1 ── 0/1 BuyerProfile
CreatorProfile 1 ── 0/1 FreelancerProfile
User 1 ── many Verification
User 1 ── many UserBadge
```

Critical foreign keys:

- Profile → User;
- role/capability → User;
- creator/buyer extension → Profile/User;
- verification → User.

## 29.2 Relationship and trust

```text
User 1 ── many Follow
User 1 ── many Block
User 1 ── many Report
User 1 ── many Review as author
User 1 ── many Review as target
User 1 ── many ReputationScore
```

Use uniqueness rules for:

- one active Follow per follower/following pair;
- one active Block per blocker/blocked pair;
- one active review per permitted order/reviewer/target/context.

## 29.3 Creator relationships

```text
CreatorProfile 1 ── many Post
CreatorProfile 1 ── many Product
CreatorProfile 1 ── many Service
User 1 ── many ProjectProposal
User 1 ── many ContestEntry
User 1 ── many seller Orders
```

Do not copy Profile identity into every listing as mutable user data.

## 29.4 Content relationships

```text
Post 1 ── many PostMedia
Post 1 ── many Comment
Post 1 ── many Reaction
Post 1 ── many Share
Post 1 ── many typed ContentLinks
Media 1 ── many typed attachment relationships where permitted
```

Comments and reactions require a valid source post/content record. Soft-deleted content may remain referenced for moderation/history.

## 29.5 Project relationships

```text
Buyer/User 1 ── many Project
Project 1 ── many ProjectAttachment
Project 1 ── many ProjectProposal
ProjectProposal 1 ── many ProposalVersion
Project 1 ── many ProjectShortlist
Project 1 ── 0/1 ProjectSelection
Project 1 ── 0/1 ProjectContract
ProjectContract 1 ── 1 Order
Project 1 ── many Conversation links
```

Critical rules:

- shortlist references a ProjectProposal;
- selection references the selected proposal/version;
- Order references the accepted contract/proposal;
- historical proposals cannot be deleted because a creator was not selected.

## 29.6 Contest relationships

```text
Buyer/User 1 ── many Contest
Contest 1 ── many ContestEntry
ContestEntry 1 ── many ContestEntryFile
Contest 1 ── many ContestShortlist
Contest 1 ── 0/1 ContestWinner
Contest 1 ── 1 ContestPrize
ContestWinner 1 ── 1 Contest Prize Order
ContestWinner 1 ── 0/1 ContestOwnership
```

Critical rules:

- one valid winner selection per contest unless contest rules explicitly allow multiple winners;
- entries remain linked after selection;
- rights transfer is separate from winner selection.

## 29.7 Product/service relationships

```text
Creator 1 ── many Product
Product 1 ── many ProductVersion
ProductVersion 1 ── many ProductFile
Product 1 ── many ProductPreview
Product/ProductVersion 1 ── many ProductLicense
ProductPurchase ── Order

Creator 1 ── many Service
Service 1 ── many ServicePackage
Service 1 ── many ServiceMedia
Service/Package 1 ── many ServiceRequirement
ServiceOrder ── Order
```

Critical rules:

- ProductPurchase references a valid Order;
- ServiceOrder references a valid ServicePackage snapshot;
- archived listings do not invalidate historical purchases/orders.

## 29.8 Order relationships

```text
Order 1 ── many OrderItem
Order 1 ── many Payment
Order 1 ── many Delivery
Order 1 ── many Revision
Order 1 ── many Refund
Order 1 ── 0/1 Dispute reference
Order 1 ── many Review
Order 1 ── many OrderTimelineEvent
Order 1 ── many Conversation links
Order 1 ── 0/1 Ownership or many Ownership events
```

Critical foreign keys:

- Payment → Order;
- Refund → Payment/Order;
- Delivery → Order/OrderItem;
- Review → Order;
- Ownership → Order;
- Order type extension → Order.

## 29.9 Wallet relationships

```text
User 1 ── many Wallet by currency/policy
Wallet 1 ── many LedgerEntry
FinancialTransaction 1 ── many LedgerEntry
Payment 1 ── many FinancialTransaction references
SellerEarning ── Order/OrderItem
Withdrawal ── Wallet
Refund ── Payment/FinancialTransaction
PlatformFee ── Order/OrderItem/FinancialTransaction
```

Ledger entries must not exist without a valid journal transaction and wallet/account reference.

## 29.10 Conversation relationships

```text
Conversation 1 ── many ConversationParticipant
Conversation 1 ── many Message
Message 1 ── many MessageAttachment
Conversation 1 ── many Offer
Offer 1 ── many OfferVersion
PaymentRequest ── Offer/Conversation
Conversation 1 ── many OrderReference/ConversationLink
Message ── DeliveryReference/LockedFile/OrderReference
```

Historical messages remain associated with the Conversation even when the context evolves.

---

# 30. Data Consistency Requirements

## 30.1 Strong consistency operations

The database must use strong transaction boundaries for:

- payment-to-Order creation;
- exclusive Product/Project purchase;
- Ownership assignment;
- duplicate purchase prevention;
- Wallet ledger journal creation;
- SellerEarning allocation;
- PlatformFee allocation;
- withdrawal reservation/release;
- refund allocation;
- contest prize funding;
- contest winner selection where payment/ownership is involved;
- entitlement/access grant creation after payment;
- order completion/payout transition where money is released.

## 30.2 Idempotency

Every external or retryable command needs an idempotency key:

- payment creation;
- webhook processing;
- Order creation;
- ownership assignment;
- refund;
- withdrawal;
- payout release;
- access grant provisioning;
- notification emission;
- analytics event ingestion.

The database stores the key and successful result reference within the relevant scope.

## 30.3 Duplicate order prevention

Prevent duplicate Orders through:

- client/server idempotency key;
- unique payment/order provider reference;
- source-specific purchase uniqueness;
- pending attempt lookup;
- transactional source-object checks;
- safe retry returning the existing result.

For ordinary repeatable products, multiple legitimate Orders may exist. The uniqueness rule must be type-specific rather than globally forbidding a buyer from buying a product twice.

## 30.4 Duplicate payment prevention

Prevent duplicate Payment processing through:

- unique provider event/reference;
- unique idempotency key;
- payment attempt status;
- immutable capture result;
- webhook deduplication;
- reconciliation of unknown outcomes.

## 30.5 Race conditions

Use:

- row locks or atomic compare-and-set for exclusive availability;
- unique constraints for ownership;
- serializable or appropriately isolated transactions for money/ownership critical sections;
- state-transition validation;
- retry on serialization conflicts;
- bounded reservations with expiry;
- reconciliation workers for external state.

## 30.6 Wallet consistency

Never update a balance without a corresponding ledger journal.

Preferred flow:

```text
Validate command
→ create balanced journal
→ create ledger entries
→ update cached Wallet balance
→ commit
```

If cached balance update fails, the transaction fails or is repaired from the ledger. The cache cannot silently diverge.

Periodic reconciliation compares:

- ledger totals;
- Wallet balance projection;
- Payment/SellerEarning totals;
- Withdrawal totals;
- Refund/reversal totals.

## 30.7 Orphan prevention

Use:

- foreign keys;
- not-null constraints for required relationships;
- transactionally created parent/child records;
- deferred validation only when necessary;
- cleanup/reconciliation jobs for external object storage;
- explicit pending/quarantine states rather than partially valid records.

Examples:

- Payment cannot exist without an Order or valid payment-attempt context.
- Refund cannot exist without a Payment/Order allocation.
- DeliveryFile cannot exist without a DeliveryVersion and Media.
- Ownership cannot become transferred without an Order/authorized source.
- Review cannot become verified without an eligible Order.
- AccessGrant cannot become active without an authorized entitlement/ownership/order relation.

## 30.8 Outbox and asynchronous work

Notifications, search indexing, analytics, and some file processing may run asynchronously.

Use an outbox/event record written in the same transaction as the source state change:

```text
Order/payment state + outbox event
→ commit
→ worker publishes/processes event
```

Consumers must be idempotent. Async failure must not create false financial or ownership state.

---

# 31. Data Lifecycle

## 31.1 User deactivation

When a User deactivates:

- login/activity may be disabled;
- public profile may be hidden or labeled unavailable;
- active listings may pause;
- new orders may be blocked;
- existing orders continue or enter a support review;
- wallet/financial obligations remain;
- ownership remains;
- reviews/orders/history remain;
- private access is revoked according to policy;
- support/legal retention continues.

## 31.2 User deletion

Deletion is a controlled/anonymization workflow.

Potentially removable:

- profile presentation data;
- optional preferences;
- non-required drafts;
- public identifiers according to policy.

Retained or anonymized:

- Orders;
- Payments;
- Wallet ledger;
- Ownership;
- Withdrawals;
- Refunds;
- Disputes;
- verified Reviews;
- PolicyAcceptance;
- audit/security records;
- legal/tax records.

Historical buyer/seller references may become `Deleted User` while retaining a stable internal subject/reference.

## 31.3 Post deletion

Post deletion:

- removes it from eligible feeds/search;
- hides public content;
- preserves moderation/report references;
- may retain a tombstone;
- does not delete associated completed Order, Review, or policy evidence;
- may retain required comments/reactions in anonymized form.

## 31.4 Order completion

After completion:

- active fulfillment actions close;
- delivery remains accessible under license/ownership;
- review window opens;
- payout becomes eligible according to rules;
- timeline remains immutable;
- refunds/disputes may remain possible within policy;
- analytics event is emitted.

Completed Orders are never hard-deleted as ordinary cleanup.

## 31.5 Product archival

Archiving a Product:

- prevents new purchases;
- removes or limits discovery;
- preserves historical ProductVersion, ProductLicense, ProductPurchase, Order, Review, and access records;
- preserves buyer update/access rights according to the purchased policy;
- does not change prior license terms.

## 31.6 Project sold/contracted

When a Project receives a selected creator/contract:

- proposal submission may close;
- Project status moves to selected/in progress;
- accepted ProposalVersion and ProjectContract are preserved;
- related Order becomes fulfillment truth;
- public availability changes;
- unrelated proposal history remains.

If the Project is exclusive and sold:

- Ownership is created;
- availability becomes Sold/Locked;
- ordinary refund does not silently relist it.

## 31.7 Contest ends

When a Contest ends:

- entries remain historical;
- judging/winner/prize states continue;
- non-winning entries remain creator-owned;
- winner Order and ownership/right transfer continue until resolved;
- public contest presentation changes to completed/archived;
- dispute and evidence records remain.

## 31.8 File deletion

Deleting a file requires checking:

- active ProductVersion;
- completed Orders;
- Delivery;
- Ownership;
- AccessGrant;
- dispute/support evidence;
- legal retention;
- backup/retention policy.

Often the correct action is:

```text
Archive/Quarantine
→ Revoke new access
→ Preserve historical reference
→ Retain required bytes or evidence
```

Hard-delete only when no legal, financial, ownership, dispute, product, or delivery requirement remains.

## 31.9 Dispute resolution

When a dispute resolves:

- preserve the case and evidence references;
- append resolution;
- apply refund/partial refund;
- update SellerEarning/PlatformFee/Wallet;
- update AccessGrant/Ownership if required;
- release or maintain payout hold;
- update Order overlay;
- notify participants;
- emit analytics event.

Resolution does not erase the underlying Order or timeline.

## 31.10 Deletion categories

| Action | Use |
|---|---|
| Hard deletion | Disposable drafts/temporary records with no required references |
| Soft deletion | User content or records that must disappear from normal views but remain referenced |
| Archival | Completed/inactive marketplace content and historical listings |
| Anonymization | Personal identity removal while preserving transaction evidence |
| Quarantine | Safety, malware, legal, or moderation hold |
| Retention | Financial, ownership, legal, dispute, and policy records |

---

# 32. Security & Sensitive Data

## 32.1 Sensitive categories

Sensitive data includes:

- authentication/security data;
- email/phone and personal identity information;
- identity verification documents;
- payment references and billing information;
- wallet balances and financial ledger;
- payout destination details;
- private messages;
- private project attachments;
- source files and paid delivery files;
- ownership/license records;
- dispute evidence;
- moderation notes;
- security logs;
- policy/compliance evidence.

## 32.2 Authentication data

The application should store only:

- managed authentication subject;
- provider;
- session/security references;
- verification summary;
- audit timestamps.

Do not store:

- plaintext passwords;
- raw provider access tokens;
- session secrets;
- private keys;
- password reset secrets after use.

## 32.3 Payment information

Do not store full card numbers, CVV, or raw bank credentials.

Store:

- provider token/reference;
- payment intent/reference;
- authorization/capture/refund references;
- safe display label;
- billing metadata required for receipts/compliance.

Provider-hosted/tokenized payment methods are preferred.

## 32.4 Wallet and financial records

Protect financial records with:

- least-privilege access;
- role-scoped queries;
- audit logs;
- encryption at rest/in transit;
- immutable ledger entries;
- restricted admin access;
- separate payout destination controls;
- reconciliation alerts.

Users can view their own records. Admin access is purpose-scoped and audited.

## 32.5 Private files

Private files require:

- private object-storage location;
- no permanent public URL;
- short-lived signed/authorized access;
- AccessGrant/Ownership validation;
- malware and content scanning;
- checksum verification;
- access/download audit;
- revocation support;
- separation of preview and original.

## 32.6 Personal information

Use:

- data minimization;
- field-level access controls where appropriate;
- encrypted sensitive columns;
- redacted logs;
- retention/deletion policy;
- export/deletion workflow;
- no unnecessary duplication across role tables.

## 32.7 Private messages and project material

Private messages, requirements, source files, and buyer attachments are visible only to:

- authorized conversation/order participants;
- explicitly permitted collaborators;
- scoped support/admin users;
- security/moderation systems with audited access.

Public feed/search projections must not leak private conversation or order references.

## 32.8 Identity verification

Identity verification records should contain:

- provider/reference;
- verification status;
- verification type;
- timestamps;
- risk/review state.

Identity documents should remain in a dedicated protected storage/workflow, not ordinary profile tables. Keep only the minimum application reference and retention metadata.

## 32.9 Security boundaries

Backend data access must enforce:

- User ownership/participant checks;
- role/capability checks;
- object visibility;
- order relationship;
- entitlement/ownership;
- support case assignment;
- admin audit scope.

Frontend-hidden fields are not protection.

---

# Database Transaction & Integrity Decisions

These rules must be preserved in Part 3 and ultimately in the Backend Architecture:

1. PostgreSQL remains the operational source of truth for all relational and transactional records.
2. Object storage contains binary bytes; Media, DeliveryFile, ProductFile, and AccessGrant metadata remains relational.
3. A successful exclusive purchase creates one durable Ownership record and one Sold/Locked outcome.
4. A uniqueness invariant prevents more than one current transferred Ownership for an exclusive Product/Project.
5. Ownership assignment, Order creation, payment association, and Sold/Locked availability update must be coordinated atomically or through an explicit recoverable reconciliation state.
6. Ordinary refunds never silently delete ownership history or relist exclusive work.
7. One universal Order supports all current order types through OrderItem and one type-specific extension.
8. Payment, wallet ledger, delivery/access, ownership, refund, dispute, payout, and review are separate authoritative concerns.
9. Wallet balances are projections; balanced immutable ledger entries are the financial source of truth.
10. Payment provider callbacks and financial commands are idempotent and deduplicated by provider reference and idempotency key.
11. Seller earnings and platform fees are allocations tied to Order/OrderItem and produce ledger entries when money moves.
12. Chat can link a pre-order conversation to an Order without rewriting messages, but Chat cannot define payment, delivery, ownership, refund, or completion state.
13. Structured Offers and PaymentRequests lead to Payments and Orders; plain Chat text does not.
14. Protected file access requires an active AccessGrant, entitlement, ownership, or authorized participant relationship on every request.
15. Delivery files are versioned; replacing a delivery never deletes the prior delivery version.
16. Revision allowance is enforced from the Order snapshot and structured Revision records, including explicit support for unlimited revisions.
17. Reviews are verified through eligible completed Orders and are unique per reviewer/target/order/context unless an explicit business rule allows otherwise.
18. Reputation and badge values are derived from review/order evidence and remain recalculable; they are not static profile labels.
19. Notifications, search indexing, and analytics use transactional outbox/event patterns and cannot mutate source financial or ownership truth.
20. Search results never grant access, ownership, payment, or permission.
21. Support and moderation change visibility, restrictions, access, or workflow state through explicit records; they do not erase material history.
22. Policy and license acceptance is versioned and snapshotted into relevant orders and transactions.
23. User deactivation/deletion cannot cascade-delete Orders, Payments, Wallet ledger entries, Ownership, Reviews, Disputes, or compliance records.
24. Soft deletion, archival, anonymization, quarantine, and hard deletion are distinct operations.
25. Strong consistency is required for payment, wallet journal creation, exclusive purchase, ownership transfer, Order creation, refunds, withdrawals, prize funding, and access-grant creation.
26. Part 3 must define the indexing, event/outbox, reconciliation, migration, backup, retention, observability, and backend data-access implementation around these invariants.
