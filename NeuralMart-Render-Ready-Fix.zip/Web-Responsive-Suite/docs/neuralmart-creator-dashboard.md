# NeuralMart — Creator Dashboard / Creator Operating System

**Document version:** 1.0  
**Scope:** Dedicated creator business management area for Creator and Both accounts.  
**Primary route:** `/dashboard/creator`

---

## 0. Product Definition

The Creator Dashboard is NeuralMart's operating system for running creative work:

- publish and manage content;
- sell products and services;
- fulfill orders;
- respond to projects;
- track earnings;
- understand audience and performance;
- grow creator reputation.

It is more advanced than the public profile, but it should not feel like an administrative back office. The guiding rule is:

> **Show what needs attention first, then show what is working, then make the next business action obvious.**

The current Creator Hub already establishes useful foundations: earnings, active orders, profile views, followers, revenue over time, recent orders, reputation, and badges. This architecture keeps those concepts while organizing them into a focused dashboard system.

---

## 1. Dashboard Architecture

### Route tree

```text
/dashboard/creator
├── /orders
│   ├── /active
│   ├── /completed
│   └── /:id
├── /content
│   ├── /posts
│   ├── /new
│   ├── /drafts
│   └── /analytics
├── /services
│   ├── /active
│   ├── /new
│   └── /:id
├── /products
│   ├── /active
│   ├── /new
│   └── /:id
├── /opportunities
│   ├── /proposals
│   ├── /contests
│   └── /saved
├── /earnings
│   ├── /overview
│   ├── /transactions
│   └── /payouts
├── /audience
├── /insights
├── /reputation
└── /settings
```

The first release does not need every route as a separate page. The navigation and information model should be stable so advanced features can be added without redesigning the shell.

---

## 2. Dashboard Navigation

### Desktop sidebar

```text
Creator Dashboard

Overview
Orders
Content
Services
Products
Opportunities
Earnings
Audience
Reputation

──────────────
View public profile
Creator settings
```

Keep the primary navigation to nine items maximum. `Insights` can be a section inside Audience/Reputation in MVP and become a top-level destination later.

### Mobile navigation

Use a compact four-item dashboard bar plus a More menu:

```text
Overview · Orders · Content · Earnings · More
```

More contains:

- Services
- Products
- Opportunities
- Audience
- Reputation
- View public profile
- Creator settings

Do not use the global app navigation and creator dashboard navigation as two competing full tab bars. The global app shell navigates between products; the dashboard shell navigates within creator operations.

### Both users

Both users keep the same Creator Dashboard. A small context switcher lets them move to the Buyer Dashboard:

```text
Selling view  ·  Buying view
```

This changes the dashboard destination, not the stored role and not the available account capabilities.

---

## 3. Dashboard Home Page

### First-screen goals

The dashboard home should answer:

1. What needs my attention?
2. How is my creator business doing?
3. What should I do next?

### Recommended layout

```text
┌─────────────────────────────────────────────────────┐
│ Creator Dashboard                  [View profile]    │
│ Good morning, Maya                                  │
│                                                     │
│ [New post] [New service] [New product]              │
├─────────────────────────────────────────────────────┤
│ NEEDS ATTENTION                                     │
│ 2 orders need delivery · 1 proposal was viewed     │
│ [Review tasks →]                                    │
├─────────────────────────────────────────────────────┤
│ BUSINESS SNAPSHOT                                   │
│ Earnings     Active orders   Profile views  Rating  │
│ $1,240       4               1,840          4.9 ★   │
├──────────────────────────────┬──────────────────────┤
│ Earnings trend                │ Reputation           │
│ [small chart]                 │ 95% on-time         │
│ [View earnings →]             │ [View reputation →]  │
├──────────────────────────────┴──────────────────────┤
│ ACTIVE WORK                                         │
│ Order/client rows with status and next action       │
├──────────────────────────────┬──────────────────────┤
│ CONTENT PERFORMANCE           │ BADGE PROGRESS       │
│ Top post / views / saves      │ Earned + next badge  │
└──────────────────────────────┴──────────────────────┘
```

### Home page rules

- Four snapshot metrics maximum above the fold.
- One `Needs attention` module, not many red badges across the page.
- Two charts maximum on the initial screen.
- Every metric links to a focused detail view.
- Quick actions create or manage work; they do not duplicate global feed navigation.
- Empty states include a useful next action.

### Needs Attention module

Shows only actionable items:

- order delivery due soon;
- unread client message;
- proposal viewed or accepted;
- payout method missing;
- product/service draft incomplete;
- contest deadline approaching;
- review received;
- profile missing required information.

Resolved or informational events belong in Notifications, not this module.

---

## 4. Creator Business Shortcuts

### MVP shortcuts

```text
[Create post]
[Add product]
[Add service]
[View orders]
[Withdraw earnings]
[Edit profile]
```

### Contextual shortcuts

Show only when relevant:

- `Complete payout setup`
- `Respond to proposal`
- `Submit contest entry`
- `Publish draft`
- `Request review`
- `Share profile`

Do not show all shortcuts as a permanent grid. Use three primary buttons in the header and place the rest in a `More actions` menu or contextual module.

---

## 5. Content Management

### Content destination

`Content` manages the creator's public Showcase system:

```text
Content
├── Published
├── Drafts
├── Scheduled (advanced)
├── Archived
└── Performance
```

### MVP tools

- View published posts
- Create/edit/delete post
- Save drafts
- Upload image/media
- Pin up to three posts
- Link a product or service
- Filter by All/Reels/Graphics/Thumbnails/Case studies
- See likes, comments, saves, and views

### Advanced tools

- Scheduled publishing
- Collections
- Multi-media carousel management
- Content templates
- Post-level conversion funnel
- Best-time-to-publish recommendations
- Bulk archive
- Repost/repurpose controls

### Content list row

```text
[thumbnail] Title / type
            Published · 1,240 views · 38 saves
            [Edit] [View analytics] [•••]
```

Keep management rows compact. Full creative previews open in a detail drawer or dedicated editor.

---

## 6. Service Management

### Service destination

```text
Services
├── Active
├── Drafts
├── Paused
└── Service performance
```

### MVP tools

- Create/edit service
- Manage Basic/Standard/Premium packages
- Set price and delivery time
- Set revision limits
- Upload gallery
- Publish/unpublish
- Pause accepting new orders
- View orders per service
- View rating/reviews per service

### Advanced tools

- Add-ons
- FAQs
- Custom offer templates
- Service-level conversion analytics
- Package A/B testing
- Capacity limits
- Auto-pause when workload exceeds threshold

### Service health summary

```text
Brand identity package
Active · 6 orders · 4.9 ★
Views 420 · Bookings 12 · Conversion 2.8%
[Manage service]
```

Do not place complex package editing on the dashboard home. It belongs in the service editor.

---

## 7. Product Management

### Product destination

```text
Products
├── Active
├── Drafts
├── Sold/archived
└── Product performance
```

### MVP tools

- Create/edit product
- Upload preview image
- Set title, description, category, tags, price
- Publish/unpublish
- View sales count
- View active/sold ownership state
- Open product detail

### Advanced tools

- Product versioning
- File replacement with buyer notification
- Bundle products
- Discount/coupon support
- Product conversion analytics
- Download/access analytics
- Licensing configuration

Exclusive ownership must be visible in management:

```text
Ownership: Exclusive
Status: Available / Sold · Locked
```

Creators should not be able to accidentally switch a sold exclusive item into a multi-license mode. Multi-License remains future opt-in and admin-controlled.

---

## 8. Order and Service Management

### Orders destination

Orders are the creator's operational queue, not simply a history table.

### MVP order states

```text
New
→ In progress
→ Delivered
→ Revision requested
→ Completed
→ Cancelled/disputed
```

### Order list

Each row shows:

- buyer;
- product/service/project type;
- order title;
- amount;
- current status;
- due date;
- next action;
- unread message indicator.

Example:

```text
Alex Rivera
Brand identity package
Due tomorrow · In progress
$800
[Open order]
```

### MVP tools

- Filter active/completed/disputed
- Open order detail
- Message buyer
- Mark progress
- Deliver work
- Respond to revision
- Complete order
- View payment status

### Advanced tools

- Saved response templates
- Delivery checklist
- Milestones
- Time tracking
- Calendar integration
- Workload/capacity view
- Repeat client notes, private to creator
- Order automation

### Operational priority

Orders due soon, revision requests, and unread buyer messages should rise above completed history.

---

## 9. Earnings and Finance Widgets

### Dashboard home widgets

Show:

- Available earnings
- Pending earnings
- Current-period earnings
- Active order value
- Next payout status

Do not show a full ledger on the dashboard home.

### Earnings destination

```text
Earnings
├── Overview
├── Transactions
├── Payouts
└── Fees and statements
```

### MVP earnings tools

- Total earnings
- Available/pending balance
- Earnings by period
- Transaction history link
- Payout status
- Withdraw action
- Platform fee visibility

### Advanced finance tools

- Revenue by service/product
- Monthly/quarterly comparison
- Net versus gross earnings
- Tax statement export
- Payout schedule controls
- Forecasting
- Currency breakdown

All financial data is private to the creator and must never appear on the public profile.

### Finance widget design

```text
Available to withdraw
$1,240.00
+ $180 pending
[Withdraw earnings]
[View financial dashboard]
```

Use one primary financial action. Avoid displaying Add Funds on the Creator Dashboard unless the creator is actively buying something; Add Funds belongs in the global Wallet/Menu flow.

---

## 10. Reputation and Badge Area

### Reputation module

Show:

- Overall rating
- Review count
- Completion rate
- On-time delivery
- Response time
- Proposal win rate
- Recent review themes

The dashboard can show detailed metrics that remain summarized or private on the public profile.

### Badge module

Show:

- Earned badges
- Next badge progress
- Requirement explanation
- Recent badge achievement
- Link to public profile preview

Example:

```text
BADGE PROGRESS
Top Seller · Earned
Rising Creator · 72% complete
6 more completed orders
```

Badges should motivate useful behavior, not encourage spam. Never award badges for raw volume without quality or policy safeguards.

### Public relationship

- Dashboard: full progress and requirements.
- Public profile: earned badges and short explanations only.

---

## 11. Audience Analytics

### Audience destination

```text
Audience
├── Overview
├── Profile activity
├── Follower growth
└── Audience interests (advanced)
```

### MVP analytics

- Profile views
- Follower count and growth
- Showcase impressions
- Post engagement
- Product/service page visits from profile

### Advanced analytics

- Follower source
- Audience category/interest trends
- Returning visitor rate
- Profile-to-message conversion
- Profile-to-booking conversion
- Post-to-product conversion
- Time/day performance

Do not expose individual viewer identities or sensitive audience attributes.

### Audience widget

```text
AUDIENCE
1,240 followers
+8.4% this month
Profile views 1,840
[View audience insights]
```

Keep the chart small and connect it to a clear interpretation such as `Profile discovery is growing`.

---

## 12. Performance Insights

Performance should answer “what should I do next?” rather than merely display numbers.

### MVP insights

- Top-performing Showcase post
- Most-viewed service/product
- Profile views trend
- Orders and earnings trend
- Proposal win-rate summary
- One actionable suggestion

Example:

```text
Your branding case study gets 2.4× more saves than average.
Consider featuring a related branding service.
```

### Advanced insights

- Content-to-order attribution
- Service funnel
- Product funnel
- Proposal funnel
- Cohort/repeat-buyer analysis
- Pricing and package comparison
- Recommendation quality feedback
- Experiment tracking

Do not put all of these on the home page. Advanced insights belong in dedicated screens with date range, filters, and explanations.

---

## 13. MVP vs Advanced Dashboard

### MVP dashboard

#### Dashboard home

- Needs Attention
- Earnings summary
- Active orders
- Profile views
- Followers
- Rating/reputation
- Recent orders
- Badge preview
- Three creator shortcuts

#### Content

- Publish/edit posts
- Drafts
- Pin content
- Basic post metrics

#### Services and products

- Create/edit/publish/pause
- Package/price management
- Basic sales/order metrics

#### Orders

- Active/completed order list
- Status changes
- Delivery and revision handling
- Buyer message link

#### Finance

- Available/pending earnings
- Withdraw
- Basic revenue trend
- Transaction link

#### Reputation

- Rating/reviews
- Completion/on-time summary
- Earned badges

#### Audience

- Profile views
- Followers
- Basic content engagement

### Advanced dashboard

- Scheduled content
- Collections
- Detailed content attribution
- Service/product funnel analytics
- Proposal and contest analytics
- Workload/capacity planning
- Saved response templates
- Milestones and time tracking
- Forecasting and financial exports
- Audience segmentation
- Pricing experiments
- Advanced badge progression
- Tax/reporting tools
- Integrations and calendar connections

---

## 14. Mobile-First Dashboard Behavior

### Mobile home

Order modules:

1. Header and three shortcuts
2. Needs Attention
3. Earnings/active work summary
4. Recent orders
5. Reputation
6. Content performance
7. Badge progress

### Mobile rules

- Snapshot metrics become a horizontal scroll row or 2×2 grid.
- Charts collapse to one small trend card.
- Order rows use status-first compact cards.
- Primary actions are sticky only inside a focused workflow, not across the whole dashboard.
- Tables become stacked cards with filters in a sheet.
- Dashboard navigation uses `Overview`, `Orders`, `Content`, `Earnings`, and `More`.

---

## 15. Clean Operating-System Rules

1. One dashboard home, not a page for every metric.
2. One Needs Attention module, not scattered warning badges.
3. Four snapshot metrics maximum above the fold.
4. Two charts maximum on home.
5. Every metric has a destination and explanation.
6. Management tools live in their own focused hubs.
7. Financial data is private and clearly separated from public credibility.
8. Both users use one Creator Dashboard with a Buying/Selling context switch.
9. Empty states tell creators what to do next.
10. Advanced analytics is progressive disclosure, not default clutter.

## Final creator operating system

```text
Overview
  What needs attention · business snapshot · next actions

Orders
  Fulfillment queue · delivery · revisions · client work

Content
  Showcase publishing · drafts · pinned work · performance

Services
  Packages · availability · bookings · service health

Products
  Digital assets · ownership · sales · listing health

Opportunities
  Proposals · contests · saved work

Earnings
  Balance · revenue · payouts · transactions

Audience
  Views · followers · engagement · discovery

Reputation
  Reviews · delivery stats · badges · improvement
```

The dashboard should feel like a creator opening their studio each day: see the work that matters, handle the next task, understand the business, and return to creating.
