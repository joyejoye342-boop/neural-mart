# NeuralMart — Digital Product Selling System

**Document version:** 1.0  
**Audience:** Creators, Buyers, and Both users  
**Primary surfaces:** Product detail · Showcase Feed · Products marketplace · Creator Content Hub · Orders

---

## 0. Product Definition

A digital product is a creator-owned digital asset or bundle that a buyer can purchase with a defined license and receive through secure download or access.

Supported product examples:

- AI reels
- Thumbnail packs
- Graphics
- Video assets
- Templates
- Prompt packs
- Source files
- Creative bundles

Products are self-serve commerce objects. They are different from:

| Digital product | Service | Project proposal |
|---|---|---|
| Pre-made asset | Creator performs scoped work | Creator proposes custom work |
| Instant or gated download | Fulfillment and revisions | Negotiated scope and timeline |
| Fixed price/license | Package price and delivery | Creator-defined offer |
| No custom delivery by default | Buyer requirements required | Buyer reviews proposals |

---

## 1. Product Model

### Core product identity

- Product title
- Short value statement
- Full description
- Product type
- Category
- Tags
- Creator
- Cover/thumbnail
- Preview gallery
- Version
- Product status

### Product types

| Type | Examples | Typical delivery |
|---|---|---|
| AI reel/video | Short reels, motion loops, edited clips | MP4/MOV bundle |
| Thumbnail pack | YouTube, campaign, social thumbnails | PNG/PSD/Figma |
| Graphic pack | Illustrations, social graphics, icon sets | PNG/SVG/AI |
| Video asset | Overlays, transitions, LUTs, sound/visual assets | ZIP/project files |
| Template | Presentation, social, UI, document templates | Figma/PSD/Canva/other |
| Prompt pack | Image/video/writing prompts and workflows | PDF/TXT/Notion/export |
| Source file | Editable working files | Figma/PSD/AI/project bundle |
| Creative bundle | Mixed related files | Versioned ZIP/bundle |

### Product configuration

- Price
- Currency
- License type
- Delivery files
- Preview files
- File format and requirements
- Version number
- Update policy
- Support policy
- Refund eligibility
- Sales/availability state

### Product ownership modes

#### Standard license

Buyer receives defined usage rights. Creator retains ownership and can sell the product to others.

#### Commercial license

Buyer can use the asset in commercial work under the stated limits.

#### Extended/team license

Advanced. Covers larger teams, client work, or higher usage limits.

#### Exclusive ownership

Advanced and tightly controlled. Once sold, the product becomes:

```text
Sold · Locked
```

The listing remains visible as a historical record, but new purchases are disabled.

Never call a product “exclusive” unless the buyer rights, creator rights, and post-sale availability are explicit.

---

## 2. Product Creation Flow

```text
Choose product type
→ Define product promise
→ Upload delivery files
→ Upload previews
→ Set price and license
→ Add version/update policy
→ Add support and requirements
→ Preview product page
→ Validate and publish
```

### Step 1 — Product promise

Required:

- Title
- Product type
- Category
- One-sentence outcome

Prompts:

```text
What will the buyer be able to make or do with this?
Who is it for?
What is included?
```

### Step 2 — Description and contents

Required:

- Full description
- Contents list
- File formats
- Compatibility requirements

Example:

```text
Included:
• 12 editable thumbnails
• 4 color variations
• Figma source file
• Quick-start guide
```

### Step 3 — Delivery files

Upload:

- ZIP bundles
- Individual files
- PDFs
- Project files
- Fonts or presets where legally distributable
- Documentation

The creator can organize files into folders and label each one:

```text
Preview only · Buyer download · License-restricted · Documentation
```

### Step 4 — Preview media

Required:

- Cover image
- At least one preview

Recommended:

- Gallery
- Short preview video
- Sample page/file
- File tree screenshot
- Before/after example

### Step 5 — Pricing and license

Required:

- Fixed price
- Currency
- License selection
- Commercial-use disclosure

The creator sees a buyer-facing preview of:

```text
$29 · Personal + commercial use
Instant download
12 files · Figma compatible
```

### Step 6 — Version and support

Required:

- Version number
- Last updated date
- Update policy
- Basic support expectation

Optional:

- Free future updates
- Paid major-version updates
- Documentation
- FAQ
- Contact/support window

### Step 7 — Validation

Validate:

- Delivery files exist and are accessible.
- Preview does not expose restricted source files.
- License is selected.
- Product type and format are clear.
- File sizes and types are allowed.
- Malware scan is complete.
- Commercial claims are accurate.
- AI-generated content disclosure is completed where relevant.
- Rights to included third-party assets are confirmed.

---

## 3. Preview System

The preview should help a buyer understand value without giving away the purchased asset.

### Preview components

1. Cover image
2. Gallery
3. Video preview
4. Sample output
5. File/content list
6. Compatibility summary
7. Watermarked or reduced-resolution sample
8. License summary

### Product-type previews

#### AI reels and video assets

- Short preview clip
- Watermarked or low-resolution playback
- Duration
- Resolution
- Codec/format
- Included clips count

#### Thumbnails and graphics

- Gallery
- Watermarked previews
- Dimensions
- Editable/non-editable status
- Included variations

#### Templates

- Screenshots
- Sample pages
- Editable application
- Included components
- Compatibility

#### Prompt packs

- Sample prompts
- Topic/category list
- Number of prompts
- Workflow preview
- Model/tool compatibility

#### Source files

- Layer/file tree preview
- Sample export
- Supported application/version
- Editable objects summary

### Preview protection

- Watermark when necessary.
- Do not serve original source files through public URLs.
- Do not expose hidden ZIP contents before purchase.
- Use secure previews with access controls.
- Make the preview honest; do not show features not included.

---

## 4. Pricing Model

### MVP

- Fixed one-time price
- Free product option
- One included license
- Optional launch discount

### Advanced

- Personal and commercial license tiers
- Team license
- Bundle pricing
- Pay-what-you-want with minimum
- Version upgrade pricing
- Limited-time promotions
- Product subscriptions or update plans

### Pricing rules

- Display final product price clearly.
- Platform fees and taxes are shown separately where applicable.
- Bundle contents and value are explicit.
- License price differences are explained, not hidden in a dropdown.
- A creator cannot change a buyer's purchased license retroactively.
- Product price changes do not alter completed order records.

### Discount behavior

Discounts must show:

- original price;
- current price;
- end date;
- included license;
- whether existing buyers receive updates.

Do not use countdown pressure without a real end time.

---

## 5. File Delivery Model

### Purchase flow

```text
Product detail
→ Buy now
→ Confirm price/license
→ Secure payment
→ Order/entitlement created
→ Download or access granted
```

### Entitlement

Every purchase creates a durable entitlement containing:

- buyer;
- product;
- purchased version;
- license;
- order;
- purchase date;
- access status;
- update eligibility.

### Secure downloads

- Files are stored privately.
- Downloads use short-lived access links.
- Public feeds never expose delivery URLs.
- Download activity can be logged.
- Creator source files remain inaccessible unless included in the purchase.

### Updates

Product update policy options:

- No updates
- Free minor updates
- Free updates for a defined period
- Paid major-version updates

Eligible buyers see:

```text
Version 1.2 available
[Download update]
```

Updates must not silently change the purchased license.

### Access and support

Buyers access products through:

- Orders;
- Menu → Purchases;
- Buyer Dashboard → Purchased products;
- Product detail if owned.

Support actions:

- Download issue
- File corruption report
- License question
- Product mismatch
- Refund/support request

---

## 6. Licensing and Usage Notes

Every product page includes a concise license summary with expandable detail.

### License fields

- Personal/commercial use
- Number of users/seats
- Client work allowed or restricted
- Resale/redistribution restriction
- Modification allowed
- AI training or model-input restriction, when relevant
- Attribution requirement
- Source-file ownership
- Exclusive/non-exclusive status

### AI content

Creators should disclose:

- whether the product contains AI-generated material;
- whether prompts/workflows are included;
- any known model/tool restrictions;
- whether the creator has rights to included assets.

### No hidden rights transfer

Buying a product does not automatically transfer:

- creator copyright;
- third-party licenses;
- model/property rights;
- exclusive ownership;
- rights to resell the underlying files.

The product page must state the actual license in plain language.

---

## 7. Product Page and In-Feed Strategy

### Product page

```text
Product header
→ Preview gallery/video
→ Title and creator
→ Rating/sales/trust
→ Contents
→ Compatibility
→ License
→ Version/update policy
→ Reviews
→ Sticky purchase box
```

### Sticky purchase box

Shows:

- selected license;
- price;
- instant access expectation;
- file format;
- secure payment;
- `Buy now`;
- `Owned · Download` when purchased;
- `Sold · Locked` for exclusive products.

### In-feed product card

Show:

- cover image;
- title;
- price;
- product label;
- creator identity and compact trust;
- short contents signal;
- one CTA.

```text
[Product] Thumbnail Creator Pack
12 editable files · $29
[View product]
```

The feed is for discovery. Full license, file, and delivery detail belongs on the product page.

### Profile connection

Products appear in:

- public Profile → Products;
- Overview featured offer;
- Showcase Feed;
- Products marketplace;
- creator Content Hub.

---

## 8. Product Management Tools

Creator Dashboard → Products:

```text
Active
Drafts
Needs changes
Paused
Archived
Sold · Locked
```

Each product row shows:

- title/type;
- status;
- price;
- version;
- sales;
- revenue;
- rating;
- downloads;
- last updated;
- `Edit`, `View`, `Analytics`, and overflow actions.

### Management actions

- Edit metadata
- Replace preview
- Upload new version
- Update delivery files
- Change price
- Change license for future buyers
- Pause sales
- Archive listing
- Duplicate as draft
- View orders
- View product insights
- Respond to reviews

### High-risk changes

Require explicit confirmation:

- license change;
- delivery-file replacement;
- price increase;
- exclusive ownership activation;
- pausing or unlisting an active product.

### Product analytics

- Impressions
- Product page views
- Preview plays
- Saves
- Buy clicks
- Purchases
- Conversion rate
- Revenue
- Refund/support rate
- Downloads
- Repeat buyers

## Final rule

A digital product should feel like a trustworthy, versioned purchase: the buyer knows what is included, what they may do with it, how they receive it, and how the creator supports it.
