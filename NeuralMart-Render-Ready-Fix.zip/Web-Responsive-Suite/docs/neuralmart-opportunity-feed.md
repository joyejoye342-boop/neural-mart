# NeuralMart — Audience Projects / Opportunity Feed

**Document version:** 1.0  
**Route:** `/contest-feed`  
**Display title:** Opportunities  
**API foundation:** `GET /api/feed/opportunities`

---

## 0. Feed Definition

The Opportunities Feed is where Creators and freelancers discover active ways to earn:

- buyer project posts;
- hiring requests;
- contests;
- collaboration opportunities.

It is a high-intent work feed, not a social showcase feed. The user is deciding whether to spend time applying, entering, or starting a conversation.

```text
Showcase Feed: What is being made?
Opportunities Feed: What can I work on?
```

---

## 1. Feed Structure

```text
OPPORTUNITIES
├── Header
│   ├── Opportunity title
│   ├── Creator context
│   └── Saved opportunities
├── Buyer composer, for Buyer/Both
│   ├── Post a project
│   └── Host a contest
├── Filter row
├── Optional saved-search row
├── Opportunity stream
│   ├── Direct project cards
│   ├── Hiring request cards
│   ├── Contest cards
│   └── Collaboration cards
└── Empty/loading/error states
```

### Creator header

```text
Active opportunities
Find projects and contests that fit your skills.
```

### Buyer header

```text
Your opportunities
[Post a project] [Host a contest]
```

Buyers can browse, but do not receive creator participation CTAs on other buyers' opportunities.

---

## 2. Card Types

### 2.1 Direct project card

```text
[buyer avatar] Greenline Studio · Verified Buyer
                Open project · 2h

Brand identity for a climate-tech startup
Create a flexible identity system for web, pitch deck,
and launch assets...

$800–$2,500 · Branding · Figma · 12 proposals
Due Apr 28
[Send proposal →]
```

Show:

- buyer verification/trust;
- project goal;
- budget;
- category and skills;
- proposal count;
- deadline;
- preferred experience;
- save action.

Primary CTA: `Send proposal`.

### 2.2 Hiring request card

A hiring request is a more urgent or simplified project subtype:

```text
Urgent hiring request
Need a motion designer this week
$600–$900 · Starts in 3 days
[Express interest →]
```

Use when the buyer wants an immediate conversation or has not fully structured a long brief. The card must clearly state whether the request is paid.

Primary CTA:

- `Send proposal` for a structured brief;
- `Express interest` for a lightweight request.

### 2.3 Contest card

```text
amber top border
[🏆] Logo Design Challenge · Contest
Prize $500 · Funded
23 entries · Ends in 4 days
Branding · Logo · Vector
[Submit entry →]
```

Show:

- prize;
- funding/escrow state;
- deadline;
- entry count;
- host verification;
- submission requirements summary.

Primary CTA: `Submit entry`.

### 2.4 Collaboration opportunity

Collaboration is a project subtype, not a fourth marketplace role. It must disclose compensation:

```text
Collaboration opportunity
Looking for a 3D artist for a public short film
Paid: $300–$500 · Credit included
[Express interest →]
```

Required labels:

- Paid
- Revenue share
- Unpaid
- Credit/portfolio collaboration

Unpaid opportunities should not be ranked alongside paid opportunities without a visible compensation filter and label.

---

## 3. Visual Differentiation

Use the shared card shell with semantic accents:

| Type | Visual cue | Primary CTA |
|---|---|---|
| Direct project | Blue/neutral type label | Send proposal |
| Hiring request | Blue with urgency label | Express interest |
| Contest | Amber border/prize | Submit entry |
| Collaboration | Violet/neutral label | Express interest |

Contests are visually strongest because prize, deadline, and rules require attention. Projects remain calmer and professional. Collaboration cards never imply paid employment when compensation is unclear.

---

## 4. Filters

### Primary filters

```text
[All] [Projects] [Contests] [Collaboration]
```

### Secondary filters

- Category
- Skills
- Budget/prize
- Deadline
- Work type: fixed project / ongoing / urgent
- Compensation: paid / revenue share / unpaid
- Experience level
- Remote/location/timezone
- Ownership/licensing
- Proposal/entry competition
- Buyer/host verification

### Filter behavior

- Filters use additive AND logic.
- Active filters appear as removable chips.
- `Clear all` is always available.
- Filter state is preserved in the URL for shareable/saved searches.
- Mobile uses a filter sheet with a result count.
- Do not display every advanced filter by default; show `More filters`.

---

## 5. Sorting and Ranking

### Default sort

Use a transparent value-and-urgency baseline:

```text
Opportunity fit
→ Prize/budget value
→ Deadline urgency
→ Freshness
→ Competition level
```

The starting feed target remains approximately:

- 70% contests
- 30% direct projects

This mix can be tuned based on actual creator engagement.

### Sort options

- Recommended
- Highest budget/prize
- Ending soon
- Newest
- Fewest proposals/entries
- Best skill match

### Ranking constraints

- Closed/expired items are excluded.
- Own projects/contests appear only in management/read-only contexts.
- Relevance must outrank raw prize size.
- A high-paying opportunity with mismatched skills should not dominate the feed.
- Paid and unpaid collaborations are never silently mixed.

---

## 6. CTA Logic

| Viewer/object | CTA |
|---|---|
| Creator → another user's open project | Send proposal |
| Creator → open contest | Submit entry |
| Creator → collaboration | Express interest |
| Both → another user's project | Send proposal |
| Both → another user's contest | Submit entry |
| Buyer → own project | Manage project |
| Buyer → own contest | Manage contest |
| Buyer → another user's opportunity | View details |
| Closed/expired opportunity | View results/details |

The server must enforce these permissions even if the UI hides an action.

---

## 7. Creator Decision-Making Tools

### Save and organize

- Save opportunity
- Add private note
- Add to collection
- Hide opportunity
- Follow buyer/host

### Proposal readiness

On a project card/detail page:

- view required skills;
- inspect attachments;
- see budget and deadline;
- see proposal competition;
- view buyer trust signals;
- open relevant portfolio examples;
- start proposal draft.

### Contest readiness

Show:

- prize funding state;
- entry format;
- rights/ownership terms;
- judging criteria;
- deadline;
- entry count;
- host history.

### Compare

Creators can compare saved opportunities on:

- budget/prize;
- deadline;
- skill fit;
- competition;
- ownership terms;
- buyer/host trust.

Comparison is private and should never look like a public competitive leaderboard.

---

## 8. Buyer Composer

Buyer and Both users see a compact composer at the top:

```text
Ready to find your next creator?
[Post a project] [Host a contest]
```

Creators see no publishing composer in this feed. They see:

```text
Active opportunities — find work that fits you.
```

This keeps the feed focused without hiding creation tools from buyers.

---

## 9. Mobile Behavior

- Single-column cards.
- Type filter row scrolls horizontally.
- Additional filters open in a bottom sheet.
- Budget/prize, deadline, and primary CTA stay visible without opening details.
- Contest prize and deadline are visually prominent.
- Project description is capped at three lines.
- Save and overflow actions are 44px targets.
- `Submit entry` and `Send proposal` use full-width buttons on mobile.
- Saved-search alerts are configured outside the feed in Notifications.

---

## 10. Empty and Safety States

### No matching opportunities

```text
No projects match these filters.
Try a broader category or save this search.
[Clear filters]
```

### No active opportunities

```text
No active opportunities right now.
Explore creator work or check back soon.
```

### Unsafe or suspicious opportunity

- Report from card overflow.
- Explain off-platform payment warnings.
- Do not expose private reporter identity.
- Remove or pause suspicious items pending review.

## Final rule

The Opportunities Feed should help a creator make a fast, informed decision: what is the opportunity, what is the value, what is the deadline, who is behind it, how competitive is it, and what action should I take?
