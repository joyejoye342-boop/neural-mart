# NeuralMart — Posting & Composer System

**Document version:** 1.0  
**Companion to:** `neuralmart-feed-architecture.md` · `neuralmart-home-page-architecture.md` · `neuralmart-navigation-hub-system.md`

---

## 0. The Governing Problem

NeuralMart has more publishable content types than any standard social app. A creator can post a portfolio update, list a product, list a service, share a reel, or write a work showcase. A buyer can post a project brief or host a contest. A freelancer can broadcast their availability.

The naive solution — show all post types to everyone all the time — produces an intimidating toolbar that makes users feel like they're configuring software, not sharing something. The correct solution is the opposite:

> **Show each user only what they can create. Show them the simplest version of it first. Reveal complexity only when they ask for it.**

This document specifies the full posting architecture: the types, the fields, the role logic, the UI flow, and the anti-overwhelm mechanisms.

---

## 1. All Post Types in NeuralMart

There are **seven distinct post types** across the platform. They fall into two families:

**Family A — Creator-generated content** (social/catalog publishing)
1. `post` — Portfolio update / work showcase / general creative post
2. `product` — Digital product listing (one-time purchase)
3. `service` — Bookable service listing
4. `reel` — Short-form video work showcase (platform-native video post)
5. `availability` — Freelancer availability broadcast ("I'm open to projects this month")

**Family B — Buyer-generated content** (commercial briefs)
6. `project` — Project brief (direct hire request, proposal-based)
7. `contest` — Contest brief (open competition with a prize)

These seven types map to the `posts`, `products`, `services`, `projects`, and `contests` database tables. `reel` and `availability` are subtypes of `posts` (distinguished by `post.type` enum), not separate tables.

---

## 2. Role × Post Type Matrix

Who can create what:

| Post type | Buyer | Creator | Both | Admin |
|---|:---:|:---:|:---:|:---:|
| `post` (portfolio/showcase) | ❌ | ✅ | ✅ | ❌ |
| `product` (digital listing) | ❌ | ✅ | ✅ | ❌ |
| `service` (bookable listing) | ❌ | ✅ | ✅ | ❌ |
| `reel` (video showcase) | ❌ | ✅ | ✅ | ❌ |
| `availability` broadcast | ❌ | ✅ | ✅ | ❌ |
| `project` brief | ✅ | ❌ | ✅ | ❌ |
| `contest` brief | ✅ | ❌ | ✅ | ❌ |

**The hard rule:** Buyers never post creative content into the feed. Creators never post buyer briefs. The `both` role is the union of both capability sets.

**Why buyers cannot post portfolio content:**  
A buyer posting into the Showcase Feed (the creative stream) would pollute the signal. The Showcase Feed is specifically a curated window into creator work — buyers discover talent there. If buyers could post "I'm looking for a designer" styled as a social post, it would corrupt the feed's identity. Buyers have the Project and Contest post types, which route to appropriate surfaces (both feeds, the Projects hub).

**Why creators cannot post buyer briefs:**  
A creator posting a project brief would mean they're hiring other creators — which is actually possible for `both` role users but conceptually confusing as a "creator action." When a `both` user hires another creator, they're acting in their buyer capacity, which is why the project/contest post types are gated behind buyer capability.

---

## 3. The Composer Entry Points

The composer is reached from multiple places, always landing on the correct post type for context:

| Entry point | Where | Default post type opened |
|---|---|---|
| Home feed composer — Creator "Share your work…" input tap | `/` | `post` (portfolio update) |
| Home feed composer — `[+ Post]` chip | `/` | `post` |
| Home feed composer — `[🛍 Product]` chip | `/` | `product` |
| Home feed composer — `[⚙ Service]` chip | `/` | `service` |
| Home feed composer — `[💼 Post Project]` button | `/` | `project` |
| Home feed composer — `[🏆 Host Contest]` button | `/` | `contest` |
| Opportunities Feed composer — `[💼 Post a Project]` | `/contest-feed` | `project` |
| Opportunities Feed composer — `[🏆 Host a Contest]` | `/contest-feed` | `contest` |
| Dashboard → Listings → "Add new product" | `/dashboard/creator` | `product` |
| Dashboard → Listings → "Add new service" | `/dashboard/creator` | `service` |
| Profile page — "Add to portfolio" | `/creators/:id` | `post` |
| Creator profile — "+ List Product" | `/creators/:id` | `product` |
| Floating action button (mobile, future) | Any page | Type selector sheet |

**Every entry point pre-selects the post type.** The user never lands on a blank composer that asks "what would you like to post?" This is the most important anti-overwhelm decision in the entire system.

---

## 4. Composer UI Architecture

### 4.1 The Three-Layer Composer Model

All composer interactions follow the same three-layer reveal pattern:

```
Layer 1 — Trigger (in-feed, always visible)
  The composer card on the home/opportunities feed.
  Minimal: avatar + placeholder text + quick-action chips/buttons.
  Purpose: make posting feel lightweight and always available.

Layer 2 — Compose Sheet (bottom sheet on mobile / modal on desktop)
  Opens when the user taps a specific action from Layer 1.
  Contains the core fields for the selected post type.
  Dismissible — tapping outside or swiping down closes without posting.
  Purpose: capture the essential content without navigating away.

Layer 3 — Full Wizard Page (navigated, full-screen)
  Accessible from Layer 2 via "Advanced options →" or triggered automatically
  for post types that require too many fields for a sheet (product, service, 
  project, contest).
  Contains all fields, media upload, pricing, scheduling, etc.
  Purpose: power-user configuration and complex post types.
```

**Which post types use which layer:**

| Post type | Primary entry | Advanced/full |
|---|---|---|
| `post` (text + image) | Layer 2 (sheet) — sufficient | Layer 3 if scheduling/tags needed |
| `reel` (video) | Layer 2 (sheet with video upload) | Layer 3 for captions/chapters |
| `availability` | Layer 2 (sheet) — minimal fields | Rarely needed |
| `product` | Layer 2 (name + price) → auto-promotes to Layer 3 | Layer 3 always for full listing |
| `service` | Layer 2 (name + price) → auto-promotes to Layer 3 | Layer 3 always for full listing |
| `project` | Layer 3 always (too many fields for sheet) | Full page `/projects/new` |
| `contest` | Layer 3 always | Full page `/contests/new` |

The rule: if a post type has more than 4 required fields, it skips Layer 2 entirely and opens Layer 3 directly. Projects and contests have 7–10 required fields — they're always full-page wizards.

### 4.2 Layer 1 — The In-Feed Composer Card

Already documented in `neuralmart-home-page-architecture.md`. Summary for this document:

**Creator variant:**
```
[Avatar]  [  Share your latest work…  ]     ← tap → opens post composer sheet
──────────────────────────────────────────
[+ Post]      [🛍 Product]    [⚙ Service]    ← direct entry to specific composer
```

**Buyer variant:**
```
[Avatar]  [  What do you need help with?  ] ← tap → opens project wizard (Layer 3)
──────────────────────────────────────────
[💼 Post Project]         [🏆 Host Contest]  ← direct entry to specific wizards
```

**Both variant:** Creator card + buyer outline strip below. Creator prompt tap → post sheet. Buyer buttons → project or contest wizard.

**One rule for the Layer 1 card:** Never show a type selector dropdown from Layer 1. Every tap from Layer 1 goes directly to a specific composer type. The chip labels are the type selectors.

### 4.3 Layer 2 — The Compose Sheet

The compose sheet is a bottom sheet (mobile) or centered modal (desktop) with these structural rules:

```
┌────────────────────────────────────────────────────────┐
│  ─── ←────── drag handle (mobile) ──────→              │
│                                                        │
│  [← Back]          [Post type name]      [Post →]      │  ← header row
│  ──────────────────────────────────────────────────    │
│                                                        │
│  [Avatar]  [Text input area — multi-line, auto-grow]   │  ← primary input
│                                                        │
│  [Media/attachment area — if media uploaded]           │  ← conditional
│                                                        │
│  ──────────────────────────────────────────────────    │
│  [📷 Photo]  [🎬 Video]  [🔗 Link]  [# Tag]  [⋯ More]  │  ← toolbar
│                                                        │
│  [Advanced options →]                                  │  ← escape to Layer 3
└────────────────────────────────────────────────────────┘
  Height: 90% of viewport (mobile), 600px (desktop)
  Animation: slide-up from bottom (mobile), fade-in-scale (desktop)
```

**Sheet header:**
- Left: `[← Back]` or `[✕]` — dismisses without saving (confirmation if text entered)
- Center: Post type name (e.g., "Work Showcase", "Portfolio Update")
- Right: `[Post →]` — primary action, disabled until minimum content is met

**Post button state:**
- Disabled: no text, no media
- Enabled: any text entered OR any media attached
- Loading: spinner during upload/submit
- Error: red border on invalid fields + inline error message

**"Advanced options →" link:** Opens the Layer 3 full page. Any content already entered in the sheet is preserved (passed as URL params or session state) — the user doesn't lose their work when they need more fields.

---

## 5. Post Type Deep Dives — Fields & UX

### 5.1 `post` — Portfolio Update / Work Showcase

**Purpose:** The standard creator social post. Can be text, image, multi-image, or link-preview. This is what fills the Showcase Feed.

**Where it appears:** Showcase Feed, creator profile Posts tab.

**Layer 2 fields (compose sheet):**

| Field | Type | Required | Notes |
|---|---|---|---|
| `content` | Textarea (auto-grow) | Yes | 2,200 char max (Instagram parity). First 3 lines visible in feed, "expand" for rest. |
| `images` | Multi-image upload | No | Up to 10 images. First image becomes feed card cover. Drag to reorder. |
| `linkUrl` | URL input | No | Auto-generates a link preview card (title, description, favicon). Only one link preview at a time. |

**Layer 3 additions (advanced options):**

| Field | Type | Notes |
|---|---|---|
| `tags` | Tag input | Up to 10 tags. Used for search/filtering in Explore. |
| `projectCredit` | Text | "Made for [client name]" — shows on card as credit line. |
| `publishAt` | Datetime picker | Schedule for future publish. |
| `visibility` | Select: Public / Followers only | Default: Public. |

**Subtype: `reel` (video showcase)**  
Same as `post` but requires a video file as the primary media instead of images. Activates when user uploads a video from the compose sheet. The post type label in the header changes from "Work Showcase" to "Reel" automatically. No separate entry point needed — video upload triggers the reel treatment.

| Field | Type | Notes |
|---|---|---|
| `videoFile` | Video upload | MP4, MOV, WebM. Max 500MB. Max 3 minutes. |
| `thumbnail` | Image upload | Auto-generated from first frame; user can replace. |
| `caption` | Textarea | Standard post content field, now used as caption. |

**Subtype: `availability` broadcast**  
A special `post` with `post.type = 'availability'` and a structured format. Accessed via a dedicated option in the "⋯ More" overflow of the compose toolbar:

```
[Broadcast Availability]
→ Opens a minimal sheet (3 fields):
   Status: [Available now] [Available soon] [Not available]
   Period: [This month] [Next month] [Custom range]
   What I'm looking for: [Free text, 280 chars max]
```

Renders in the feed as a styled card with a green "Available" badge and a "Start a conversation →" CTA that opens a direct message thread. Auto-expires at the end of the availability period.

---

### 5.2 `product` — Digital Product Listing

**Purpose:** A product the creator sells once (no recurring relationship). Templates, presets, UI kits, music tracks, fonts, stock photos, ebooks, etc.

**Where it appears:** Showcase Feed (as a Product card), creator profile Products tab, Market hub (`/products`).

**Entry always opens Layer 3 (full page `/products/new`).** Products require too many commercial fields for a sheet. The compose sheet briefly appears with name + price, then auto-promotes to the full page on `[Continue →]`.

**Fields — Full wizard (Layer 3):**

```
STEP 1 — Core info (always required)
  Product name          Text, 120 chars max
  Category              Select: Digital Asset · Template · UI Kit · Font · 
                                Photography · Music · Writing · Illustration · Other
  Short description     Textarea, 300 chars — appears in feed card
  Full description      Rich text (markdown), unlimited — appears on product detail page
  Price                 Number input, $0.01 min. $0 = "Free" (downloadable freebie)
  Cover image           Image upload, required. Shown in feed card. Aspect 4:3 enforced.

STEP 2 — Files & delivery
  Product file(s)       File upload, up to 5 files, 500MB total
                        Accepted: .zip, .fig, .sketch, .psd, .pdf, .mp3, .mp4, .ttf, .otf, any
  Preview files         Image upload, up to 10 images for the product gallery
  Preview video         Video upload, optional, max 60s (product demo)

STEP 3 — Pricing & options
  License type          Select: Personal · Commercial · Extended Commercial
  License notes         Textarea, optional
  Limited quantity      Toggle: Yes/No. If Yes → enter max units available.
  Enable discount codes Toggle (Phase 2)

STEP 4 — Visibility
  Publish immediately   Toggle (default: on)
  Schedule publish at   Datetime picker (if not immediate)
```

**Anti-overwhelm in the product wizard:** The wizard uses a step progress indicator (Step 1 of 4). Steps 2–4 are collapsible — a creator can complete Step 1 and publish a minimal listing, then come back to add files and extras. The "Publish" button is available after Step 1 with a `⚠ Incomplete listing` warning, not a hard block.

---

### 5.3 `service` — Bookable Service Listing

**Purpose:** A service the creator delivers on an ongoing or project basis. Brand identity, video editing, UI/UX design, copywriting, music production, etc. Buyers book and pay; creator delivers.

**Where it appears:** Showcase Feed (Service card), creator profile Services tab, Market hub Services tab (`/services`).

**Entry always opens Layer 3 (full page `/services/new`).**

**Fields — Full wizard (Layer 3):**

```
STEP 1 — What you offer
  Service title         Text, 120 chars max. Clear and specific.
                        Helper: "I will [deliverable] for [audience]"
  Category              Select: Branding · Motion Design · UI/UX · Illustration · 
                                Photography · Video · Writing · Music · Voice · Other
  Short tagline         Text, 160 chars — appears on service cards in feed
  Full description      Rich text — appears on service detail page

STEP 2 — Pricing & packages
  Pricing model         Select:
                          Fixed price (single rate)
                          3-tier packages (Basic / Standard / Premium)
                          Hourly rate
  
  [If Fixed price]:
    Price               Number
    Delivery days       Number (business days)
    What's included     Textarea (bullet list)
    Revisions           Number or "Unlimited"
  
  [If 3-tier packages]:
    For each tier (Basic, Standard, Premium):
      Tier name         Text (customize the label)
      Price             Number
      Description       Textarea
      Delivery days     Number
      Revisions         Number
      What's included   Multi-checkbox (add items)
  
  [If Hourly]:
    Hourly rate         Number
    Min hours           Number
    Max hours           Number or "No limit"

STEP 3 — Portfolio & proof
  Cover image           Required. Aspect 4:3. Shown in feed card + service header.
  Gallery images        Up to 8. Shown on service detail page.
  Portfolio links       Up to 3 URLs (Behance, Dribbble, personal site)
  Testimonial           Textarea, optional (manual entry until review system is live)

STEP 4 — Availability & requirements
  Currently accepting   Toggle: Yes / No (hides service from marketplace if No)
  Typical turnaround    Select: 1–3 days · 1 week · 2 weeks · 1 month · Varies
  What I need from you  Textarea — requirements the buyer must provide at booking
  Add-ons               Repeatable block: [Add-on name] + [Price] + [Delivery days]
```

**3-tier package UI note:** The package configuration is the most complex part of the service composer. It uses a visual side-by-side card layout (not a form table) so creators can see how their packages will look to buyers as they fill them in. This prevents the "form feels like a spreadsheet" problem.

---

### 5.4 `project` — Project Brief (Direct Hire)

**Purpose:** A buyer posts a description of work they need done, a budget range, and required skills. Creators submit proposals. Buyer selects one.

**Where it appears:** Showcase Feed (compact project card), Opportunities Feed (full project card), Projects hub.

**Entry always opens Layer 3 (full page `/projects/new`).**

**Fields — Single-page form (not a multi-step wizard):**

```
REQUIRED
  Project title         Text, 120 chars. Specific and descriptive.
                        Helper: "I need a [deliverable] for [context]"
  Category              Select: Branding · Motion · UI/UX · Illustration · 
                                Photography · Video · Writing · Music · Development · Other
  Brief description     Textarea, 2,000 chars. What needs to be done, context, goals.
  Budget min            Number ($)
  Budget max            Number ($). Must be ≥ budget min.
  Skills required       Tag input, up to 8 tags. Autocomplete from known skill list.
  Deadline              Date picker (optional). "No hard deadline" toggle.

OPTIONAL
  Reference files       File upload, up to 5 files (mood boards, style guides, logos, etc.)
  Reference URLs        Up to 3 URLs
  Preferred timeline    Select: ASAP · 1–2 weeks · 1 month · Flexible
  Experience level      Select: Any · Intermediate · Expert
  Additional notes      Textarea, 500 chars
```

**Why not a wizard for projects?** Projects are professional briefs. Buyers who post projects are in work mode — they have specific information to fill in and they want to get it done. The step-by-step wizard creates artificial friction ("I have to click Next to see the next field?"). A single scrolling form is faster and more professional. The form is divided by visual section headings, not steps.

**Smart defaults:**
- Category pre-selects based on the buyer's previous project category (if applicable).
- Budget range remembers the last used range as a pre-fill.
- Deadline defaults to "No hard deadline" toggle ON.

---

### 5.5 `contest` — Contest Brief (Open Competition)

**Purpose:** A buyer posts a prize, a brief, and a deadline. Any creator can submit work. The buyer picks a winner and the prize is paid from escrow.

**Where it appears:** Opportunities Feed only (contest cards), Contests hub.

**Entry always opens Layer 3 (full page `/contests/new`).**

**Fields — Single-page form:**

```
REQUIRED
  Contest title         Text, 120 chars.
  Category              Select (same list as project categories)
  Brief                 Textarea, 3,000 chars. Be specific — more detail = better entries.
  Prize amount          Number ($). Minimum $50.
  Deadline              Date + time picker. Required for contests (unlike projects).
                        Must be at least 7 days from now.

OPTIONAL
  Cover image           Image showing the desired outcome style / mood board
  Reference files       File upload, up to 5 files
  Winner selection      Select: "I'll pick manually" / "Most votes wins" (future)
  Submission format     Multi-checkbox: Image · Video · PDF · URL · Other
  Max entries per creator Select: 1 / 3 / Unlimited (default: Unlimited)
  NDA required          Toggle (contestants agree to NDA before viewing brief)
```

**Prize escrow warning:** When the prize amount is entered, an inline callout appears:  
> *"⚠ Your prize ($500) will be held in escrow when you publish. This ensures creators are paid when a winner is selected. You can cancel an unfunded contest before submissions begin."*

This is NOT a modal — it's an inline `bg-amber-50 border-amber-200` callout card below the prize amount field. It appears as the user tabs away from the amount field. It doesn't block posting, but it sets expectations.

---

## 6. Preventing Overwhelm — The Anti-Complexity System

The posting system has 7 post types. Without careful design, the composer could become a dropdown with 7 options, a tab bar with 7 tabs, or a modal with 7 type cards. All of these are wrong.

### 6.1 Pre-selection by role

The deepest anti-overwhelm mechanism: every composer entry point pre-selects the post type. The user never sees a list of post types to choose from. They tap a chip, button, or link and land directly in the right composer.

- Tap `[+ Post]` → post composer. No type selection.
- Tap `[🛍 Product]` → product wizard. No type selection.
- Tap `[💼 Post Project]` → project form. No type selection.

The "choice" is made by which chip/button the user taps, not by a selector inside the composer.

### 6.2 Role filtering eliminates irrelevant types

Buyers never see Creator chips. Creators never see Buyer buttons. The role filtering in the Layer 1 composer card removes 2–5 irrelevant options before the user even opens a composer.

A buyer sees exactly 2 posting options: Project and Contest.  
A creator sees exactly 3 posting chips (plus availability in "⋯ More"): Post, Product, Service.  
A `both` user sees 5 total entry points — 3 creator chips + 2 buyer outline buttons — which is still manageable because the visual hierarchy separates them (creator = primary card, buyer = secondary outline strip).

### 6.3 Progressive complexity — fields revealed on demand

Within each composer, optional fields are collapsed or hidden behind "Advanced options →" until needed. Every composer shows the minimum viable fields first. Complexity is opt-in.

| Composer | Required fields shown first | Advanced fields hidden |
|---|---|---|
| Post | Content + media toolbar | Tags, credit, schedule, visibility |
| Product | Name + price + cover | Files, license, gallery, limited qty |
| Service | Title + price + category | Package tiers, add-ons, availability toggle |
| Project | Title + brief + budget | Reference files, timeline, experience level |
| Contest | Title + brief + prize + deadline | Reference files, submission format, max entries |

### 6.4 The `⋯ More` overflow (composer toolbar)

The compose sheet has a toolbar row below the text input:
```
[📷 Photo]  [🎬 Video]  [🔗 Link]  [# Tag]  [⋯ More]
```

Tapping `[⋯ More]` reveals additional options in a small action sheet (not another modal):
```
Additional options:
  📡  Broadcast Availability      ← opens availability composer
  📍  Add location                ← adds location tag to post
  👥  Tag collaborators           ← mention other creators
  🔕  Disable comments            ← toggle
```

Availability broadcast lives here — it's a specialized post type that most creators will rarely use. Burying it in `⋯ More` instead of a permanent chip keeps the primary toolbar clean.

### 6.5 Contextual entry points keep types separated

Post types don't compete with each other on the same screen because they have different contexts:

| Context | What appears | Why |
|---|---|---|
| Home feed (general browse) | Short composer card with primary chips | Match the browse mindset — posting is secondary |
| Creator profile page | "Add to portfolio" button, "+ List product" link | Portfolio context — post types make sense here |
| Dashboard → Listings | "Add new product", "Add new service" buttons | Work management context — catalog post types |
| Opportunities feed | Buyer composer only | Commercial intent context — only commercial post types |

A creator in the Dashboard Listings view sees only product/service options. A creator on their profile page sees "Add to portfolio" (post type). The context determines the option — the creator never sees all 5 creator options at once anywhere in the app.

---

## 7. Media, Files, Links, Pricing, Deadlines, Categories

### 7.1 Media handling

**Images:**
- Max 10 images per post, max 25MB each, accepted formats: JPG, PNG, WebP, HEIC (auto-converted to WebP on upload)
- First image = feed card cover. User can drag to reorder.
- Crop tool available (freeform, square, 4:3 — post type enforces aspect ratio)
- `aspect-[4/3]` enforced on post covers and product covers. Service covers: 16:9 option also available.

**Videos:**
- Max 1 video per post (posts/reels), max 500MB, max 3 minutes for posts, max 60s for service/product preview
- Formats: MP4 (H.264/H.265), MOV, WebM
- Auto-generates thumbnail from first frame; user can select a custom frame or upload a custom thumbnail
- Video compression applied server-side before storage (target: ≤ 10MB for playback file)

**Files (for products and project references):**
- Max 5 files per product, max 500MB total per product
- No format restriction for product files (creators sell what they make: .fig, .psd, .zip, .pdf, .mp3, etc.)
- Reference files for projects: max 5 files, max 50MB total, accepted: images, PDFs, .zip
- Files are stored in object storage (not served directly). Download links are signed URLs, expiring after 48h for preview and 7 days for purchased downloads.

### 7.2 Link handling

- One link preview per post. Auto-fetches OpenGraph title, description, and thumbnail from the URL.
- If OG data unavailable, falls back to displaying the raw URL as a formatted link card.
- Link preview card is dismissible ("✕" to remove the preview and just show the raw link in post text).
- Malicious URL detection: links are checked against a blocklist at submit time. Blocked links show an inline error: "This URL cannot be shared on NeuralMart."

### 7.3 Pricing

**For products:**
- Free ($0) is valid — signals a freebie/lead magnet.
- Currency is USD only in v1. International pricing (Phase 2).
- Minimum price: $0.01 (effectively $1 in practice — we round to nearest cent but don't enforce a floor).
- Maximum price: no hard cap, but anything over $10,000 triggers a `⚠ Unusually high price — double-check before posting` warning.
- Price is always shown as `$XX.XX` with two decimal places in the UI, `integer cents` in the API/database.

**For services:**
- Fixed price, hourly, or 3-tier packages.
- Minimum: $1 per tier or per hour.
- 3-tier: each tier must be priced higher than or equal to the tier below (enforced with inline error).
- "From $X" in feed cards always shows the lowest available price (Basic tier or fixed price or hourly min).

**For projects:**
- Budget is a range ($min – $max), not a fixed price.
- Min must be ≥ $1. Max must be ≥ min.
- Budget range is display-only at project posting — actual price is negotiated and agreed in the proposal/acceptance flow.

**For contests:**
- Prize is a single fixed amount, required. Minimum $50.
- Prize is moved to escrow on publish (payment integration required — placeholder in v1 with a `⚠ escrow pending` state on the contest card).

### 7.4 Deadlines

| Post type | Deadline | Notes |
|---|---|---|
| `post` / `reel` | None | Posts don't expire. Archive/hide is manual. |
| `availability` | End date (required) | Auto-sets `post.expiresAt`. Card shows countdown. |
| `product` | None | Products stay listed until creator unpublishes. |
| `service` | None | Stays live until `creator_profiles.acceptingWork = false` or service is paused. |
| `project` | Optional | Displayed as "Preferred by [date]". Does not auto-close the project. |
| `contest` | Required | Minimum 7 days. Auto-changes status to `judging` at deadline. Displayed as countdown timer on card. |

**Deadline UI patterns:**
- Days remaining > 7: shows formatted date ("Ends Jan 15")
- Days remaining 2–7: shows "Ends in N days" (amber text)
- Days remaining < 2: shows "Ends in N hours" (red text, `animate-pulse` on the deadline badge)
- Expired but status not updated: shows "⚠ Past deadline" (amber warning, admin can auto-close)

### 7.5 Categories

Category tags are shared across post types where they make semantic sense. The full category taxonomy:

**Creative disciplines (for posts, products, services, projects, contests):**
`Branding` · `Motion Design` · `UI/UX Design` · `Illustration` · `Photography` · `Video Production` · `Writing & Copy` · `Music & Audio` · `Voice Over` · `3D & Animation` · `Web Development` · `Other`

**Category rules:**
- Each post type selects exactly one category (single select, not multi-tag).
- Category is required for products, services, projects, and contests.
- Category is optional for posts (creators don't always write category-specific content).
- The "Other" category exists but deprioritized in Explore filters — content categorized as "Other" doesn't appear in any specific category browse page. This is an intentional incentive to use specific categories.

---

## 8. The Smart Guided Posting Flow

### 8.1 When to use it

The guided posting flow is **not** shown every time. It is shown only for first-time posts of each type. Once a user has created at least one of a given type, they skip the guide and go straight to the compose form.

| Condition | What happens |
|---|---|
| First `post` ever | Show one-screen "What to share?" guide before the sheet |
| First `product` ever | Show "Your first product" guide (4 screens) |
| First `service` ever | Show "Set up your service" guide (4 screens) |
| First `project` ever (buyer) | Show "How projects work" guide (2 screens) |
| First `contest` ever (buyer) | Show "How contests work" guide (2 screens) |
| Subsequent posts of the same type | Skip guide, go directly to composer |

Users can skip the guide at any point via a `[Skip guide]` link in the header.

### 8.2 Post guide (for creators posting their first work showcase)

```
Screen 1 of 1:
  [Illustration: creator holding a laptop with sparkles]
  "Your work deserves an audience."
  
  NeuralMart's feed is how buyers discover creators like you.
  Share a work sample, a recent project, or behind-the-scenes process.
  
  Tips for great posts:
  ✓ Show finished work, not just concepts
  ✓ Add a brief description of the client/context
  ✓ Tag the relevant skill category
  
  [Start sharing →]
```

### 8.3 Product guide (for creators listing their first digital product)

```
Screen 1 of 3:
  "Sell your work while you sleep."
  Upload once, sell forever.
  Buyers purchase and download automatically.
  [Next →]

Screen 2 of 3:
  "What makes a great product listing?"
  ✓ High-quality cover image (buyers judge by the cover)
  ✓ Clear description of what's included
  ✓ Accurate file format list
  ✓ A fair price for the value you're providing
  [Next →]

Screen 3 of 3:
  "Pricing guidance:"
  [Mini price range examples by category from platform data]
  "UI Kits: typically $15–$99"
  "Fonts: typically $10–$49"  
  "Templates: typically $5–$29"
  [These are rough guides — price what your work is worth.]
  [Start listing →]
```

### 8.4 Project guide (for buyers posting their first project)

```
Screen 1 of 2:
  "Post a project. Get proposals."
  
  Describe what you need. Set your budget.
  Creators will find your project and send proposals.
  You review, pick your favorite, and kick off the work.
  
  [Next →]

Screen 2 of 2:
  "Tips for great briefs:"
  ✓ Be specific about the deliverable ("A 5-page pitch deck" not "some slides")
  ✓ Share reference examples if you have them
  ✓ Set a realistic budget — low budgets attract fewer proposals
  ✓ Mention your timeline even if it's flexible
  
  [Post my first project →]
```

### 8.5 Contest guide (for buyers hosting their first contest)

```
Screen 1 of 2:
  "Host a contest. Let talent compete."
  
  Instead of hiring one creator, post a contest.
  Many creators submit work. You pick the winner.
  Prize goes from escrow to the winner automatically.

  [Next →]

Screen 2 of 2:
  "Contests work best when:"
  ✓ The brief is detailed and visual (share reference images)
  ✓ The prize is fair for the scope of work
  ✓ The deadline is realistic (7+ days for quality submissions)
  ✓ You commit to selecting a winner — creators are counting on you
  
  [Host my first contest →]
```

### 8.6 Smart field suggestions (contextual AI hints — Phase 2)

On the project and contest forms, placeholder text and helper copy should actively guide the user:

**Project title field:**
```
Placeholder: "e.g. Brand identity for a wellness startup"
Helper (shown on focus): "Specific titles get 40% more proposals"
```

**Project budget fields:**
```
[Budget Min]  [Budget Max]
Helper: "Tip: creators filter by budget. $0–$50 budgets rarely attract experienced talent."
```

**Contest prize field:**
```
Placeholder: "$500"
Helper (shown when amount entered < $100): "Prizes under $100 attract fewer entries. Consider $150+ for better quality."
```

These are inline helper texts (`text-xs text-muted-foreground`), not validation errors. They appear contextually, not on page load.

---

## 9. Composer State Management

### 9.1 Draft persistence

Any content entered in the compose sheet or wizard pages is automatically saved as a local draft. If the user:
- Navigates away (back button, deep link, phone call)
- Closes the app
- The session expires

The draft is preserved in `localStorage` (sheets) or `sessionStorage` (wizard pages) under a key like `neuralmart_draft_post`, `neuralmart_draft_product`, etc.

On next open of the same composer type, a restoration prompt appears:
```
┌───────────────────────────────────┐
│  📝  You have an unsaved draft    │
│  "Looking for a brand designer…"  │
│  [Resume draft]    [Start fresh]  │
└───────────────────────────────────┘
```

"Start fresh" clears the draft. "Resume draft" pre-fills the form.

**Draft retention:** 7 days. After 7 days, drafts are silently cleared.

### 9.2 Validation — field-level, not page-level

Validation runs field-by-field as the user types (debounced 500ms), not only on submit. This prevents the "I filled out the whole form and clicked Submit only to discover 3 errors" pattern.

**Validation rules by field type:**

| Field | Rule | Error message |
|---|---|---|
| Title (all types) | 5–120 chars | "Title must be 5–120 characters" |
| Content/brief | 20–2200 chars | "Please write at least 20 characters" |
| Price | > 0 | "Price must be greater than $0" |
| Budget max | ≥ budget min | "Max budget must be at least equal to min budget" |
| Prize | ≥ $50 | "Minimum contest prize is $50" |
| Deadline (contest) | ≥ 7 days from now | "Deadline must be at least 7 days away" |
| Cover image | Required for products/services | "A cover image is required" |
| Video | < 500MB, valid format | "Video must be under 500MB (MP4, MOV, or WebM)" |

**Submit button state:** Enabled only when all required fields pass validation. Disabled state shows a tooltip on hover: "Complete the required fields to post."

### 9.3 Post-submit behavior

After successful submission:

| Post type | Success action |
|---|---|
| `post` / `reel` / `availability` | Sheet closes. Feed refreshes. New post appears at top with subtle `↑ Your post` indicator. |
| `product` | Full page closes. Navigates to `/products/:id` (product detail page, creator's view). Toast: "Product listed!" |
| `service` | Full page closes. Navigates to `/services/:id`. Toast: "Service live!" |
| `project` | Full page closes. Navigates to `returnTo` param (e.g., `/`) or `/projects/:id`. Toast: "Project posted — creators will find it in the feed." |
| `contest` | Full page closes. Navigates to `returnTo` or `/contests/:id`. Toast: "Contest live! Prize held in escrow." |

Toast notifications use a `🎉` emoji only for first-time posts of a type (mirrors the guided flow's celebratory tone). Subsequent posts use plain toasts: "Posted", "Listed", "Live."

---

## 10. Editing and Deleting Posts

### 10.1 What can be edited after posting

| Post type | Editable fields | Non-editable after posting |
|---|---|---|
| `post` / `reel` | Content text, tags, visibility | Media (cannot swap images/video — delete and repost) |
| `availability` | Status, period, what I'm looking for | — |
| `product` | All fields except product files (can add files, not remove) | — |
| `service` | All fields | — |
| `project` | Title, brief, skills, timeline, notes | Budget range (cannot change after first proposal received), category |
| `contest` | Title, brief, cover image, notes | Prize amount, deadline (immutable after first entry received) |

**Why contests have immutable prize and deadline:** Creators submit entries based on the prize and deadline they see at time of submission. Changing either retroactively is a breach of trust. The UI enforces this: prize and deadline fields become read-only text (not inputs) once the first submission exists.

### 10.2 Delete behavior

All post types can be deleted by the creator/owner. Delete is a soft delete (`deleted_at` timestamp) — content is hidden from feeds immediately but retained in the database for 30 days (for dispute resolution) before hard deletion.

Deletion consequences:
- `post` / `reel`: Removed from feeds and profile. Likes/comments cascade soft-deleted.
- `product`: Removed from Market and feed. Buyers who purchased retain their download access.
- `service`: Removed from Market and feed. Active orders are not cancelled automatically — creator must communicate with affected buyers.
- `project`: Removed from feeds. If in `open` status, active proposals become orphaned — proposers receive a notification: "The project you proposed on was withdrawn."
- `contest`: If no submissions exist, deleted cleanly and prize released from escrow. If submissions exist, cannot be deleted — only closed (status → `cancelled`). Cancellation triggers a notification to all submitters and refund from escrow.

---

## 11. Composer Component Architecture

### Components to build

| Component | Type | Used by |
|---|---|---|
| `ComposerCard` | Feed component | `home.tsx`, `contest-feed.tsx` |
| `CreatorComposer` | Variant of ComposerCard | Creators, Both |
| `BuyerComposer` | Variant of ComposerCard | Buyers |
| `BothComposer` | Variant of ComposerCard | Both role |
| `ComposeSheet` | Bottom sheet / modal | Post, Reel, Availability |
| `PostComposerForm` | Form inside ComposeSheet | Post/Reel/Availability |
| `MediaUploader` | Reusable component | All composer types |
| `LinkPreviewCard` | Auto-fetch OG data | Post composer |
| `TagInput` | Reusable input | Post, Project, Contest |
| `ProductWizard` | Full-page wizard | `/products/new` |
| `ServiceWizard` | Full-page wizard | `/services/new` |
| `ProjectForm` | Full-page form | `/projects/new` |
| `ContestForm` | Full-page form | `/contests/new` |
| `PriceInput` | Reusable — currency formatted | Product, Service, Contest |
| `ServicePackageEditor` | 3-tier package UI | ServiceWizard |
| `DeadlinePicker` | Date + countdown | Contest, availability |
| `EscrowCallout` | Inline warning card | Contest prize field |
| `DraftRestorationPrompt` | Sheet header | All composers |
| `ComposerGuide` | First-time overlay | All post types, first use |
| `PostSuccessToast` | Toast notification | All post types |

### Component data flow

```
ComposerCard (Layer 1)
  ↓ user taps chip/button
ComposeSheet (Layer 2, for post/reel/availability)
  ↓ "Advanced options →" OR complex post type
  ProductWizard / ServiceWizard / ProjectForm / ContestForm (Layer 3)
    ↓ onSuccess
  PostSuccessToast + navigate(returnTo || defaultRoute)
```

All Layer 3 pages receive an optional `?returnTo=` query param. The `returnTo` is set by the caller (the feed or hub that triggered the composer). On success, the wizard redirects to `returnTo` so the user returns to their context (home feed, opportunity feed, dashboard).

---

## 12. Summary — The Composer Philosophy

The NeuralMart composer system is built around one principle: **the right composer appears for the right user in the right context, already knowing what they want to create.**

The user never:
- Sees a list of post types and has to choose
- Sees options irrelevant to their role
- Gets blocked by optional fields
- Loses their work because of navigation

The user always:
- Lands in a composer pre-configured for their role and context
- Sees only the minimum required fields first
- Can add complexity when they need it (Advanced options, wizard steps)
- Gets guided on their first use of each post type
- Returns to exactly where they were when they're done

Seven post types. One clean experience.

---

*End of document.*  
*Companion docs: `neuralmart-feed-architecture.md` · `neuralmart-home-page-architecture.md` · `neuralmart-navigation-hub-system.md` · `neuralmart-role-permissions-model.md`*
