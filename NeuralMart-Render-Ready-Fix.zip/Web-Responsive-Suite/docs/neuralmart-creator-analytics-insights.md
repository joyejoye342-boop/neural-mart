# NeuralMart — Creator Analytics & Performance Insights Hub

**Document version:** 1.0  
**Route:** `/dashboard/creator/insights`  
**Audience:** Creator and Both accounts

---

## 0. Analytics Goal

Analytics should help creators make better decisions, not simply produce a wall of counters.

The hub answers:

1. How many people discovered my work?
2. What did they do next?
3. Which formats and offers create meaningful business outcomes?
4. Where are buyers dropping off?
5. What should I try next?

The measurement chain is:

```text
Impression
→ View
→ Click / save / follow
→ Chat lead
→ Purchase / order
→ Repeat buyer
```

---

## 1. Analytics Route Structure

```text
/dashboard/creator/insights
├── /overview
├── /content
├── /funnel
├── /commerce
├── /opportunities
├── /audience
└── /recommendations
```

MVP can combine these into one page with anchored sections. The route structure should be stable for later expansion.

### Global controls

- Date range: 7 days, 30 days, 90 days, custom
- Compare previous period
- Content type filter
- Linked product/service filter
- Organic/promoted filter, once promotions exist
- Export, advanced

Every chart displays its date range and timezone.

---

## 2. Analytics Overview

```text
INSIGHTS
Last 30 days · Compared with previous 30 days

Reach              Engagement          Qualified leads       Revenue
18,420             1,860               34                   $2,840
↑ 18%              ↑ 9%                ↑ 21%                ↑ 14%

[Reach trend]
[Content → action funnel]

Top content
1. Fintech onboarding · 3 chats
2. Brand system reel · 86 saves

Next best action
Add a delivery example to your branding service.
```

### Overview KPI set

Show four metrics only:

- Reach/impressions
- Engagement actions
- Qualified chat leads
- Purchases/orders or attributed revenue

Do not place followers, likes, views, and earnings in the same KPI row. They represent different stages and create false comparisons.

---

## 3. Metric Definitions

### Views and impressions

- **Impression:** an eligible feed/card exposure.
- **View:** a meaningful media/content view according to the platform's event rule.
- **Unique reach:** distinct authenticated viewers in the selected period.

Show impressions and unique reach together when available. Do not call impressions “people reached.”

### Clicks

- Profile clicks
- Product/service clicks
- External portfolio clicks
- CTA clicks

Every click has a destination type. A click on `View profile` is not equal to a purchase click.

### Saves and follows

- Saves
- Save rate
- Follows attributed to content
- Follow conversion rate

Saves are an intent signal, not an immediate commercial conversion.

### Chat leads

A chat lead is a new or resumed conversation attributable to a creator content/profile touchpoint, with safeguards against counting every message.

Show:

- new chat leads;
- qualified chat leads, when qualification is supported;
- response-to-lead rate;
- lead-to-order conversion, later.

Do not expose the identities of individual viewers in aggregate analytics.

### Purchases and orders

Show:

- product purchases;
- service orders;
- project acceptances;
- attributed revenue;
- conversion rate.

Use a clear attribution window, such as a 7-day click or 1-day view window. Always label the model.

### Repeat buyers

Show:

- buyers with more than one completed order;
- repeat buyer rate;
- repeat revenue share;
- change over time.

Do not display repeat-buyer identities or private customer details on analytics charts.

---

## 4. Content Performance by Format

### Format comparison

```text
FORMAT PERFORMANCE
Format          Reach   Save rate   Leads   Orders
Case studies    8,420   6.8%        14      3
Graphics        5,210   4.1%        6       1
Reels           4,790   3.2%        9       2
Thumbnails      2,100   5.0%        5       0
```

### Available formats

- Reels/videos
- Thumbnails
- Graphics
- Case studies
- Service posts
- Product showcases
- Availability posts

### Interpretation rules

- Use rates alongside counts.
- Require minimum exposure before declaring a format winner.
- Show confidence language such as `Early signal` when data is limited.
- Do not recommend abandoning a format from one underperforming post.
- Separate creator goals: reach, relationship, and revenue.

### Content detail view

Per item:

- impressions/views;
- average watch time for video;
- saves;
- follows;
- profile/product/service clicks;
- chats;
- purchases/orders;
- attributed revenue;
- organic/promoted split;
- publish date and format.

---

## 5. Funnel and Conversion Insights

### Funnel

```text
18,420 impressions
  4,120 content views
    860 profile visits
      34 chat leads
        12 orders
```

The funnel should make drop-off visible without implying that every stage is directly causal.

### Funnel views

- Content → profile
- Profile → chat
- Profile → service view
- Service view → booking
- Product view → purchase
- Project proposal → acceptance

### Recommendations from funnel gaps

- High views, low profile visits → strengthen CTA or caption.
- High profile visits, low chats → improve availability or positioning.
- High service views, low bookings → clarify package, price, or proof.
- High chats, low orders → improve response time or proposal process.
- High purchases, low repeats → improve delivery/follow-up experience.

---

## 6. Project and Contest Metrics

Creators need a separate Opportunities view because proposal and contest behavior is not the same as content performance.

### Project metrics

- Projects viewed
- Proposals submitted
- Proposal views
- Buyer replies
- Shortlists
- Accepted proposals
- Win rate
- Average response time
- Earnings from projects

### Contest metrics

- Contests viewed
- Entries submitted
- Shortlists/finalists
- Wins
- Prize earnings
- Entry-to-finalist rate

### Rules

- Never mix contest prize earnings with product/service revenue without labels.
- Proposal win rate is private to the creator.
- Public profiles may show completed projects or contest wins, not proposal funnel details.
- Recommendations should favor relevant opportunities, not simply the highest prize.

---

## 7. Audience Insights

### MVP

- Profile views
- Follower growth
- Content reach
- Saves and follows
- Top-performing format

### Advanced

- Returning visitor rate
- Audience interest categories
- Discovery source
- Viewer-to-chat conversion
- Viewer-to-order conversion
- Time/day performance
- Audience overlap between content and offers

Privacy rules:

- no individual viewer identities;
- no sensitive demographic inference;
- no private buyer profiling;
- minimum aggregation thresholds for audience segments.

---

## 8. Recommendations Engine

Recommendations should be small, specific, and connected to an editable surface.

### Examples

```text
Your case studies create 2× more saves than graphics.
Feature one on your profile Overview.

Your service gets views but few bookings.
Add three delivery examples and clarify turnaround time.

You have 3 proposals awaiting a response.
Reply today to protect your opportunity.

Your repeat buyer rate is rising.
Create a returning-client service package.
```

### Recommendation rules

- One primary recommendation at a time.
- Show the evidence behind it.
- Include `Why am I seeing this?`
- Allow dismiss/snooze.
- Do not recommend actions that conflict with urgent work.
- Do not turn analytics into a gamified pressure loop.

---

## 9. Data Quality and Attribution

- Define every metric in the UI.
- Deduplicate repeated view events.
- Exclude the creator's own views from performance metrics.
- Mark estimated or delayed revenue clearly.
- Use settled transactions for purchase/revenue metrics.
- Preserve original event dates when content is edited.
- Separate organic and promoted exposure.
- Keep a consistent attribution window.
- Show `Not enough data` when a rate would be misleading.

Analytics are directional decision tools, not promises of causality. Tooltips should explain this where conversion attribution is shown.

---

## 10. Analytics MVP vs Advanced

### MVP

- 7/30/90-day range
- Reach/impressions
- Views
- Clicks
- Saves/follows
- Profile visits
- Chat leads, if events exist
- Purchases/orders
- Basic format comparison
- Basic project/contest response metrics
- One recommendation

### Advanced

- Attribution funnel
- Repeat buyer analytics
- Organic/promoted comparison
- Revenue by content/service/product
- Audience segments
- Cohort trends
- Forecasting
- Content experiments
- Export/API
- Opportunity quality scoring

## Final rule

Analytics should move a creator from “something got views” to “this kind of work attracts this kind of buyer, and here is the next thing worth trying.”
