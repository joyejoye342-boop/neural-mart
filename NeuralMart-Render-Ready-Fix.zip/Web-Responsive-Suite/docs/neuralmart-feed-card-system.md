# NeuralMart — Feed Card System

**Document version:** 1.0  
**Scope:** Card architecture for creator content, marketplace listings, buyer opportunities, and recommendation modules.  
**Companion documents:** `neuralmart-feed-architecture.md` · `neuralmart-composer-system.md` · `neuralmart-home-page-architecture.md`

---

## 0. Card System Principles

NeuralMart has many content objects, but users should not feel that every card belongs to a different product. The card system therefore follows five rules:

1. **One shared shell, many content bodies.** Every card uses the same author header, content region, metadata rhythm, action footer, and overflow menu.
2. **One primary action per card.** A card may have secondary actions, but only one action receives primary visual weight.
3. **Context changes density, not identity.** The same project can appear as a compact opportunity in the Showcase Feed and a detailed hiring card in the Opportunities Feed. It should still be recognizably the same project.
4. **Trust appears close to the decision.** Ratings, verification, sales history, response time, budget, and deadline are shown where a buyer or creator is deciding whether to act.
5. **Commercial cards never pretend to be social posts.** A product, service, project, or contest has clear type labeling and a direct CTA. It can live in a social feed without disguising its purpose.

The desired feeling is: **familiar social cards with marketplace-grade decision support.**

---

## 1. Card Taxonomy

NeuralMart uses nine user-facing card types, grouped into four families:

### A. Creator showcase cards

1. **Product Showcase Card** — a creator's digital product or exclusive project asset.
2. **Reel / Video Card** — short-form motion or video work.
3. **Graphic / Thumbnail Showcase Card** — visual portfolio work, single image or gallery.
4. **Promotional Creator Post Card** — a creator announces a launch, service, product, availability, or milestone.

### B. Marketplace and work cards

5. **Service Card** — a bookable creator service.
6. **Buyer Project / Hiring Request Card** — a buyer's open brief requesting proposals.
7. **Contest Card** — a buyer's prize-based creative brief.

### C. Utility and editorial modules

8. **Availability Card** — a freelancer's structured availability signal. It is a specialized creator post, not a new feed family.
9. **Recommendation Block** — a non-user editorial module that suggests creators, products, services, or opportunities.

### Normalization rule

The system should not create separate back-end concepts for every visual variation:

| User-facing card | Canonical source |
|---|---|
| Reel / video card | `posts.type = reel` |
| Graphic / thumbnail showcase | `posts.type = image` or `text` with media |
| Promotional creator post | `posts.type = product`, `service`, or a post subtype/intent |
| Hiring request | `projects` with `status = open` |
| Availability card | `posts.type = availability` |
| Recommendation block | Feed module, not a user-generated object |

This keeps permissions, moderation, analytics, and feed APIs manageable while allowing cards to be visually specialized.

---

## 2. Shared Card Shell

Every card uses the following anatomy unless a full-bleed media treatment is explicitly called out:

```text
┌──────────────────────────────────────────────┐
│  AUTHOR HEADER                                │
│  [avatar] Name · trust badge       [•••]      │
│           role/type · relative time            │
├──────────────────────────────────────────────┤
│  TYPE LABEL + CONTENT BODY                    │
│  [type badge]                                 │
│  title/caption/brief                          │
│  media or structured details                  │
├──────────────────────────────────────────────┤
│  TRUST / DECISION METADATA                    │
│  rating · sales · budget · deadline · status  │
├──────────────────────────────────────────────┤
│  ACTION FOOTER                                │
│  secondary actions          [PRIMARY CTA →]   │
└──────────────────────────────────────────────┘
```

### 2.1 Header anatomy

| Element | Rule |
|---|---|
| Avatar | 36px on mobile, 40px on desktop. Always links to a public creator profile when one exists. |
| Display name | One line, semibold, maximum 24 characters before truncation. |
| Trust badge | Only show verified/trusted status when it is earned. Never use decorative badges that look like verification. |
| Role/type line | Small muted text such as `Creator · UI/UX` or `Buyer · Startup`. |
| Timestamp | Relative time for fresh content; absolute deadline/date for opportunity cards. |
| Overflow | `•••` menu contains Save, Share, Report, Hide, and owner actions. Never place all actions in the visible footer. |

### 2.2 Type labels

Every non-standard post has a small type label near the title:

| Type | Label | Accent |
|---|---|---|
| Creator post | `Showcase` | Primary blue |
| Reel | `Reel` | Violet/primary |
| Product | `Product` | Teal/primary |
| Service | `Service` | Primary blue |
| Project | `Open project` or `Hiring request` | Muted amber |
| Contest | `Contest` | Amber |
| Availability | `Available for work` | Green |
| Recommendation | `Recommended` | Neutral violet |

Type labels are semantic chips, not large banners. Their purpose is orientation, not decoration.

### 2.3 Footer anatomy

The footer supports no more than four visible controls:

- Save/bookmark
- Comment or message, when relevant
- Share
- One primary CTA

The primary CTA is a filled button on desktop and a full-width or high-contrast button on mobile. Secondary actions remain ghost buttons or icon buttons.

### 2.4 Shared trust strip

Trust data is selected by card type:

- Creator cards: verified status, rating, completed orders, response time, follower or sales signal.
- Product cards: sales count, rating/reviews, delivery type, ownership/licensing state.
- Service cards: rating, review count, orders completed, response time, starting price.
- Project cards: budget range, proposal count, buyer verification, buyer spend/history signal.
- Contest cards: funded/escrow status, prize, deadline, host verification, entry count.

Do not show every trust field on every card. The card should show only the information needed for the next decision.

---

## 3. Card Type 1 — Product Showcase Card

### Purpose

Help a buyer discover and purchase a creator-made digital product or exclusive project asset from the social Showcase Feed, while still supporting a full product listing in the Market hub.

### Target audience

- **Primary:** Buyers and general audiences discovering something useful or visually appealing.
- **Secondary:** Creators browsing peer work and buying products from other creators.

### Visible content

```text
[creator avatar] Creator Name        [Product]
                 Creator · UI/UX · 2h

[cover image, 4:3]

Product title
One-line description
$49 · Exclusive ownership
```

For exclusive creator projects, the card must show the licensing state directly:

- `Available · Exclusive ownership`
- `Sold · Locked`

### CTA buttons

| Viewer state | Primary CTA |
|---|---|
| Buyer viewing available product/project | `Buy now · $49` |
| Creator viewing another creator's item | `View product` or `Buy now` |
| Owner viewing own item | `Manage listing` |
| Sold exclusive item | `Sold · Locked` disabled |
| User already owns item | `Owned · View purchase` |

Secondary actions: Save, Share, View creator.

### Metadata shown

- Price
- Category
- Sales count when at least one sale exists
- Ownership model (`Exclusive ownership` by default)
- Availability state
- Optional file type signal such as `Figma · 12 files`

### Trust and reputation

- Creator avatar and verified badge
- Sales count
- Rating/review count when available
- `Secure checkout` or `Instant delivery` only when those flows are actually supported
- For exclusive items: immutable `Available` or `Sold · Locked` state

### Mobile behavior

- Full-width card inside the single feed column.
- Media uses a fixed `aspect-ratio: 4 / 3` to prevent layout shifts.
- Price sits on the media as a compact pill; the ownership state sits beside the category below the title.
- CTA is full width at the bottom, at least 44px tall.
- The entire media/title region opens detail; tapping the CTA performs the purchase intent directly.
- Do not use a two-column product grid inside the social feed. Grid belongs in the Market hub.

### Feed variants

**Showcase Feed:** image-led, compact, social footer visible. The card can be consumed passively and uses `View product` or `Buy now` as the single commercial action.

**Opportunities Feed:** product cards do not appear. Product listings are not hiring opportunities and must not compete with projects or contests.

**Market hub:** denser grid card with filters, price sorting, and a stronger purchase CTA. The card may show more metadata because the user has purchase intent.

---

## 4. Card Type 2 — Reel / Video Card

### Purpose

Show short-form motion, video editing, animation, or process work in a familiar social format that lets the visual speak first.

### Target audience

- Buyers looking for a creator's style or capabilities.
- Creators and general audiences discovering work.
- Potential clients evaluating motion/video quality before contacting a creator.

### Visible content

```text
[creator avatar] Creator Name             [Reel]
                 Motion Design · 3h

[full-bleed video thumbnail / poster]
[play button]                         [0:42]

Caption, up to 3 lines
Optional: Made for [client/project]
```

### CTA buttons

Primary CTA is contextual:

- Buyer/general audience: `View creator`
- Buyer who has commercial intent: `Start a project` or `Message creator`
- Creator viewing another creator: `View creator`
- Owner: `Manage reel`

Secondary actions: Like, Comment, Share, Save.

Do not place `Buy now` on a reel unless the reel explicitly links to a product or service. If linked, show a small secondary link card such as `Related service →`.

### Metadata shown

- Duration
- Category or skill
- Posted time
- Optional view count only after the platform has meaningful view data
- Optional client/project credit

### Trust and reputation

- Creator profile link and verified state
- Creator category
- Optional response time or `Available for work` signal when active
- Never use view count as a trust badge. It is engagement, not quality assurance.

### Mobile behavior

- 9:16 or 4:5 poster for vertical reels; 16:9 for landscape work. Preserve source intent but cap card height at 560px.
- Video is muted and paused by default until it enters the viewport and the user has opted into autoplay.
- Tap poster to play/pause. Keep controls minimal.
- Use a gradient scrim behind the play button and duration only; never overlay the full caption on top of the work.
- On slow connections, show poster image first and defer video loading.

### Feed variants

**Showcase Feed:** full visual treatment with social interactions. This is where reels belong.

**Buyer/project feed:** reels do not appear as standalone cards. A creator reel may appear as a compact `Work sample` attachment inside a proposal or creator recommendation block, not in the project stream.

---

## 5. Card Type 3 — Graphic / Thumbnail Showcase Card

### Purpose

Present static portfolio work — thumbnails, campaign graphics, illustrations, UI screens, logos, and visual case-study snapshots — in a clean visual showcase.

### Target audience

- Buyers comparing visual styles and quality.
- Creators building reputation and attracting followers.
- General audiences browsing creative work.

### Visible content

```text
[creator avatar] Creator Name             [Showcase]
                 Branding · 1d

[single image OR 2–4 image gallery]

Caption/title
Optional project credit
```

### CTA buttons

- `View creator` is the primary CTA when there is no linked commercial object.
- `View related service` when the creator linked a service.
- `View product` when the work is a product preview.
- Owner: `Edit showcase`.

Secondary actions: Like, Comment, Share, Save.

### Metadata shown

- Category/skill
- Number of images (`1/4` for gallery)
- Client/project credit when public
- Posted time
- Optional software/tool tags in the expanded detail view, not the feed card

### Trust and reputation

- Creator identity and profile category
- Verified badge
- Portfolio count or completed work count only in expanded detail or profile
- Do not place ratings over visual work; keep the artwork clean.

### Mobile behavior

- Single image: 4:3 or source-ratio crop with a predictable max height.
- Gallery: horizontal swipe carousel, one image visible at a time, dot/position indicator.
- Avoid auto-advancing galleries.
- Caption is below media and capped at 3 lines with `More`.
- Tap image opens a media viewer; tap author opens profile.

### Feed variants

**Showcase Feed:** image-first and social. The visual is the card's dominant element.

**Buyer/project feed:** not a standalone feed card. When a project needs visual references, show them in a `Reference gallery` section inside the project card/detail page. Never mix a buyer's mood board with a creator's portfolio post without a clear `Reference` label.

---

## 6. Card Type 4 — Service Card

### Purpose

Make a creator's service understandable and bookable without forcing the buyer to open a full profile first.

### Target audience

- Buyers with a defined need and purchase/hiring intent.
- Creators browsing peer offerings or purchasing another creator's service.

### Visible content

```text
[creator avatar] Creator Name             [Service]
                 UI/UX Design · 4.9 ★

[optional cover image, 4:3]

Brand identity package for early-stage startups
From $300 · 7-day delivery
```

### CTA buttons

| Viewer state | Primary CTA |
|---|---|
| Buyer viewing another creator | `View service` or `Book now` |
| Creator viewing another creator | `View service` |
| Owner | `Manage service` |
| Paused/unavailable | `Currently unavailable` disabled |

Secondary actions: Save, Message creator, View creator.

### Metadata shown

- Starting price or lowest package price
- Delivery estimate
- Category
- Rating and review count
- Package count (`3 packages`) when relevant
- Availability (`Accepting work` / `Paused`)

### Trust and reputation

- Rating and review count
- Completed orders or jobs
- Response time
- Verified creator badge
- Clear package/delivery information

The card must not show a rating of `5.0` with no reviews as if it were established reputation. Render it as `New` or `No reviews yet` until there is review history.

### Mobile behavior

- Optional cover image uses 4:3 and lazy loading.
- If no cover exists, use a calm category-colored placeholder with the service icon; never a broken image.
- Price and rating share one metadata row.
- CTA is full width.
- Package details remain collapsed. The detail page handles Basic/Standard/Premium comparison.

### Feed variants

**Showcase Feed:** compact service promotion. Show cover, one-line value proposition, rating, and `View service`.

**Buyer/project feed:** service cards are not inserted into the project stream. A matching service may appear in a recommendation block below a project, labeled `Creators you may like`, but never as if it were a proposal.

**Market hub:** supports filter chips, category sorting, and stronger `Book now` treatment.

---

## 7. Card Type 5 — Buyer Project / Hiring Request Card

### Purpose

Turn a buyer's need into a clear opportunity for creators while allowing buyers to recognize and manage their own posted brief.

`Hiring request` is the plain-language card label. `Project` remains the canonical object and route.

### Target audience

- **Primary:** Creators looking for paid work.
- **Secondary:** Buyers reviewing their own request or browsing other buyers' briefs.
- **Both users:** Creator actions take priority on other users' projects; owner actions take priority on their own.

### Visible content

```text
[buyer avatar] Maya's Startup              [Open project]
                Buyer · Verified · 2h

Need a brand identity for our Series A fundraise
We need a designer to create a logo, pitch deck system,
and launch assets...

$800–$2,500 · Branding · Figma · 12 proposals
Preferred by Mar 20
```

### CTA buttons

| Viewer state | Primary CTA |
|---|---|
| Creator viewing another user's open project | `Send proposal` |
| Both viewing another user's open project | `Send proposal` |
| Buyer viewing own project | `Manage project` |
| Buyer viewing someone else's project | `View project` |
| Closed/in-progress/completed project | `View details` or status button, never `Send proposal` |

Secondary actions: Save, Share, View buyer, Hide.

### Metadata shown

- Budget range
- Category
- First 2–3 required skills
- Proposal count
- Deadline or preferred date
- Open/in-progress/closed state
- Relative posted time

The card should not show a full brief, all attachments, buyer's private information, or a proposal list.

### Trust and reputation

- Buyer verification state
- Buyer history signal such as `3 projects completed` when available
- Optional spend/response signal: `Usually responds in 24h`
- Proposal count as competition context
- Funded/verified budget indicator only when the platform can verify it

Never expose sensitive financial history or a buyer's exact spend without explicit product permission.

### Mobile behavior

- Single-column card, approximately 200–260px depending on brief length.
- Brief is capped at 3 lines.
- Budget is a high-contrast metadata item; it should be scannable without opening the card.
- Skills wrap to one line with `+N more`.
- CTA is full width for creators.
- Tapping the card opens `/projects/:id`; the CTA opens the same detail page with proposal focus.

### Feed variants

**Showcase Feed:** compact social-discovery variant. Muted amber `Open project` label, two-line brief, budget, skills, proposal count, and creator CTA. It should feel like an occasional opportunity among creator work.

**Opportunities Feed:** detailed hiring variant. More brief text, deadline, buyer trust signal, and filters. It should feel like a professional work board.

**Buyer home feed:** the buyer's own new project appears as a normal compact project card after posting, with `Manage project`, not a creator-facing proposal CTA.

---

## 8. Card Type 6 — Contest Card

### Purpose

Present a time-bound, prize-based opportunity with enough information for creators to decide whether to enter and enough trust information to know the contest is legitimate.

### Target audience

- Creators seeking competitions and paid creative opportunities.
- Buyers comparing or managing contests they host.
- General audiences may browse, but entering is creator-only.

### Visible content

```text
┌─ amber top border ────────────────────────────┐
│ [🏆] Logo Design Challenge             [Contest]│
│      Branding · 23 entries                     │
│                                                │
│ Prize                                           │
│ $500                                            │
│                                                │
│ Design a flexible identity for a climate-tech  │
│ startup...                                      │
│                                                │
│ Ends in 4 days · Funded prize                  │
│ [Submit entry →]                                │
└────────────────────────────────────────────────┘
```

### CTA buttons

| Viewer state | Primary CTA |
|---|---|
| Creator viewing open contest | `Submit entry` |
| Both viewing another user's open contest | `Submit entry` |
| Buyer viewing own contest | `Manage contest` |
| Buyer viewing another user's contest | `View contest` |
| Contest closed/judging | `View submissions` or `View results` |

Secondary actions: Save, Share, View host.

### Metadata shown

- Prize amount
- Category
- Deadline/countdown
- Entry count
- Funded/escrow state
- Host identity
- Submission format, only if it materially affects participation

### Trust and reputation

- Host verification
- `Prize funded` / `Escrow pending` state
- Clear deadline
- Host history signal such as completed contests
- Rules or winner-selection method on detail, not in the compact card

The contest card must never imply a prize is guaranteed if escrow has not been confirmed. Use `Escrow pending` and disable `Submit entry` if platform policy requires funding first.

### Mobile behavior

- Amber top border, not a fully amber background.
- Prize amount is the visual anchor, using large serif type.
- Countdown changes from date to urgency language: `Ends Apr 12` → `Ends in 3 days` → `Ends in 8 hours`.
- Deadline under 48 hours uses red text, but do not animate the entire card.
- Full-width `Submit entry` button.

### Feed variants

**Showcase Feed:** contest cards do not appear. Contests are intentionally kept out of the leisure/social feed.

**Opportunities Feed:** full card with amber identity, prize, deadline, entry count, escrow state, and creator CTA.

**Buyer dashboard:** own contests use an operational card with submission count, judging state, and `Review submissions`.

---

## 9. Card Type 7 — Promotional Creator Post

### Purpose

Let creators promote a product, service, launch, availability window, case study, or milestone without creating a new product category or turning every post into an advertisement.

### Target audience

- Buyers discovering creator offerings.
- Existing followers and general audiences.
- Creators promoting their own work.

### Supported promotion intents

The creator selects a simple intent when composing, or the system infers it from a linked object:

| Intent | Example | Card treatment |
|---|---|---|
| New work | `Just finished a brand system` | Showcase/image treatment |
| Product launch | `My new UI kit is live` | Product attachment card |
| Service promotion | `Taking on two branding clients this month` | Service attachment card |
| Availability | `Open for design work in April` | Green availability strip |
| Case study | `How I redesigned a fintech onboarding flow` | Image/gallery + project credit |

### Visible content

```text
[creator avatar] Creator Name            [Showcase]
                 Branding · 1d

Short promotional caption
[linked product/service/portfolio preview]
Optional offer or availability message
```

### CTA buttons

The CTA must match the linked object:

- Linked product: `View product` or `Buy now`
- Linked service: `View service` or `Book now`
- Availability: `Message creator`
- Portfolio-only post: `View creator`
- Owner: `Manage post`

Never use generic `Learn more` when a precise action exists.

### Metadata shown

- Linked object type
- Category
- Price or starting price if applicable
- Availability state
- Posted time

### Trust and reputation

Use the linked object's trust elements, not a second duplicate trust strip. For example, a service promotion shows rating and reviews in the service attachment, while the post header shows the creator identity only once.

### Mobile behavior

- Keep the promotional caption to 3 lines before expansion.
- Render the linked object as a nested mini-card with a clear boundary and type label.
- Do not stack more than one nested commercial object.
- Hide promotional cards from users who repeatedly dismiss them; do not remove organic showcase posts.

### Feed variants

**Showcase Feed:** allowed, but rate-limited. A creator should not be able to fill the feed with repetitive sales posts.

**Opportunities Feed:** promotional posts never appear as standalone cards. A service may appear only as a recommendation below a project.

### Promotion frequency rule

At most one promotional card from the same creator in a rolling 24-hour window in a user's Showcase Feed, unless the user follows that creator and has explicitly opted into all updates.

---

## 10. Card Type 8 — Availability Card

### Purpose

Give freelancers a low-friction way to communicate that they are open for work, without requiring them to publish a full service listing or project proposal.

### Target audience

- Buyers looking for available talent.
- Creators who want to signal capacity or upcoming availability.

### Visible content

```text
[creator avatar] Creator Name       [Available for work]
                 Motion Design · 2h

Available for 1–2 projects in April
Looking for: brand films, product animation

Accepting work · Typical response under 24h
[Message creator →]
```

### CTA buttons

- Buyer/general audience: `Message creator`
- Creator viewing another creator: `View creator`
- Owner: `Edit availability`
- Expired: `Availability ended` disabled, then remove from active feed ranking

### Metadata shown

- Availability window
- Capacity signal (`1–2 projects`)
- Category
- Optional response time
- Optional preferred project type

### Trust and reputation

- Creator profile and verification
- Completed jobs or reviews where available
- Response-time signal only if measured by the platform

### Mobile behavior

- Compact card, usually 150–190px high.
- Green is limited to the availability badge and CTA icon; do not turn the entire card green.
- Automatically expires at the end date.
- Keep the message CTA full width.

### Feed variants

**Showcase Feed:** appears as an occasional creator update, subject to rate limiting.

**Opportunities Feed:** not a hiring opportunity itself. It may appear in a recommendation module under a project, never mixed into the active opportunity ranking.

---

## 11. Card Type 9 — Recommendation Block

### Purpose

Help users move from passive browsing to a relevant next action without adding another permanent feature section to the feed.

Recommendation blocks are editorial feed modules, not user posts. They must be visually distinct from organic content but still use the shared card language.

### Target audience

Recommendation blocks are role- and context-aware:

| Context | Recommended content |
|---|---|
| Buyer browsing Showcase Feed | Creators, services, products |
| Creator browsing Showcase Feed | Similar creators, open projects |
| Creator in Opportunities Feed | Matching creators' services only after a gap, not instead of opportunities |
| New user with empty feed | Creator starter set + hub shortcuts |
| Buyer after viewing a project | Relevant creators or services |

### Visible content

```text
Recommended for you                         [See all →]
Based on your interest in Branding

[mini creator card] [mini creator card] [mini creator card]
```

or:

```text
Creators who can help with this project
[avatar] Maya · Branding · 4.9★      [View]
[avatar] Alex · Pitch decks · 5.0★    [View]
```

### CTA buttons

- `See all` opens the relevant hub or filtered Explore page.
- Mini creator: `View profile`
- Mini service: `View service`
- Mini project: `View project`
- Dismiss: `Not interested`

### Metadata shown

Only the minimum needed to evaluate the recommendation:

- Creator category and rating
- Service starting price
- Project budget/deadline
- Reason for recommendation in one short line

### Trust and reputation

Recommendations must include the same source object's trust signals. Never show a recommendation with no author, category, or reason.

### Mobile behavior

- Horizontal carousel with 2.2 mini-cards visible at 390px.
- Maximum one recommendation block per 8 organic cards.
- Never insert a recommendation block before the first organic card.
- Use a light tinted background and a small `Recommended` label to distinguish it from a user post.
- Avoid auto-scrolling carousels.

### Feed variants

**Showcase Feed:** recommendation blocks help buyers discover creators and help creators discover projects.

**Opportunities Feed:** only contextually relevant creator/service recommendations appear, and never before the first two actual opportunities. Commercial opportunities always outrank recommendations.

---

## 12. Feed Placement Matrix

| Card type | Showcase Feed | Opportunities Feed | Market/Hub | Profile | Dashboard |
|---|:---:|:---:|:---:|:---:|:---:|
| Product showcase | ✅ | ❌ | ✅ | ✅ | ✅ creator |
| Reel/video | ✅ | ❌ | ❌ | ✅ | ✅ creator |
| Graphic showcase | ✅ | ❌ | ❌ | ✅ | ✅ creator |
| Service card | ✅ | recommendation only | ✅ | ✅ | ✅ creator |
| Buyer project/hiring request | ✅ compact | ✅ full | ❌ | ❌ | ✅ buyer |
| Contest card | ❌ | ✅ full | ❌ | ❌ | ✅ buyer |
| Promotional creator post | ✅ rate-limited | ❌ | linked object only | ✅ | ✅ creator |
| Availability card | ✅ rate-limited | recommendation only | ❌ | ✅ | ✅ creator |
| Recommendation block | ✅ conditional | ✅ conditional | optional | optional | optional |

### Placement rules

1. The Showcase Feed is the only feed with creator social content.
2. The Opportunities Feed is the only feed with contest cards.
3. Open projects can appear in both feeds, with different density and CTA context.
4. Recommendations never replace the object that caused the recommendation.
5. A card appears once per feed page; do not show the same object twice in one response.
6. A creator's own product/service/project uses management actions and is never presented as a purchase or proposal opportunity to its owner.

---

## 13. Feed-Specific Card Density

### Showcase Feed — social mode

Prioritize visual discovery and lightweight interaction:

1. Author and visual media
2. Caption/title
3. One or two trust/commerce signals
4. Social actions
5. One contextual CTA

Target: one complete card plus a visible portion of the next card above the fold.

### Opportunities Feed — work mode

Prioritize decision-making:

1. Opportunity type and value
2. Deadline or availability
3. Brief and required skills
4. Trust/funding signal
5. Apply/enter/manage CTA

Target: approximately two opportunity cards visible above the fold.

### Detail pages

The feed card is never the full object. Detail pages contain:

- Full description/brief
- Full gallery/files
- Complete package or submission rules
- Reviews and history
- Conversation/proposal/purchase flow
- Legal ownership, licensing, or escrow details when relevant

---

## 14. Role and CTA Logic

Use capability and ownership checks in this order:

```text
1. Is the viewer the owner?
   → Show Manage/Edit/Review action.

2. Is the object active and actionable?
   → Show the role-appropriate primary CTA.

3. Is the viewer allowed to perform that action?
   → Show CTA if allowed; otherwise View details.

4. Is the object unavailable, sold, closed, expired, or paused?
   → Show a clear disabled status, never a misleading action.
```

### Role examples

| Scenario | Correct result |
|---|---|
| Buyer sees creator product | Buy now |
| Creator sees another creator service | View service |
| Creator sees buyer open project | Send proposal |
| Buyer sees another buyer project | View project |
| Both sees another user's open project | Send proposal |
| Buyer sees own project | Manage project |
| Creator sees open contest | Submit entry |
| Buyer sees own contest | Manage contest |
| Anyone sees sold exclusive project | Sold · Locked |

No card should rely on color alone to communicate why a CTA is unavailable. Use visible label text.

---

## 15. Design Language

### 15.1 Shared visual tokens

| Token | Recommendation |
|---|---|
| Surface | `bg-card`, one consistent card surface across types |
| Border | `border-border`; accent border only for contests/status emphasis |
| Radius | `rounded-2xl` for cards, `rounded-xl` for nested attachment cards |
| Shadow | `shadow-sm`; elevate only on hover/focus |
| Card gap | 20px on mobile, 24px on desktop |
| Inner padding | 16px mobile, 20px desktop |
| Title | `font-serif font-bold` for product/opportunity titles; `font-sans` for utility labels |
| Body | 14–16px with relaxed line height |
| Muted metadata | 12–13px, muted foreground |
| CTA height | Minimum 44px on mobile |

### 15.2 Accent semantics

| Accent | Meaning | Use |
|---|---|---|
| Primary blue | Creation, navigation, standard action | Creator posts, service actions, proposal CTA |
| Amber/gold | Prize, contest, financial opportunity | Contest cards, contest nav, prize/deadline emphasis |
| Green | Available, active, completed safely | Availability status, funded/confirmed status |
| Red | Error, expired, destructive, urgent deadline | Validation, expired state, cancellation |
| Violet/neutral tint | Editorial recommendation | Recommendation blocks only |

Accent colors never replace the shared surface or typography. They identify meaning, not card ownership.

### 15.3 Image language

- Reserve full-bleed media for creator visual work.
- Reserve structured text-first cards for projects, contests, services, and availability.
- Never use generic stock imagery as a fallback for a creator's work. Use a quiet category-colored placeholder instead.
- Keep media aspect ratios stable.
- Lazy-load everything below the first card.

### 15.4 Motion language

- Card entrance: subtle fade/slide consistent with the existing app.
- Hover: slight border or shadow change, no large scale effects.
- Video: play/pause only; no autoplay with sound.
- Purchase/proposal/entry success: short confirmation state on the CTA.
- Sold/closed transition: status badge changes immediately; do not animate a card away before the server confirms.

---

## 16. Accessibility and Interaction Requirements

- Every card has a semantic heading and accessible type label.
- The full card is not one giant link when it contains multiple interactive controls. Use a clickable media/title region plus separate buttons.
- Icon-only actions require `aria-label`.
- Color is paired with text for sold, closed, funded, verified, and availability states.
- Keyboard focus is visible on card regions, buttons, carousels, and overflow menus.
- Reels and galleries expose play/pause, position, and alternative text.
- Screen readers should encounter the card in this order: type → author → title/brief → key metadata → primary action → secondary actions.
- Touch targets are at least 44×44px, including carousel controls and overflow menus.

---

## 17. Performance and Feed Integrity

### Rendering

- Render cards from a discriminated union: `type` determines the card body.
- Reserve media dimensions before loading images or video.
- Use skeletons matching the final card variant.
- Avoid loading product files, full galleries, or videos until the user opens detail or explicitly plays.
- Recommendation blocks should be lazy-mounted only when near the viewport.

### API and ranking metadata

Each feed item should return a normalized envelope:

```ts
type FeedCardEnvelope = {
  id: string;
  type:
    | 'post'
    | 'reel'
    | 'product'
    | 'service'
    | 'project'
    | 'contest'
    | 'availability'
    | 'recommendation';
  context: 'showcase' | 'opportunities' | 'profile' | 'dashboard';
  createdAt: string;
  status?: 'active' | 'sold' | 'closed' | 'expired' | 'paused';
  ownerId?: number;
  payload: unknown;
};
```

The API, not only the client, must enforce:

- closed/expired projects and contests are excluded from active feeds;
- sold exclusive projects/products are excluded from available marketplace results;
- the owner receives management metadata;
- role-based actions are validated server-side;
- recommendation blocks do not duplicate a card already in the response.

### Feed integrity rules

- Max two consecutive cards of the same type in Showcase Feed.
- No recommendation before the first organic card.
- No more than one promotional card from the same creator in 24 hours.
- Opportunities are ranked above recommendation modules.
- Do not mix contests into Showcase Feed.
- Do not mix creator social posts into the Opportunities Feed.

---

## 18. Empty, Unavailable, and Error States

### No creator content

```text
The showcase is warming up.
Explore creators to start building your feed.
[Explore creators →]
```

### No opportunities

```text
No active opportunities right now.
Check back soon or explore creator work.
[Explore creators →]
```

### Sold exclusive item

```text
Sold · Locked
This exclusive project has been purchased and is no longer available.
[View creator portfolio →]
```

### Closed project/contest

Show the card only in history/profile/dashboard contexts with a muted status chip. Never show an actionable CTA.

### Card data failure

Show a compact fallback card with the type label and `This item is temporarily unavailable`, plus a retry action. One malformed card must not crash the entire feed.

---

## 19. Recommended Build Order

1. Shared `FeedCardShell` with header, type label, metadata row, footer, overflow menu.
2. `PostCard` variants for graphic showcase, promotional post, and reel.
3. `ProductCard` with available/owned/sold state.
4. `ServiceCard` with rating and availability state.
5. Compact `ProjectCard` for Showcase Feed.
6. Full `ProjectCard` and `ContestCard` for Opportunities Feed.
7. Availability card and creator recommendation block.
8. Normalized feed envelope and server-side status/permission enforcement.
9. Skeleton and failure states per variant.
10. Analytics for impression, open, save, CTA click, and conversion by card type and feed context.

---

## Final Product Rule

NeuralMart should feel like one familiar feed with different kinds of useful cards — not nine separate mini-products. The user should recognize the author, understand the object, see the most important trust signal, and know the next action in under two seconds.

**Social content earns attention. Marketplace cards turn attention into action. Opportunity cards turn intent into work. Recommendation blocks guide the next step. The shared shell keeps all four experiences coherent.**
