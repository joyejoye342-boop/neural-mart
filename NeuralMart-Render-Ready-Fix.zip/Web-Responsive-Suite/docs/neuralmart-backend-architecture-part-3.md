# NeuralMart — Backend Architecture
## Part 3 of 3: Security, Scalability & Final Architecture

**Document version:** 1.0  
**Depends on:** Part 1 (`docs/neuralmart-backend-architecture-part-1.md`), Part 2 (`docs/neuralmart-backend-architecture-part-2.md`), Prompts #1–#36, and the approved NeuralMart database, order, feed, marketplace, chat-commerce, and trust architectures  
**Scope:** Sections 25–38 and final integration decisions  
**Implementation status:** Architecture specification only; no production code is specified here

---

## 0. Consolidated Architecture Position

The three backend parts form one architecture, not three independently deployed systems:

| Specification part | Sections | Primary concern |
|---|---:|---|
| Part 1 | 1–12 | Modular backend, identity/authorization, feeds, content, marketplace, projects, proposals, contests |
| Part 2 | 13–24 | Universal Orders, Payment/Wallet, Chat-Commerce, protected files, trust, jobs, search, analytics, admin |
| Part 3 | 25–38 | API and event contracts, security, performance, operations, phased scale, final architecture map |

### 0.1 MVP technology choices

Use the current workspace foundation and the Prompt #36 database decisions:

| Area | MVP recommendation | Boundary |
|---|---|---|
| Backend shape | TypeScript modular monolith | One deployable API application with explicit domain modules and internal contracts |
| HTTP framework | Existing Express 5 API | Transport/router layer only; routes call module-owned application commands/queries |
| API style | Versioned JSON REST | Commands and resource queries; small mobile-friendly read models; no GraphQL requirement |
| Contracts | Shared Zod schemas in the existing API contract package | The same request/response definitions should serve API validation and generated/typed clients |
| Web client | Existing React API client/query package | Client cache is never authoritative for permissions or transaction state |
| Operational data | PostgreSQL through the existing Drizzle/database package | System of record for identity, listings, Orders, Payments, ledger, Ownership, delivery metadata, Chat, and audit references |
| Binary data | Private object storage | Database contains metadata and references, not file bytes |
| Async work | Transactional outbox plus durable worker process | At-least-once delivery; idempotent handlers; broker-neutral |
| Web authentication | Existing PostgreSQL-backed session pattern | Secure, HttpOnly, SameSite cookie; CSRF/origin controls for unsafe requests |
| External providers | Narrow adapters for payment, email, push, storage/CDN | Provider success is verified before local authoritative transitions |

This is an implementation-aligned starting point, not a requirement to freeze the current route or table layout. Module ownership and data integrity must be improved without replacing the approved domain model.

Do not require a separate GraphQL server, Redis, Kafka-compatible event platform, dedicated search engine, warehouse, or microservice fleet for MVP. Introduce each only when a measurable requirement justifies its operational cost.

### 0.2 Module ownership, consolidated

The stable domain modules are:

- Identity & Session; Authorization & Trust; Profile.
- Social Content; Media; Feed & Discovery; Marketplace Catalog.
- Project & Proposals; Contest; Commerce Orchestrator.
- Universal Order; Payment; Wallet/Ledger; Ownership; Delivery & Access.
- Chat-Commerce; Trust & Reputation; Notifications.
- Support & Moderation; Settings & Policy; Analytics & Reporting.

At MVP, these are code and data ownership boundaries inside one application/database, not separate network services. Each module owns its writes and rules. Cross-module changes use declared commands. A database transaction may cross module-owned repositories where a previously approved invariant requires it; other side effects use committed events.

---

# 25. API Layer

## 25.1 Recommendation: REST-first with purpose-built read models

Use JSON REST as NeuralMart’s primary API for web, mobile, admin, and future clients.

REST fits the current Express backend and shared Zod contracts; maps directly to explicit domain commands; is straightforward to cache and observe; and keeps mobile callers from assembling critical transaction workflows themselves. Use purpose-built query endpoints for feeds, dashboards, Order Centers, and conversation summaries rather than returning huge resources or making mobile clients issue many round trips.

GraphQL is not needed for MVP. Consider it only if measured clients have substantially different read-shape needs that cannot be served efficiently by stable REST read models. If adopted later, GraphQL is a query facade over the same modules and authorization rules; mutations still call domain commands and cannot bypass the Order/Payment/Ownership boundaries.

Do not expose the database schema as a public API.

## 25.2 Client surfaces

| Client | API treatment |
|---|---|
| Web | REST resources and purpose-built feed/dashboard queries; same-origin session where available |
| Mobile | Same domain API, cursor pagination, compact card DTOs, upload/download sessions, retry-safe commands |
| Admin | Same backend and domain commands under a separate admin namespace and staff authorization scopes; no table-level bypass |
| Webhooks | Isolated provider endpoints with provider-specific signature verification, replay protection, and idempotent processing |
| Future partners | Explicitly scoped API clients and data permissions; do not reuse end-user session assumptions |

## 25.3 Route and command shape

Conceptual API groups:

```text
/api/v1/auth
/api/v1/profiles
/api/v1/feed/showcase
/api/v1/feed/opportunities
/api/v1/posts
/api/v1/marketplace/products
/api/v1/marketplace/services
/api/v1/projects
/api/v1/proposals
/api/v1/contests
/api/v1/orders
/api/v1/conversations
/api/v1/media
/api/v1/wallet
/api/v1/notifications
/api/v1/admin/...
/api/webhooks/{provider}
```

Exact paths and DTO shapes are a Prompt #38 contract-design deliverable. Commands must represent intent, for example `accept`, `start`, `submit-delivery`, `approve`, `request-revision`, `request-refund`, or `open-dispute`; do not expose generic `PATCH status` operations for protected state machines.

High-impact POST commands accept an idempotency key in a documented request header or body field. The server scopes the key to actor, operation, and relevant source object. A retry returns the original committed result or an explicit pending state.

## 25.4 Versioning and compatibility

- Publish a stable `/api/v1` contract for the first supported mobile/web API version.
- If an existing `/api` path already has deployed consumers, treat it as a temporary compatibility route to the same v1 application logic; do not maintain separate behavior.
- Additive optional fields and new compatible operations may be added to v1.
- Breaking changes to field meaning, authorization, status semantics, or required inputs require an explicit new API version or a controlled migration window.
- Version provider webhooks by provider contract and retain the ability to process retried older event shapes.
- Use schema versioning for events separately from HTTP API versioning.
- Publish deprecation dates and migration guidance before removing a supported contract.

## 25.5 Contract and response rules

- Validate request parameters, body, and response DTOs using shared schemas at the API boundary.
- Keep numeric currency values in integer minor units and include currency code.
- Use UTC timestamps with explicit timezone/ISO representation; retain business timezone where deadline rules need it.
- Use keyset/cursor pagination for feeds, messages, notifications, and Order lists.
- Return only fields authorized for the current actor and projection; omit private fields rather than returning them with UI-hidden flags.
- Include a request/trace identifier and stable machine-readable error code.
- If a command has committed but asynchronous work remains, return the current authoritative state plus a pending status and polling/resource link; never label it successful prematurely.

## 25.6 Session and API security

- Keep provider identity, local User identity, and application session boundaries separate.
- For browser cookie sessions, use Secure in production, HttpOnly, an appropriate SameSite policy, session rotation after authentication/privilege changes, and revocation on logout, password/security reset, and account restriction.
- For cookie-authenticated unsafe methods, validate CSRF token and/or strict Origin/host policy according to deployment topology. SameSite is defense in depth, not a reason to ignore CSRF review.
- Native mobile authentication must use a documented session/token flow and operating-system secure storage; exact client credential lifetimes are for Prompt #38.
- Enforce CORS with an explicit allowed-origin policy for credentialed requests; do not use an unrestricted reflected origin.
- Webhook routes are not authenticated with user cookies. Verify provider signature, timestamp/replay window, and provider event identity before processing.

---

# 26. Event Architecture

## 26.1 Purpose and authority

Events notify interested modules that an authoritative domain change committed. Events are not commands, current-state databases, or proof of payment by themselves.

For business events that must not be lost, write the source change and outbox record in the same PostgreSQL transaction. Workers deliver events at least once. Consumers deduplicate by event ID and apply effects idempotently.

High-volume impressions/views can be ingested asynchronously and need not block a feed response. Payment confirmation, exclusive sale, completed Order, review, and badge events originate only from committed server-side domain state.

## 26.2 Conceptual event envelope

Every cross-module/outbox event should carry:

- globally unique `eventId`;
- canonical `eventType`;
- `schemaVersion`;
- `occurredAt` in UTC;
- source module and aggregate/entity type, ID, and sequence/version;
- actor User ID or explicit system/service actor, when applicable;
- correlation and causation IDs;
- idempotency/source reference for external callbacks where applicable;
- a bounded, non-sensitive payload with stable identifiers and event-specific facts;
- optional tenant/organization scope only if that product capability is enabled.

Events should reference authoritative records by ID rather than copy full profiles, messages, payment credentials, file bytes, or large mutable entity snapshots. Do not place secrets or unnecessary personal data in the event envelope.

## 26.3 Canonical events and consumers

The following event names are the cross-module integration keys requested for this specification. PascalCase names in Part 2 are illustrative domain labels; map them to these canonical keys when crossing the outbox/worker contract.

| Canonical event | Produced only after | Primary consumers |
|---|---|---|
| `USER_REGISTERED` | User identity and required initial account state commit | Profile bootstrap, welcome notification, risk/security, analytics |
| `POST_PUBLISHED` | Post passes publish/visibility/moderation checks | Showcase feed eligibility, search, notification, analytics |
| `PRODUCT_PURCHASED` | Product Order, payment confirmation, and applicable entitlement/access are authoritative | Order Center, seller earning allocation, notification, analytics, product purchase projection |
| `PROJECT_SOLD` | Exclusive project Ownership and Sold/Locked state commit | Catalog/feed/search removal, Ownership view, receipt/notification, analytics |
| `ORDER_CREATED` | Universal Order and required type extension/snapshot commit | Order Center, Chat reference/system card, notification, analytics |
| `PAYMENT_CONFIRMED` | Verified provider/payment result and local Payment record commit | Order finalization, ledger posting/settlement flow, Access/Ownership as applicable, notification, analytics |
| `FILE_UNLOCKED` | Active AccessGrant/entitlement commits after valid payment/rights check | Chat card update, notification, download analytics, buyer library |
| `CONTEST_WINNER_SELECTED` | Contest winner selection is authorized and commits | Contest views, winner/host notifications, prize Order workflow, analytics |
| `ORDER_COMPLETED` | Order completion transition passes type/policy/hold checks | Review eligibility, payout eligibility, badge/reputation inputs, notification, analytics |
| `REVIEW_SUBMITTED` | Order-linked review eligibility and uniqueness checks pass | Moderation, reputation projection, badge evaluation, notification, analytics |
| `BADGE_EARNED` | Badge definition/eligibility and UserBadge record commit | Profile/search/feed projections, notification, analytics |

`PROJECT_SOLD` applies only to an exclusive Sell Once project. Hiring/contracting on a project does not emit this event. `CONTEST_WINNER_SELECTED` does not by itself assert `OwnershipTransferred` or prize payout.

Other important events include `OWNERSHIP_TRANSFERRED`, `REFUND_RECORDED`, `WITHDRAWAL_COMPLETED`, `DELIVERY_SUBMITTED`, `REVISION_REQUESTED`, `DISPUTE_OPENED`, `CONTENT_RESTRICTED`, and `ACCESS_REVOKED`.

## 26.4 Ordering, delivery, and failure rules

- Assume at-least-once delivery; never assume exactly-once transport.
- Preserve per-aggregate ordering where required using sequence/version checks; unrelated aggregates need not block one another.
- Ignore stale versions or reconcile from authoritative current state when events arrive late/out of order.
- Retry transient failures with bounded exponential backoff and jitter; move exhausted jobs to a controlled failed/dead-letter state.
- Keep payment, ledger, Order, Ownership, access, and source data authoritative even when a consumer is unavailable.
- Replaying an event must not create another charge, refund, Order, Ownership, notification, review, or badge award.
- Consumers must be rebuildable where they maintain projections (search, feed, counters, analytics, summaries).
- Record event schema evolution and ensure older event payloads can be handled or intentionally rejected with a safe migration path.

---

# 27. Caching Strategy

## 27.1 MVP and progression

MVP may use short-lived in-process caching for small immutable/reference data and HTTP/CDN caching for explicitly public media. Do not introduce a shared Redis dependency before a multi-instance or measured cache requirement exists.

When shared cache is justified, use it only as a read accelerator. The database and owning domain module remain authoritative.

## 27.2 Safe cache candidates

- public profile/card fragments;
- popular creator public summaries;
- public categories, tags, and taxonomy;
- published product/service metadata and approved public previews;
- feed candidate pages or stable public feed fragments;
- search results with short TTL;
- non-sensitive aggregate counts;
- immutable public thumbnails and media derivatives at CDN.

Cache keys must include relevant version, locale/currency where applicable, surface/filter/sort, and visibility/audience scope. Per-user personalized results must not leak across identities.

## 27.3 Invalidation and stale-data policy

Use event-driven invalidation or version changes on publish/edit/archive, moderation, block/mute changes, creator availability changes, purchase/sale, price/terms update, contest closure, and access/rights changes. TTL is a backstop, not the only correctness mechanism.

For sale and availability-sensitive listings, a stale cached card may be shown only as a candidate; checkout revalidates availability and terms from PostgreSQL. Search/feed cards recheck source state before offering a purchase action.

Never authorize from cached data or trust stale cache for:

- payment/payment completion;
- spendable or withdrawable wallet balance;
- Order state transitions;
- exclusive Ownership or availability locks;
- access grants, private-file permissions, and revocation;
- account restrictions, staff privileges, or current participant authorization.

## 27.4 Cache failure behavior

- **Cache unavailable:** fall back to bounded, indexed source queries or return a retryable error if safe load limits would be exceeded.
- **Stale content:** revalidate source version/status for sensitive actions; purge or shorten TTL after policy/availability changes.
- **Cache stampede:** use request coalescing, bounded stale-while-revalidate for safe public data, and query limits.
- **Invalidation lag:** never make restricted or sold content privately accessible/purchasable based on stale cache.

---

# 28. Rate Limiting & Abuse Prevention

## 28.1 Policy model

Apply layered, configurable controls by:

- route/action class;
- unauthenticated IP/network;
- authenticated User/account;
- session/device signal where lawful and proportionate;
- resource/context (project, contest, conversation, Order, file grant);
- provider callback identity.

Do not rely on IP limits alone; shared networks and mobile carrier NAT can cause false positives. Limits should include gradual challenge/verification, temporary cooldown, and an appeal/support path for account-level restrictions.

## 28.2 Priority actions

| Abuse type | Backend controls |
|---|---|
| Registration/login/password reset abuse | Per-IP and account-aware throttles, generic responses, verification/challenge escalation, session controls |
| Spam/fake bids | One active proposal per creator/project under Part 1's MVP rule unless an explicit revision/variant is allowed; active-proposal quotas, submission cooldowns, project/account restriction checks, quality and anomaly review |
| Contest entry spam | Contest-configured entry limits, immutable submission idempotency, deadline validation, media scan gate, rate limits |
| Message abuse/bots | Per-conversation/user send limits, new-contact controls, automated spam signals, block/report/mute, attachment quotas |
| Excessive API requests | Route-class quotas, burst and sustained limits, pagination caps, query complexity/timeouts |
| Fraudulent/repeated purchases | Idempotency, velocity/risk checks, payment-provider verification, buyer/account risk holds, transaction reconciliation |
| Repeated file access | Per-grant and account limits, short-lived URLs, download concurrency controls, anomaly review; do not revoke legitimate access from one retry |
| Account abuse | Progressive account restrictions, verification gates, device/session revocation, documented appeal and staff audit |

Thresholds must be tuned from production telemetry and abuse outcomes, not hard-coded from arbitrary assumptions. A rate limit must not replace payment, authorization, ownership uniqueness, or order-state invariants.

## 28.3 Business and security rules

- Apply rate limits before expensive search, upload, password, proposal, contest, payment, and admin work.
- Idempotent retries of the same legitimate command should return its prior result, not be misclassified as a new transaction.
- Use risk controls to create a review/hold state; do not silently alter a confirmed ledger record.
- Avoid exposing thresholds or account-enumeration details to abusive actors.
- Provide stable `429` responses and retry guidance without disclosing detection signals.
- Staff may adjust restrictions only through a case-linked, audited operation.

---

# 29. Error Handling

## 29.1 Error response contract

Use a consistent JSON error envelope, preferably compatible with Problem Details semantics, containing:

- stable machine-readable `code`;
- safe human-readable `message`;
- HTTP status;
- request/trace ID;
- optional field-level validation errors;
- optional `retryable` indicator and `Retry-After`;
- optional current safe resource state and allowed next action for a conflict;
- no stack trace, SQL text, provider secrets, internal risk rules, or sensitive subject data.

The exact schema is a Prompt #38 deliverable and should be represented by the shared API contract package.

## 29.2 Error categories

| Category | Typical response | Client behavior |
|---|---|---|
| Unauthenticated | `401` with generic safe code | Sign in/refresh session |
| Unauthorized | `403`, or non-enumerating `404` where object existence is sensitive | Do not retry without permission change |
| Validation | `400`/`422` with safe field errors | Correct submitted fields |
| Conflict/state race | `409` with current permitted status/next action | Refresh, then choose an allowed action |
| Idempotent duplicate | Existing result or stable conflict response | Do not repeat payment/action |
| Payment processing/unknown | `202` or equivalent pending representation | Poll the same resource; never start a second charge |
| Rate limited | `429` plus safe retry guidance | Back off |
| Dependency unavailable | `503` or pending state if a durable command was accepted | Retry using the same idempotency key |
| Unexpected server failure | `500` with trace ID | Retry only if operation is safe/idempotent; contact support when needed |

## 29.3 Error rules

- Separate authorization denial from invalid state without leaking hidden resource details.
- Do not expose whether an email, phone, account, or payment instrument exists in enumeration-sensitive flows.
- Provider decline codes are normalized to safe user-facing categories; restricted raw payloads remain server-side.
- A timeout or network error is not proof of transaction failure. The client queries the existing Payment/Order state.
- Log trace IDs and safe error codes, not secrets or full request bodies.
- Do not convert an exception into a success-shaped fallback response.

---

# 30. Audit Logging

## 30.1 Audit scope

Create durable, append-only audit records for:

- payment attempts, confirmations, captures, refunds, chargebacks, and reconciliation;
- wallet ledger adjustments, withdrawal requests/decisions, holds, and payout releases;
- Ownership reservations, transfers, reversals, and Sold/Locked changes;
- Order lifecycle overrides, cancellations, disputes, and resolution references;
- staff actions, case assignments, sensitive record/file/message reads, and moderation restrictions;
- account/security events, session revocation, role/capability activation, and verification changes;
- badge award, suspension, demotion, manual correction, and reinstatement;
- material access grants/revocations and administrative download access.

Operational audit is separate from behavioral analytics and normal application logs.

## 30.2 Audit record

Conceptual audit fields:

- audit event ID and schema version;
- UTC timestamp;
- actor User/service/staff ID and effective staff role;
- action and target entity type/ID;
- correlation/trace/case/Order/provider reference;
- reason/purpose and authorization scope;
- before/after state hashes or safe field-level change summary;
- source IP/device information only to the extent justified by security policy;
- outcome and denial/failure code.

Do not store card data, passwords, session secrets, access tokens, signed URLs, full private message bodies, or unredacted identity documents in audit events.

## 30.3 Tamper resistance and retention

- Grant the application append permission, not update/delete permission, to audit records.
- Separate staff/product access from database-operator access; tightly restrict direct DB mutation.
- Use immutable history and reversal/correction records instead of rewriting past events.
- Protect sensitive audit reads with their own audit entries.
- Back up audit and financial/ownership history with a different failure boundary from the primary database.
- For high-impact records, add tamper-evident hash chaining or periodic signed digests and/or an append-only external/WORM sink as operational maturity grows.
- Retention and legal holds follow the approved data lifecycle; purge only through documented, audited policy.

Application logs, provider logs, and audit events serve different purposes. Never treat an ordinary rotating log as the only financial or ownership record.

---

# 31. Backend Security

## 31.1 Authentication and session protection

- Use the established identity-provider boundary and one NeuralMart User identity; do not split buyer/creator accounts.
- Use modern password hashing where NeuralMart stores passwords; never store plaintext credentials.
- Throttle login, registration, recovery, and verification attempts; use generic account lookup responses.
- Rotate sessions after login, recovery, and privilege changes; revoke sessions on logout, security reset, compromise, or restriction.
- Use Secure/HttpOnly cookies, appropriate SameSite settings, CSRF protection for cookie-authenticated state changes, and strict credentialed CORS allowlists.
- Require stronger authentication/step-up for staff, payout, account recovery, and other high-risk actions according to policy.
- Store session secrets/provider credentials only in managed secrets; never put them in source, logs, API responses, or client bundles.

## 31.2 Authorization and injection protection

- Every protected operation checks identity, capability, resource relationship, current state, and risk/verification gates as in Part 1.
- Enforce resource ownership/participant joins on the server; never use a client-supplied `userId` or hidden button as authorization.
- Prevent IDOR/BOLA with object-scoped queries and explicit access policies.
- Use parameterized ORM/database operations; validate/sanitize inputs; escape rendered user text; use output encoding and a suitable Content Security Policy.
- Do not concatenate user query syntax into SQL or search DSL. Apply allowlists to sort/filter fields and maximum query complexity.
- Verify origin, content type, body size, and method for sensitive endpoints.

## 31.3 Payment and transaction protection

- Verify webhook signature, provider identity, timestamp/replay window, amount, currency, Order reference, and provider status.
- Use idempotency keys, provider references, database uniqueness constraints, and authoritative reconciliation.
- Never trust client-reported payment success or permit arbitrary amount/fee/beneficiary changes.
- Protect withdrawal destinations and require eligible balance reservation before provider payout.
- Do not make cache, analytics, or search the decision-maker for an Order, payment, wallet, or Ownership operation.

## 31.4 File, media, and private-data protection

- Store originals privately; authorize every protected-file request using current AccessGrant/Ownership/Order/Policy state.
- Scan and validate uploads in quarantine; sandbox processors; limit size, decompression, duration, and resource use.
- Prevent SSRF by disallowing arbitrary server-side fetches or enforcing strict host/IP/redirect controls for any supported remote import.
- Use short-lived, scoped signed access and separate safe preview derivatives from originals.
- Protect PII, identity verification, financial records, private messages, and internal risk data by least-privilege access, encryption in transit/at rest, redaction, and retention policy.
- Keep secret-bearing values out of analytics, telemetry, error messages, and CDN cache keys.

## 31.5 Application, infrastructure, and response security

- Use request-size limits, secure headers, dependency updates, vulnerability scans, and tested backups/restore procedures.
- Log authentication, authorization, payment, admin, and file-access denials without logging sensitive payloads.
- Rate-limit abuse-sensitive commands and maintain an incident response path for session theft, leaked files, payment manipulation, or exposed credentials.
- Production configuration fails closed when required secrets or security settings are missing.
- Admin actions are role- and case-scoped; high-risk finance, file, badge, and ownership overrides require explicit reason and appropriate secondary approval.

---

# 32. Performance Architecture

## 32.1 Mobile-first API performance

- Use cursor pagination and bounded page sizes for feeds, search, messages, notifications, orders, and activity.
- Return compact DTOs for cards and list screens; fetch detail sections on demand.
- Batch-load creator/profile/media summaries to prevent N+1 query patterns.
- Keep Showcase and Opportunities feed contracts separate, with role-aware filters and source eligibility as defined in Part 1.
- Use indexed PostgreSQL queries for MVP; precompute only after measurement.
- Use request timeouts, query limits, connection pooling, and statement/query monitoring.
- Track p50/p95/p99 latency by endpoint and client; establish product SLOs from observed traffic before setting hard numeric budgets.

## 32.2 Domain-specific priorities

| Surface | Performance design |
|---|---|
| Feed | Keyset pagination, minimal card payload, batched media/creator summaries, cache only safe public candidates, recheck availability/visibility |
| Profile | Cache public fragments; load tab-specific data independently; do not fetch private analytics for public presentation |
| Search/discovery | Bounded filters, indexed text/category/skill fields, stable sort/cursor, source revalidation before transaction |
| Chat | Paginate messages by time/ID, fetch participants/read cursors efficiently, store attachments as Media references, avoid loading full history |
| Order Centers | Role/status/due-date indexes from Prompt #36; provide next-action summaries and pagination; load full timeline/files only on detail |
| Media | Responsive image variants, adaptive/streamed video preview, resumable uploads when supported, byte-range/background downloads where supported |
| Low bandwidth | Small thumbnails first, defer originals, compress safe previews, expose file size before download, allow retry/resume where storage/client supports it |

## 32.3 Performance and correctness tradeoffs

- A fast stale card may be acceptable; stale authorization, price at checkout, balance, ownership, or file access is not.
- Query optimization and indexing precede replica/shard complexity.
- Cache public read models, not transaction truth.
- Async work handles expensive media and projections; user-facing transaction status remains explicit while pending.
- Avoid returning unbounded social graph, timeline, proposal, message, or file collections.

---

# 33. Scalability Strategy

## 33.1 Stage 1 — MVP

Use:

- one TypeScript/Express modular monolith;
- one PostgreSQL primary and the approved schema/indexes;
- object storage for file bytes;
- transactional outbox and a small durable worker process;
- database-driven feeds and PostgreSQL search;
- narrow, measured public-data caching and CDN for safe public derivatives;
- provider adapters for payments, notifications, object storage, and delivery;
- centralized structured logs, request IDs, database/query monitoring, and backup/restore process.

Avoid microservices, database sharding, Kafka-like streaming, a warehouse, full feed fanout, and a dedicated search service before there is evidence to justify them.

## 33.2 Stage 2 — Growing Platform

Add components only when an observed bottleneck or capability requirement exists:

- shared cache when multiple API instances or repeated public reads create meaningful database load;
- read replicas for eligible read traffic when primary read pressure is measurable and acceptable lag is understood;
- dedicated media workers/pools when scan/transcode queue age or resource isolation affects API latency;
- dedicated search when text relevance, faceting, typo tolerance, or query volume exceeds practical PostgreSQL capability;
- precomputed feed eligibility/candidate projections when feed queries are a measured database hotspot;
- partition high-volume append-only analytics, notification-delivery, access, or event tables when size/maintenance requires it;
- isolated analytics storage/warehouse when reporting load competes with operational workloads;
- stronger queue/broker infrastructure when outbox throughput, fanout, replay, or independent worker scaling cannot meet service targets.

## 33.3 Stage 3 — Large Marketplace

Potentially:

- event streaming for high fanout and independent consumers;
- hybrid feed fanout and ranking infrastructure;
- specialized analytics warehouse and recommendation feature pipelines;
- regional delivery/read architecture;
- service decomposition for independently scaled/operated modules;
- domain sharding only after a stable shard key and cross-shard transaction policy exist.

These are conditional capabilities, not a promised launch architecture.

## 33.4 Evidence-based extraction and infrastructure triggers

Use operational measurements and a written decision record:

| Change | Evidence required before adoption |
|---|---|
| Add shared cache | Repeated safe reads are a material share of DB load/latency; invalidation rules can be made reliable; cache outage has a fallback |
| Add read replica | Read contention is measurable after query/index tuning; target queries tolerate replication lag; no authorization/transaction decision depends on replica freshness |
| Add durable queue/broker beyond current worker/outbox | Outbox dispatch/fanout or job backlog repeatedly misses measured processing targets; operations can support replay, monitoring, and schema evolution |
| Add dedicated media workers | CPU/memory-heavy scanning/transcoding or sustained media backlog harms API/request performance |
| Add dedicated search | Search quality/latency/filters or load exceed realistic PostgreSQL indexing/query limits |
| Extract a module/service | It has independent load/availability/release needs; stable contracts exist; ownership of data is clear; network failure and consistency behavior are tested |
| Split Order/Payment/Ownership | Only after a reviewed design preserves idempotency, ledger invariants, unique exclusive Ownership, failure reconciliation, and safe compensation across network boundaries |
| Shard databases | One primary remains the demonstrated bottleneck after tuning, replicas, partitioning, and archiving; global uniqueness/transaction boundaries and operations are explicitly designed |

Measure tail latency, query plans, connection saturation, replication lag, queue age, scan backlog, search quality, incident rate, and failure recovery. Do not scale from aggregate traffic alone.

## 33.5 Non-negotiable scale boundaries

- Read replicas never authorize checkout, current Order transition, wallet spend, withdrawal reservation, ownership lock, or protected-file access.
- Payment, Order, and Ownership are not casually split; if later separated, use explicit idempotent commands, durable saga/reconciliation, and clear single-writer invariants.
- Search/feed/cache/analytics remain rebuildable projections.
- Maintain one User identity, one universal Order aggregate, one coherent wallet/ledger model, and one exclusive Ownership uniqueness invariant.

---

# 34. Backend Environments

## 34.1 Environment purposes

| Environment | Purpose | Data and providers |
|---|---|---|
| Local | Individual development and debugging | Synthetic seed data; local/provider sandbox only; safe disposable storage |
| Development | Shared feature integration | Isolated development database/bucket/secrets; no production PII or payouts |
| Testing/CI | Automated unit, integration, and concurrency tests | Isolated ephemeral/test database; deterministic fixtures; provider test mode |
| Staging | Production-like end-to-end and migration rehearsal | Separate credentials/storage; sanitized data only; no real financial effects unless explicitly configured |
| Production | Authoritative users and transactions | Restricted access; real provider configuration; monitored backups, audit, and incident response |

Prompt #36's separate testing environment remains required even though the requested list emphasizes local, development, staging, and production.

## 34.2 Configuration and secrets

- Configuration is environment-specific and validated at startup.
- Secrets are supplied through the platform's secrets/environment management, not source control, committed files, browser bundles, or logs.
- Do not copy production secrets into development, CI, staging, or developer machines.
- Separate database roles, payment-provider mode/credentials, object-storage buckets/prefixes, webhook secrets, and email/push credentials per environment.
- Production fails closed if essential auth/session, database, storage, or provider configuration is missing.
- Avoid environment-dependent business logic; use explicit versioned policies/feature flags with an owner and rollback path.

## 34.3 Migrations and deployments

- Version schema migrations in source control and run them in a controlled deploy step.
- Use backward-compatible expand/migrate/contract changes when an old and new API/server may run concurrently.
- Rehearse migration against staging backups/data shape; monitor lock duration and rollback/forward-repair plan.
- Schema and event changes are coordinated with deployed readers/writers and workers.
- Seed deterministic synthetic development data; never run demo-account/password seed operations against production.
- Apply feature toggles for risky rollout, not permanent hidden parallel implementations.

## 34.4 Logging, monitoring, and isolation

- Use structured logs with correlation/trace IDs and redaction.
- Keep production logs, audit, analytics, and database access separately permissioned.
- Monitor API errors/latency, database connection/query health, worker/outbox backlog, payment reconciliation, file scanning, storage errors, and provider webhooks.
- Production incident access is time-limited, least-privilege, and audited.
- Do not use production snapshots in lower environments unless approved, minimized, and irreversibly sanitized.

---

# 35. MVP Backend Scope

The MVP is a complete but narrow marketplace backend, not a disconnected demo. It must enforce the invariants of the user flows it exposes.

## 35.1 MVP modules and capabilities

- Authentication/session, account recovery, one User, flexible Buyer/Creator capabilities, role context, and resource authorization.
- Shared Profile with optional CreatorProfile/BuyerProfile/Freelancer specialization.
- Showcase and Opportunities feeds with database queries, visibility/block checks, cursor pagination, and simple ranking.
- Posts, drafts/publishing, media metadata, private upload quarantine, scan/preview, and moderation states.
- Products, licenses, services/packages, and availability/pricing.
- Projects, proposals with historical versions, shortlist/selection, project chat, and contest distinction.
- Contests with rules snapshot, funded prize gate, entries, winner selection, prize Order, and authorized ownership path.
- Universal Order and typed extensions for MVP order types.
- Payment-provider integration, verified callbacks, one ledger-based Wallet model, seller earnings/fees, basic withdrawals/refunds, and reconciliation.
- Exclusive Sell Once availability lock, unique Ownership, Sold/Locked presentation, and failure recovery.
- Basic Chat, offers/payment requests, Order references, locked-file preview, and authorized Delivery/access.
- Delivery versions and essential bounded Revision behavior.
- Verified purchase reviews, rating eligibility, and basic reputation/trust signals.
- Basic contextual in-app/email/push notification events and preferences.
- Basic reporting, moderation restrictions, support reference, and audited sensitive actions.
- Essential privacy/security settings and versioned policy acceptance where needed for selling, purchasing, and contest entry.
- Transactional outbox, essential worker jobs, structured errors, audit trail, backups, and operational monitoring.

## 35.2 Explicit MVP exclusions

- No microservice-per-module topology.
- No GraphQL requirement.
- No dedicated search engine, Redis cluster, event streaming platform, or warehouse by default.
- No complex recommendation or automated dispute adjudication.
- No complex enterprise/team transaction workflow.
- No client-authoritative payment, ownership, Order, wallet, or access state.

Basic dispute opening/reference, safety holds, support escalation, simple badge presentation, and core analytics event capture remain part of the base architecture when those user-facing flows are enabled. The V2 scope deepens them rather than changing their source of truth.

---

# 36. V2 Scope

Add after MVP source records and event semantics are stable:

- richer analytics aggregates, attribution, Bid Insights, and dashboard projections;
- fuller badge progression, history, grace/demotion, appeals, and reputation quality controls;
- dedicated search engine, advanced filtering, synonyms/facets, and ranking experimentation where justified;
- consent-aware recommendation signals and stronger fairness/explanation controls;
- more complete dispute intake, evidence workflow, case routing, and resolution tooling (the separate Dispute System owns adjudication detail);
- expanded project workflows, milestones, extensions, scope changes, and richer proposal negotiation;
- enhanced delivery/versioning, source-file control, revision handling, and milestone approvals;
- richer notification preferences, digests, quiet hours, channel-level delivery controls, and delivery health;
- stronger fraud/risk detection for account, proposal, payment, refund, download, review, and contest behavior;
- read replica, shared cache, isolated worker pools, partitioning, or specialized analytics storage when the operational evidence in Section 33 supports them.

V2 must keep the same universal Order, ledger, Ownership, User, and AccessGrant boundaries.

---

# 37. Advanced / Scale-Dependent Scope

Only when business need, volume, reliability, or enterprise requirements justify the added operations:

- service decomposition behind stable module contracts;
- event streaming for high-volume domain-event fanout and independently scaled consumers;
- large-scale recommendation/ranking systems with governance and explainability;
- warehouse/lakehouse analytics and advanced data products;
- advanced identity, fraud, and risk scoring with review/appeal controls;
- enterprise organizations, delegated access, team wallets/workflows, and complex compliance;
- complex milestone, escrow, split-payment, multi-party settlement, and automated marketplace protections;
- hybrid feed fanout/ranking and dedicated distributed search;
- regional availability, partitioning, and selected sharding with explicit transaction semantics.

Never extract or shard solely to follow a trend. Preserve global payment idempotency, balanced ledger history, one universal Order relationship, exclusive Sell Once uniqueness, rights/access enforcement, and auditability if any infrastructure boundary changes.

---

# 38. Final Backend Architecture Map

## 38.1 Runtime architecture

```text
Web / Mobile / Admin clients
        │
        ▼
JSON REST API (Express 5, versioned contracts)
        │
        ├── Authentication / session / verification
        ├── Authorization / capabilities / resource policy / rate limits
        ├── Validation / error envelope / request correlation
        ▼
Application commands and queries
        │
        ├── Identity / Profile / Content / Media
        ├── Feed / Discovery / Catalog
        ├── Projects / Proposals / Contests
        ├── Commerce Orchestrator / Universal Order
        ├── Payment / Wallet-Ledger / Ownership
        ├── Delivery / Access / Revision
        ├── Chat-Commerce / Reviews / Reputation / Badges
        ├── Notifications / Support / Moderation / Policy
        └── Analytics / Reporting
        │
        ├── PostgreSQL: operational source of truth
        ├── Object storage: private originals and approved derivatives
        ├── Cache: optional, read-only projection accelerator
        └── Search: PostgreSQL MVP; replaceable projection
                │
                ▼
      Transactional outbox + durable workers
                │
                ├── Media scan/transcode
                ├── Payment/ownership/access reconciliation
                ├── Notification providers
                ├── Search/feed/badge/analytics projections
                ├── CDN purge and archival
                └── Payment, email, push, storage/CDN external adapters
```

The API and workers are deployable processes from the same modular codebase for MVP. Shared module commands preserve domain rules whether called synchronously by a route or asynchronously by a worker.

## 38.2 End-to-end user journey

```text
User registers/authenticates
→ One User + Profile + enabled capabilities
→ Creates a Post, Product, Service, Project, or Contest
→ Media is privately uploaded, scanned, and approved
→ Eligible content/listings appear in Showcase, Opportunities, and Search
→ Buyer discovers creator/listing/project/contest
→ Buyer opens a contextual Conversation or submits a Proposal/Contest Entry
→ Structured Offer / selected Proposal / listing terms are accepted
→ Commerce Orchestrator creates or activates one universal Order snapshot
→ Payment provider confirms through a verified callback
→ Payment + ledger + Order references finalize idempotently
→ Exclusive purchase commits Ownership + Sold/Locked atomically where applicable
→ Delivery/entitlement/AccessGrant is created for the correct user and rights
→ Chat displays committed Offer, Order, Delivery, or File Unlock references
→ Buyer reviews, requests a permitted Revision, or completes
→ Order completion opens verified Review eligibility and payout gates
→ Review/reputation/badge projections update from trusted source events
→ Notifications and Analytics consume the outbox without becoming transaction truth
```

For a standard project contract, “project selected” converts accepted proposal terms into the contract Order; it does not emit `PROJECT_SOLD`. For an exclusive Sell Once project, payment validation and the ownership transaction set Sold/Locked and emit `PROJECT_SOLD` only after commit.

## 38.3 Critical transaction boundaries

1. **Create Order:** validate source and terms, write immutable snapshot, Order/OrderItem/type extension, timeline, idempotency identity, and outbox event in one local transaction.
2. **Confirm payment:** verify provider evidence outside the local commit boundary; then atomically record verified Payment state, unique provider reference, balanced ledger journal/allocation references, Order payment summary, timeline, and outbox. Use reconciliation when an external outcome is unknown.
3. **Exclusive sale:** after trusted payment validation, lock/compare-and-set the exclusive source, recheck availability, create/link Order and unique Ownership/OwnershipTransfer, mark Sold/Locked, grant applicable rights/access, and append timeline/outbox in the same PostgreSQL transaction. If unavailable after capture, reconcile and compensate; never tell two buyers they own one exclusive item.
4. **Unlock file:** after confirmed payment/rights, atomically create the entitlement/AccessGrant and update relevant Order/Delivery references; issue access only after the committed grant. Retry provisioning without a second charge.
5. **Withdrawal/refund:** reserve/reverse funds and write balanced ledger entries idempotently; provider completion is verified and reconciliation-safe.
6. **Contest prize:** fund/hold the advertised prize before contest opening; winner selection, prize Order, delivery, rights transfer, and payout remain separate authorized gates.
7. **Every important commit:** write its audit/timeline and transactional outbox record with the domain change. External consumers are at-least-once and idempotent.

The database transaction is the atomicity boundary for local records. External provider calls are never represented as if they participate in that transaction.

## 38.4 Consolidated source-of-truth rules

- User/role/capability records authorize activity; active-role UI context does not grant permissions.
- Product, Service, Project, Contest, Proposal, Entry, and Post retain separate domain meanings.
- One universal Order owns commercial lifecycle; type extensions hold only type-specific facts.
- Payment records provider lifecycle; Wallet/Ledger records money; a balance is a derived view.
- Ownership records exclusive rights and transfer history; ordinary refund does not silently relist.
- Delivery/Revision records fulfillment; AccessGrant/Entitlement records technical retrieval permission; neither substitutes for a license.
- Chat preserves communication and structured references; it cannot mark payment, ownership, refund, access, or completion.
- Review, Reputation, and Badge outputs derive from eligible authoritative transactions and policy.
- Feeds, search, caches, analytics, counters, dashboards, and recommendation features are rebuildable projections.
- Moderation and audit preserve historical records and use explicit restrictions/reversals rather than destructive edits.

## 38.5 Deployment and change boundary

MVP deployments update the modular monolith and worker processes from one versioned codebase, migrate PostgreSQL compatibly, and deploy provider/storage configuration per environment. A module extraction or technology replacement must preserve the same commands, event meanings, authorization checks, transaction invariants, and historical records. Detailed endpoint schemas, error DTOs, event payload versions, and client examples are defined in Prompt #38.

---

## Backend Architecture Dependencies — Prompt #38: API Architecture & Contract Design

Prompt #38 must treat the following as established:

1. **Primary API:** versioned JSON REST is the MVP contract for web, mobile, and admin; GraphQL is optional only after a measured read-shape need.
2. **Implementation alignment:** TypeScript/Express 5, shared Zod API contracts, the existing React API client, PostgreSQL/Drizzle, and PostgreSQL-backed web sessions form the compatible workspace baseline.
3. **Module boundaries:** preserve Part 1/2 domain ownership and use commands/queries through application services; route files do not own business invariants.
4. **Identity and authorization:** one User with additive capabilities; authorization is identity + capability + persisted resource relationship + state/risk checks.
5. **Core resources:** Users/Profiles, Posts/Media, Products/Services, Projects/Proposals, Contests/Entries, Conversations/Messages/Offers, universal Orders, and type-specific extensions.
6. **Transaction sources of truth:** Order for commercial lifecycle; Payment for provider status; Wallet/Ledger for money; Ownership for exclusive rights; Delivery/AccessGrant for fulfillment/access; Chat for communication.
7. **Protected commands:** payment, refund, withdrawal, ownership transfer, file unlock, Order transitions, contest winner/prize transitions, reviews, and moderation are server-authoritative and idempotent.
8. **API behavior:** scoped idempotency keys for high-impact mutations; cursor pagination; UTC timestamps; integer minor-unit money plus currency; safe pending/reconciling responses; stable machine-readable error codes.
9. **Security:** CSRF/Origin protection for cookie-authenticated mutations, strict credentialed CORS, webhook verification/replay defense, resource-level authorization, rate limiting, private files, scoped staff access, redaction, and audit.
10. **Events:** canonical uppercase event keys in Section 26, versioned envelopes, transactional outbox, at-least-once delivery, idempotent consumers, and projection rebuildability.
11. **Caching and search:** projections only; checkout, balance, Order authorization, Ownership, and file access always revalidate authoritative PostgreSQL state.
12. **Operations and evolution:** one modular monolith and PostgreSQL primary for MVP; shared cache, replicas, dedicated search/workers, streaming, analytics warehouses, and microservices require evidence and a preserved consistency boundary.
13. **Contract-design deliverables:** precise route/verb matrix, request/response Zod schemas, authentication/session transport for web and mobile, pagination/error examples, idempotency scope, webhook DTOs, event schemas, deprecation/versioning rules, and client-facing retry/pending behavior.

Prompt #38 may refine endpoint shape and client transport details but must not redefine these product, data ownership, payment, Order, Ownership, delivery, Chat, or security invariants.
