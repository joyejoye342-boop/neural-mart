# NeuralMart — Contest / Competition System

**Document version:** 1.0  
**Scope:** Buyer-hosted creative contests and creator participation  
**Primary routes:** `/contests/new`, `/contests/:id`, `/contest-feed`

---

## 0. Contest Definition

A NeuralMart contest is a funded creative brief where multiple creators may submit entries, ideas, previews, or solutions and the host selects one or more winners under published rules.

It is different from a direct project:

| Direct project | Contest |
|---|---|
| Buyer hires one creator through proposals | Multiple creators submit entries |
| Negotiation happens before selection | Rules and prize are published before entries |
| Scope can evolve with the selected creator | Judging criteria must be clear up front |
| Payment follows an agreed engagement | Prize is funded before the contest opens |

The contest system must protect both sides:

- Buyers receive clear, comparable entries.
- Creators know the prize, effort, rights, deadline, and selection rules before participating.

---

## 1. Contest Types

### MVP contest types

1. **Single-winner creative contest**
   - One winner receives the funded prize.
   - Other entries are not purchased or licensed.

2. **Multiple-winner contest**
   - Host defines first place, runner-up, or category prizes.
   - Prize allocation is fixed before entries open.

### Advanced contest types

- Blind judging contest
- Invite-only contest
- Private client brief
- Multi-stage competition
- Paid finalist round
- Community voting with host approval
- Open-source/community challenge
- Team-based competition
- Recurring challenge series

The UI should not expose every type in MVP. Start with a simple choice:

```text
One winner · Multiple winners · Invite-only
```

---

## 2. Contest Creation Flow

Contest creation is guided because unclear contest rules create disputes.

```text
Choose contest type
→ Define the creative outcome
→ Add requirements and deliverables
→ Set category and skills
→ Define prize and winner structure
→ Set schedule
→ Define rights and feedback
→ Choose visibility and eligibility
→ Preview, fund, moderate, and publish
```

### Step 1 — Contest intent

Required:

- Contest title
- One-sentence outcome
- Category
- Short description of the business or creative context

Prompts:

```text
What do you want creators to make?
Who is it for?
Where will the winning work be used?
```

### Step 2 — Brief and deliverables

Required:

- Full creative brief
- Expected deliverables
- Required format
- Minimum quality or technical requirements
- Submission deadline

Use a structured deliverables list:

```text
[+ Add deliverable]
Primary logo concept
Black-and-white variation
Social avatar export
```

Avoid asking non-technical buyers to write a formal specification. Use examples and plain-language prompts.

### Step 3 — Category and skills

Required:

- Primary category
- At least one skill/tag

Suggested categories:

- Branding
- Illustration
- Graphic design
- UI/UX
- Motion
- Video
- Writing
- Photography
- Music
- 3D

Optional:

- Tools/software
- Experience level
- Language
- Location/timezone
- Industry familiarity

### Step 4 — References and context

Optional:

- Inspiration images
- Brand assets
- Existing guidelines
- Reference links
- Audience description
- Competitor examples
- Do-not-use examples

Each reference must be labeled:

```text
Inspiration · Required asset · Background context
```

This reduces ambiguity about whether the creator is expected to copy or merely understand the direction.

### Step 5 — Judging criteria

Required:

- At least three criteria
- Relative importance or equal weighting

Example:

```text
Brand fit              40%
Originality             25%
Practical usability     25%
Presentation quality    10%
```

Criteria must describe what the host will evaluate, not just adjectives such as “make it good.”

### Step 6 — Prize and winner structure

Required:

- Prize amount
- Currency
- Winner count
- Runner-up or category prizes, if any
- Platform fee disclosure
- Prize funding confirmation

The host sees:

```text
Prize: $500
Platform fee: $50
Total to fund before publishing: $550
```

The creator sees the funded prize and any additional award terms. The platform fee is not deducted from the advertised prize.

### Step 7 — Schedule

Required:

- Entry deadline
- Timezone
- Judging period
- Expected winner announcement date

Optional:

- Scheduled open date
- Q&A period
- Finalist review period
- Winner revision period

Minimum schedule validation:

- Entry deadline is in the future.
- Judging period has enough time for the defined entry volume.
- Winner announcement is after the entry deadline.
- Revision period does not silently extend the contest's rights terms.

### Step 8 — Rights, ownership, and feedback

Required:

- What the winner receives
- When ownership/license transfers
- Whether source files are required
- Whether non-winning entries remain with creators
- Whether feedback will be provided

Recommended default:

```text
Winner receives the stated usage rights after prize payout.
Non-winning creators retain their work and grant no usage rights.
```

The host cannot use, publish, or materially adapt a non-winning entry without a separate agreement.

### Step 9 — Visibility and eligibility

Options:

- Public contest
- Unlisted link
- Invite-only
- Blind judging
- Verified creators only
- Category/skill eligibility
- Minimum creator level, if justified

Public contests are the default. Private options should explain that fewer entries may result.

### Step 10 — Preview, safeguards, and publish

Preview the creator-facing contest page and card:

- title;
- brief;
- category/tags;
- prize/funding state;
- deadline;
- deliverables;
- judging criteria;
- rights;
- host trust signals;
- visibility.

Before publishing, run:

- minimum prize check;
- brief completeness check;
- rights/ownership check;
- prohibited-content check;
- payment/funding check;
- deadline sanity check.

The host then:

```text
Save draft
→ Submit for review
→ Fund prize
→ Publish contest
```

Do not show a contest as `Funded` to creators until the funding hold succeeds.

---

## 3. Contest Page Structure

### Desktop

```text
┌────────────────────────────────────────────────────────────┐
│ [Contest] Logo Design Challenge                            │
│ Hosted by Greenline · ✓ Verified · Open                    │
│ $500 funded · 23 entries · Ends in 4 days                  │
├─────────────────────────────────────┬──────────────────────┤
│ THE BRIEF                            │ PRIZE & DEADLINE     │
│ Deliverables                         │ $500                 │
│ Requirements                         │ Ends Apr 28          │
│ References                           │ [Submit entry]       │
│ Judging criteria                     │                      │
│ Rights and usage                     │ Host profile         │
├─────────────────────────────────────┴──────────────────────┤
│ Entries / creator submission area                          │
└────────────────────────────────────────────────────────────┘
```

### Page sections

1. Header and status
2. Prize/funding/deadline summary
3. Host identity and trust
4. Brief
5. Deliverables
6. Requirements and exclusions
7. References
8. Judging criteria
9. Submission format and limits
10. Rights and usage
11. Feedback/revision policy
12. Entries or creator entry workspace
13. Contest Q&A, if enabled
14. Related opportunities

### Header rules

Always show:

- contest type;
- current state;
- funded/unfunded state where relevant;
- prize;
- entry deadline;
- entry count;
- host identity;
- report action.

The primary action changes by state:

```text
Open → Submit entry
Closed for entries → Entries closed
Judging → Judging in progress
Winner selected → View winner
Completed → View results
```

---

## 4. Contest States

### Host contest states

```text
Draft
→ Needs changes
→ Pending funding
→ Pending moderation
→ Scheduled
→ Open
→ Closed for entries
→ Judging
→ Winner selected
→ Prize processing
→ Completed
```

Alternative states:

- Paused
- Cancelled
- Expired/no winner
- Disputed
- Under safety review

### State rules

#### Draft

Private to the host. Autosaved and editable.

#### Pending funding

Contest cannot open until the prize hold succeeds.

#### Pending moderation

Contest is not discoverable or enterable.

#### Open

Eligible creators may submit, save, and ask permitted questions.

#### Closed for entries

No new entries. Creators can view their submitted entry and status.

#### Judging

Host reviews entries. New entries and ordinary edits are locked.

#### Winner selected

Winner selection is recorded, notifications are sent, and rights/payout confirmation begins.

#### Prize processing

Payment is being held, released, or awaiting required winner confirmation.

#### Completed

Payout and rights transfer are complete. Results can be public or private according to the contest settings.

#### Cancelled/disputed

Entry visibility, funds, and next actions are controlled by the cancellation/dispute policy rather than ad hoc host messaging.

### Entry states

```text
Draft
→ Submitted
→ Updated version
→ Shortlisted
→ Finalist
→ Winner
→ Not selected
```

Alternative states:

- Withdrawn
- Disqualified
- Revision requested
- Rights confirmation pending
- Payout pending
- Paid

---

## 5. Creator Entry Submission Flow

```text
Evaluate contest
→ Save or start entry
→ Add concept and metadata
→ Upload preview/supporting files
→ Confirm originality and rights
→ Preview submission
→ Submit
→ Track status and feedback
```

### Required entry fields

- Entry title
- Preview or primary submission
- Short concept explanation
- Confirmation that the entry follows the brief
- Originality/rights declaration

### Optional fields

- Longer rationale
- Process notes
- Tools used
- Deliverables included
- Portfolio link
- Alternate versions
- Accessibility description
- Source files, when required

### File handling

- Allow platform upload rather than URL-only submission.
- Generate previews and thumbnails.
- Scan files.
- Preserve creator ownership until the contest's published rights transfer occurs.
- Watermark previews when appropriate.
- Keep source files private until the rules require delivery.
- Display maximum file size, type, dimensions, and duration before upload.

### Submission confirmation

Before submission show:

```text
You are submitting:
Logo Concept A
Files: 2 previews · 1 PDF
Contest: Logo Design Challenge
Prize: $500 funded
Deadline: Apr 28, 11:59 PM Dhaka time
Rights: winner receives stated usage rights after payout
```

The creator must explicitly confirm:

- work is original or properly licensed;
- attached files are safe to share;
- they accept the published contest rules.

---

## 6. Buyer Review, Shortlist, and Winner Selection

### Review workspace

The host receives a private board:

```text
All entries · Shortlisted · Finalists · Disqualified
```

Each entry supports:

- full preview;
- creator identity or blind mode;
- concept explanation;
- files;
- criteria score;
- private note;
- shortlist;
- feedback;
- report;
- compare.

### Shortlist flow

```text
Open entry
→ Score against criteria
→ Add private note
→ Shortlist
→ Optional feedback/request
→ Move to finalist
```

Shortlisting does not promise payment or selection.

### Finalist flow

If the contest includes finalists:

1. Host selects finalists.
2. Finalists receive notification.
3. Host may request a defined revision or clarification.
4. Finalist deadline is visible to all finalists.
5. Host selects the winner or winners.

Requests outside the published contest terms should be converted into a paid follow-on engagement.

### Winner selection

Before selecting:

- funding is verified;
- required criteria are completed;
- host confirms winner count and prize allocation;
- rights terms are displayed;
- the host acknowledges that selection is final subject to dispute policy.

Selection is atomic:

```text
Contest → Winner selected
Winning entry → Winner
Other finalists → Not selected
Prize → Reserved for winner
```

For multiple winners, the pre-published allocation controls payout. The host cannot change the split after entries close without an approved exception.

---

## 7. Prize and Payout Logic

### Funding

- Prize must be funded before the contest opens.
- Funds are held for the contest and are not available to the host while open.
- The advertised prize is the creator-facing amount.
- Platform fees are disclosed separately.

### Single winner

```text
Host funds prize
→ Contest opens
→ Entry period closes
→ Winner selected
→ Winner accepts/rights confirmed
→ Dispute window
→ Prize released
```

### Multiple winners

The host defines:

- first-place prize;
- runner-up prizes;
- category prizes;
- total amount.

The total is funded before opening.

### Winner confirmation

The winner has a defined acceptance period. If the winner does not respond:

- send reminders;
- offer a decline action;
- escalate to the host/platform;
- use the published fallback rule.

The fallback rule must be visible before entry:

- move to next finalist;
- reopen selection;
- refund/cancel under policy.

### No winner/cancellation

The contest must state what happens if:

- no entry meets the criteria;
- the host cancels before entries;
- the host cancels after entries;
- the host fails to select a winner;
- the platform pauses the contest for safety.

Do not allow a host to use non-winning work without a separate paid agreement. Refunds, creator compensation, and platform fees follow the approved contest policy and applicable law.

### Payout

Payout becomes available after:

- winner confirmation;
- rights/deliverable requirements;
- any required dispute window;
- fraud and safety checks.

The winner sees payout status in the contest and Earnings dashboard.

---

## 8. Revision and Feedback Logic

### Before entry deadline

Creators may replace or update their own entry if the contest permits edits. Each version has:

- version number;
- timestamp;
- files;
- status;
- creator note.

Only the latest eligible version is judged unless the contest explicitly allows multiple entries.

### During judging

Entries are locked by default. No silent replacement is allowed.

### Finalist revision

Only available when published in the contest rules:

- fixed number of revision rounds;
- clear deadline;
- defined deliverables;
- no material scope expansion;
- visible to the finalist;
- acceptance or decline action.

### Winner revision

Winner revisions are fulfillment of the published contest terms, not an unlimited work-for-free phase.

If the host asks for more work:

```text
Continue as paid project
→ Start linked chat/order
```

### Feedback

Feedback modes:

- No feedback
- Private feedback to finalists
- Private feedback to all participants
- Public summary after completion

Feedback should be:

- tied to criteria;
- respectful;
- specific;
- visible only to the intended audience.

Hosts should never be required to provide detailed critiques to every participant in MVP, but the UI should make the chosen feedback policy explicit.

---

## 9. Public, Private, and Blind Contests

### Public

- Discoverable in Opportunities.
- Eligible creators can view and submit.
- Host and contest page are public.
- Results can be public after completion.

### Unlisted

- Accessible through a link or invitation.
- Not shown in general feed/search.
- Can still allow eligible creators to submit.

### Invite-only

- Host selects eligible creators.
- Entry access is restricted.
- Host may invite from a creator profile.

### Blind judging

- Creator identity is hidden during initial review.
- Metadata that reveals identity is minimized.
- Host can reveal identity after shortlist or winner selection.

Visibility options must not be used to bypass moderation, funding, or rights disclosure.

---

## 10. Anti-Spam and Low-Quality Safeguards

### Host safeguards

- Minimum prize thresholds.
- Required structured brief.
- Funding before opening.
- Minimum entry window.
- No silent prize reduction.
- Clear rights terms.
- Host verification and contest history.
- Limits on repeated cancellation.
- Cancellation/reputation consequences.

### Creator safeguards

- Account and payment/identity verification where required.
- Entry limits per contest.
- Rate limits on submissions.
- Minimum time between duplicate entries.
- Clear file/type/size rules.
- Originality declaration.
- Plagiarism/duplicate detection.
- Report and appeal flow.
- Contest history visible to creators.

### Low-quality controls

- Required concept explanation, not only an empty file.
- Minimum preview quality/dimensions.
- Brief-specific validation.
- Moderation for prohibited content.
- Host can disqualify only using published rules or safety grounds.
- Platform can hide spam, but should preserve an appeal path.

### Fairness controls

- No editing rules after entries close.
- No public vote manipulation.
- Host cannot use non-winning entries without agreement.
- No hidden paid upsell to enter.
- Disqualified entries receive a reason category where safe.
- Contest hosts cannot repeatedly abandon contests without account consequences.

---

## 11. Chat and Future Paid Work

### Contest-linked chat

The contest can create a linked chat when:

- the host invites a finalist;
- a creator asks an allowed clarification question;
- the host selects a winner;
- a post-contest project is offered.

Avoid unrestricted private contact before submission if it creates off-platform payment risk.

### After selection

Actions:

- `Continue in chat`
- `Start delivery`
- `Create paid follow-on project`
- `Request additional licensing`
- `Invite creator to service/order`

### Non-winning creators

A host can offer paid work to a non-winning creator, but:

- the offer is separate from the contest prize;
- no creator is required to accept;
- the host cannot condition prize payout on extra unpaid work;
- the offer is recorded as a separate project/order.

---

## 12. MVP vs Advanced

### MVP contest system

- Public single-winner contests
- Optional multiple-winner prize allocation
- Guided creation flow
- Required brief, category, prize, deadline, criteria, and rights terms
- Funding before opening
- Public contest page
- One entry per creator by default
- Preview upload and concept description
- Edit until deadline
- Closed-entry judging
- Shortlist and winner selection
- Basic private feedback
- Winner payout flow
- Contest-linked chat after selection
- Report/dispute safeguards

### Advanced contest system

- Blind judging
- Invite-only and unlisted contests
- Multi-stage rounds
- Paid finalist rounds
- Team entries
- Community voting
- Automated duplicate/plagiarism detection
- Advanced comparison and scoring
- Category prizes and recurring series
- Public result galleries
- Detailed creator analytics
- API/export
- Advanced rights/licensing packages
- Contest reputation scoring

## Final rule

A contest is only healthy when the creator can understand the brief, prize, deadline, judging, rights, and risk before submitting—and the buyer can review fairly without receiving unpaid ownership of work they did not select.
