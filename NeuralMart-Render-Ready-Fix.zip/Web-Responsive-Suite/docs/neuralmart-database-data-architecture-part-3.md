# NeuralMart — Database & Data Architecture
## Part 3 of 3: Indexing, Social Scale, Analytics, Operations, Recovery, and Final Foundation

**Document version:** 1.0  
**Depends on:** Parts 1 and 2  
**Status:** Final database foundation for Prompt #37 — Backend Architecture  
**Scope:** Indexing, social feed performance, analytics, scalability, environments, backup/disaster recovery, phase plan, final entity and relationship maps, governance, and backend dependencies

---

## 0. Final Architecture Position

Parts 1–3 together form the complete NeuralMart Database & Data Architecture.

```text
PostgreSQL
→ Operational source of truth

Object storage
→ Binary file bytes

Cache, background jobs, search index, analytics store
→ Supporting systems and rebuildable projections
```

The design is relational-first and transaction-aware:

- one User identity with additive Buyer/Creator capabilities;
- one shared Profile and optional role-specific profile extensions;
- separate Post, Product, Service, Project, Contest, and Order concepts;
- one universal Order with type-specific extensions;
- one ledger-based financial system;
- durable Ownership records for exclusive transfers;
- versioned Delivery and Revision records;
- context-linked Chat;
- order-verified Review/Rating records;
- append-only material history;
- explicitly derived feed, search, analytics, and dashboard projections.

The MVP should start with a single well-managed PostgreSQL primary and object storage. Scale by adding read replicas, caches, search, partitioning, and analytics infrastructure only when operational metrics justify the added complexity.

---

# 33. Database Indexing Strategy

## 33.1 Index design rules

Indexes accelerate reads but add storage and slow writes. Every index should support a named query or integrity constraint.

Use:

- primary-key indexes for identity;
- unique indexes for idempotency and domain invariants;
- composite indexes that follow actual filter/sort order;
- partial indexes for frequently queried active subsets;
- text/trigram/GIN indexes only for demonstrated search needs;
- stable cursor pagination using `(createdAt, id)` or equivalent.

Avoid:

- indexing every status column independently;
- duplicating indexes already covered by a composite index;
- indexing large unbounded text fields without a query requirement;
- indexing frequently updated counters;
- broad indexes on low-cardinality values that do not help a filter;
- including private data in search indexes.

Review index usage and write cost periodically. Remove unused indexes only after checking all query paths, constraint dependencies, and production query logs.

## 33.2 User lookup

Critical:

- unique authentication provider + subject;
- unique normalized username/handle;
- normalized email lookup index where email is an account identifier;
- account status + updated/created time for staff support queries;
- UserRole by `(userId, roleKey)` with uniqueness;
- Profile by `userId` unique.

Sensitive email/phone lookup should use a protected normalized representation or encrypted field plus a safe lookup strategy. Do not expose raw PII in broad indexes or logs.

## 33.3 Creator discovery

Indexes:

- CreatorProfile `(publicStatus, isPaused, primaryCategory, createdAt DESC, id)`;
- category/skill relationship table `(skillId, creatorProfileId)`;
- CreatorProfile `(publicStatus, availability, ratingSummary DESC)` only if the product supports that sort;
- Profile username/handle unique;
- creator text search vector or dedicated search index.

Do not index rapidly changing follower counts as the default discovery sort unless measurement and product ranking justify it.

## 33.4 Feed queries

Source-based MVP queries need indexes such as:

- Post `(status, visibility, publishedAt DESC, id)`;
- Post `(authorUserId, status, publishedAt DESC, id)`;
- FeedEligibility `(feedKey, eligibilityStatus, visibleFrom, visibleUntil, sourceType, sourceId)`;
- FeedEntry projection `(feedKey, rankKey DESC, sourceId)` if/when a feed projection is introduced;
- Project `(status, visibility, publishedAt DESC, id)` for Showcase project cards;
- Contest `(status, visibility, deadline, id)` for Opportunities;
- Product/Service eligibility by `(status, visibility, publishedAt DESC, id)`.

Use a stable keyset cursor. Offset pagination becomes expensive and unstable on a rapidly changing feed.

## 33.5 Product discovery

Indexes:

- Product `(status, visibility, categoryId, publishedAt DESC, id)`;
- Product `(creatorId, status, updatedAt DESC, id)`;
- Product `(status, currency, priceMinor, id)` for price-range filtering;
- ProductVersion `(productId, releaseStatus, publishedAt DESC)`;
- ProductCategory/Tag bridge indexes in both directions;
- full-text index or search document for public title/description/tags.

Use a partial index for active published products when it meaningfully reduces the index size.

## 33.6 Project discovery

Indexes:

- Project `(status, visibility, categoryId, publishedAt DESC, id)`;
- Project `(status, deadline, id)`;
- Project `(status, currency, budgetMaxMinor, id)` where budget sorting/filtering is common;
- ProjectSkill `(skillId, projectId)`;
- Project `(buyerId, status, updatedAt DESC, id)` for buyer management;
- proposal count should be a rebuildable summary, not an index-only substitute for proposals.

## 33.7 Contest discovery

Indexes:

- Contest `(status, visibility, categoryId, deadline, id)`;
- Contest `(status, prizeAmountMinor DESC, deadline, id)` if this is a frequent Opportunities sort;
- Contest `(hostUserId, status, updatedAt DESC, id)`;
- ContestEntry `(contestId, status, submittedAt DESC, id)`;
- ContestEntry `(creatorUserId, submittedAt DESC, id)`.

## 33.8 Service discovery

Indexes:

- Service `(status, visibility, categoryId, publishedAt DESC, id)`;
- Service `(creatorId, status, updatedAt DESC, id)`;
- ServicePackage `(serviceId, active, tier, priceMinor)`;
- service skills/tags in both directions;
- creator availability/capacity only where query selectivity warrants it.

## 33.9 Order lookup and management

Critical:

- unique public order number;
- buyer Orders `(buyerId, createdAt DESC, id)`;
- seller Orders `(sellerId, createdAt DESC, id)`;
- buyer/seller status queues `(participantId, primaryStatus, updatedAt DESC, id)` as separate role-aware indexes where needed;
- due work `(sellerId, fulfillmentStatus, deadline, id)` for creator queues;
- buyer action queue `(buyerId, fulfillmentStatus, updatedAt DESC, id)`;
- OrderItem `(orderId, createdAt, id)`;
- type-specific source reference indexes;
- timeline `(orderId, occurredAt DESC, id)`.

Avoid a large composite index containing every status dimension. Choose indexes around the actual Order Center filters and keep the rest as post-filtering or secondary lookups.

## 33.10 Transaction and payment lookup

Critical:

- unique provider + provider reference;
- unique idempotency key within its command/provider scope;
- Payment `(orderId, createdAt DESC, id)`;
- Payment `(status, updatedAt)` for reconciliation jobs;
- FinancialTransaction `(sourceType, sourceId)`;
- FinancialTransaction `(createdAt, id)` for accounting windows;
- LedgerEntry `(walletId, currency, createdAt DESC, id)`;
- LedgerEntry `(journalTransactionId)`;
- Refund `(paymentId, createdAt, id)`;
- Withdrawal `(walletId, status, createdAt DESC, id)`.

Financial lookup and reconciliation depend more on unique constraints and complete source references than on broad report indexes.

## 33.11 Wallet lookup

Indexes:

- unique `(userId, currency, walletKind)` as policy requires;
- LedgerEntry `(walletId, currency, createdAt DESC, id)`;
- SellerEarning `(sellerId, status, createdAt DESC, id)`;
- Withdrawal `(userId, status, createdAt DESC, id)`.

Cached balances are projections; indexing them does not make them authoritative.

## 33.12 Chat conversations and messages

Critical:

- ConversationParticipant unique `(conversationId, userId)` while active;
- ConversationParticipant `(userId, lastReadAt, conversationId)`;
- Conversation `(updatedAt DESC, id)` for global maintenance only;
- Conversation participant inbox index using participant membership plus last activity;
- Message `(conversationId, createdAt DESC, id)`;
- Message `(authorUserId, createdAt DESC, id)` where account history needs it;
- MessageAttachment `(messageId, id)`;
- ConversationLink `(contextType, contextId, conversationId)`;
- Offer `(conversationId, status, createdAt DESC, id)`.

Do not load all messages to compute unread counts. Maintain a participant read cursor or unread summary that can be reconciled.

## 33.13 Notifications

Indexes:

- Notification `(recipientUserId, createdAt DESC, id)`;
- partial unread index `(recipientUserId, createdAt DESC, id)` where unread;
- unique deduplication key scoped to recipient and event;
- NotificationDelivery `(notificationId, channel, status)`;
- NotificationDelivery `(status, nextAttemptAt)` for retry workers.

## 33.14 Reviews

Indexes:

- Review `(targetUserId, submittedAt DESC, id)` for creator reviews;
- Review `(targetObjectType, targetObjectId, submittedAt DESC, id)` where typed target design permits;
- Review `(orderId, authorUserId, context)` unique for review eligibility;
- Review `(status, submittedAt)` for moderation queues;
- Rating `(reviewId)` unique.

## 33.15 Ownership

Critical:

- unique current transferred ownership per exclusive object;
- Ownership `(ownerUserId, acquiredAt DESC, id)`;
- Ownership `(sellerUserId, acquiredAt DESC, id)`;
- Ownership `(orderId)`;
- OwnershipTransfer `(ownershipId, effectiveAt, id)`;
- source availability lookup keyed by exclusive Product/Project ID and active state.

The uniqueness rule is an integrity constraint first and a performance optimization second.

## 33.16 File access

Critical:

- AccessGrant `(userId, mediaId, status, expiresAt)`;
- AccessGrant `(orderId, status, mediaId)`;
- AccessGrant `(ownershipId, status, mediaId)`;
- DeliveryFile `(deliveryVersionId, displayOrder, id)`;
- ProductFile `(productVersionId, fileRole, displayOrder, id)`;
- Media `(ownerUserId, uploadStatus, createdAt DESC, id)`;
- DownloadRecord `(userId, downloadedAt DESC, id)`;
- DownloadRecord `(mediaId, downloadedAt DESC, id)`.

Access checks should be indexed by the authorization path used at request time. Do not index signed URLs or secret access tokens.

## 33.17 Performance priorities

### Mobile feed

Highest value:

- source eligibility + published time;
- `(createdAt, id)` cursor order;
- creator avatar/media references;
- feed projection index only if needed;
- cache of public card data with bounded staleness.

### Marketplace search

Highest value:

- active status + category + price/deadline;
- skill/tag bridges;
- text search index;
- dedicated search engine only when query quality/volume needs it.

### Order management

Highest value:

- buyer/seller + status + updated/deadline;
- order number unique;
- timeline by order/time;
- unread conversation references.

### Financial operations

Highest value:

- provider reference uniqueness;
- idempotency uniqueness;
- wallet ledger by account/time;
- status indexes for reconciliation and payout queues;
- source transaction references.

### Chat performance

Highest value:

- conversation membership by user;
- conversation activity for inbox;
- messages by conversation/time;
- participant read cursor;
- attachment by message.

---

# 34. Social Feed Performance

## 34.1 Workload profile

NeuralMart social activity includes:

- posts;
- reactions;
- comments;
- saves;
- shares;
- follows;
- impressions and other feed interactions.

These workloads differ:

- Posts and comments require durable relational records.
- Reactions, Saves, and Follows need uniqueness and user-facing state.
- Impressions and lightweight clicks can be high-volume analytics events.
- Feed assembly is a read-model problem, not the source of content truth.

## 34.2 MVP feed generation

For MVP:

1. Query eligible source records from PostgreSQL.
2. Apply simple transparent ranking and role-aware visibility.
3. Use keyset/cursor pagination.
4. Join only the minimal card fields needed.
5. Batch-load creator and media summary data.
6. Cache stable public card fragments briefly.
7. Record high-volume impressions asynchronously.

This is the simplest reliable design for early traffic and is consistent with the Showcase and Opportunities Feed architecture.

## 34.3 Hybrid feed strategy

Recommended progression:

```text
MVP:
Database query + small cache + async event capture

V2:
Precomputed eligibility/candidate projections + cache

Large scale:
Hybrid fanout-on-read/fanout-on-write with ranking services
```

### Database queries

Use directly for:

- authoritative status;
- privacy and block checks;
- newly published content;
- order/project/contest availability;
- current permissions.

### Precomputed feeds

Use only as a candidate/read projection:

- source object ID;
- feed key;
- score/rank;
- eligibility timestamp;
- audience/cohort;
- projection version.

Always recheck source status, visibility, block state, moderation, and access before serving.

### Caching

Cache:

- public creator/profile fragments;
- category lists;
- public product/service card summaries;
- stable media derivatives;
- short-lived feed pages for anonymous or low-personalization contexts.

Do not cache as authoritative:

- private order status;
- ownership;
- payment state;
- access grants;
- active restrictions.

Use explicit cache keys/versioning and invalidation on publication, moderation, deletion, sale, or availability changes.

## 34.4 Fanout strategy

Do not choose fanout-on-write for every creator at launch.

Start with fanout-on-read/database candidate queries. At scale:

- fanout-on-write can serve ordinary creators with moderate follower counts;
- fanout-on-read remains better for very high-follower creators and heterogeneous opportunity cards;
- a hybrid feed can combine precomputed followed-creator candidates with live marketplace opportunity candidates.

This avoids a single very large fanout job when a high-reach creator posts.

## 34.5 Social interaction storage

### Reactions

- durable Reaction rows;
- unique active reaction per user/content/type;
- counts maintained as rebuildable summaries or asynchronous counters.

### Comments

- relational Comment rows;
- index by source content and creation cursor;
- parent reference for threaded replies;
- moderation/deletion state preserved.

### Saves

- unique active Save per user/saved object;
- user-first index for saved collections;
- source-first index for aggregate counts if needed.

### Shares

- persist share intent when product needs a visible share history;
- otherwise treat high-volume share/impression events as AnalyticsEvent;
- never infer an order conversion from a share alone.

### Follows

- unique active follower/followed pair;
- indexes in both directions;
- counts are projections, not truth.

### Feed interactions

- durable user actions (save, follow, proposal submit) use operational tables;
- high-volume impressions/views/clicks use event ingestion;
- deduplicate client retries with event ID/session/target/time policy.

## 34.6 Counter strategy

Counters are denormalized read accelerators:

- `reactionCount`;
- `commentCount`;
- `saveCount`;
- `followerCount`;
- `viewCount`.

Rules:

- update transactionally for low-volume critical counts where appropriate;
- use asynchronous aggregation for high-volume event counts;
- recompute from source rows/events as a repair path;
- do not make eligibility, ownership, or payment decisions from counters.

---

# 35. Analytics Data Architecture

## 35.1 Separation of operational and analytics data

Operational PostgreSQL stores:

- Users and roles;
- marketplace objects;
- Orders;
- Payments;
- Wallet ledger;
- Ownership;
- Delivery/access;
- Reviews;
- current transaction states.

Analytics storage stores:

- high-volume behavioral events;
- aggregates and time-series summaries;
- attribution;
- experiment/ranking features where appropriate.

At MVP scale, a partitioned PostgreSQL AnalyticsEvent table plus an outbox is sufficient. A warehouse or event platform is a later scaling decision.

## 35.2 AnalyticsEvent

Conceptual fields:

- event ID;
- event type/key;
- schema version;
- actor User ID, nullable for anonymous activity;
- target entity type;
- target entity ID;
- related Order/Project/Product/Service/Contest/Post IDs where relevant;
- server occurred-at timestamp;
- client occurred-at timestamp if useful and untrusted;
- session ID or pseudonymous session reference;
- device class/platform;
- application version;
- source surface/feed;
- referrer/campaign attribution;
- experiment/rank position where applicable;
- event properties with bounded, non-sensitive fields;
- idempotency/deduplication key;
- ingestion timestamp.

Event target references are analytical envelopes. They may be polymorphic because an event describes activity across many entity types; they do not replace typed foreign keys in operational records.

## 35.3 Event types

Track meaningful actions:

### Discovery

- impression;
- view;
- click/open;
- profile visit;
- product view;
- service view;
- project view;
- contest view.

### Engagement

- save;
- follow;
- share;
- comment/reaction where analytics needs it;
- chat lead started.

### Marketplace conversion

- checkout started;
- proposal submitted;
- contest entry submitted;
- offer accepted;
- payment succeeded/failed;
- order created;
- delivery approved;
- order completed;
- review submitted.

### Attribution

- first/last source surface;
- feed/campaign/referrer;
- source post/listing;
- session chain or parent event;
- conversion window.

## 35.4 Privacy controls

Analytics events should:

- collect only fields with product purpose;
- avoid message bodies, file names, payment credentials, and private project content;
- pseudonymize or aggregate when identity is unnecessary;
- respect consent and retention rules;
- separate security logs from product analytics;
- bound event property size and schema.

## 35.5 Event pipeline

For events that must align with an operational commit:

```text
Database transaction
→ writes operational state
→ writes outbox event
→ commits
→ background worker publishes/delivers
→ analytics destination deduplicates and aggregates
```

Examples:

- PaymentSucceeded;
- OrderCompleted;
- OwnershipTransferred;
- RefundIssued;
- ReviewSubmitted.

For impressions and clicks:

- batch or asynchronously ingest;
- tolerate retries;
- use event IDs/deduplication;
- do not block feed rendering on analytics delivery.

## 35.6 Analytics consumers

### Creator Analytics

- impressions-to-profile visits;
- profile-to-product/service/order conversion;
- saves and follows;
- order conversion;
- repeat buyers;
- delivery/revision/review metrics.

### Creator Dashboard

- current active orders from operational records;
- pending/available earnings from financial ledger projections;
- performance summaries from analytics aggregates;
- trust from verified reviews and reputation records.

### Buyer Dashboard

- active projects and order actions from operational records;
- proposal/contest activity;
- purchase history from Orders;
- spending summaries from financial ledger;
- discovery personalization from consented behavior.

### Bid Insights

- proposal submissions;
- views;
- shortlist;
- clarification;
- selection;
- proposal-to-contract conversion.

Contests and products should remain separate from proposal funnel denominators.

### Financial Dashboard

Financial totals come from Payment and Wallet ledger data, not generic behavioral events. Analytics can provide trends, but it cannot replace ledger reconciliation.

### Admin Analytics

- aggregate marketplace volume;
- completed/active order count;
- payment/refund/dispute/cancellation rates;
- delivery and payout operations;
- abuse/risk signals with restricted access.

### Recommendation systems

Events can later create:

- interest vectors;
- category affinity;
- creator/content relevance;
- conversion features;
- freshness and diversity features.

Recommendations remain derived and must respect blocks, visibility, user preferences, safety, and marketplace fairness rules.

## 35.7 Aggregation and retention

Keep raw detailed events for a documented period, then:

- retain coarser aggregates longer;
- delete or anonymize user-linked event detail when allowed;
- preserve financial/order events according to legal/accounting requirements;
- retain enough event provenance to explain dashboard metrics.

Part 3's policies should distinguish operational audit retention from behavioral analytics retention.

---

# 36. Scalability Strategy

## 36.1 MVP

Use:

- one PostgreSQL primary;
- automated managed backups and point-in-time recovery where available;
- object storage for binaries;
- focused indexes;
- keyset pagination;
- simple database-driven feeds;
- short-lived cache for public/high-read data;
- background job worker for emails, file scans, notifications, and reconciliation;
- transactional outbox for important events;
- basic query/connection monitoring.

Do not start with:

- database sharding;
- Kafka-like event platform;
- a separate analytics warehouse;
- feed fanout at write for all users;
- service-per-domain databases;
- complex event sourcing;
- multiple competing search engines.

## 36.2 V2

Add when measurable traffic or query load warrants:

- read replica for eligible read traffic;
- dedicated search engine;
- precomputed feed candidate/eligibility tables;
- cache for public profiles/listings/feed pages;
- partitioning for high-volume AnalyticsEvent, audit, or access logs;
- scheduled aggregation tables;
- queue-backed reconciliation and media processing;
- archive tier for cold data;
- workload-specific connection pools.

Read replicas are eventually consistent. They must not be used for authorization, payment decisions, exclusive availability locks, current wallet balances, or ownership decisions.

## 36.3 Large-scale NeuralMart

Only after Postgres scaling limits are demonstrated:

- partition the largest append-only tables;
- distribute analytics to a columnar warehouse;
- use hybrid feed fanout and ranking services;
- shard selected domains by a stable key only if one primary cannot meet target throughput;
- separate high-volume workloads with explicit ownership and consistency boundaries;
- introduce regional read/write architecture only with a clear cross-region transaction policy.

Sharding must not be introduced before deciding how to preserve:

- global ownership uniqueness;
- financial journal consistency;
- one order identity;
- idempotency scope;
- cross-shard support/reporting.

## 36.4 Read replicas

Suitable:

- public creator discovery;
- published products/services;
- historical dashboards;
- feed source reads;
- admin reports with tolerated lag.

Not suitable:

- checkout availability;
- payment confirmation;
- order transition validation;
- ownership lock;
- file authorization;
- wallet spendable balance;
- withdrawal reservation.

## 36.5 Caching

Cache public/read-mostly objects with clear invalidation. Do not cache permissions as the sole gate.

Cache examples:

- category trees;
- public profile sections;
- published card metadata;
- feed candidate pages;
- non-sensitive counters.

Do not rely on cache for:

- account restrictions;
- active ownership;
- payment state;
- current balance;
- order actor authorization;
- access grants.

## 36.6 Partitioning

Partition only after evidence of table size or maintenance pressure.

Good candidates:

- AnalyticsEvent by event time;
- high-volume FeedInteraction/impression records;
- NotificationDelivery;
- DownloadRecord/access logs;
- append-only audit events, if retention/query design supports it.

Do not casually partition core tables with global unique constraints:

- User;
- Order;
- Ownership;
- Payment idempotency;
- Wallet ledger.

If partitioning such tables becomes necessary, explicitly preserve global uniqueness through key design and transaction coordination.

## 36.7 Sharding

Sharding is a last-stage option. It is justified only when:

- a single primary is demonstrably unable to handle write throughput/storage;
- query optimization, archiving, replicas, and partitioning are insufficient;
- a stable shard key exists;
- cross-shard transaction requirements are understood;
- operations can support data movement, repair, and reconciliation.

Potential shard keys might be user/account or a transaction domain, but exclusive Sell Once records may require a globally coordinated uniqueness service or single authoritative shard per asset.

## 36.8 Background jobs and event-driven processing

Use jobs for:

- media scanning/transcoding;
- notification delivery;
- search indexing;
- analytics aggregation;
- payment reconciliation;
- payout and refund work;
- ownership/access repair;
- counter repair;
- archival/deletion workflows.

Jobs must:

- be idempotent;
- use retry/backoff;
- record failure state;
- be observable;
- avoid making the client believe an uncommitted action completed.

## 36.9 Archival

Archive cold data without breaking references:

- completed listing snapshots;
- old analytics events;
- expired notification deliveries;
- stale temporary uploads;
- closed support records after policy retention.

Keep active transaction, ownership, and financial references queryable. Archiving is not deletion.

---

# 37. Database Environments

## 37.1 Development

Purpose:

- local feature development;
- schema iteration;
- synthetic seed data;
- rapid reset where safe.

Rules:

- never use production credentials/data;
- use deterministic seeds;
- permit disposable databases;
- migration changes are tested before merge.

## 37.2 Testing

Purpose:

- unit and integration tests;
- transaction/concurrency tests;
- schema compatibility checks;
- migration verification.

Rules:

- isolated database per test run or suite where practical;
- synthetic data only;
- deterministic clocks/fixtures for deadlines and state transitions;
- test parallelism must not share mutable financial fixtures;
- tests must verify unique constraints and rollback behavior.

## 37.3 Staging

Purpose:

- production-like end-to-end validation;
- migration rehearsal;
- provider/webhook and storage integration tests.

Rules:

- separate credentials and buckets;
- production-shaped scale, not production PII;
- use sanitized/anonymized data only if approved;
- no real payment or payout effects unless explicitly configured in test mode;
- rehearsal migrations and restore drills before production.

## 37.4 Production

Purpose:

- authoritative user and transaction data.

Rules:

- restricted database access;
- audited administrative operations;
- automated backups and monitoring;
- tested migration and rollback/forward-recovery plan;
- no manual ad hoc updates to financial/ownership records without audited repair procedure.

## 37.5 Migrations and schema versioning

Migrations are:

- versioned;
- reviewed;
- ordered;
- recorded in a migration history table;
- tested against a representative dataset;
- deployable with compatible application versions where possible.

Preferred pattern for nontrivial changes:

```text
Expand schema
→ deploy compatible application
→ backfill/reconcile
→ switch reads/writes
→ verify
→ contract/remove old schema later
```

Do not rename/drop a production column in the same step that first introduces the replacement if a rolling deployment could run both versions.

## 37.6 Seed and test data

Use distinct seed categories:

- reference data (categories, badge definitions, policy records);
- development/demo data;
- integration-test fixtures.

Never seed fake transactions into production financial ledgers. Use test payment providers/test mode and synthetic accounts in non-production.

## 37.7 Database monitoring

Monitor:

- connection pool saturation;
- query latency by normalized query;
- slow queries;
- lock waits/deadlocks;
- replication lag;
- disk and index growth;
- autovacuum/bloat;
- transaction retries;
- migration duration/failure;
- backup/PITR status;
- financial reconciliation differences;
- outbox backlog;
- failed background jobs.

Alerts should identify user impact and include safe diagnostic context without exposing secrets or private content.

---

# 38. Backup & Disaster Recovery

## 38.1 Backup strategy

Use:

- automated full backups;
- continuous transaction log/WAL archiving for point-in-time recovery where supported;
- encrypted backup storage;
- separate access controls from production database credentials;
- retention periods aligned with legal, financial, and product needs;
- independent object-storage versioning/backup for critical files.

Recommended starting posture, subject to platform capabilities and business requirements:

- daily full backup;
- point-in-time recovery target of at most 15 minutes of data loss for core transactional records;
- recovery time objective of 4 hours for core order/payment service;
- longer recovery window may be acceptable for analytics/search projections.

These are proposed targets to validate against cost, provider capability, and operating commitments—not a claim that current deployments meet them.

## 38.2 Backup retention

Define retention by data class:

- financial and transaction records: legally/accountingly required duration;
- ownership and license history: retain while rights are active and as long as legally necessary after;
- operational database backups: short-term PITR plus periodic longer snapshots;
- analytics raw events: shorter, documented retention with aggregate retention;
- temporary upload data: short lifecycle and cleanup;
- dispute/support evidence: policy/legal retention.

## 38.3 Restoration testing

Restoration is not considered proven until tested.

Test:

- restore to an isolated environment;
- replay WAL/PITR to a selected timestamp;
- verify migrations can run;
- reconcile user/order/payment/ledger counts;
- verify ownership uniqueness;
- verify object-storage references and checksums;
- verify encrypted backups are readable by authorized recovery operators;
- record restore duration and gaps.

Run restoration drills on a scheduled basis and after major storage/backup changes.

## 38.4 Recovery priority

Highest priority:

1. Payment references, ledger journals, refunds, withdrawals, and SellerEarning.
2. Orders and their immutable commercial snapshots.
3. Exclusive Ownership and OwnershipTransfer history.
4. Access entitlements and delivery metadata.
5. User/account references and authorization state.
6. Disputes, audit events, policy acceptance, and support evidence.
7. Products/services/projects/contests and their attachments metadata.
8. Chat messages and order-linked references.
9. Posts, reactions, and other social content.
10. Search indexes, feed projections, caches, and analytics aggregates.

Recovery of financial and ownership data must be reconciled before resuming money movement or exclusive sales.

## 38.5 Financial recovery

After restore:

- reconcile provider payment/capture/refund references;
- verify balanced ledger journals;
- compare wallet projections to ledger;
- identify withdrawals in uncertain state;
- avoid replaying duplicate payout/refund actions;
- keep affected operations paused until discrepancies are resolved.

## 38.6 Ownership recovery

After restore:

- rebuild current Ownership state from durable transfer events;
- validate unique current ownership per exclusive object;
- validate Sold/Locked listing summaries;
- ensure no conflicting in-progress reservation;
- reconcile payment and Order references;
- keep exclusive purchase disabled for any unresolved object.

## 38.7 File metadata recovery

Database backups preserve Media/DeliveryFile/AccessGrant metadata and object keys. Object storage should provide:

- versioning or recovery for critical objects;
- lifecycle rules;
- checksum validation;
- separate backup or replication for irreplaceable source/delivery assets;
- a reconciliation job for missing objects and orphaned uploads.

Restoring file metadata without the corresponding object bytes is an incomplete recovery.

## 38.8 Disaster recovery priorities

Restore transaction correctness before restoring discovery convenience:

```text
Identity/access
→ Order/payment/ledger
→ Ownership/access grants
→ Delivery/files
→ Support/disputes/audit
→ Marketplace listings
→ Social feeds/search/analytics projections
```

Search and feed projections can be rebuilt. A lost financial journal or incorrect exclusive ownership state cannot be safely reconstructed from a cache.

---

# 39. MVP vs V2 vs Advanced Database Scope

## 39.1 MVP

Launch with the minimum coherent operational model:

### Identity

- User;
- UserRole/capability summary;
- Profile;
- CreatorProfile;
- BuyerProfile where required;
- essential account/privacy/notification settings;
- Verification state/reference.

### Social/content

- Post;
- PostMedia;
- Media metadata;
- Comment;
- Reaction;
- Save;
- Follow/Block;
- moderation status.

### Marketplace

- Product;
- ProductVersion;
- ProductFile/ProductPreview;
- ProductLicense;
- Service;
- ServicePackage;
- ServiceRequirement;
- Project;
- ProjectAttachment;
- ProjectProposal/ProposalVersion;
- ProjectShortlist;
- Contest;
- ContestEntry/EntryFile;
- ContestWinner and prize reference sufficient for MVP.

### Commerce

- universal Order;
- OrderItem;
- essential type-specific order extensions;
- Payment and provider references;
- Wallet;
- immutable ledger Transaction/LedgerEntry;
- SellerEarning and PlatformFee allocations;
- Ownership;
- Delivery/DeliveryVersion/DeliveryFile;
- AccessGrant/DownloadRecord;
- basic Revision;
- Refund;
- basic dispute reference;
- Review/Rating.

### Communication and platform

- basic Conversation/Participant/Message/MessageAttachment;
- structured Offer/PaymentRequest only where commerce needs them;
- OrderReference;
- Notification/Preference/Delivery status;
- essential Settings;
- PolicyVersion/Acceptance;
- SupportTicket/Report for launch safety.

### Analytics and operations

- basic AnalyticsEvent/outbox;
- core indexes;
- migrations;
- managed backups/PITR appropriate to available platform;
- development/test/staging/production separation;
- basic monitoring and reconciliation.

## 39.2 V2

Add when product use cases justify:

- milestone/payment schedules;
- richer revisions and scope-change offers;
- advanced product license and multi-license rules;
- advanced delivery versioning and file manifests;
- stronger reputation and badge history/progress;
- advanced search engine and facets;
- precomputed feed candidates;
- expanded reports/moderation workflows;
- detailed analytics aggregates;
- recommendation event features;
- read replicas;
- partitioned high-volume event/access tables;
- advanced policy acceptance and organization/team structures.

## 39.3 Advanced

Add only with operational scale and business need:

- analytics warehouse/lake;
- advanced recommendation/ranking features;
- enterprise organizations and approval workflows;
- complex milestone/escrow/split-financial structures;
- sophisticated fraud/risk data;
- large-scale fanout and feed ranking;
- partitioning across more operational tables;
- selected domain sharding;
- regional infrastructure;
- long-term data archival tiers and legal holds;
- marketplace intelligence and advanced attribution.

Advanced systems extend the same User, Order, Payment, Wallet, Ownership, Delivery, and Conversation relationships. They do not create parallel transaction truth.

---

# 40. Final NeuralMart Entity Relationship Map

## 40.1 High-level relationship architecture

```text
USER (central identity)
├── Profile (one shared presentation)
├── UserRole / UserCapability (additive capability and restrictions)
├── CreatorProfile (optional)
│   └── FreelancerProfile (optional specialization)
├── BuyerProfile (optional)
├── Settings / LinkedAccounts
├── Verification / UserRestriction
├── Follow / Block / Report
└── Wallet (one financial identity; currency/account policy may create sub-ledgers)

PROFILE + CAPABILITIES
├── Posts ── Media
├── Products ── ProductVersions ── ProductFiles / ProductLicenses
├── Services ── ServicePackages / Requirements / Media
├── Projects ── Attachments / Proposals / Shortlist / Selection
└── Contests ── Prize / Entries / Shortlist / Winner

MARKETPLACE ACTIVITY
├── ProjectProposal → ProposalVersion → ProjectContract
├── ContestEntry → ContestWinner → ContestPrize Order
├── Product/Service purchase
└── Offer/PaymentRequest
          │
          ▼
      UNIVERSAL ORDER
      ├── OrderItems / Type Extension
      ├── Payment
      ├── FinancialTransaction / LedgerEntry
      ├── SellerEarning / PlatformFee
      ├── Ownership / OwnershipTransfer
      ├── Delivery / DeliveryVersion / DeliveryFile
      ├── Revision
      ├── Refund / Cancellation
      ├── Dispute reference
      ├── Review / Rating
      ├── Conversation / OrderReference
      └── Timeline / Outbox events

CONVERSATION
├── ConversationParticipants
├── Messages / Attachments
├── Offers / OfferVersions
├── PaymentRequests
├── LockedFiles / DeliveryReferences
└── OrderReferences

MEDIA & ACCESS
Media metadata ── Object Storage bytes
Media ── typed attachment bridges
Ownership / Entitlement / Order → AccessGrant → DownloadRecord

TRUST & PLATFORM
UserBadge / BadgeProgress / BadgeHistory / ReputationScore
Notification / Preference / Delivery / ReadState
SupportTicket / TicketMessage
Report / ModerationAction / UserRestriction / ContentRestriction
PolicyVersion / PolicyAcceptance

ANALYTICS
Authoritative events + outbox
→ AnalyticsEvent
→ Aggregates / Creator Analytics / Dashboards / Bid Insights / Admin Analytics
→ Search and recommendation projections
```

## 40.2 Central foundation entities

Central foundations:

1. **User** — security, identity, and actor boundary.
2. **Profile** — shared public identity.
3. **Post/Media** — social and showcase content foundation.
4. **Product/Service/Project/Contest** — distinct marketplace source objects.
5. **Order** — universal commercial lifecycle.
6. **Payment/FinancialTransaction/LedgerEntry** — auditable financial truth.
7. **Ownership/AccessGrant** — durable rights and protected access.
8. **Conversation** — contextual communication linked to marketplace and orders.
9. **AnalyticsEvent/outbox** — derived measurement, never operational truth.

---

# 41. Final Entity Classification

An entity may participate in multiple domains, but this table gives its primary architectural classification.

| Category | Major entities | Why |
|---|---|---|
| **Core Entity** | User, Profile, CreatorProfile, BuyerProfile, Product, Service, Project, Contest, Order, Conversation, Ownership | Defines identity, primary marketplace objects, or transaction aggregates other systems depend on |
| **Supporting Entity** | UserRole, UserCapability, FreelancerProfile, Verification, ProductVersion, ProductLicense, ServicePackage, ProjectAttachment, ProposalVersion, ContestPrize, AccessGrant | Adds capability, version, configuration, rights, or access rules to a core record |
| **Transactional Entity** | ProjectProposal, ContestEntry, Offer, PaymentRequest, OrderItem, Delivery, DeliveryVersion, Revision, Cancellation, Refund, Dispute, Withdrawal, ContestWinner, Review | Records a user/system action or lifecycle transition with actor, status, and history |
| **Financial Entity** | Wallet, Payment, FinancialTransaction, LedgerEntry, SellerEarning, PlatformFee, Withdrawal, Refund, ContestPrize funding | Represents money, liabilities, allocations, movement, or settlement; auditable and immutable |
| **Content Entity** | Post, Media, Comment, Reaction, Save, Share, ProductPreview, ContestEntryFile, MessageAttachment | Stores user-created or presentation-oriented content and media relationships |
| **Relationship Entity** | Follow, Block, ConversationParticipant, ProjectShortlist, ContestShortlist, PostMedia, ServiceMedia, ProductFile, DeliveryFile, OrderReference, ConversationLink | Represents a connection between entities with its own attributes, state, or ordering |
| **System Entity** | Settings, Notification, NotificationPreference, NotificationDelivery, SupportTicket, Report, ModerationAction, UserRestriction, ContentRestriction, PolicyVersion, PolicyAcceptance, Session | Operates the platform, safety, preferences, communication delivery, or compliance |
| **Analytics Entity** | AnalyticsEvent, AnalyticsAttribution, MetricSnapshot, feed projection/read model | Captures or summarizes behavior for measurement, ranking, and reporting; rebuildable and not authoritative |

Important:

- `Wallet` is a financial account summary; LedgerEntry is the movement truth.
- `FeedEntry` is an analytics/discovery projection, not a source content entity.
- `ProductPurchase` is a transactional bridge, not a second Order.
- `ReputationScore` is derived; Review/Rating and verified transaction evidence remain the source.

---

# 42. Final Relationship Summary

## User ↔ Profile ↔ Roles

```text
User 1:1 Profile
User 1:many UserRole/UserCapability
```

The User is the identity/security boundary. Profile is shared presentation. Roles are additive capability records.

## User ↔ Creator/Freelancer/Buyer capabilities

```text
User
├── CreatorProfile (optional)
│   └── FreelancerProfile (optional specialization)
└── BuyerProfile (optional)
```

One person can hold Buyer and Creator capabilities without another account or wallet.

## Creator ↔ Products/Services/Posts

```text
CreatorProfile 1:many Product
CreatorProfile 1:many Service
User/CreatorProfile 1:many Post
```

Creator identity is referenced; listings/posts own their domain-specific fields.

## Buyer ↔ Projects

```text
Buyer/User 1:many Project
Project 1:many ProjectAttachment
```

The buyer remains the project owner; a selected creator does not become the project owner unless a separate exclusive ownership transfer occurs.

## Project ↔ Proposals ↔ Order

```text
Project 1:many ProjectProposal
ProjectProposal 1:many ProposalVersion
ProjectSelection → selected proposal/version
ProjectContract 1:1 Order
```

Proposal records preserve negotiation history. Order becomes fulfillment truth.

## Contest ↔ Entries ↔ Winner

```text
Contest 1:many ContestEntry
Contest 1:many ContestShortlist
Contest 0/1 or many ContestWinner per published rules
ContestWinner → ContestPrize Order
ContestWinner → optional ContestOwnership
```

Winner selection, prize completion, and rights transfer are separate records/states.

## Product/Project ↔ Order ↔ Ownership

```text
Product/Project
→ Order/OrderItem
→ Ownership
→ Buyer/Owner
```

Ownership is the source of exclusive rights; a normal refund does not silently relist the asset.

## Order ↔ Payment ↔ Transaction

```text
Order 1:many Payment
Payment → FinancialTransaction
FinancialTransaction 1:many balanced LedgerEntry
```

Payment state and wallet ledger state are linked but not interchangeable.

## Order ↔ Delivery ↔ Revision

```text
Order 1:many Delivery
Delivery 1:many DeliveryVersion
Revision → Order + source DeliveryVersion + resulting DeliveryVersion
```

Files are granted through AccessGrant, not by the mere presence of a message or delivery row.

## Order ↔ Review

```text
Completed eligible Order
→ Review by participant
→ Rating(s)
→ Reputation and marketplace trust projections
```

Uniqueness constraints enforce one allowed review per order/author/target/context.

## Order ↔ Dispute

```text
Order 0:1 active Dispute reference (or many historical cases if policy permits)
```

Dispute state overlays the Order and points to case/evidence records. Resolution applies financial/access/ownership outcomes without deleting history.

## Conversation ↔ Message ↔ Offer ↔ Order

```text
Conversation 1:many Message
Conversation 1:many Offer
Offer → PaymentRequest → Payment → Order
Conversation → OrderReference
Message → Delivery/LockedFile/Order reference
```

The same conversation may link to an Order without rewriting pre-order history. Chat does not become transaction truth.

## Wallet ↔ Transaction ↔ Withdrawal/Refund

```text
User 1:many Wallet by currency/policy
Wallet 1:many LedgerEntry
FinancialTransaction 1:many LedgerEntry
Withdrawal/Refund → FinancialTransaction and ledger allocations
```

Balance values are projections of ledger entries.

## User ↔ Badge ↔ Reputation

```text
User 1:many UserBadge
BadgeDefinition 1:many BadgeLevel
BadgeProgress/BadgeHistory preserve progression
ReputationScore derives from verified orders/reviews/outcomes
```

Badges and reputation are evidence-based, versioned, and recalculable.

## Entity ↔ AnalyticsEvent

```text
Authoritative entity event
→ Outbox
→ AnalyticsEvent(actor?, target type/id, timestamp, context, attribution)
→ Aggregates/search/recommendation projections
```

Analytics references source IDs but never controls source entity permissions or state.

---

# 43. Final Data Governance Principles

## 43.1 Normalization

- Normalize source relationships and transaction facts.
- Use typed foreign keys for core relationships.
- Denormalize only for read performance and mark projections as rebuildable.
- Do not duplicate User/Profile identity fields without a historical snapshot reason.
- Preserve immutable snapshots for accepted commercial terms.

## 43.2 Consistency

- Use database constraints for uniqueness and valid relationships.
- Use transactions for payment, order, wallet, ownership, refund, and access grants.
- Use idempotency and reconciliation for external systems.
- Keep summary status fields synchronized with authoritative extension records.

## 43.3 Auditability

- Append material financial, ownership, order, moderation, policy, and access events.
- Record actor, timestamp, source, reason, and correlation/idempotency reference.
- Do not edit history to represent a new outcome; append a compensating/reversal event.

## 43.4 Privacy

- Collect only necessary data.
- Separate public profile data from private account and financial data.
- Respect block, visibility, and participant boundaries in every query.
- Use anonymization where deletion conflicts with financial/legal retention.
- Limit analytics identity and retention.

## 43.5 Security

- Enforce authorization server-side.
- Use least privilege for database and support access.
- Keep files private by default and issue short-lived authorized access.
- Tokenize provider payment/payout references.
- Protect secrets outside ordinary database records.
- Audit privileged actions and sensitive file access.

## 43.6 Ownership integrity

- Ownership is represented by durable records and transfer history.
- Exclusive availability is rechecked and locked atomically.
- One current successful owner per exclusive asset.
- Refund does not automatically reverse ownership or relist an asset.
- Contest entry rights transfer only under accepted published rules.

## 43.7 Financial integrity

- Immutable balanced ledger is the money source of truth.
- Cached balances are repairable projections.
- Payment, fee, earnings, withdrawal, refund, and payout references reconcile.
- Provider callbacks are authenticated, deduplicated, and idempotent.

## 43.8 Data retention

- Distinguish hard delete, soft delete, archive, quarantine, anonymization, and legal hold.
- Preserve completed Orders, ledger, ownership, dispute, review verification, and policy acceptance records as required.
- Apply separate retention windows to analytics and operational records.

## 43.9 Scalability

- Measure before adding replicas, partitions, search engines, warehouses, or sharding.
- Use keyset pagination and workload-specific indexes.
- Keep analytics and feed projections rebuildable.
- Use asynchronous jobs for noncritical work and reconciliation.

## 43.10 Extensibility

- Add new marketplace transaction types through typed extensions of universal Order.
- Add new content/marketplace kinds without turning core references into unconstrained IDs.
- Version contracts, licenses, proposals, product releases, deliveries, and event schemas.
- Preserve API/backend compatibility during migrations.

---

# 44. Final Architecture Recommendation

## 44.1 Recommended system

```text
Primary operational store:
PostgreSQL

Binary object store:
Private/public object storage with access mediated by the application

Asynchronous work:
Background workers and transactional outbox

Discovery:
PostgreSQL indexes and full-text search first;
dedicated search index when needed

Social feed:
Database candidate queries + cursor pagination + bounded cache at MVP;
precomputed projections and hybrid fanout as traffic grows

Analytics:
Outbox-backed AnalyticsEvent pipeline;
PostgreSQL partitions/aggregates at MVP;
warehouse at scale
```

## 44.2 Why this is the right balance

This architecture:

- preserves financial and ownership integrity through relational constraints;
- supports social/feed reads without duplicating content;
- works with contextual chat-commerce;
- keeps source files and delivery files outside the database while enforcing access relationally;
- supports current and future product licenses;
- serves both web and mobile clients from the same consistent model;
- permits search, ranking, and analytics growth without making those systems authoritative;
- stays implementable by an MVP team on a single PostgreSQL primary;
- makes high-risk transitions explicit and testable.

## 44.3 Central truth boundaries

| Question | Source of truth |
|---|---|
| Who is the user and what can they do? | User, UserRole/Capability, account restrictions |
| What is publicly listed? | Product, Service, Project, Contest, Post |
| What was purchased/contracted? | Order and immutable Order snapshot |
| Did money move? | Payment and financial ledger |
| Who owns exclusive rights? | Ownership and OwnershipTransfer |
| Who can open a file? | AccessGrant plus Order/entitlement/ownership policy |
| What was delivered? | Delivery and DeliveryVersion |
| What happened in chat? | Conversation and Message |
| What is reputation? | Verified Review/Rating evidence and Reputation projection |
| What does analytics say? | Analytics events/aggregates, never operational authority |

---

# 45. Backend Architecture Dependencies — Prompt #37

Prompt #37 must treat the following as established database requirements.

## Database strategy

- PostgreSQL is the relational-first operational source of truth.
- Object storage contains binary file bytes.
- Cache, queues, search, and analytics systems are supporting/rebuildable projections.
- Do not create a second primary database for a domain without an explicit consistency design.

## Core entities

- User, Profile, UserRole/UserCapability;
- CreatorProfile, optional FreelancerProfile, BuyerProfile;
- Post, Media, Product, Service, Project, Contest;
- ProjectProposal/ProposalVersion, ContestEntry/Winner;
- universal Order/OrderItem and type-specific extensions;
- Payment, Wallet, FinancialTransaction, LedgerEntry;
- Ownership/OwnershipTransfer;
- Delivery/DeliveryVersion/DeliveryFile, Revision, AccessGrant;
- Conversation/Participant/Message/Offer/PaymentRequest;
- Review/Rating, Badge/Reputation;
- Notification, Settings, Support/Report/Moderation, PolicyAcceptance;
- AnalyticsEvent and outbox.

## User and role model

- One account identity with additive Buyer/Creator capabilities.
- Freelancer, Contest Participant, and Digital Seller are creator activity/capability contexts, not separate accounts.
- Active context changes presentation, not authorization.
- Admin/staff remains separated from ordinary marketplace participation.

## Profile model

- One shared Profile per User.
- CreatorProfile and BuyerProfile are optional capability extensions.
- FreelancerProfile is an optional specialization under CreatorProfile.
- Do not duplicate shared display identity or financial data into role profiles.

## Marketplace entities

- Post is social presentation, not a replacement for Product, Service, Project, or Contest.
- A source entity may appear in multiple feeds via eligibility/read projections without duplication.
- Core relationships use typed foreign keys.
- Product/service/project/contest data is versioned or snapshotted when terms become commercial.

## Order model

- One universal Order aggregate with OrderItems and type-specific extensions.
- The Order owns the commercial lifecycle.
- Payment, delivery, ownership, revision, refund, dispute, payout, and review remain separate state dimensions and records.
- Accepted scope, price, rights, deadline, license, and revision terms are immutable snapshots.

## Transaction and wallet/ledger model

- Payment provider status is not the wallet ledger.
- Financial transactions use immutable balanced ledger entries.
- Wallet balances are projections, never the only source of truth.
- Payment, fee, SellerEarning, withdrawal, refund, and payout transitions are idempotent and reconciled.

## Ownership model

- Ownership is a durable record with transfer history.
- Exclusive purchase locks availability only after trusted payment validation and atomic ownership assignment.
- Database uniqueness prevents duplicate current transferred ownership.
- Ordinary refund never silently relists exclusive work.
- Contest winner selection and contest rights transfer are separate.

## Delivery/file model

- File bytes remain in object storage; metadata and access policy remain relational.
- Delivery versions are append-only.
- File access requires an active authorized AccessGrant, entitlement, ownership, or permitted order relation.
- Every protected access request performs authorization; client URLs are not trusted.
- Previews and originals are separate access classes.

## Chat-commerce model

- Conversations retain history as they acquire Offer, PaymentRequest, and Order references.
- Offers and payment requests are structured records.
- Chat messages may point to transaction records but do not define payment, ownership, delivery, refund, or completion state.

## Review and reputation model

- Reviews are verified against eligible completed Orders.
- Duplicate review prevention uses order/author/target/context uniqueness.
- Reputation and badge state are derived from verified evidence and remain recalculable.

## Notification model

- Notifications originate from material authoritative events.
- Outbox/background delivery is idempotent.
- Notification failure cannot roll back a committed financial, ownership, or order transition.

## Analytics model

- Analytics events include schema version, event type, actor/target, server timestamp, session/device context where appropriate, and attribution.
- Sensitive/private payloads are excluded or minimized.
- Operationally significant events use transactional outbox.
- Behavioral events never replace Payments, Orders, Wallet ledger, Ownership, or Delivery records.

## Security requirements

- Server-side permission checks on every protected operation.
- Least-privilege access to financial, identity, dispute, and file data.
- No raw card/CVV or application-held authentication secrets in ordinary tables.
- Private files use short-lived authorized access and audit records.
- Support/admin access is case-scoped and audited.
- Deletion workflows preserve required transaction and compliance history.

## Indexing requirements

- Unique indexes for authentication subject, username, public order number, provider references, idempotency keys, ownership invariants, and relationship uniqueness.
- Composite indexes align with feed cursor, marketplace filters, buyer/seller order queues, chat inbox/messages, ledger history, notifications, and file access checks.
- Do not index every field; review query plans and write costs.

## Consistency requirements

- Strong transaction boundaries for payment/order, exclusive ownership, ledger journals, refunds, withdrawals, contest prizes, and access grants.
- Idempotent retries for payment callbacks and all money/ownership operations.
- Outbox for asynchronous notification, search, and analytics processing.
- Reconciliation for external payment, payout, object storage, and projection state.
- Append-only material audit/timeline history.

## Scalability requirements

- MVP starts with one PostgreSQL primary, focused indexes, keyset pagination, a small cache, object storage, and background workers.
- Read replicas serve only lag-tolerant reads, never authorization or transaction decisions.
- Partition high-volume append-only analytics/access data only when measured.
- Search/warehouse/precomputed feeds are added as supporting systems when justified.
- Sharding is a last resort after defining global uniqueness and cross-shard transaction behavior.

---

## Final Foundation Statement

NeuralMart's database is a relational-first hybrid built around one identity model, distinct marketplace source objects, one universal Order, an immutable financial ledger, durable ownership, protected versioned delivery, and contextual Chat. Feeds, search, analytics, badges, counters, and dashboards are derived views. This is the official database foundation for Prompt #37 — Backend Architecture.

