# NeuralMart — Order & Marketplace Lifecycle Architecture
## Part 5 of 5: Final Consolidation, Disputes, Ownership, Analytics, and Roadmap

**Document version:** 1.0  
**Depends on:** Parts 1, 2, 3, and 4  
**Scope:** Final order architecture, order-level dispute integration, exclusive ownership, analytics, roadmap, and preserved decisions

---

## 0. Final Recommendation

NeuralMart should use one scalable commercial architecture:

```text
Marketplace object
→ Checkout or accepted offer
→ Universal Order aggregate
→ Payment/transaction records
→ Type-specific fulfillment
→ Delivery/access/ownership records
→ Completion, refund, dispute, review, and payout overlays
→ Analytics events and user-facing notifications
```

The universal Order is the lifecycle owner, but it is not the only record involved in a transaction.

```text
Order
├── Type-specific order extension
├── Immutable commercial snapshot
├── Payment transactions
├── Wallet/ledger references
├── Delivery and revision records
├── Entitlements/access grants
├── Ownership records
├── Timeline/audit events
├── Review records
├── Dispute reference
├── Notification references
└── Analytics events
```

This architecture keeps normal user experiences simple while allowing services, products, projects, contests, chat-commerce, exclusive ownership, and future transaction types to share the same reliable foundation.

### 0.1 Non-negotiable boundaries

- The backend, not UI state, controls price, availability, payment, access, ownership, and status transitions.
- Payment confirmation is not itself an order completion.
- Chat is not the source of truth for payment, scope, ownership, delivery access, refunds, or disputes.
- Wallet/ledger records are the source of truth for money movement.
- Delivery and entitlement records are the source of truth for file access.
- Ownership records are the source of truth for exclusive ownership.
- Disputes are overlays on an order, not replacements for the order lifecycle.
- Refunds preserve historical order and ownership records.
- All money, ownership, availability, and access transitions must be idempotent and auditable.

---

# A. Final Order Architecture

## A.1 Universal Order aggregate

Every commercial transaction creates or references one universal Order aggregate.

The core Order contains:

- Internal immutable Order ID
- Human-readable order number
- `orderType`
- `orderOrigin`
- `fulfillmentMode`
- Buyer identity
- Seller/creator identity
- Optional buyer organization/team
- Optional creator team/agency
- Related product/service/project/contest/conversation references
- Immutable commercial snapshot
- Primary lifecycle status
- Payment status summary
- Fulfillment/delivery status summary
- Ownership status summary
- Revision status summary
- Refund status summary
- Dispute status summary
- Payout status summary
- Created/updated/accepted/started/delivered/completed/cancelled timestamps
- Current next-action information
- Participant visibility and permission context

The core record owns the universal lifecycle but does not flatten every type-specific concept into one oversized record.

## A.2 Immutable commercial snapshot

At the moment of purchase or accepted contract, the Order preserves:

- Product/service/project/contest title
- Version or package
- Scope and deliverables
- Price and currency
- Discounts
- Taxes and buyer-visible fees
- Platform fee treatment
- Seller gross and expected net
- Deadline and timezone
- Milestone schedule
- Revision allowance
- License and usage rights
- Source-file terms
- Cancellation policy
- Refund policy
- Buyer/seller role snapshots

Later listing or profile changes do not rewrite the purchased terms.

## A.3 Shared lifecycle overlays

The universal Order is combined with separate records for:

| Concern | Authoritative record |
|---|---|
| Commercial lifecycle | Order |
| Payment authorization/capture/refund | Payment transaction |
| Money movement | Wallet/financial ledger |
| Delivery | Delivery and delivery-item records |
| File access | Entitlement/access-grant records |
| Exclusive ownership | Ownership record |
| Revisions | Revision records |
| Disputes | Dispute reference and dispute case |
| Reviews | Order-linked review record |
| Chat context | Conversation and structured message records |
| Notifications | Notification records/preferences |
| Reporting | Derived analytics events/aggregates |
| Internal traceability | Append-only timeline/audit events |

The Order stores current summary fields and references. It must not become the only place where a specialized state is represented.

## A.4 Order command model

User actions should enter the system as authorized commands:

```text
CreateOrder
ConfirmPayment
AcceptOrder
StartWork
SubmitDelivery
RequestRevision
ApproveDelivery
CompleteOrder
RequestCancellation
RequestRefund
OpenDispute
ResolveDispute
TransferOwnership
ReleasePayout
```

Each command:

1. Authenticates the actor.
2. Checks authorization for the order and type.
3. Locks or atomically validates the required records.
4. Validates the current state and transition.
5. Performs the necessary payment, wallet, delivery, entitlement, or ownership operation.
6. Writes the Order update and timeline event.
7. Emits notifications and analytics events.
8. Is safe to retry with an idempotency key.

The UI may optimistically show progress, but the server response is authoritative.

## A.5 Permission model

Buyer permissions include:

- viewing their order;
- supplying requirements;
- approving delivery;
- requesting revisions;
- requesting cancellation/refund;
- opening a dispute;
- reviewing;
- accessing entitled files.

Creator permissions include:

- viewing orders assigned to them;
- accepting/starting eligible work;
- requesting requirements;
- submitting delivery;
- responding to revisions;
- requesting extensions;
- viewing earnings state;
- reviewing the buyer where applicable.

Admin/support permissions are scoped by case and role:

- inspect evidence;
- resolve or escalate issues;
- apply policy actions;
- initiate authorized compensation/refunds;
- access protected files only through audited support flows.

No hidden UI action is considered a security control. Every permission is enforced server-side.

---

# B. Final Order-Type Matrix

## B.1 Recommended order types

| Order type | Buyer | Seller | Main fulfillment | Ownership/access | Review |
|---|---|---|---|---|---|
| `digital_product` | Product buyer | Product creator | Instant digital access | Entitlement/license | Buyer review |
| `exclusive_product` | Exclusive buyer | Product creator | Exclusive digital access | Permanent exclusive ownership | Buyer review |
| `exclusive_project` | Project buyer | Project creator/owner | Ownership transfer and asset access | Permanent project ownership | Buyer review |
| `service` | Service buyer | Creator/freelancer | Package-based work | Delivery/license as contracted | Mutual where applicable |
| `project_contract` | Project owner | Selected creator | Custom scoped fulfillment | Rights/source files as contracted | Mutual where applicable |
| `custom_chat_order` | Offer buyer | Offer creator | Custom offer fulfillment | As offer defines | Mutual where applicable |
| `contest_prize` | Contest host | Winning creator | Winner delivery and rights | Rights transfer as rules define | Context-dependent |
| `paid_file_delivery` | File buyer | File sender | Secure file unlock | Entitlement/access grant | Context-dependent |

## B.2 Order origins

`orderOrigin` explains where the order began:

- `marketplace_product`
- `marketplace_service`
- `project_proposal`
- `contest`
- `chat_offer`
- `chat_delivery`
- `admin_support`
- `repeat_order`

Order origin is not the same as order type. For example:

```text
orderType: paid_file_delivery
orderOrigin: chat_delivery
fulfillmentMode: secure_download
```

## B.3 Fulfillment modes

`fulfillmentMode` describes how value is delivered:

- `instant_download`
- `secure_download`
- `service_delivery`
- `project_milestone`
- `project_final_delivery`
- `contest_prize_delivery`
- `ownership_transfer`
- `hybrid`

## B.4 Type-specific rules

### Digital product

- Payment normally creates the order immediately.
- Seller acceptance is not required.
- Entitlement and secure access are created after confirmed payment.
- Delivery is instant but still protected.
- Order can complete after access is granted or after the defined completion window.

### Exclusive product

- Availability is checked and reserved atomically.
- A successful purchase creates a durable ownership record.
- Product becomes Sold/Locked.
- Refund does not silently make the product available again.

### Exclusive project

- Project ownership is reserved in the purchase transaction.
- Duplicate ownership is prevented by a database uniqueness invariant.
- Ownership transfer is recorded independently from the Order summary.
- Sold/Locked presentation remains after ordinary refund unless an explicit ownership-reversal process is authorized.

### Service

- Package and requirements are snapshotted.
- Creator may need to accept or begin work.
- Delivery, revision, approval, and completion are explicit.
- Package revision limits are enforced by the backend.

### Project contract

- Accepted proposal becomes a formal contract/order.
- Scope, price, deadline, milestones, revisions, and rights are immutable unless a new version is explicitly accepted.
- Buyer and creator can have separate delivery, approval, payment, and payout states.

### Custom chat order

- A structured offer becomes the commercial source.
- Chat provides context and action entry points.
- Accepted offer and payment create the Order.
- Later scope changes require an add-on, offer revision, or new order.

### Contest prize

- Prize must be funded before the contest opens.
- Winner selection creates or activates a contest prize order.
- Rights and final delivery are separate gates from winner selection.
- Non-winning entries remain with creators unless separately licensed or purchased.

### Paid file delivery

- Locked previews may be shown before payment.
- Payment creates the order, entitlement, and access grant atomically or through a recoverable saga.
- Original files remain private.
- Refund, dispute, and access revocation are separate recorded consequences.

---

# C. Final State Machine

## C.1 Universal primary order state

The universal primary state is:

```text
Draft
→ Pending Payment
→ Paid
→ Accepted
→ In Progress
→ Awaiting Buyer
→ Awaiting Delivery
→ Delivered
→ Revision Requested
→ Approved
→ Completed
```

Terminal or overlay outcomes:

```text
Cancelled
Expired
Disputed
Refunded
Partially Refunded
```

These are not all mutually exclusive dimensions. For example:

```text
Primary: Completed
Refund: Partial
Dispute: Resolved
Payout: Released
Ownership: Transferred
```

## C.2 Separate status dimensions

### Payment

```text
Not Started
Pending
Authorized
Captured/Paid
Failed
Partially Refunded
Refunded
Charged Back
```

### Fulfillment

```text
Not Started
Awaiting Acceptance
Awaiting Buyer
In Progress
Awaiting Delivery
Delivered
In Review
Approved
Completed
```

### Delivery/access

```text
Not Applicable
Locked
Preview Available
Ready
Access Granted
Downloaded
Revoked
```

### Ownership

```text
Not Applicable
Available
Reserved
Pending Transfer
Transferred
Locked/Sold
Reversed by Authorized Process
```

### Revision

```text
Not Applicable
Available
Requested
In Progress
Delivered
Accepted
Exhausted
```

### Refund

```text
Not Requested
Requested
Under Review
Approved
Partially Refunded
Fully Refunded
Declined
```

### Dispute

```text
None
Opened
Evidence Collection
Under Review
Resolved for Buyer
Resolved for Seller
Partially Resolved
Closed
```

### Payout

```text
Not Applicable
Pending
Held
Eligible
Released
Reversed
```

## C.3 State transition rules

- A user cannot directly set an arbitrary status.
- A creator cannot mark a buyer's approval or payment as complete.
- A buyer cannot mark creator delivery as submitted.
- Payment confirmation must come from a trusted payment result.
- Delivery approval must create a structured event.
- Completion can occur through approval, automatic completion, or authorized resolution.
- Refunds and disputes update overlays and financial/access consequences without deleting history.
- A failed transition must leave the order in a safe retryable state.

## C.4 Auto-completion

Auto-completion may be used when:

- delivery was submitted;
- the review period expired;
- no revision/dispute was opened;
- the order type permits auto-completion.

Auto-completion must:

- notify both parties;
- append a system timeline event;
- preserve the delivery and approval deadline;
- move payout according to policy;
- open the review window;
- avoid bypassing a valid dispute or safety hold.

---

# D. Final Ownership/Availability Rules

## D.1 Exact exclusive lifecycle

The final exclusive purchase lifecycle is:

```text
Available
→ Checkout
→ Payment Validation
→ Ownership Lock
→ Sold
→ Ownership Transfer
```

These labels describe the user and backend phases. The database transaction may combine some phases, but the system must preserve their meaning.

## D.2 Available

An exclusive item is Available only when:

- the listing is active;
- no successful ownership record exists;
- no valid ownership reservation is active;
- the item is not policy-blocked;
- the seller still controls the asset;
- the item is eligible for purchase.

The UI may show:

```text
Available · Buy exclusive
```

Availability is always rechecked on the server.

## D.3 Checkout

Checkout creates a pending purchase attempt, not ownership.

The attempt records:

- buyer;
- item;
- displayed price;
- currency;
- license/rights selection;
- idempotency key;
- checkout expiration;
- payment reference.

The item may still be available to other buyers at this stage.

The UI may show a short-lived `Checkout in progress` state for the current buyer, but this is not a public Sold state.

## D.4 Payment Validation

The server validates:

- current price and terms;
- buyer eligibility;
- item availability;
- payment authorization/capture result;
- duplicate attempt status;
- fraud/risk policy;
- seller/item policy state.

Payment success alone does not authorize the client to claim ownership.

## D.5 Exact locking point

The exact locking point is the atomic server-side ownership reservation immediately after payment has been authoritatively validated and before the transaction commits the successful purchase.

Conceptually:

```text
BEGIN TRANSACTION
→ Lock exclusive item row
→ Confirm no successful ownership/reservation exists
→ Create ownership reservation/ownership record
→ Create or activate universal Order
→ Create payment/order linkage
→ Mark item Sold/Locked
→ Commit
```

The ownership record and Sold/Locked listing update commit together.

If the system uses a short reservation before payment completion, that reservation is not a successful ownership lock and must expire safely. The permanent ownership lock occurs only in the successful purchase transaction.

## D.6 Backend enforcement

The backend must enforce:

- row-level lock or equivalent atomic compare-and-set;
- unique constraint on the exclusive item ownership key;
- unique successful purchase key for the payment/idempotency scope;
- authoritative price and availability recheck;
- buyer permission and eligibility;
- no client-provided ownership state;
- no public file access before entitlement/ownership authorization;
- no relisting through ordinary refund.

## D.7 Duplicate purchase prevention

Prevent duplicate ownership through multiple layers:

1. Client idempotency key.
2. Server idempotency record.
3. Payment provider idempotency.
4. Locked availability check.
5. Unique ownership constraint.
6. Unique successful order constraint for the item.
7. Safe retry handling after timeout.

A retried request returns the existing successful Order rather than creating a second order.

## D.8 Ownership record

The durable ownership record contains:

- ownership ID;
- exclusive asset/project/product ID;
- buyer ID;
- seller/creator ID at time of sale;
- order ID;
- payment transaction reference;
- purchased rights/license;
- ownership effective timestamp;
- transfer status;
- access status;
- refund/reversal references;
- audit timestamps.

The Order stores a summary and snapshot. The ownership record controls actual ownership.

## D.9 Seller record

The seller record preserves:

- seller identity at sale;
- listing identity;
- original asset identity;
- seller's ownership/authorization to sell;
- seller proceeds and payout state;
- sale timestamp;
- rights transferred;
- whether the seller may continue using or displaying the work.

Seller profile and portfolio presentation must update without deleting the historical sale.

## D.10 Buyer record

The buyer record preserves:

- buyer identity;
- order;
- ownership;
- license/rights;
- access grants;
- receipt;
- purchase date;
- current refund/dispute/access state.

The buyer can see:

```text
Owned · Exclusive
```

and the purchased rights summary.

## D.11 Sold/Locked presentation

After the ownership transaction commits:

Public listing/profile:

```text
Sold · Locked
No longer available for purchase
```

Buyer:

```text
Owned · View files
```

Seller:

```text
Sold · Ownership transferred
```

Other buyers:

```text
Unavailable
```

Do not expose private buyer identity unless the product explicitly supports public attribution and the buyer has consented.

## D.12 Failure recovery

### Payment fails

- No ownership record is committed.
- No Sold/Locked state is committed.
- Pending checkout may expire.
- Payment attempt is recorded as failed.
- The item remains Available unless another successful purchase committed.
- Buyer can retry with a new or safely reused idempotency key.

### Payment succeeds but order creation fails

The system must not silently lose the payment or create an untracked sale.

Recovery:

1. Payment webhook/reconciliation identifies the successful payment.
2. Idempotent order creation is retried.
3. Ownership reservation and Sold/Locked update are attempted.
4. If successful, the existing payment is linked to the Order.
5. If ownership cannot be safely assigned, payment is placed into a reconciliation/hold state.
6. The platform either completes the sale through a safe retry or issues a compensating void/refund.

The buyer receives a clear pending-resolution state rather than a false ownership claim.

### Ownership assignment fails

- The transaction must not report successful ownership to the buyer.
- If payment is only authorized, void authorization.
- If payment is captured, create a compensating refund or hold according to payment policy.
- Keep the failed attempt and compensation in the timeline.
- Do not mark the item Sold/Locked unless the ownership record committed.

### Transaction timeout

A timeout is an unknown outcome, not an automatic failure.

Recovery:

- retry using the same idempotency key;
- query the authoritative payment/order/ownership state;
- return the already-created Order if the commit succeeded;
- reconcile incomplete records through an idempotent worker;
- prevent a second ownership attempt while reconciliation is unresolved.

### Rollback requirements

Rollback may remove only uncommitted provisional state.

It must never:

- delete a committed ownership record;
- silently relist a sold exclusive item;
- erase a successful payment;
- remove a completed timeline event;
- revoke an ownership transfer without an explicit authorized reversal.

---

# E. Final Payment-to-Order Sequence

## E.1 Standard purchase

```text
1. Buyer selects product/service/project/offer.
2. Server loads current commercial terms.
3. Server validates price, eligibility, availability, and policy.
4. Client confirms checkout.
5. Server creates an idempotent payment attempt.
6. Payment provider authorizes/captures as appropriate.
7. Server receives trusted payment confirmation.
8. Server creates or activates the universal Order.
9. Server creates type-specific extension.
10. Server creates entitlement/delivery/ownership records as required.
11. Server writes timeline event.
12. Server emits notifications and analytics events.
13. Server returns the Order and current next action.
```

## E.2 Service/project order

```text
Proposal or package
→ Final terms confirmation
→ Payment authorization/capture
→ Order creation
→ Requirements
→ Acceptance/start
→ Work
→ Delivery
→ Revision/approval
→ Completion
→ Payout/review
```

## E.3 Exclusive purchase

```text
Checkout
→ Payment validation
→ Atomic item lock
→ Ownership record
→ Universal Order
→ Sold/Locked update
→ Ownership transfer/access grant
→ Receipt and notifications
```

The exact implementation may create the Order before or inside the same database transaction as the ownership record, but the user must not see a successful Sold/Owned outcome unless all required records are committed or a recoverable pending state is explicitly shown.

## E.4 Payment and wallet separation

Payment answers:

```text
Did the buyer's payment method authorize/capture/refund?
```

Wallet/financial records answer:

```text
What money is owed, held, released, reversed, or withdrawable?
```

Order answers:

```text
What commercial relationship and fulfillment obligation exists?
```

These systems reference each other but do not substitute for one another.

---

# F. Final Delivery & Revision Model

## F.1 Delivery

Every fulfillment delivery is a versioned, permissioned record:

- delivery ID;
- order/milestone;
- sender/recipient;
- version;
- preview items;
- original files;
- access policy;
- license/rights summary;
- delivery note;
- timestamp;
- review deadline;
- replacement lineage.

Original files remain private. Access uses an active order entitlement, ownership grant, or approved delivery authorization.

## F.2 Delivery visibility

Before payment:

- safe preview only;
- no original protected file;
- no permanent public storage URL.

After payment/entitlement:

- short-lived authorized access link;
- permission checks on every access request;
- access/download events;
- revocation when refund, fraud, policy, or dispute rules require it.

## F.3 Revisions

Revision records enforce:

- included round count;
- used and remaining rounds;
- in-scope request;
- requester;
- request date;
- response deadline;
- delivered revision version;
- acceptance/rejection;
- out-of-scope change path.

A plain Chat message can provide context, but only a structured revision action changes the revision state or consumes an allowance.

## F.4 Type rules

- Digital products: updates/corrections, not ordinary revisions.
- Services: package-defined revisions.
- Project contracts: contract/milestone-defined revisions.
- Custom chat orders: accepted-offer-defined revisions.
- Contest orders: published finalist/winner rules.
- Paid file deliveries: no revision unless explicitly contracted.

## F.5 Approval and completion

Buyer approval:

1. validates the buyer has access to the order;
2. validates the delivery is reviewable;
3. records the approved delivery/version;
4. moves fulfillment toward completion;
5. starts review/payout consequences.

Auto-completion is permitted only where policy allows and no valid revision/dispute/safety hold exists.

---

# G. Final Cancellation/Refund Integration

## G.1 Cancellation

Cancellation is a lifecycle decision. Refund is a financial decision. They are related but separate.

Cancellation records:

- actor;
- reason;
- stage;
- payment state;
- delivery state;
- ownership/access consequence;
- refund decision;
- timeline event.

An order can be:

```text
Cancelled + Fully Refunded
Cancelled + Partially Refunded
Cancelled + No Refund
```

## G.2 Refund

Refund processing updates:

- payment transaction;
- Order refund overlay;
- buyer wallet/receipt;
- seller pending or released earnings;
- platform fee accounting;
- access/entitlement state;
- ownership state where policy requires;
- notification;
- timeline;
- analytics.

Refunds do not delete:

- the Order;
- payment attempts;
- delivery versions;
- ownership history;
- review history subject to moderation policy;
- dispute history.

## G.3 Exclusive refunds

An ordinary refund does not automatically relist an exclusive product or project.

If a policy-authorized reversal is required:

1. resolve the refund/reversal decision;
2. revoke or amend access as appropriate;
3. create an explicit ownership-reversal record;
4. update the listing only through the authorized process;
5. preserve the original Sold/Locked history;
6. notify affected parties;
7. emit separate ownership and availability events.

## G.4 Dispute integration points

The standalone Dispute System will define detailed policy, evidence handling, staffing, SLAs, and adjudication. This Order architecture defines only the order integration boundary.

### Trigger

A dispute may be triggered when an authorized participant:

- opens a claim from Order Detail;
- reports non-delivery, materially incomplete delivery, unauthorized charge, access failure, or scope failure;
- responds to a refund or cancellation flow with a formal claim;
- is escalated by support, risk, or a payment event.

The trigger must reference:

- Order ID;
- actor;
- claim category;
- claimed amount or consequence;
- relevant delivery/milestone/version;
- initial narrative;
- evidence references.

### Order enters dispute state

The Order receives:

```text
disputeStatus: Opened
```

The Order may also receive an operational hold:

- payout hold;
- completion hold;
- access hold;
- ownership action hold;
- cancellation/refund review hold.

The dispute does not erase the prior primary order status.

Example:

```text
Primary: Delivered
Dispute: Opened
Payout: Held
```

### Evidence references

The Order-level integration stores references, not duplicated evidence:

- delivery IDs and versions;
- file access/download events;
- requirements;
- structured revision records;
- payment transaction IDs;
- refund records;
- ownership records;
- relevant Chat conversation/message IDs;
- timeline event IDs;
- uploaded dispute evidence IDs managed by the future Dispute System.

### Chat/file history references

The dispute record may point to:

- the order-linked conversation;
- structured offer/contract messages;
- delivery messages;
- revision requests;
- approval messages;
- file IDs and version lineage;
- access logs.

It does not make Chat text authoritative over structured Order, Payment, Delivery, or Ownership records.

### Order timeline

The Order timeline records:

- Dispute opened;
- claim submitted;
- seller response requested;
- seller response received;
- admin review started;
- resolution recorded;
- refund/partial refund initiated;
- access/ownership consequence;
- dispute closed.

Sensitive evidence and internal notes remain visible only to authorized users.

### Buyer claim

The buyer submits:

- claim category;
- concise description;
- desired outcome;
- affected delivery/milestone;
- evidence references;
- requested amount or remedy.

The Order records that a buyer claim exists and links to the future Dispute case.

### Seller response

The seller can:

- acknowledge the claim;
- respond with a structured explanation;
- reference delivery versions;
- reference requirements and approval history;
- propose correction, replacement, partial refund, or other allowed remedy;
- attach evidence through the Dispute System.

The seller response does not directly resolve the Order.

### Admin review

Authorized support/admin tooling can:

- inspect the Order and linked records;
- place or maintain operational holds;
- request information;
- record an authorized resolution;
- initiate refund/partial refund;
- change access according to policy;
- determine whether ownership action is required.

All internal actions are audited.

### Resolution

The Order-level resolution outcome can be:

- resolved for buyer;
- resolved for seller;
- partially resolved;
- corrected/re-delivered;
- refund approved;
- partial refund approved;
- no refund;
- access restored;
- access revoked;
- ownership preserved;
- ownership reversal escalated.

The detailed adjudication remains in the future Dispute System.

### Final order state

After dispute closure:

- the primary Order state remains historically accurate;
- dispute status becomes `Closed`;
- financial state reflects the actual refund/chargeback;
- payout reflects hold/release/reversal;
- delivery/access reflects the resolution;
- ownership reflects any explicit authorized action;
- review eligibility follows the final policy outcome;
- notifications and analytics are emitted.

---

# H. Final User Experience Architecture

## H.1 Buyer Order Center

Buyer views:

```text
All Orders
Active
Awaiting Delivery
Delivered
Completed
Cancelled
Refunded
Disputed
```

Cards show:

- order type;
- product/service/project title;
- creator;
- current status;
- next action;
- deadline;
- price;
- delivery/access state;
- review/refund/dispute state;
- unread Chat activity.

## H.2 Creator Order Center

Creator views:

```text
New Orders
Active Orders
Awaiting Buyer
Delivery Due
Revision Requests
Completed
Cancelled
Disputed
```

Cards prioritize:

- next action;
- due date;
- buyer;
- package/milestone;
- revision state;
- earnings state;
- dispute/refund state.

Compact metrics:

- needs action;
- due soon;
- pending earnings;
- on-time active orders.

## H.3 Universal Order Detail

Every order detail page uses:

```text
Status and next action
→ Summary
→ Parties
→ Commercial terms
→ Delivery/files
→ Revisions
→ Timeline
→ Chat
→ Financial information
→ Review
→ Help/refund/dispute
```

Type-specific sections appear only when relevant.

## H.4 Mobile-first rules

On mobile:

- primary action is sticky;
- status/deadline appear first;
- filters use bottom sheets;
- cards are full width;
- timeline collapses;
- files use full-screen preview/download;
- Chat opens with order context preserved;
- payment/refund/dispute actions require clear confirmation;
- long commercial terms are grouped into expandable sections.

## H.5 Notifications

Notifications are generated from material order events, not every database update.

They are:

- order-linked;
- deduplicated;
- action-oriented;
- deadline-aware;
- configurable by channel;
- grouped when multiple events belong to one order.

High-impact events such as payment failure, delivery due, revision request, refund decision, and dispute response use stronger delivery channels than low-priority activity.

## H.6 Chat

Chat supports:

- pre-order questions;
- structured offers;
- requirements;
- delivery messages;
- revisions;
- approvals;
- post-order support;
- follow-on work.

Chat references the Order and mirrors material events but cannot independently mutate authoritative transaction state.

---

# I. Final Analytics Integration

## I.1 Analytics principle

Analytics should be modular and event-driven:

```text
Authoritative Order/Payment/Delivery events
→ Small canonical analytics event layer
→ Role-specific aggregates and views
```

Do not calculate business truth from UI impressions or Chat text.

## I.2 Canonical event groups

Track only meaningful events initially:

- checkout started;
- payment succeeded/failed;
- order created;
- order accepted;
- work started;
- delivery submitted;
- revision requested;
- delivery approved;
- order completed;
- cancellation;
- refund;
- dispute opened/resolved;
- ownership transferred;
- access granted/revoked;
- review submitted;
- payout released.

Every event includes:

- event name;
- timestamp;
- Order ID;
- order type;
- origin;
- buyer/seller references subject to privacy policy;
- amount/currency where appropriate;
- product/service/project reference;
- source surface;
- idempotency/deduplication key.

## I.3 Creator Dashboard metrics

Primary:

- active orders;
- needs-action orders;
- completed orders;
- delivery due soon;
- pending earnings;
- available earnings;
- verified rating;
- on-time delivery rate when sample size is meaningful.

Secondary:

- average completion time;
- revision frequency;
- cancellation rate;
- refund rate;
- dispute rate;
- repeat buyer rate.

The dashboard should explain trends and next actions rather than display every raw metric.

## I.4 Buyer Dashboard metrics

Primary:

- active orders;
- awaiting delivery;
- delivered awaiting approval;
- completed purchases;
- reviews awaiting submission;
- open disputes/refund cases.

Optional personal summaries:

- total spending by period;
- repeat creators;
- favorite purchase categories;
- average approval time.

Buyer analytics remain private and must not expose sensitive creator or marketplace data.

## I.5 Financial Dashboard metrics

Buyer:

- total paid;
- refunds;
- spending by order type;
- pending payment issues;
- receipts.

Creator:

- gross sales;
- platform fees;
- pending earnings;
- available earnings;
- refunds/chargebacks;
- payouts;
- earnings by product/service/project.

Financial Dashboard values derive from ledger/payment records, not estimated Order totals.

## I.6 Bid Insights

Bid Insights uses project/proposal events:

- proposals submitted;
- proposals viewed;
- shortlist rate;
- clarification requests;
- selection rate;
- average accepted price;
- accepted delivery time;
- proposal-to-order conversion.

It should not count ordinary product sales as bids or mix contests into direct proposal conversion.

## I.7 Creator Analytics

Creator Analytics can connect:

```text
Showcase impression
→ Profile visit
→ Product/service/project click
→ Chat/offer
→ Order
→ Completion
→ Review/repeat order
```

Metrics:

- order conversion rate;
- average order value;
- completion time;
- delivery/on-time rate;
- revision frequency;
- refund/dispute rate;
- repeat buyer rate;
- revenue by source;
- product/service/project performance.

Attribution must be labeled as observed, assisted, or last-touch rather than presented as certain when multiple surfaces influenced a purchase.

## I.8 Admin Analytics

Admin Analytics can aggregate:

- total orders;
- completed orders;
- active orders;
- GMV/volume;
- average order value;
- payment failure rate;
- cancellation rate;
- refund rate;
- dispute rate;
- dispute resolution time;
- delivery completion rate;
- revision frequency;
- payout holds;
- ownership conflict attempts;
- access failures;
- repeat buyer rate;
- marketplace conversion.

Sensitive analytics require role-based access and should be aggregated or anonymized where appropriate.

## I.9 Metric definitions

Metrics must define:

- numerator;
- denominator;
- time window;
- order types included;
- treatment of cancelled/refunded/disputed orders;
- currency conversion policy;
- privacy threshold;
- attribution rule.

For example:

```text
Completion rate
= completed eligible orders
  / eligible orders entering fulfillment
```

Do not call a zero-review creator “0-star rated.” Use `No reviews yet`.

## I.10 Analytics complexity boundary

MVP should use:

- append-only order events;
- daily/hourly aggregates where useful;
- simple role-specific queries;
- explicit metric definitions.

Advanced event streaming, experimentation platforms, predictive forecasting, and multi-touch attribution are not required for the initial order system.

---

# J. MVP → V2 → Advanced Roadmap

## J.1 MVP

### Core architecture

- Universal Order aggregate
- Essential order types:
  - digital product;
  - service;
  - project contract;
  - custom chat order;
  - paid file delivery
- Basic contest prize linkage where contests already exist
- Immutable commercial snapshot
- Primary order state
- Separate payment, delivery, refund, and payout summaries

### Transaction capabilities

- Payment authorization/capture
- Idempotent order creation
- Availability validation
- Exclusive ownership locking
- Duplicate purchase prevention
- Basic entitlements/access grants
- Private file storage and secure access
- Basic delivery
- Basic completion
- Basic cancellation
- Basic full refund
- Basic verified reviews
- Order timeline

### User experience

- Buyer Order Center
- Creator Order Center
- Universal Order Detail
- Basic linked Chat
- Basic order notifications
- Mobile-first status/actions

### Reliability

- Server-side authorization
- Unique constraints for exclusive ownership
- Payment/order reconciliation
- Append-only material events
- Basic access/download audit
- Basic error and retry handling

## J.2 V2

### Fulfillment

- Milestones
- Advanced revision handling
- Partial refunds
- Delivery versioning improvements
- Replacement delivery workflows
- Richer access and license management
- Contest winner order completion

### Commerce and negotiation

- Versioned offers
- Add-ons and scope changes
- Better proposal-to-contract flow
- Buyer approval windows
- Automatic completion rules
- More nuanced cancellation policies

### Analytics

- Richer order analytics
- Creator conversion funnels
- Repeat buyer metrics
- Bid Insights integration
- Buyer spending insights
- Admin operational dashboards

### Trust and support

- Enhanced review moderation
- Reputation/badge connections
- Order-level dispute integration
- Payout holds and releases
- More complete audit/reconciliation tools

## J.3 Advanced

### Contracts and fulfillment

- Sophisticated contract versions
- Complex milestone payment schedules
- Multi-party buyer teams
- Creator agencies and collaborators
- Approval chains
- Enterprise procurement workflows
- Purchase orders and invoicing
- Multi-currency settlement sophistication

### Protection and automation

- Automated dispute intelligence
- Risk-based payment/fulfillment holds
- Advanced marketplace protection
- Fraud and collusion detection
- Automated evidence assembly
- Delivery quality checks
- Rights and license compliance automation

### Financial automation

- Complex escrow/release policies
- Automated split payouts
- Tax/reporting workflows
- Chargeback automation
- Cross-border settlement
- Reconciliation orchestration

Advanced features must extend the universal model rather than create parallel order systems.

---

# K. Final Architecture Principles

## K.1 One order, many specialized records

Use one universal Order aggregate with type-specific extensions and shared overlays.

## K.2 State dimensions remain separate

Payment, fulfillment, delivery, ownership, revision, refund, dispute, and payout are not one overloaded status string.

## K.3 Backend enforcement

Price, availability, duplicate prevention, access, ownership, permissions, and state transitions are enforced server-side.

## K.4 Idempotency everywhere it matters

Payment callbacks, order creation, ownership assignment, refunds, payouts, notifications, and analytics events must be safe to retry.

## K.5 Immutable history

Purchased terms, ownership events, delivery versions, financial records, refunds, disputes, and timeline events are preserved.

## K.6 Chat is connected, not authoritative

Chat makes commerce understandable and conversational. Structured Order, Payment, Wallet, Delivery, Ownership, and Dispute records remain authoritative.

## K.7 Secure delivery by default

Original files remain private. Access is granted by entitlement, ownership, or explicit order permission and uses short-lived authorized links.

## K.8 Exclusive ownership is a transaction, not a UI label

The item becomes Sold/Locked only when payment validation, ownership assignment, and order linkage commit safely.

## K.9 Simple user experience over complex internals

Normal users should see:

```text
What happened?
What do I do next?
When is it due?
Where are my files and receipt?
```

They should not need to understand every ledger, reservation, webhook, or state overlay.

## K.10 Mobile-first operations

The critical actions—pay, accept, provide requirements, deliver, approve, revise, refund, dispute, and download—must work clearly on mobile.

## K.11 Marketplace trust is evidence-based

Reviews, completed orders, delivery reliability, badges, and ownership signals derive from verified transaction history, not self-reported claims.

## K.12 Analytics stays modular

Start with canonical events and meaningful aggregates. Add advanced attribution, predictions, and automation only when the core data is reliable.

## K.13 Future transaction types extend the model

A future transaction type should add:

- a type-specific extension;
- validation rules;
- fulfillment behavior;
- delivery/access/ownership behavior;
- user-facing card/detail sections;
- analytics mappings;

It should not create a separate payment, order center, review, dispute, or notification system.

---

# L. Key Decisions That Must Be Preserved in Prompt #36

1. NeuralMart has one universal Order aggregate.
2. Products, services, projects, contests, custom chat orders, and paid file deliveries use type-specific extensions.
3. Payment, fulfillment, delivery, ownership, revision, refund, dispute, and payout remain separate dimensions.
4. Active orders preserve the commercial terms purchased or accepted.
5. Chat is a communication and commerce surface, not transaction truth.
6. Wallet/ledger records are authoritative for money movement.
7. Delivery and entitlement records are authoritative for file access.
8. Ownership records are authoritative for exclusive ownership.
9. Exclusive ownership follows:

   ```text
   Available
   → Checkout
   → Payment Validation
   → Ownership Lock
   → Sold
   → Ownership Transfer
   ```

10. The atomic ownership lock occurs after authoritative payment validation and before the successful purchase transaction commits.
11. Unique constraints and idempotency prevent duplicate exclusive purchases.
12. Payment success without order/ownership completion enters reconciliation, not silent success or silent failure.
13. A normal refund does not automatically relist an exclusive project or product.
14. Ownership reversal requires an explicit authorized process and preserves history.
15. Delivery files remain private and use authorized access grants.
16. Deliveries are versioned; replacements do not delete prior versions.
17. Structured revision records control revision allowances; ordinary Chat messages do not.
18. Disputes are overlays on Orders; the future Dispute System owns detailed case policy and adjudication.
19. Order timelines are append-only for material events.
20. Buyer and creator Order Centers are role-aware views over the same universal Order data.
21. One universal Order Detail shell adapts to order type.
22. Notifications are contextual, deduplicated, and action-oriented.
23. Reviews are linked to eligible completed orders and show verified purchase/client context.
24. Reputation and badges use verified marketplace outcomes, not raw volume alone.
25. Analytics derive from canonical Order/Payment/Delivery events, not UI state or Chat text.
26. MVP prioritizes reliable transactions and clear operations over advanced automation.
27. V2 adds milestones, richer revisions, partial refunds, negotiation, delivery versioning, and deeper analytics.
28. Advanced work extends the same model into contracts, protection, automation, enterprise, and complex settlement.

---

## Final Consolidated Architecture

```text
PRODUCT / SERVICE / PROJECT / CONTEST / CHAT OFFER
                    │
                    ▼
        CHECKOUT OR ACCEPTED CONTRACT
                    │
                    ▼
       PAYMENT VALIDATION + IDEMPOTENCY
                    │
                    ▼
          UNIVERSAL ORDER AGGREGATE
          ├── Type-specific extension
          ├── Commercial snapshot
          ├── Payment transactions
          ├── Wallet/ledger references
          ├── Delivery and revisions
          ├── Entitlements/file access
          ├── Ownership
          ├── Timeline/audit
          ├── Reviews
          ├── Dispute reference
          ├── Notifications
          └── Analytics events
                    │
                    ▼
     FULFILLMENT → DELIVERY → APPROVAL
                    │
                    ▼
 COMPLETION / REFUND / DISPUTE / PAYOUT / REVIEW
                    │
                    ▼
   BUYER CENTER + CREATOR CENTER + DASHBOARDS
```

This is the final recommended NeuralMart Order & Marketplace Lifecycle architecture. It is scalable enough for future transaction types and simple enough for ordinary buyers and creators to understand.
