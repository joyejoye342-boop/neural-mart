# NeuralMart — Master Product Architecture Document
**Version 1.0 | Platform Classification: Social Creator Marketplace + Freelancing + Chat-Commerce**

---

## 1. Product Identity Summary

**NeuralMart** is a next-generation creator-economy platform that merges:
- A **social content marketplace** (creators showcase and sell)
- A **freelancing & project marketplace** (buyers post needs, creators bid/apply)
- A **contest platform** (open competitions for creative work)
- A **chat-commerce system** (transact, deliver, and unlock files inside conversations)

**Positioning:** The simplicity of a social platform, the power of a professional marketplace. It is NOT a Facebook clone — it borrows Facebook's ease of navigation while building its own distinct commercial and creator-first identity.

**Core Promise:** Feature-rich underneath. Simple on the surface. Fast everywhere.

**Primary Audience:**
- **Creators / Freelancers** — designers, developers, writers, video creators, musicians, digital product sellers
- **Buyers / Clients** — individuals and businesses looking to hire, buy, or run contests
- **General Audience** — users who discover and consume creator content and may convert into buyers

---

## 2. Core User Roles

| Role | Description |
|------|-------------|
| **Creator** | Sells digital products, offers services, posts showcase content, participates in contests/projects |
| **Freelancer** | Submits proposals/bids on project posts, manages client work, delivers files via chat |
| **Buyer / Client** | Posts projects/contests, hires freelancers, purchases digital products, reviews work |
| **General User / Audience** | Browses creator feeds, follows creators, may purchase, may post project requests |
| **Admin** | Platform moderation, user management, dispute resolution, financial oversight |

> **Note:** A single account can hold Creator + Freelancer roles simultaneously. Role-switching is seamless and contextual, not separate logins.

---

## 3. Main Platform Pillars

| Pillar | Description |
|--------|-------------|
| **1. Social Feed & Discovery** | Role-based feeds for creator content and project opportunities |
| **2. Creator Marketplace** | Digital product listings, service packages, profile storefronts |
| **3. Freelancing & Projects** | Project posts, bidding, proposals, milestone management |
| **4. Contests** | Open creative contests with submissions, judging, and prizes |
| **5. Chat-Commerce** | Messaging with integrated payment, file delivery, and unlock flows |
| **6. Creator Profiles** | Public social-style profiles with portfolio, stats, badges |
| **7. Financial Center** | Wallet, withdrawals, transactions, bid credits, revenue analytics |
| **8. Account & Settings** | Profile management, notifications, security, preferences |
| **9. Admin & Trust Layer** | Moderation, dispute resolution, badge system, fraud prevention |

---

## 4. Top-Level Navigation Architecture

### Bottom Navigation Bar (Mobile) / Top Nav (Desktop)

```
[Home]  [Explore]  [+Create]  [Messages]  [Menu]
```

| Nav Item | Role: Creator | Role: Buyer/Audience |
|----------|--------------|---------------------|
| **Home** | Creator Showcase Feed + Project/Contest Feed | Main feed (creator content + project posts) |
| **Explore** | Search creators, products, services, projects | Browse creators, categories, trending |
| **+ Create** | Post content, list product, list service, post contest | Post project request |
| **Messages** | Chat inbox with payment/file actions | Chat inbox with payment/file actions |
| **Menu** | Full control center (financial, settings, support) | Full control center |

### Secondary Navigation (Inside Hub Pages)
Each hub has its own internal tab/sub-nav. Never surfaced at the top-level nav.

---

## 5. Main Feed Architecture

### 5A. Creator Home (2 Feeds — Tab-Switched)

**Tab 1: Showcase Feed**
- Creator posts: images, videos, reels, graphics, digital product promotions
- Service promos, portfolio highlights, behind-the-scenes content
- Engagement: likes, comments, saves, shares, "buy/hire" CTAs
- Sorted by: recency, algorithm-ranked engagement, followed creators first

**Tab 2: Opportunities Feed** (Projects + Contests)
- Buyer-posted project requests
- Active contests with deadlines and prize amounts
- Filters: category, budget range, deadline, contest vs. project
- CTAs: "Bid Now," "Submit Entry," "View Details"

### 5B. Buyer / General Audience Home (1 Combined Feed)

**Single Feed:**
- Creator showcase content (posts, products, service promos)
- Buyer-posted project requests from the community
- "Post a Project" CTA pinned at the top of the feed (always accessible)
- Trending creators, featured products
- Sorted by: relevance, followed creators, trending

---

## 6. Feature Hub Structure

Each hub is a dedicated sub-app with its own internal navigation. Hub entry points appear as cards/shortcuts on the home feed or in the Explore section — not as raw nav items.

### Hub Map

```
NeuralMart
├── Creator Hub
│   ├── Dashboard (earnings, orders, stats)
│   ├── My Products (digital product listings)
│   ├── My Services (service packages)
│   ├── My Posts (showcase content management)
│   └── Analytics (views, conversions, earnings)
│
├── Project Hub
│   ├── Browse Projects (buyer-posted needs)
│   ├── My Proposals (bids submitted)
│   ├── Active Projects (ongoing work)
│   └── Completed Projects (history)
│
├── Contest Hub
│   ├── Browse Contests
│   ├── My Submissions
│   ├── Active Contests (I'm running — buyer side)
│   └── Completed Contests
│
├── Marketplace Hub
│   ├── Browse Digital Products
│   ├── Browse Services
│   ├── Categories
│   └── My Purchases
│
├── Chat Hub (Messages)
│   ├── Inbox
│   ├── Active Orders (in chat)
│   └── Archived
│
└── Financial Hub (in Menu)
    ├── Wallet / Balance
    ├── Add Funds
    ├── Withdraw
    ├── Transaction History
    ├── Revenue Analytics
    └── Bid Credits
```

---

## 7. Creator Ecosystem Architecture

### Creator Profile (Public-Facing)
- Social-style profile header: avatar, cover photo, bio, location, member since
- Creator stats: total sales, rating, response time, completion rate, followers
- **Badge display** (prominent, near name)
- Content tabs: Posts | Products | Services | Reviews
- Follow button, Message button, "Hire Me" shortcut
- Portfolio grid (pinned best work)

### Creator Dashboard (Private)
- Revenue overview: today, week, month, lifetime
- Active orders count + quick-action cards
- Pending reviews/disputes
- Profile completion score
- Quick post / quick list shortcuts
- Notifications panel

### Creator Content Tools
- Post composer: image, video, reel, text, product tag, service tag
- Digital product listing: title, description, files, pricing, preview image, category
- Service package listing: Basic / Standard / Premium tiers, delivery time, revisions
- Promotion tools (V2): featured listing, boost post

### Creator Badge System (See Section 12 for full spec)
Badges are earned by activity milestones and displayed on profiles, in search results, and on dashboard.

---

## 8. Buyer / Audience Ecosystem Architecture

### Buyer Profile (Public-Facing)
- Avatar, name, member since, country
- "Verified Buyer" badge (if verified)
- Review history (reviews left for creators/freelancers)
- Posted projects (public or anonymous)

### Buyer Dashboard (Contextual — inside Menu)
- Active projects
- Contest management
- Purchase history
- Spend analytics

### Buyer Flow: Purchasing a Digital Product
1. Browse/Search → Product Page → Preview → Add to Cart / Buy Now
2. Payment → Instant file delivery (download link) OR via chat unlock

### Buyer Flow: Hiring a Freelancer
1. Post a project OR browse creators/services
2. Review proposals → shortlist
3. Accept proposal → milestone creation → active project
4. Milestone delivery → review → release payment
5. Leave review

### Buyer Flow: Running a Contest
1. Post contest (brief, budget, category, deadline)
2. Receive submissions from creators
3. Review + shortlist + select winner
4. Release prize payment
5. Optional: purchase runner-up work

---

## 9. Freelancing / Project / Contest Architecture

### Project Post (Buyer-Created)
Fields: title, description, category, budget (fixed or range), deadline, attachment, visibility (public/invite-only)

### Proposal / Bid (Creator/Freelancer-Submitted)
Fields: cover letter, proposed price, delivery timeline, portfolio samples, questions for buyer

### Project Lifecycle States
```
Posted → Accepting Bids → Proposal Accepted → In Progress → Delivered → Revision → Completed → Closed
```

### Milestone System
- Projects can be split into milestones
- Each milestone: description, amount, due date
- Buyer releases milestone payment when satisfied
- Escrow holds funds until release or dispute

### Contest Architecture
- Contest post: title, brief, category, prize amount, deadline, max submissions per user
- Submission: file upload + description + creator ID
- Status: Open → Judging → Winner Selected → Closed
- Prize: held in escrow, released to winner
- Non-winning submissions: buyer can purchase individually (optional)

### Dispute System (Freelancing + Contests)
- Either party can raise a dispute on any active order/project
- Dispute states: Filed → Under Review → Resolved (auto or admin)
- Admin mediation available for escalated cases

---

## 10. Chat-Commerce Architecture

### Message Thread Types
- **Buyer ↔ Creator** (discovery, negotiation, hiring)
- **Buyer ↔ Freelancer** (project discussion, delivery, revisions)
- **System Messages** (order updates, payment confirmations, file unlocks)

### Chat Features (MVP)
- Text messaging with read receipts
- File attachment (images, docs, zip, video preview)
- Order card inside chat (milestone status, price, deadline)
- **Payment request** (creator sends payment link inside chat)
- **File unlock flow:** Creator locks a delivered file → buyer pays → file unlocks

### Chat-Commerce Flow (File Delivery + Unlock)
```
Creator uploads file → Marks as "Paid Delivery" → Sets unlock price →
Buyer receives locked file preview → Pays inside chat → File unlocks & downloads
```

### Chat Security
- End-to-end message encryption (V2 priority)
- No sharing of external contact info (email/phone) — platform policy enforced
- Automated scanning for off-platform solicitation

### Chat-Commerce Escrow Integration
- Payment requests in chat tie to the escrow system
- Funds held until delivery confirmed or dispute resolved

---

## 11. Financial / Account / Settings Architecture

### Menu Page (Facebook-Style Control Center)

**Financial Section:**
- Wallet Balance (current available + pending)
- Add Funds (card, bank transfer, crypto — V2)
- Withdraw Funds (bank transfer, PayPal, Payoneer)
- Transaction History (filterable by date, type, amount)
- Revenue Analytics (creator earnings breakdown)
- Payment Sharing (split earnings with collaborators — V2)
- Bid Credits (purchase and manage bid tokens for proposals)
- Bid Insights (which bids converted, win rate)

**Account Section:**
- Profile Settings (name, avatar, cover, bio, links)
- Security (password, 2FA, active sessions)
- Notifications (granular toggles per event type)
- Privacy Settings
- Identity Verification (KYC for withdrawals)

**Support Section:**
- Help Center (FAQ / Knowledge Base)
- Submit a Ticket
- Live Chat Support (V2)
- Dispute Center

**Legal / Policy Section:**
- Terms of Service
- Privacy Policy
- Cookie Policy
- Creator Policy

**Global Actions:**
- Logout
- Delete Account (with confirmation flow)
- Searchable settings bar (type to find any setting — like Facebook's Menu search)

### Escrow & Payment Flow
```
Buyer adds funds → Funds held in escrow on milestone creation →
Work delivered → Buyer approves → Funds released to creator wallet →
Creator withdraws to external account (platform fee deducted)
```

### Platform Fees (Business Logic)
- Creator/Freelancer service fee: e.g. 10–20% sliding scale based on total earnings
- Digital product fee: flat % per sale
- Contest prize fee: % of prize amount
- Buyer protection fee: optional add-on (V2)

---

## 12. Admin & Moderation Architecture

### Admin Capabilities
- User management: search, view, suspend, ban, verify
- Content moderation: flag review queue, remove posts/listings
- Dispute resolution: view full order/chat history, mediate, force-resolve
- Financial oversight: transaction monitoring, fraud flags, manual payouts
- Contest management: verify prizes, resolve invalid submissions
- Badge management: assign/remove manual badges, adjust thresholds

### Moderation Queue
- Reported content: posts, listings, profiles, messages
- Auto-flagged content (keyword/ML-based — V2)
- Dispute escalations

### Creator Badge System (Full Design)

| Badge | Trigger | Benefit |
|-------|---------|---------|
| **Rising Star** | 1st sale completed | Profile highlight |
| **Verified Creator** | Identity verified + 5 sales | Blue checkmark-style badge |
| **Top Rated** | 4.8+ rating, 20+ orders | Search ranking boost |
| **Power Seller** | $1,000+ total earnings | Featured in marketplace |
| **Elite Creator** | $10,000+ + consistent quality | Elite badge, reduced platform fee |
| **Contest Winner** | Won a public contest | Contest badge on profile |
| **Fast Responder** | Avg response < 1 hour | Trust signal on profile |

Badges appear: on public profiles (near name), in search result cards, on the creator dashboard header.

### Trust & Safety Systems
- Email verification (required at signup)
- Phone verification (required for withdrawals)
- KYC / ID verification (required above withdrawal threshold)
- Anti-spam: bid rate limiting, message rate limiting
- Fraud detection: unusual transaction patterns flagged for review

---

## 13. MVP vs V2 vs Advanced Split

### MVP (Launch-Ready)

**Core:**
- User registration / login (email + Google OAuth)
- Role selection: Creator or Buyer (can enable both)
- Creator Showcase Feed + Buyer Feed
- Creator profile (public) with portfolio, stats, badge display
- Creator dashboard (earnings, orders, quick stats)
- Digital product listings + purchase flow (instant download)
- Service package listings (3 tiers)
- Project posting (buyer) + proposal/bid submission (creator)
- Basic contest posting + submission + winner selection
- Chat system (text + file attachment)
- File unlock flow in chat (payment-gated delivery)
- Wallet system (add funds, view balance, transaction history)
- Withdrawal request flow
- Badge system (Rising Star, Verified Creator, Top Rated)
- Basic admin panel (user management, content flags, dispute queue)
- Notifications (in-app + email)
- Mobile-responsive UI

**Out of MVP:**
- Live chat support
- Boost/promote listings
- Payment sharing / collaborator splits
- E2E message encryption
- Crypto payments
- Advanced analytics
- ML-based content moderation

### V2 (Post-Launch Stabilization)
- Promoted listings + sponsored search
- Advanced creator analytics (traffic sources, conversion funnels)
- Payment sharing (collaborator revenue split)
- Live chat / video call inside platform
- E2E encryption for messages
- Saved searches and smart alerts for buyers
- Elite badge tier + fee reduction logic
- Mobile app (React Native / Expo)

### Advanced / V3
- AI-powered project matching (creators recommended to buyers automatically)
- Creator subscription model (fans subscribe to creator for exclusive content)
- NFT-backed digital product certificates (optional)
- Team accounts / agency management
- White-label platform API
- Crypto payment integration
- International tax handling (VAT, GST, 1099)

---

## 14. Main Risks, Complexity Areas & Architectural Cautions

| Risk | Area | Mitigation |
|------|------|------------|
| **Escrow integrity** | Financial | Use auditable state machine for every payment state; never mutate payment state directly |
| **Dispute abuse** | Trust | Rate-limit dispute creation; require evidence upload; admin mediation SLA |
| **Off-platform solicitation** | Chat | Automated keyword scanning + user reporting |
| **Feature creep on home feed** | UX | Enforce the "home = entry points only" rule in design reviews |
| **Chat-commerce complexity** | Payments | File unlock flow must be atomic — file access only confirmed after payment confirmation webhook |
| **Role confusion** | UX | Clear role-context switches; dashboard always shows current active role |
| **Bid credit abuse** | Freelancing | Rate-limit bids per user per day; track bid quality over time |
| **Search & discovery quality** | Marketplace | Plan search architecture early (Elasticsearch or similar) — keyword search alone is insufficient at scale |
| **Mobile performance** | UX | Feed virtualization required early; large image uploads must be compressed client-side |
| **Badge gaming** | Trust | Badge criteria must be server-verified, not self-reported; audit trail required |
| **Multi-currency / payout complexity** | Financial | Scope to 1–2 payout methods in MVP; add more in V2 |

---

## 15. Recommended Build Order

### Phase 1 — Foundation (Weeks 1–4)
1. Auth system (email + Google OAuth, role selection)
2. User profiles (creator public profile + buyer profile)
3. Database schema: users, roles, products, services, projects, orders, messages
4. API server with route structure
5. Basic navigation shell (home, explore, messages, menu)

### Phase 2 — Creator Core (Weeks 5–8)
6. Creator dashboard
7. Digital product listing + upload
8. Service package listing
9. Creator Showcase Feed (post composer, feed rendering)
10. Creator badge system (basic tiers)

### Phase 3 — Marketplace & Buyer Flow (Weeks 9–12)
11. Product browse + purchase flow
12. Service hire flow
13. Project post (buyer) + proposal/bid (creator)
14. Basic escrow + milestone payment logic

### Phase 4 — Chat-Commerce (Weeks 13–16)
15. Chat system (text + file)
16. Payment request in chat
17. File unlock flow (locked file → pay → unlock)
18. Order card in chat thread

### Phase 5 — Contests + Financial Center (Weeks 17–20)
19. Contest posting + submission flow
20. Winner selection + prize release
21. Wallet: add funds, withdraw, transaction history
22. Bid credits system
23. Menu page (full financial + settings control center)

### Phase 6 — Admin + Polish (Weeks 21–24)
24. Admin panel (users, content, disputes)
25. Notification system (in-app + email)
26. Search & discovery (Explore page)
27. Mobile optimization pass
28. Performance audit + load testing
29. Security audit (auth, payments, file delivery)
30. Beta launch prep

---

*Document prepared for NeuralMart platform planning. This architecture is intentionally structured for phased delivery — MVP first, with clear V2 and V3 expansion paths. Each section is designed to be handed to a build team as-is.*
