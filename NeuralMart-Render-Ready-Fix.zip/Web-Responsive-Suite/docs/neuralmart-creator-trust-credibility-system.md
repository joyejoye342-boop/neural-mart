# NeuralMart — Creator Profile Trust & Credibility System

**Document version:** 1.0  
**Scope:** Public trust signals, private dashboard metrics, placement, eligibility, and visual hierarchy for creator profiles.

---

## 0. Trust System Goal

The creator profile must feel trustworthy without looking like a scorecard or an admin report.

Trust should answer four buyer questions:

1. Is this a real and accountable person?
2. Can they produce this quality of work?
3. Do they deliver reliably?
4. Are other buyers satisfied?

The system therefore separates evidence into four groups:

```text
Identity
→ Quality
→ Reliability
→ Marketplace history
```

No signal is shown publicly unless it is verified, understandable, and useful to a buyer's decision.

---

## 1. Public Trust Signals

### 1.1 Identity and verification

Public:

- Verified creator badge
- Display name and category
- Member-since date
- Optional approximate location/timezone
- Public portfolio links
- Creator capability label

Private/dashboard:

- Verification method
- Legal identity data
- Payout verification details
- Identity documents
- Risk flags

The public badge should explain itself on tap:

```text
Verified creator
NeuralMart confirmed this creator's account information.
```

Do not imply that identity verification guarantees quality or transaction safety.

### 1.2 Quality proof

Public:

- Featured work
- Showcase posts
- Case studies
- Product/service samples
- Verified rating
- Review count
- Relevant badges

Private/dashboard:

- Content impressions
- Saves
- Engagement rate
- Click-through rate
- Conversion by post
- Profile-to-order funnel

Public work is the strongest quality signal. Do not cover it with too many numeric badges.

### 1.3 Reliability proof

Public:

- Response time
- Completion rate
- Delivery/on-time rate, once meaningful
- Availability state
- Completed order/project count

Private/dashboard:

- Response rate
- Median response time
- Late delivery rate
- Cancellation rate
- Revision frequency
- Repeat-client rate
- Dispute rate

Public labels should be translated into plain language:

```text
Usually responds in under 4 hours
95% on-time delivery
28 completed orders
```

Avoid exposing a misleading percentage when the sample is too small.

### 1.4 Marketplace history

Public:

- Completed orders
- Completed projects
- Sales count
- Contest wins/finalist achievements
- Repeat buyer signal, only when statistically meaningful
- Earned creator badges

Private/dashboard:

- Total earnings
- Gross/net revenue
- Buyer identity and client list
- Exact repeat-buyer rate
- Proposal views and win rate
- Revenue per service/product
- Refund/dispute details

Never expose private earnings, private client names, or buyer purchase history by default.

---

## 2. Signal Placement

### Header: immediate trust

Show no more than four compact signals:

```text
✓ Verified creator
Available
4.9 ★ · 42 reviews
Responds in < 4h
```

The header should prioritize identity, availability, rating, and response expectation.

### Overview: decision support

Use two compact blocks:

```text
CREDIBILITY
4.9 ★ · 42 verified reviews
28 completed orders · 95% on-time

TRACK RECORD
3 contest wins · 12 repeat clients
Top Seller badge
```

Only include a Track Record block when there are enough achievements to make it useful.

### Services and Products

Trust signals appear close to the action:

- service card: rating, reviews, delivery time, completed orders;
- product card: sales count, rating, ownership state;
- service detail: package-specific reviews and delivery expectations;
- product detail: purchase/review history and creator summary.

### Reviews tab

Reviews receive the most detail because the user has selected a trust-specific destination:

- overall rating;
- count;
- distribution;
- verified review list;
- context of the completed order/project;
- creator responses.

### Showcase

Keep trust light:

- creator identity in the compact header;
- optional verified badge;
- no large rating overlay on artwork;
- linked service/product trust appears in the attachment card.

### Badges

Show a maximum of three badges in the header or Overview preview. `View all badges` opens a compact modal or inline expansion, not another top-level tab.

Each badge needs:

- name;
- earned state;
- one-line meaning;
- earned date or progress context where useful.

Do not use decorative badges that resemble verification.

---

## 3. Public vs Dashboard Visibility

| Signal | Public profile | Creator dashboard | Rule |
|---|:---:|:---:|---|
| Verified creator | Yes | Yes | Show only after verification |
| Rating | Yes | Yes | Display `No reviews yet` before meaningful rating |
| Review count | Yes | Yes | Link to verified review list |
| Response time | Yes | Yes | Use measured recent data |
| Response rate | Usually summarized | Yes | Public only as a plain-language tier |
| Delivery/on-time rate | Yes when meaningful | Yes | Require sufficient completed work |
| Completion rate | Yes when meaningful | Yes | Never show misleading small-sample precision |
| Cancellation rate | No by default | Yes | Explain privately for improvement |
| Dispute rate | No | Yes | Sensitive business metric |
| Repeat buyers | Summary only | Exact metric | Public label only after threshold |
| Sales count | Yes | Yes | Public count, private revenue |
| Total earnings | No | Yes | Always private |
| Profile views | No | Yes | Private analytics |
| Follower count | Yes | Yes | Social proof, not quality proof |
| Contest wins | Yes | Yes | Show verified wins/finalists |
| Proposal win rate | No | Yes | Competitive business data |
| Badge progress | Earned badges only | Full progress | Do not expose unfinished private goals |
| Activity status | Available/paused | Full schedule | Avoid fake “online” pressure |

---

## 4. Trust Signal Eligibility

### Minimum sample rules

Do not display precise operational percentages until the creator has enough completed activity. Before that, use:

- `New creator`
- `Building a track record`
- `No reviews yet`
- `Availability not yet established`

The exact thresholds can be configured, but the product should avoid showing precise performance from one or two orders.

### Recency rules

- Response time: calculate from a recent rolling window.
- Availability: expire automatically.
- Rating: update after verified reviews are accepted.
- Delivery stats: use completed eligible orders only.
- Contest wins: only display finalized results.
- Sales count: update after successful transactions are settled.

### Verification rules

Every public trust signal must have a source:

```text
verified identity
completed order
verified review
measured response
settled transaction
final contest result
```

Do not allow creators to self-enter claims such as `100% success` or `Top 1%` as public trust facts.

---

## 5. Activity Indicators

Activity indicators should communicate availability without creating unhealthy pressure.

Public:

- `Available for work`
- `Not currently accepting new work`
- `Usually responds in under 4 hours`
- `Active recently`, only if the user has opted in

Private:

- online status;
- exact last active time;
- workload/capacity;
- response backlog;
- pending orders.

The public profile should never expose exact activity timestamps, active client conversations, or current workload details.

---

## 6. Trust Hierarchy by Profile Type

### Creator-only

Prioritize:

1. Showcase quality
2. Service/product reviews
3. Sales/completed order count
4. Creator badges
5. Response and delivery signals

### Freelancer-heavy

Prioritize:

1. Availability
2. Case studies
3. Completed projects
4. Response time
5. On-time delivery
6. Project reviews

### Hybrid Creator/Freelancer

Prioritize:

1. Featured work
2. Primary service
3. Availability
4. Rating/reviews
5. Product sales
6. Project and contest track record

The trust block changes emphasis, not visual structure.

---

## 7. Keeping Trust Calm and Understandable

1. Show four or fewer signals in the header.
2. Use plain-language labels instead of raw internal metrics.
3. Put detailed evidence in Reviews, About, or dashboard pages.
4. Never show private earnings or dispute data publicly.
5. Avoid duplicate rating displays in every section.
6. Keep badges secondary to work and verified reviews.
7. Prefer `28 completed orders` over a wall of percentage cards.
8. Use tooltips or detail drawers to explain verification and calculations.
9. Label small-sample states honestly.
10. Let the work remain visually dominant.

### Recommended header

```text
✓ Verified creator · Available
4.9 ★ 42 verified reviews
28 completed orders
Usually responds in under 4 hours
```

This is enough for an initial trust judgment. The buyer can open Reviews or About for evidence.

---

## 8. Dashboard Trust Surface

The Creator Dashboard may show deeper metrics:

- rating trend;
- review themes;
- response rate;
- median response time;
- on-time delivery;
- completion/cancellation rate;
- repeat buyer percentage;
- proposal win rate;
- contest performance;
- badge progress;
- profile-to-order conversion.

These belong in `Reputation` and `Insights`, not the public profile. The dashboard should frame them as tools for improvement rather than permanent public labels.

---

## 9. Safety and Integrity

- Do not allow review manipulation or incentivized undisclosed reviews.
- Link public reviews to verified orders/projects.
- Detect suspicious rating spikes for moderation review.
- Let users report a review, badge, or public claim.
- Remove or mute trust signals when the underlying account is suspended.
- Preserve historical order evidence even if a listing is later paused.
- Keep public badges and verification visually distinct.

## Final rule

Public trust is a compact summary of verified evidence. The profile shows enough to reduce buyer uncertainty; the dashboard shows enough to help the creator improve. Neither should become a wall of numbers.
