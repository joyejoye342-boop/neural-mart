# NeuralMart — Service / Gig Marketplace System

**Document version:** 1.0  
**Audience:** Creators, freelancers, Buyers, and Both users  
**Primary surfaces:** Service marketplace · Creator profile · Showcase Feed · Service detail · Orders

---

## 0. Service Definition

A service is a creator's fixed-price or scoped offer to perform work for a buyer under defined deliverables, turnaround, revisions, and requirements.

Services sit between digital products and custom projects:

| Product | Service | Project bid |
|---|---|---|
| Pre-made asset | Predefined creator work | Custom buyer brief |
| Instant delivery | Fulfilled delivery | Proposal before selection |
| Fixed license/price | Package or scoped price | Negotiated offer |
| No custom work by default | Defined custom work | Scope determined after selection |

Services should make buying predictable while still allowing a creator's expertise and portfolio to matter.

---

## 1. Service Structure

### Service identity

- Service title
- Outcome statement
- Category
- Tags/skills
- Description
- Preview media
- Creator identity/trust
- Packages
- Requirements
- FAQ
- Availability/capacity
- Status

### Service title pattern

Prefer:

```text
I will create a clean brand identity for your startup
```

Avoid vague titles such as:

```text
Design services
```

### Service description

The creator should explain:

- what problem the service solves;
- what is included;
- what is not included;
- who it is for;
- what the buyer needs to provide;
- what happens after purchase.

---

## 2. Service Packages

### MVP package model

Support one required Basic package and optional Standard/Premium packages.

| Package | Purpose |
|---|---|
| Basic | Small, clearly bounded outcome |
| Standard | Most common buyer need |
| Premium | Expanded scope, depth, or support |

Each package includes:

- Package name
- Price
- Description
- Deliverables
- Delivery time
- Revision count
- Requirements
- Source-file status
- Usage/license status

### Example

```text
BASIC
Social logo kit
$80 · 3 days · 1 revision

STANDARD
Complete logo system
$180 · 6 days · 2 revisions

PREMIUM
Logo + mini brand guide
$350 · 10 days · 3 revisions
```

### Add-ons

Advanced:

- Extra revision
- Rush delivery
- Additional format
- Source file
- Extra concept
- Commercial license
- Additional page/asset

Add-ons must not be used to hide required core deliverables.

---

## 3. Scoped Services and Custom Quotes

When a buyer's need does not fit a package:

```text
Request custom scope
→ Describe need
→ Attach references
→ Creator responds with quote
→ Buyer approves
→ Service order starts
```

Custom quote fields:

- Scope
- Deliverables
- Price
- Timeline
- Revisions
- Milestones
- Usage rights
- Expiration date

This is a scoped service order, not an open project bid. The buyer is responding to a specific creator's service rather than broadcasting a brief to the marketplace.

---

## 4. Turnaround and Revision Logic

### Turnaround

Each package defines:

- delivery time in business or calendar days;
- creator timezone;
- earliest start/queue state;
- buyer requirement dependency;
- rush availability, if supported.

The order clock starts when:

1. payment/authorization succeeds;
2. buyer submits all required information;
3. creator accepts or the package is auto-confirmed.

The buyer sees:

```text
Expected delivery: Apr 18
Starts after required information is received
```

### Revisions

Revisions are defined per package:

- number of rounds;
- what qualifies as a revision;
- response time;
- included file/format changes;
- out-of-scope work.

A revision means changing the agreed deliverable, not adding a new deliverable.

### Revision flow

```text
Creator delivers
→ Buyer reviews
→ Buyer accepts
or
→ Buyer requests revision within included scope
→ Creator updates
→ Buyer accepts
```

If the buyer asks for new work:

```text
Create add-on or custom quote
```

Do not allow unlimited “small changes” to become hidden scope expansion.

---

## 5. Portfolio Proof Integration

Every service should connect to proof:

- three relevant Showcase posts;
- one case study;
- related product;
- completed order/review summary;
- creator level and reliability evidence.

### Proof selection

Creators choose proof during service creation:

```text
Add relevant work
→ Select Showcase items
→ Add relevance note
→ Reorder
```

Example:

```text
Brand system for climate-tech startup
Relevant because it included web, pitch deck, and social assets.
```

### Buyer experience

On service detail:

- show proof below the package summary;
- allow `View all Showcase work`;
- keep private client information hidden;
- distinguish sample work from verified order history.

---

## 6. Service Appearance

### Feed

Service cards appear as commercial cards in the Showcase Feed:

```text
[Service] Brand identity for startups
Starting at $180 · 6 days · 2 revisions
4.9 ★ · 24 completed orders
[View service]
```

Primary CTA:

- `View service` from discovery;
- `Book now` when the package is sufficiently clear.

### Public profile

Services appear in:

- Profile → Services;
- Overview featured offer;
- service showcase posts;
- creator Showcase filters where linked.

### Search

Search results show:

- service title;
- creator;
- starting price;
- delivery time;
- rating/reviews;
- creator level;
- one relevant badge;
- category/skills.

Search ranking:

```text
Query/category fit
→ Availability
→ Quality/reviews
→ Delivery confidence
→ Price relevance
→ Badge/trust evidence
```

### Market hub

The Services marketplace is filter-first and package-oriented:

- category;
- price;
- delivery;
- rating;
- creator level;
- package type;
- availability;
- language/timezone.

It is separate from the social feed but linked from it.

---

## 7. Service Detail Page

```text
Service header
→ Creator trust summary
→ Preview media
→ Description and outcome
→ Package selector
→ Deliverables and exclusions
→ Requirements
→ Portfolio proof
→ Reviews
→ FAQ
→ Sticky order box
```

### Sticky order box

Shows:

- selected package;
- price;
- delivery;
- revisions;
- included deliverables;
- `Continue`;
- `Contact creator`;
- secure payment/escrow explanation.

Do not hide package differences behind a generic `Buy` button.

---

## 8. Service Order Flow

```text
Choose service
→ Choose package
→ Add-ons, optional
→ Provide requirements
→ Confirm scope, price, delivery, and license
→ Secure payment/authorization
→ Order created
→ Creator accepts or starts fulfillment
→ Delivery
→ Revision or approval
→ Completion
→ Review and repeat order
```

### Buyer requirements

The creator defines required inputs:

- copy/text;
- logo/brand assets;
- dimensions;
- examples;
- access or permissions;
- destination format;
- preferred style;
- deadline constraints.

The buyer sees missing requirements before payment or immediately after purchase, depending on the package.

### Order states

```text
Pending requirements
→ Awaiting creator acceptance
→ In progress
→ Delivered
→ Revision requested
→ Approved
→ Completed
```

Alternative states:

- Paused
- Late
- Cancelled
- Disputed
- Refunded

### Delivery

Creators deliver through the order workspace:

- files;
- links;
- message;
- delivery note;
- version number.

The buyer can download, approve, or request an included revision.

### Completion and reviews

Completion occurs when:

- buyer approves;
- buyer does not respond within the defined review period;
- dispute/refund state is resolved.

Only completed/settled orders create verified service reviews and completed-order trust signals.

---

## 9. Service Management Tools

Creator Dashboard → Services:

```text
Active
Drafts
Needs changes
Paused
Out of capacity
Archived
```

Each service row shows:

- title;
- package count;
- starting price;
- active orders;
- sales;
- rating;
- views;
- bookings;
- conversion;
- last updated.

### Creator actions

- Create/edit service
- Add/remove package
- Change price for future buyers
- Define availability/capacity
- Add proof
- Add FAQ
- Pause orders
- Mark out of capacity
- Archive
- Duplicate as draft
- View service analytics
- Respond to reviews

### High-risk changes

Require explicit confirmation:

- removing a package with active orders;
- changing included deliverables;
- reducing revisions;
- changing usage rights;
- increasing price;
- pausing an active service;
- changing delivery time.

Active orders preserve the terms purchased at checkout.

---

## 10. Product, Service, and Project Boundaries

### Digital product

Use when the buyer wants:

- an existing asset;
- immediate access;
- a fixed license;
- no custom creator fulfillment.

CTA: `Buy now`.

### Service

Use when the buyer wants:

- defined creator work;
- predictable package scope;
- delivery and revisions;
- a direct relationship with one creator.

CTA: `Book service`.

### Project bidding

Use when the buyer wants:

- custom scope;
- multiple creator offers;
- price/timeline comparison;
- open or invite-based proposals.

CTA: `Post project` / `Send proposal`.

### Contest

Use when the buyer wants:

- multiple creative entries;
- fixed prize;
- published judging rules;
- selection from submitted concepts.

CTA: `Host contest` / `Submit entry`.

Do not force a buyer into a project bid when a clearly packaged service is sufficient. Do not use a service page to hide a highly custom brief.

---

## 11. Service Analytics

Per-service metrics:

- Impressions
- Service page views
- Package selection
- Requirement-start rate
- Checkout-start rate
- Orders
- Conversion rate
- Average order value
- Delivery time
- Revision frequency
- Repeat buyers
- Revenue
- Refund/dispute rate

The service can connect to the Creator Analytics funnel:

```text
Showcase impression
→ Service view
→ Package selection
→ Order
→ Completion
→ Repeat order
```

## Final rule

A service listing should make the buyer confident about exactly what happens after purchase: what they receive, what they must provide, when delivery happens, how revisions work, and how the creator's proof supports the promise.
