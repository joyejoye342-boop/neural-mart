# NeuralMart — Buyer Project Management Hub

**Document version:** 1.0  
**Primary route:** `/dashboard/buyer/projects`  
**Audience:** Buyer and Both accounts

---

## 0. Hub Definition

The Project Management Hub is where buyers manage hiring intent after publishing:

- posted projects;
- active requests;
- proposal review;
- shortlisted creators;
- project-related conversations;
- contest entries;
- purchased services/products connected to a project need.

It is not the discovery Project Board. The Project Board helps creators find work; this hub helps buyers operate their own work pipeline.

---

## 1. Hub Structure

```text
PROJECTS
├── Overview
├── My projects
│   ├── Drafts
│   ├── Open
│   ├── Reviewing
│   ├── In progress
│   └── Closed
├── Contest activity
│   ├── Hosted contests
│   ├── Judging
│   └── Completed
├── Shortlisted creators
├── Project conversations
├── Related purchases
└── Archived
```

### Desktop layout

```text
┌─────────────────────────────────────────────────────────┐
│ Projects                         [Post a project]        │
│ Manage hiring, proposals, and active creator work       │
├─────────────────────────────────────────────────────────┤
│ [Needs attention] [Open] [In progress] [Closed]         │
├───────────────────────┬─────────────────────────────────┤
│ Project list           │ Selected project overview       │
│                       │ proposals · shortlist · chat    │
└───────────────────────┴─────────────────────────────────┘
```

### Mobile layout

- Summary counts at top.
- Full-width project cards.
- Tabs/filters in a horizontal row.
- Project detail opens as a dedicated route, not a nested scroll panel.
- Proposal comparison opens in a sheet or separate page.

---

## 2. Project Statuses

### Direct project

```text
Draft
→ Open
→ Reviewing proposals
→ Shortlisted
→ Creator selected
→ In progress
→ Awaiting delivery
→ Revision requested
→ Completed
→ Closed
```

Alternative states:

- Paused
- Cancelled
- Disputed
- Expired

### Contest

```text
Draft
→ Open for entries
→ Judging
→ Winner selected
→ Prize processing
→ Completed
```

Alternative states:

- Cancelled
- Prize issue
- Disputed

### Status display

Every project card shows:

- status;
- next action;
- deadline;
- proposal/entry count;
- budget/prize;
- unread project chat indicator.

Avoid showing only a color-coded status. Use text such as `Reviewing proposals` or `Awaiting delivery`.

---

## 3. Overview and Needs Attention

```text
PROJECTS OVERVIEW
Open requests        3
Proposals to review  8
Active engagements   2
Contests judging     1

NEEDS ATTENTION
Review 4 new proposals
Choose a winner for your contest
Approve delivered brand assets
Reply to shortlisted creator
```

Only actionable work belongs in Needs Attention. Historical completed projects belong in Closed.

### Project card

```text
Brand identity for startup
Reviewing proposals · Due Apr 28
$800–$2,500 · 12 proposals
4 shortlisted · 2 unread chats
[Review proposals]
```

---

## 4. Proposal Review and Shortlisting

### Review list

Each proposal shows:

- creator identity and level;
- relevant badges;
- rating/reviews;
- estimated price;
- delivery estimate;
- proposal message;
- relevant work samples;
- response time;
- any questions answered.

### Actions

- Shortlist
- Remove from shortlist
- Message
- Compare
- Request clarification
- Invite to project
- Decline
- Select creator

### Shortlist view

```text
SHORTLISTED CREATORS
[Maya] 4.9 ★ · $1,200 · 7 days   [Message]
[Alex] 4.8 ★ · $900 · 10 days    [Compare]
```

Shortlist is private to the buyer and does not notify creators when a proposal is removed unless product policy requires it.

### Comparison rules

Compare only decision-relevant fields:

- relevant skills;
- work samples;
- price;
- delivery;
- rating/reviews;
- response signal;
- proposal fit.

Do not create a spreadsheet-like comparison of every profile metric.

---

## 5. Selection and Project Start

```text
Review proposal
→ Message or request clarification
→ Select creator
→ Confirm scope, budget, and delivery
→ Fund/authorize payment when required
→ Project becomes In progress
```

Before selection, confirm:

- selected creator;
- agreed budget;
- deliverables;
- target deadline;
- revision expectations;
- payment/escrow state;
- ownership/licensing terms.

The system should warn if the selection differs materially from the public project budget or scope.

---

## 6. Contest Management

### Hosted contest view

Show:

- prize and funding status;
- deadline;
- entry count;
- judging state;
- entries needing review;
- winner selection;
- prize processing.

### Entry review

Buyer actions:

- view entry;
- shortlist/favorite;
- add private note;
- compare finalists;
- request clarification if allowed by rules;
- select winner;
- mark runner-up;
- report entry.

Entries should remain private or public according to the contest rules. A buyer's private notes never appear to creators.

---

## 7. Project Conversations

The hub shows project-related conversations as a filtered view of Messages:

```text
PROJECT CHATS
Brand identity · Maya Johnson · 2 unread
Product launch video · Alex Rivera · Awaiting reply
```

Actions:

- Open chat
- View linked project
- View linked order/payment request
- Archive conversation

Do not create a second messaging system. Project conversations remain connected to the existing conversation model.

---

## 8. Related Purchases

Buyers may purchase products or services while planning a project. Show these in a separate `Related purchases` module:

- product/service;
- creator;
- order status;
- delivery/download state;
- link to project if manually associated.

Do not merge purchased products into the project lifecycle. A purchased template can support a project without becoming part of its proposal status.

---

## 9. Active vs Closed Views

### Active

Includes:

- Open
- Reviewing proposals
- Shortlisted
- In progress
- Awaiting delivery
- Judging

Sorted by:

1. Needs action
2. Deadline
3. Financial/work impact

### Closed

Includes:

- Completed
- Closed
- Cancelled
- Expired

Supports:

- search;
- date filter;
- category;
- creator;
- contest/project type;
- reopen support/dispute flow where policy allows.

Closed items are read-only except for review, receipt, dispute, and support actions.

---

## 10. Both User Behavior

Both users see this hub under their Buying view. Their Creator Dashboard remains separate under Selling view.

The same person can:

- manage a project as Buyer;
- respond to a project as Creator;
- purchase a product related to the project;
- review the final work;

The interface uses the context label `Buying view` rather than creating two separate accounts.

## Final rule

The Buyer Project Hub should feel like a calm hiring pipeline: every active project has one clear status, one next action, and one place to review creators and related communication.
