# NeuralMart — Project Bidding / Proposal System

**Document version:** 1.0  
**Audience:** Creators, freelancers, Buyers, and Both users  
**Primary surfaces:** Opportunity Feed · Project detail · Creator Dashboard · Buyer Project Hub

---

## 0. Proposal Definition

A proposal is a creator's structured offer to complete a buyer's direct project.

It answers:

1. What will the creator deliver?
2. How much will it cost?
3. When can it be completed?
4. Why is this creator a good fit?
5. What evidence supports the offer?

Proposals are different from contest entries:

| Proposal | Contest entry |
|---|---|
| Response to a buyer project | Response to published contest rules |
| Creator offers price and timeline | Host offers a fixed prize |
| Buyer can negotiate before selection | Winner is selected under contest criteria |
| One creator is usually selected | One or multiple entries may win |
| Pitch and scope are central | Concept and submission are central |

---

## 1. Project Types That Support Bidding

### Supports proposals

1. **Fixed-scope project**
   - Buyer defines deliverables and budget range.
   - Creator proposes price and delivery.

2. **Open-budget project**
   - Buyer requests offers.
   - Creator proposes price with a clear scope assumption.

3. **Hiring request**
   - Lightweight or urgent request.
   - Creator can send a short proposal or express interest.

4. **Ongoing/retainer project**
   - Creator proposes recurring price, availability, and cadence.
   - Advanced feature.

5. **Invite-only project**
   - Buyer invites selected creators to submit proposals.

6. **Milestone project**
   - Creator proposes staged deliverables and payments.
   - Advanced feature.

### Does not support proposals

- Contests use entries, not bids.
- Digital products use purchase/ownership flow.
- Standard services use booking/order flow.
- Unpaid collaborations use `Express interest`, not a paid bid.

Paid collaborations may use a simplified proposal with compensation and scope.

---

## 2. Proposal Structure

### Proposal header

```text
Maya Johnson · Top Rated Creator
Proposed: $1,200 · 7 days
Available to start Apr 12
```

### Required fields

- Proposed total price
- Currency
- Delivery timeline
- Short pitch/cover letter
- Confirmation that the creator understands the brief

### Recommended fields

- Deliverables included
- Scope assumptions
- Milestones
- Revision count
- Start date/availability
- Relevant samples
- Questions for buyer

### Advanced fields

- Alternate pricing options
- Hourly or recurring rate
- Milestone payment schedule
- Dependencies
- Out-of-scope items
- Usage/licensing assumptions
- Team members or subcontractors

### Proposal anatomy

```text
WHY I’M A FIT
Short, specific pitch connected to the brief.

WHAT I’LL DELIVER
1. Brand direction
2. Final logo system
3. Social avatar exports

PRICE AND TIMELINE
$1,200 · 7 days · 2 revision rounds

APPROACH
Brief description of process and first milestone.

RELEVANT WORK
[Showcase sample] [Service] [Case study]

QUESTIONS
One clarification needed about the launch date.
```

The form should guide specificity without forcing a long essay.

---

## 3. Price and Timeline Logic

### Price modes

#### Fixed total

```text
Total: $1,200
```

Best for defined deliverables.

#### Range response

```text
Estimated range: $1,000–$1,400
```

Requires scope assumptions and a final confirmation before selection.

#### Milestone pricing

```text
Discovery       $250
First concept   $400
Final delivery  $550
Total           $1,200
```

#### Recurring pricing

Advanced:

```text
$800 / month · 20 hours · cancel with 14 days notice
```

### Price rules

- Show proposed price next to the buyer's budget.
- Do not penalize a creator automatically for being above or below range.
- Require a note when the proposal falls outside the stated range.
- Display whether platform fees are included.
- Preserve the original proposal amount in history.
- Changes after selection require buyer confirmation and a new order/project agreement.

### Timeline fields

- Earliest start date
- Estimated delivery date or number of days
- Milestone dates, when relevant
- Buyer dependencies
- Revision turnaround

The system shows:

```text
7 days delivery
Can start Apr 12
Assumes final copy is provided by Apr 13
```

Avoid converting a creator's working-day estimate into a false calendar guarantee.

---

## 4. Pitch and Cover Letter

The pitch should be brief and project-specific.

Prompt creators with:

- What part of the brief stood out?
- What relevant experience do you have?
- What would you do first?
- What assumption or question should the buyer know?

### Quality guidance

Show a subtle checklist:

```text
✓ Mentions the buyer's actual goal
✓ Explains relevant experience
✓ States a clear first step
○ Add one relevant sample
```

Do not use a public “pitch score.” Recommendations are private to the creator.

### Proposal length

- MVP minimum: 50 characters.
- Suggested range: 100–600 characters.
- Longer proposals are allowed but collapsed in buyer comparison.
- Avoid auto-generated filler or generic repeated text.

---

## 5. Portfolio and Sample Attachments

Creators can attach:

1. Existing Showcase posts
2. Public case studies
3. Products or services
4. External portfolio links
5. New supporting uploads

### Selection flow

```text
Add relevant work
→ Choose from Showcase
→ Optional upload
→ Add one-line relevance note
→ Reorder
```

Example:

```text
[Case study] Fintech onboarding
Relevant because it included a complex mobile flow.
```

### Rules

- Maximum three highlighted samples in MVP.
- Samples remain owned and managed by the creator.
- Private client work requires permission before attachment.
- Buyer sees only the intended preview, not private source files.
- Links are validated and labeled as external.
- A creator can remove a sample without deleting the original Showcase item.

The system should prefer relevant samples over a large portfolio dump.

---

## 6. Proposal Submission and Editing

```text
Review project
→ Start proposal draft
→ Add offer and samples
→ Preview buyer view
→ Submit
```

### Draft behavior

- Autosave.
- Preserve uploaded files and linked samples.
- Show missing fields.
- Allow discard with confirmation.

### After submission

- Creator can withdraw while the project is open, if the buyer has not selected them.
- Editing creates a new proposal version and notifies the buyer.
- Price/timeline changes are explicit.
- Buyer sees current version and version history where helpful.
- A creator cannot submit duplicate active proposals to the same project unless the buyer allows revisions.

### Proposal states

```text
Draft
→ Submitted
→ Viewed
→ Buyer replied
→ Shortlisted
→ Interviewing
→ Accepted
→ Declined
→ Withdrawn
→ Expired
```

---

## 7. Shortlist Logic

Shortlisting is a buyer workflow state, not a public creator rank.

### Buyer actions

- Shortlist
- Remove from shortlist
- Add private note
- Compare
- Message
- Request clarification
- Invite to revise offer
- Accept proposal
- Decline

### Notification rules

- Creator is notified when shortlisted.
- Creator is not notified when removed from a private shortlist unless product policy chooses transparency.
- Buyer can shortlist without starting a chat.
- A shortlist does not reserve the project or guarantee selection.

### Ranking support

The system can suggest proposals using:

```text
Brief fit
→ Relevant samples
→ Price/timeline fit
→ Verified reliability
→ Communication quality
```

Suggested ranking must remain explainable and must not reduce selection to lowest price.

---

## 8. Buyer Comparison Tools

### Comparison view

```text
                 Maya          Alex          Noor
Price            $1,200        $900          $1,450
Delivery         7 days        10 days       6 days
Rating           4.9           4.8           4.7
Relevant work    3 samples     2 samples     3 samples
Revisions        2             1             3
Availability     Apr 12        Apr 15        Apr 10
```

### Comparison controls

- Filter shortlisted only
- Sort by fit, price, delivery, rating, or newest
- Expand pitch
- View relevant samples
- Message creator
- Add private note
- Request clarification
- Select creator

### Buyer scorecard

Optional private scorecard:

- Brief fit
- Relevant experience
- Communication
- Value
- Timeline confidence
- Risk/unknowns

The scorecard supports thinking; it does not create a public score or automatic decision.

---

## 9. Creator Bid Tracking

Add `Proposals` under the Creator Dashboard:

```text
/dashboard/creator/opportunities/proposals
```

### Tabs

```text
Drafts
Submitted
Viewed
Shortlisted
In conversation
Accepted
Declined
Withdrawn
```

### Proposal card

```text
Brand identity for startup
Submitted 2 days ago · Viewed
$1,200 · 7 days
2 relevant samples
Next: buyer may reply
[Open project] [Edit/withdraw]
```

### Creator actions

- Open project
- View proposal
- Edit allowed version
- Withdraw
- Send follow-up message
- Duplicate as a starting draft for another project
- Add private note
- View Bid Insights

Duplicate never copies buyer-private data or submits automatically.

---

## 10. Proposal and Chat Relationship

Chat becomes available when:

- buyer replies to a proposal;
- buyer invites clarification;
- proposal is shortlisted;
- buyer selects the creator;
- creator asks an allowed project question.

The conversation remains linked to:

- project;
- proposal version;
- selected budget/timeline;
- order or milestone agreement after acceptance.

Chat does not silently change the proposal. Any agreed change must be recorded as an explicit proposal/order update.

---

## 11. Relationship to Contest System

Shared infrastructure:

- Opportunities Feed
- Creator profile and badges
- Relevant portfolio attachments
- Saved opportunities
- Linked chat
- Notifications
- Opportunity analytics
- Buyer trust signals

Different behavior:

| Proposal | Contest entry |
|---|---|
| Price is creator-proposed | Prize is host-defined |
| Timeline is creator-proposed | Deadline is contest-defined |
| Pitch explains fit and approach | Concept explains the submission |
| Buyer negotiates/selects | Host judges under published rules |
| Scope can be agreed after selection | Rights and judging must be published before entry |

Contest finalists may receive a paid project invitation, but the invitation is separate from the contest prize. Proposal metrics and contest metrics remain separate in Bid Insights.

## Final rule

A proposal should feel like a clear, respectful offer—not a race to the lowest price. Buyers should compare fit, value, evidence, and reliability, while creators should understand exactly what is being offered and what happens next.
