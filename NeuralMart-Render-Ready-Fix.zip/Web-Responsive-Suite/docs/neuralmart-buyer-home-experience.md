# NeuralMart — Buyer / General Audience Home Experience

**Document version:** 1.0  
**Route:** `/`  
**Audience:** Buyer and Both accounts in buying context

---

## 0. Product Definition

Buyer home is a discovery-first Showcase Feed with a lightweight hiring entry point. It is not a Buyer Dashboard and does not require a separate contest feed.

The buyer should feel:

> **I can discover great creators, understand what they offer, and post a project when I need something made.**

The home experience keeps the same NeuralMart shell, card system, and visual language as Creator home. It changes the feed mix and composer actions, not the product identity.

---

## 1. Buyer Home Structure

```text
BUYER HOME
├── App header
│   ├── Logo
│   ├── Search
│   ├── Notifications
│   ├── Messages
│   └── Menu/three dots
├── Welcome and discovery composer
│   ├── Post a project
│   ├── Browse creators
│   └── Optional quick links
├── Optional new-user discovery gateway
├── Combined Showcase Feed
│   ├── Creator posts
│   ├── Product showcases
│   ├── Service cards
│   ├── Open project cards
│   └── Recommendation blocks
└── Feed continuation and empty states
```

Contests are not a separate buyer home feed. Buyers can host contests from the project-posting entry or the Opportunities area when needed.

---

## 2. Above-the-Fold Experience

```text
┌────────────────────────────────────────────┐
│ NeuralMart                  [search] [•••] │
├────────────────────────────────────────────┤
│ Good morning, Maya                         │
│ Looking for someone to make something great?│
│ [Post a project]                            │
├────────────────────────────────────────────┤
│ QUICK DISCOVERY                             │
│ [Find creators] [Browse services] [Products]│
├────────────────────────────────────────────┤
│ SHOWCASE FEED                               │
│ [creator post]                              │
└────────────────────────────────────────────┘
```

For returning users, the Quick Discovery row becomes thinner or disappears after repeated use. The feed should begin quickly rather than forcing the user through a dashboard header.

---

## 3. How Creator Content Appears

Buyer home uses the shared card system:

- creator post cards;
- reels/videos;
- graphic/thumbnail showcases;
- product cards;
- service cards;
- compact open-project cards;
- recommendation blocks.

### Buyer-facing CTA logic

| Card | Primary action |
|---|---|
| Creator showcase | View creator |
| Reel/graphic | View creator or related service |
| Product | Buy now / View product |
| Service | View service / Book now |
| Open project | View project; no proposal CTA |
| Recommendation | View profile/service/project |

Projects appear as occasional work opportunities in the buyer's own discovery feed, but buyers cannot send proposals. A buyer's own project uses `Manage project`.

### Feed rhythm

Target starting mix:

- 55% creator visual posts
- 20% products
- 10% services
- 15% open project briefs

Do not insert contests into this home feed.

---

## 4. Project-Posting Entry

### Primary entry

The buyer composer is visible near the top:

```text
What are you looking to create?
[Post a project]
```

### Secondary entry points

- Header `Post project` button
- Quick Discovery → `Find a creator`
- Menu → Work Center → My projects
- Orders or saved creators → `Start a project`
- Creator profile → `Hire this creator`

### Project versus contest

`Post a project` opens a choice sheet:

```text
What kind of opportunity do you want to create?

[Direct project]
Receive proposals from selected creators.

[Contest]
Receive multiple entries and award a prize.
```

`Contest` remains a secondary choice so the home remains simple for general buyers.

---

## 5. Buyer Quick Actions

Show only three primary actions:

1. Post a project
2. Find creators
3. Browse services/products

Secondary actions belong in Menu or contextual surfaces:

- View orders
- Add funds
- Payment sharing
- Saved creators
- Manage projects
- Host a contest

Do not put wallet balances, proposal counts, or contest statistics on Buyer home.

---

## 6. Creator and Buyer Home Difference

| Surface | Buyer | Creator |
|---|---|---|
| Default content | Creator work + products/services + projects | Showcase + opportunities |
| Composer | Post a project | Share work/product/service |
| Project CTA | View/manage | Send proposal |
| Contest feed | Not needed for home | Opportunities route |
| Quick action | Post project | Create post/service/product |
| Dashboard | Buyer Dashboard separately | Creator Dashboard separately |

Both users see the same home shell but receive additive actions based on the card and capability. There is no visually separate app.

---

## 7. Discovery and Recommendations

Buyer recommendations may use:

- followed creators;
- categories viewed;
- saved work;
- services/products opened;
- previous purchases;
- project categories;
- creator availability.

Show the reason in one line:

```text
Because you saved 3 branding projects
```

Recommendations should never replace the first organic card or flood the feed with sales listings.

---

## 8. Mobile Behavior

- Single-column feed.
- Project composer is a full-width primary card.
- Quick discovery uses a horizontal scroll row.
- Content cards use stable media ratios.
- `Post a project` can remain sticky as a compact action after scrolling, but only if the original composer is no longer visible.
- No separate contest tab in the buyer bottom navigation.
- Search, Messages, and Menu remain available from the app shell.

## Final rule

Buyer home should feel like browsing a creative community with a clear “I need something made” door—not like managing a procurement dashboard.
