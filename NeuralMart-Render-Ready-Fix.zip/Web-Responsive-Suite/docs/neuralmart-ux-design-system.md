# NeuralMart — UI/UX Design System Strategy

Version 2 — incorporates v2 Feed Architecture (Creator Showcase Feed + Contest Feed).

---

## 0. Product context snapshot

NeuralMart is a social creator marketplace + freelancing platform + chat-commerce system in one. It has two types of primary users (Buyers and Creators, often the same person), two feeds (Showcase and Contest), five feature hubs, one wallet, and one inbox. The design challenge is making that complexity feel like a single, clean product — not a dashboard of six different SaaS tools.

The guiding tension: **business power layered beneath social simplicity.** The goal is that a first-time user feels like they're browsing a beautiful creative feed. The goal is that a power user feels like they have access to a full professional marketplace. Both must be true at the same time on the same screen.

---

## 1. Overall UX Philosophy

**"One surface, total clarity."**

NeuralMart is NOT built around feature completeness. It's built around the question: *what is the user trying to do in the next 30 seconds?* Every design decision flows from that.

Four pillars:

1. **Feed-first, features on demand.** The home screen is a beautiful, browsable feed. No dashboard widgets, no charts, no notifications grid on the landing screen. Complex tools (Wallet, Dashboard, Settings) are one or two taps away but never in the way.

2. **Progressive complexity.** A Buyer's first experience: scroll beautiful creative work, tap one to buy. A Creator's first experience: scroll, get inspired, publish your own work. The marketplace machinery (proposals, tiers, contests, wallet) appears only when the user's intent signals they're ready for it — never as a default view.

3. **Context over configuration.** The app figures out what you need from your role and behavior rather than making you configure views. A Creator lands on Showcase feed. A Buyer gets a composer card to post a project. Nobody configures this — it just works. Optional configuration (context toggle, notification prefs) exists but is never required.

4. **Calm, not blank.** Empty states should teach and invite, not show a spinner and nothing. A new Showcase feed should show trending creator cards as seeds, not a void. An empty Wallet should show what the wallet does and how to fund it.

---

## 2. Navigation Behavior

### 2.1 The five-item rule
The main nav always has exactly **five destinations** for all roles. No more, no less. Adding a sixth main-nav item for any feature is a flag that the feature needs a different entry point — not a new nav slot.

Main nav (same for all roles):
`Home` · `Explore` · `Messages` · `Dashboard` · `Menu`

### 2.2 The Contest Feed exception
Contest Feed is not a sixth nav item. It is a **context switcher in the header** — a Trophy icon beside the Bell notification button in the top bar. This treats Contest Feed the same way a social app treats a trending/explore toggle: a fast context switch from the primary feed, not a new destination category. Tapping it slides to Contest Feed; tapping again (or tapping Home) slides back to Showcase Feed.

### 2.3 Desktop sidebar
- **Main 5 nav items** occupy the sidebar body: tall, icon + label, full-width buttons, generous spacing.
- **Contest Feed icon** lives in the sidebar as a secondary item below the main 5, visually separated by a thin divider, styled with the accent color (amber) to signal it's a different kind of destination.
- **User card** anchors the sidebar bottom: avatar, name, role badge, links to profile.
- The sidebar is **always visible on ≥ md** and **never collapses to a hamburger** — full sidebar persistence is a deliberate choice to prevent the hidden-nav confusion that affects most mobile-adapted desktop apps.

### 2.4 Mobile bottom nav + header
- **Bottom nav**: 5 items, icons + micro labels (10px), equal tap targets.
- **Top header**: Logo (left) · Contest Feed icon (right cluster) · Bell (right cluster) · Avatar (right cluster). Exactly three actions in the right cluster.
- Bottom nav is **always visible** — no auto-hide on scroll. The scroll-up-to-reveal trick saves 56px but costs users their sense of navigation security. NeuralMart is a discovery product; users should always feel grounded.

### 2.5 Active state rules
- Active nav item: primary color text + icon, `bg-primary/10` pill background.
- Hover (desktop): `bg-accent/10` — neutral, doesn't compete with active state.
- Never use underlines for active nav; never use bold-only; the color+background combination is always both.

---

## 3. Mobile-First Design Rules

### 3.1 Breakpoint strategy
NeuralMart is designed **mobile-first**; desktop is an enhancement. The primary design canvas is a 390px viewport (iPhone 15 / modern Android standard).

- `base` (default): mobile layout, single column, bottom nav, compact header.
- `md` (768px): sidebar appears, bottom nav hides, content shifts right by sidebar width (256px).
- `lg` (1024px): content max-width engages (5xl = 1024px), centered.
- `xl` (1280px): optional right-side panel (Creator profile, context widgets) — not yet built, reserved.

### 3.2 Touch targets
- Minimum tap target: **44×44px** (Apple HIG minimum, matches Android material guidance).
- Icon buttons: rendered at 40px visible + 4px padding each side = 48px tap target.
- Cards: entire card surface is tappable for primary action; secondary actions (like, share) are individual tap targets inside the card.

### 3.3 Safe areas
Bottom nav uses `pb-safe` (maps to `env(safe-area-inset-bottom)`) so it clears home indicator bars on iPhone. All full-bleed pages use `min-h-[100dvh]` not `min-h-screen` to account for dynamic viewport on mobile browsers.

### 3.4 Scroll behavior
- Feed pages: vertical scroll only, no horizontal scroll (horizontal scroll is a discoverability trap).
- Modals/sheets: slide up from bottom on mobile (not center-of-screen dialogs — center dialogs are desktop-native and feel wrong on mobile).
- No fixed floating action buttons competing with the content. CTAs that look like FABs belong in the feed itself (composer cards) or in the header.

### 3.5 Typography scale for mobile
- Page headers: `text-4xl` on desktop, `text-2xl` on mobile.
- Card titles: `text-xl` desktop / `text-lg` mobile.
- Body text: `text-sm` (14px) — never smaller in interactive content.
- Meta text (timestamps, counts): `text-xs` (12px) — acceptable because it's supplementary.

---

## 4. Page Hierarchy Rules

```
LEVEL 0 — Auth shell (Login / Register)
LEVEL 1 — Home Feed (the daily-use screen)
LEVEL 2 — Feature Hub pages (Explore, Creators, Products, Services, Projects, Contests, Messages, Orders)
LEVEL 3 — Detail pages (Product detail, Service detail, Project detail, Creator profile)
LEVEL 4 — Creation flows (New Project, New Contest, Edit Profile)
LEVEL 5 — Settings / System (Wallet, Badges, Notifications, Support)
```

**Rules:**
- Level 1 must load in under 2 seconds perceived (skeleton + optimistic render).
- Level 2 hubs show **list/grid only** — no nested detail in the hub view.
- Level 3 detail pages are **deep-linkable** and contain the full context needed to act (no "go back to the list to see the price").
- Level 4 creation flows are **always single-page forms** (no multi-step wizards unless a flow genuinely can't fit one screen — e.g. a long contest brief).
- Level 5 is never the default; always requires deliberate navigation.

**Navigation rule:** Users can go from Level 1 → Level 3 directly (tapping a card on the feed goes to Product Detail). They don't need to go through Level 2. But Level 2 hubs exist as browsable destinations for when the user's intent is exploration rather than a specific item.

---

## 5. Card/Feed Design Rules

### 5.1 Card anatomy
Every feed card has exactly **four zones**:
1. **Header** (author identity): avatar, name, timestamp, overflow menu (…).
2. **Media** (optional, visual lead): image/video/preview — always `aspect-video` or `aspect-[21/9]` to prevent layout shifts.
3. **Body** (content): text with `line-clamp-3`, price badge (if product), budget range (if project).
4. **Footer** (actions): 3 max — primary action left (like/bid/buy), secondary middle (comment/view), tertiary right (share/more).

### 5.2 Card types and their visual signatures
| Card type | Visual identifier | Action affordance |
|---|---|---|
| Post (creator update) | Full-width media, social footer | Like, Comment, Share |
| Product | Thumbnail with price badge overlay | "View Product" button |
| Service | Category chip + tier count badge | "View Tiers" |
| Project brief | Blue Briefcase icon + budget range | "Submit Proposal" (Creator) |
| Contest brief | Amber Trophy icon + prize badge | "Enter Contest" (Creator) |

Never mix card types into visually identical layouts — the icon/badge signature must always signal the card type before the user reads the title.

### 5.3 Feed density
- **Showcase Feed**: single-column, max-width `max-w-2xl` centered — same as a social media feed. Post cards can be tall. Breathing room between cards: `space-y-6` (24px).
- **Contest Feed**: same single-column layout but cards are shorter (no media zone by default). Contests and projects are information-dense but should never feel like a spreadsheet.
- **Hub grids** (Products, Services, Creators): 1 col mobile / 2 col tablet / 3 col desktop. Grid gaps: 24px.

### 5.4 Card hover states
Cards get a **subtle border-color shift** (`hover:border-primary/20`) on hover, not a shadow elevation. Shadow-on-hover is heavy; border-color shift is lightweight and doesn't disturb layout. The cursor pointer signals interactivity without the card "lifting."

---

## 6. Interaction Rules: Creators vs Buyers

### 6.1 Creator interaction signature
Creators see the world through **publishing and response**. Their primary interactions:
- **Post** new content (always one tap from the feed via the composer)
- **See** who engaged with their work (likes, comments)
- **Receive** and respond to proposals/invitations
- **Browse** the Contest Feed for opportunities

Creator-specific affordances should feel **professional but fluid** — more like a creator tool than a job board. When a Creator taps a Project brief, the CTA is "Submit a Proposal" (forward action), not "View details" (passive).

### 6.2 Buyer interaction signature
Buyers see the world through **discovery and hiring**. Their primary interactions:
- **Browse** creator work and products
- **Post** projects or contests (from composer or hub pages)
- **Respond** to proposals (accept/reject)
- **Pay** (wallet, in-chat payment, checkout)

Buyer-specific affordances should feel **confident and low-friction** — more like a hiring tool than a marketplace. When a Buyer taps a Product, the CTA is "Buy Now" with price visible. When they land on a Project Detail, they see proposals ranked, not a form.

### 6.3 Shared interaction rules
- **Optimistic UI**: likes, follows, and other low-stakes actions should apply immediately in the UI, with error rollback if the API fails. Don't make users wait 300ms to see their like registered.
- **Destructive actions** (delete listing, withdraw funds, cancel order) always get a confirmation dialog. Non-destructive actions never do.
- **Error states**: shown as inline text near the failed element, never as page-level errors unless the entire page failed to load.

---

## 7. Keeping a Complex Marketplace Visually Simple

### The four rules of marketplace simplicity:

**Rule 1: One job per screen.**
Every screen has one primary job. Home = discover. Explore = search. Product Detail = decide to buy. Dashboard = check status. Never combine two primary jobs on one screen. The moment you add "and also manage your settings" to a page's primary job, you've violated this rule.

**Rule 2: Progressive disclosure beats option paralysis.**
Show the 20% of options that cover 80% of use cases. Put the rest behind an expandable "Advanced" section, an overflow menu (…), or a dedicated settings page. The Projects/Contests creation forms are a good example: show Title, Category, Budget, Deadline, Description. Everything else (skills required, attachments, milestones) lives in an "Advanced options" accordion that starts collapsed.

**Rule 3: Color is communication, not decoration.**
On NeuralMart, color encodes category:
- **Primary (indigo/violet)**: Creator actions — following, liking, publishing, your own profile
- **Accent (amber)**: Contest/opportunity actions — contest prizes, winning, opportunities
- **Muted/neutral**: Buyer actions — hiring, posting projects, paying
- **Destructive (red)**: Delete, cancel, dispute — always destructive
Never use accent color just because a section "needs more visual interest."

**Rule 4: Whitespace is a feature.**
The consistent vertical rhythm (`space-y-6` for feed, `p-4 md:p-8` for page padding, `gap-6` for grids) is not decoration — it's pacing. Dense content with insufficient whitespace reads as complicated. The same content with proper whitespace reads as organized. Don't fill empty space with widgets just because the screen has room.

---

## 8. Icon/Navigation Principles

### 8.1 Icon set
**Lucide React** exclusively (already installed). No mixing icon libraries — mixed icon styles create visual noise that users subconsciously feel as "unpolished."

### 8.2 Navigation icon vocabulary (locked — never change these without updating this doc)
| Destination | Icon | Why |
|---|---|---|
| Home (Showcase Feed) | `Home` | Universal convention |
| Explore | `Search` | Universal convention |
| Messages | `MessageSquare` | Chat convention |
| Dashboard | `LayoutDashboard` | Conventional dashboard icon |
| Menu / More | `Menu` (hamburger) | Universal "more" convention |
| Contest Feed | `Trophy` | Direct semantic link to contests/competitions |
| Notifications | `Bell` | Universal convention |
| Wallet | `Wallet` | Direct semantic |
| Orders | `Package` | Delivery/order convention |
| Settings | `Settings` | Universal convention |

**Rule:** Icon choices for nav items must be universally understood without a label. If a user couldn't identify the destination without reading the label, the icon choice is wrong.

### 8.3 Icon sizes
- Nav icons: `w-5 h-5` (20px) — standard nav weight.
- Action icons inside buttons: `w-4 h-4` (16px).
- Illustrative icons (empty states, card type badges): `w-8 h-8` or `w-12 h-12` depending on context.
- Never mix sizes within the same component zone.

### 8.4 Icon + label rules
- Bottom nav: icon + 10px label below.
- Sidebar: icon + 16px label beside (same line).
- Header actions: icon only (tooltips on desktop hover for accessibility).
- Buttons: icon + label (never icon-only buttons that perform irreversible actions).

---

## 9. Spacing and Information Density Rules

### 9.1 Base spacing unit
**4px** (Tailwind's default `1` unit). All spacing is a multiple of 4px. No `1.5rem` or custom values.

### 9.2 Density levels
NeuralMart uses **three density levels**, each appropriate for a different context:

| Density | Where | Vertical padding | Example |
|---|---|---|---|
| **Comfortable** (default) | Feed cards, creator profiles, detail pages | `p-6` (24px) | PostCard, ProductDetail |
| **Compact** | Dashboard widgets, table rows, sidebar items | `p-4` (16px), `h-12` items | Dashboard stat cards, Orders list |
| **Loose** | Auth pages, creation forms, onboarding | `p-8` (32px), `space-y-8` | Login, NewProject |

Never use Comfortable density in a Dashboard. Never use Compact density in a creation form. The density level is a signal: Comfortable = browse; Compact = manage; Loose = focus.

### 9.3 Content width constraints
- Feed content: `max-w-2xl` (672px) — enforces a readable line length and social-feed feel.
- Creation forms: `max-w-3xl` (768px) — wider for form layouts with side-by-side fields.
- Detail pages: `max-w-5xl` (1024px) — allows side-by-side (content + sidebar) at full desktop.
- Full-width: only for cover images and media that benefit from edge-to-edge display.

### 9.4 The "above the fold" rule for mobile
The most important action on any page must be **visible without scrolling on a 390×844px viewport** (iPhone standard). For feed pages, this means the first card must render above the fold. For creation forms, the primary CTA ("Post Project") must be unreachable by scrolling only — it must also be pinned to the bottom or visible at the top.

---

## 10. Dashboard vs Feed UI Differences

| Dimension | Feed (Showcase/Contest) | Dashboard |
|---|---|---|
| **Primary information type** | Other people's content | Your own data |
| **Time orientation** | Now / recent (chrono) | Period summaries (stats) |
| **Interaction goal** | Engage, discover, transact | Monitor, act on your work |
| **Visual density** | Comfortable (cards, whitespace) | Compact (stats, tables, status) |
| **Scroll type** | Infinite / paginated feed | Bounded panels with "see all" links |
| **Empty state** | Suggest follows / discovery | Onboarding checklist (first-time) |
| **Color use** | Rich (creator content drives color) | Neutral with data-viz accent for charts |

**Key rule:** The Dashboard must never look like a feed. If a dashboard module looks like a PostCard, it's too casual for a management context. If a feed card looks like a dashboard widget, it's too cold for a social context.

---

## 11. Profile Feed Behavior Rules

Creator profiles have a tabbed feed: **Posts | Products | Services**.

### 11.1 Tab default
- Default tab: **Posts** (social-first, lowered friction for discovery).
- Products and Services tabs are for users with intent to hire/buy — they find their way there if they want to.

### 11.2 Post grid vs. list
- Posts grid: `grid-cols-2 md:grid-cols-3` with square `aspect-square` thumbnail previews (Instagram-style). Tapping opens the full post card.
- Products/Services: `grid-cols-1 md:grid-cols-2` — wider cards with price and action button visible.

### 11.3 Creator profile header behavior
The creator's cover + avatar section **sticks on scroll** until the tab bar reaches the top of the viewport, then the tab bar sticks and the header scrolls away. This is the standard social profile pattern (Twitter/Instagram/LinkedIn all do this). Implementation: `sticky top-0` on the tab bar with `z-10`, `overflow-hidden` on the cover.

### 11.4 Follow/Message CTA placement
- Desktop: fixed right-side column with Follow button, Message button, stats summary (always visible while browsing their profile).
- Mobile: buttons in the profile header section (visible without scrolling), then they scroll away as the user enters the tab feed.

---

## 12. Search, Filters, and Deep Tools Without Clutter

### 12.1 Search hierarchy
Three levels of search, each progressively more specific:

1. **Global search** (Explore page): searches across all entity types simultaneously. Unified results list with type-icon differentiation. No separate "search within Products" from this level — filters come after results.
2. **Hub-level filter** (Products/Services/Projects/Contests hub pages): a single filter bar below the hub header. Shows 3-4 most common filters inline; advanced filters collapse behind a "Filters" button.
3. **In-context search** (Messages inbox, Orders history): a search bar that filters the current list. Never navigates away.

### 12.2 Filter affordances
**Do:**
- Chips/pills for multi-select filters (category, status) — visually compact, togglable.
- Price range: a simple `$min – $max` two-field input, never a slider (sliders are imprecise on mobile).
- "Active filters" count badge on the Filters button when any non-default filters are applied.
- "Clear all" button that appears only when filters are active.

**Don't:**
- Full-page filter sheets for basic filtering (use a compact dropdown or popover).
- Require "Apply" button presses — filters should update results in real-time.
- Nested filter hierarchies (filter within a filter group) — flatten and simplify.

### 12.3 Progressive complexity for advanced tools
Advanced features (multi-milestone projects, custom service tiers, contest judging criteria) follow the accordion pattern: the most important fields are always visible; everything else is in an "Advanced options" section that starts collapsed. The collapsed section uses a chevron and a count of the fields inside ("3 more options"). This preserves discoverability without overloading the default view.

### 12.4 The empty-search rule
When search returns no results, never show a blank page. Show:
1. "No results for [query]" — tell them what they searched for.
2. 2–3 similar/related items as suggestions.
3. A secondary action ("Browse all products instead" or "Post a project to find a creator for this").

---

## 13. Color / Style / Motion Guidelines

### 13.1 Core palette
| Role | HSL | Token | Use |
|---|---|---|---|
| **Primary** | `262 83% 58%` (deep indigo-violet) | `--primary` | All creator actions, active nav, buttons, links |
| **Accent** | `45 100% 55%` (electric amber) | `--accent` | Contest/opportunity surface, prizes, Trophy icon, CTAs in Contest Feed |
| **Background** | Dark near-black | `--background` | Page backgrounds |
| **Card** | Elevated dark surface | `--card` | Card backgrounds, sidebar |
| **Muted** | Subtle gray | `--muted` | Skeleton states, inactive inputs, dividers |
| **Destructive** | Red | `--destructive` | Delete, cancel, dispute actions only |

### 13.2 Color rules
- **Primary** is always associated with identity and creator actions. Never use it for contest/prize affordances.
- **Accent (amber)** is exclusively for opportunity/contest-related affordances. Its presence is a signal: "there's money/opportunity here."
- **Never** use more than two color highlights on one card. Most cards should have zero accent color; it appears only when the card IS an opportunity/contest type.
- Dark mode is the default. Light mode is a future addition. All color choices must work at WCAG AA contrast ratios in dark mode.

### 13.3 Typography
- **Headings**: Plus Jakarta Sans / Outfit (serif-flavored sans): `font-serif` class, `tracking-tight`
- **Body/UI**: System sans-serif stack (Tailwind default): `font-sans`
- **Monospace** (prices, wallet amounts): `font-mono` with `tabular-nums` — ensures numbers don't dance when amounts change.

### 13.4 Motion guidelines
**Principle**: motion communicates state change; it never decorates.

| Motion event | Implementation | Duration |
|---|---|---|
| Page transition | `fade-in slide-in-from-bottom-4` (tailwindcss-animate) | 400ms, ease-out |
| Feed switch (Showcase ↔ Contest) | Instant content swap (no animation) — fast is better than animated for tab switching | 0ms |
| Card hover | `transition-colors` on border | 150ms |
| Like button | Scale pulse `scale-125` then back | 200ms, spring |
| Loading spinner | Continuous rotation (Hexagon logo) | 2000ms, linear |
| Modals/sheets | Slide up from bottom (mobile), fade+scale (desktop) | 200ms, ease-out |
| Skeleton to content | Fade-in | 300ms |

**Rules:**
- Never animate things the user didn't trigger.
- Never animate content that's already visible (e.g., animating a card just because the user scrolled to it).
- Reduce motion: all animations should respect `prefers-reduced-motion`. Use `motion-safe:` prefix on animation classes.

---

## 14. Loading / Performance-Oriented UX Rules

### 14.1 Skeleton-first loading
Every data-dependent page shows **skeleton placeholders** that match the exact layout of the loaded content (not a generic spinner). This prevents layout shifts and gives users a spatial map of what's loading.

Skeleton rules:
- Match the number of items that will likely appear (show 3 feed card skeletons, not 1).
- Match aspect ratios (skeleton for a `aspect-video` media zone must be `aspect-video`).
- Animate with shimmer, not pulse — shimmer (gradient sweep) reads as "loading" more universally.

### 14.2 Stale-while-revalidate
TanStack Query `staleTime: 30_000` is already configured (30s). Rules for overrides:
- Feed data: 30s stale time — feeds feel fresh but don't hammer the API on every tab switch.
- User's own data (`/api/auth/me`, `/api/dashboard/*`): 0s stale time — always fresh, because stale user data causes trust issues.
- Static-ish data (badges list, creators directory): 5min stale time.

### 14.3 Optimistic updates
For social actions (like, follow), apply the state change **immediately** in the UI. If the API returns an error, revert and show a brief toast. The 100-300ms round-trip wait before a like registers is a noticeable quality gap on mobile connections.

### 14.4 Image loading
- All creator content images: `loading="lazy"` (browser-native, already the default in React).
- Critical path images (creator avatar, product hero): `loading="eager"` + explicit `width`/`height` to prevent layout shifts.
- All images: `object-cover` inside their container — never `object-contain` in card media zones (distorted/padded images feel unprofessional in a creator marketplace).

### 14.5 API call discipline for the home feed
The Home page currently fires `GET /api/auth/me` and `GET /api/feed/showcase` in parallel immediately on mount — this is correct. Avoid waterfall loading (waiting for `/me` to return before fetching the feed). The feed can render without knowing who the user is; likes can be loaded after in a second pass.

### 14.6 Code splitting
Each hub page (Products, Services, Projects, Contests) is a separate React component already. Add `React.lazy()` wrapping in `App.tsx` for Level 2+ pages — the Home Feed and Login/Register should be eagerly loaded; everything else can be lazy-loaded on navigation. This keeps the initial bundle small and the first paint fast.

### 14.7 Error boundaries
Each feed (ShowcaseFeed, ContestFeed), each hub page, and each detail page should be wrapped in a React Error Boundary that renders a "Something went wrong — try refreshing" fallback rather than crashing the whole app. The current crash of `home.tsx` (the `.posts` bug fixed earlier) caused the entire page to be replaced by the runtime error overlay — an error boundary would have contained it to just the feed section.

---

## 15. v2 Feed Architecture — UX Specification

This section is the implementation-facing spec for the Feed Architecture v2 described in the product brief.

### 15.1 Creator Showcase Feed (default home)

**What it is:** The primary home screen for all users. Creator-generated content: portfolio posts, products, services. The aesthetic north star is "beautiful creative feed" — think Dribbble's shot feed crossed with Instagram's post feed.

**Who sees what at the top:**
- **Buyer/Both users**: a "Post to Contest Feed" composer card (see §15.3) — compact, not intrusive.
- **Creator/Both users**: a "Share your work" chip-button row (quick actions: New Post, New Product, New Service) — one tap to publish.
- **All users**: the feed itself immediately below, scrollable, infinite.

**Feed content order:**
1. Posts from creators the user follows (personalized, above the fold)
2. Trending posts from all creators (discovery, fills gaps)
3. Promoted products / featured services (marked as "Featured" — future monetization)

### 15.2 Contest Feed

**What it is:** A separate feed of open Projects, Contests, and Hiring requests. Only buyer-originated content lives here. The aesthetic north star is "opportunity board" — organized, purposeful, action-oriented.

**Entry:** Trophy icon in the top-right header cluster (desktop: sidebar secondary item). One tap from anywhere.

**Content order:**
1. Highest-prize contests (Creator-biased: makes their eyes go to the best opportunity first)
2. Recently posted projects (freshness signals activity)
3. About-to-expire opportunities (urgency)

**Buyer composer in Contest Feed:** Same "Post to Contest Feed" composer card at the top (Buyers see it here too, so they can post without going back to Showcase first).

### 15.3 The Buyer Composer Card

A compact, Facebook-style post-composer card that appears:
- At the top of the Showcase Feed (for Buyers/Both only)
- At the top of the Contest Feed (for all users, since anyone might want to hire)

Anatomy:
```
┌─────────────────────────────────────────────────────────┐
│  [Avatar]  What do you need help with?                  │
│  ─────────────────────────────────────────────────────  │
│  [📋 Post a Project]   [🏆 Host a Contest]              │
└─────────────────────────────────────────────────────────┘
```

Tapping either button navigates to the existing `/projects/new` or `/contests/new` forms. After successful submission, those forms redirect back to `/` (the Showcase Feed home), matching the product requirement that "the buyer returns automatically to Creator Showcase Feed." The newly created item appears only in the Contest Feed, not in the Showcase Feed — keeping the Showcase Feed clean as a creator-content-only surface.

### 15.4 Feed switching behavior

**Speed requirement:** Switching between Showcase and Contest feed must feel **instantaneous** (< 50ms perceived). Implementation: both feeds are routed as separate pages (`/` and `/contest-feed`) with their own TanStack Query caches, so navigating back to a previously visited feed shows cached content immediately while revalidating in the background.

**Visual affordance:** The Trophy (Contest Feed) icon in the header gets an **amber dot badge** when there are new opportunities since the user last visited Contest Feed (future feature, not yet implemented — but the badge position should be designed into the icon from the start).

### 15.5 Creator posting flow

A Creator posting to the Showcase Feed (sharing work) is a **distinct action from a Buyer posting to the Contest Feed**. The composer at the top of the Showcase Feed, for Creator/Both users, shows quick-action chips:

```
┌──────────────────────────────────────────────────────┐
│  [Avatar]  Share your latest work...                 │
│  ──────────────────────────────────────────────────  │
│  [+ Post]  [+ Product]  [+ Service]                  │
└──────────────────────────────────────────────────────┘
```

This mirrors the Facebook post composer UX: clicking the "Share your latest work..." text or the "+ Post" chip opens the creation flow. The + Product and + Service chips navigate to their respective creation pages (Planned: `/products/new`, `/services/new`).

### 15.6 Separation guarantee

| Content type | Showcase Feed | Contest Feed |
|---|---|---|
| Creator portfolio posts | ✅ | ❌ |
| Digital products | ✅ (as product cards in feed) | ❌ |
| Services | ✅ (as service cards in feed) | ❌ |
| Buyer-posted projects | ❌ | ✅ |
| Buyer-hosted contests | ❌ | ✅ |
| Hiring requests | ❌ | ✅ |

This separation is enforced at the **API level** (two separate endpoints: `/api/feed/showcase` and `/api/feed/opportunities`), not just the frontend. The feeds cannot "bleed" because they query different tables.
