# NeuralMart — Backend Architecture
## Part 1 of 3: Core Architecture & Marketplace Logic

**Document version:** 1.0  
**Depends on:** NeuralMart product architecture from Prompts #1–#35 and Database & Data Architecture from Prompt #36 Parts 1–3  
**Continues in:** Part 2 — Orders, Payments, Wallet, Chat-Commerce, Delivery, Reviews, Notifications, and Support  
**Scope:** Backend topology, domain modules, identity/authorization, sessions, feeds, content, marketplace listings, exclusive ownership, projects, proposals, and contests  
**Implementation status:** Architecture specification only; no production code is specified here

---

## 0. Continuity and Dependency Rules

This specification translates the approved product and data architectures into backend responsibilities. It does not replace them.

The backend must preserve:

- one User identity with additive Buyer and Creator capabilities;
- one shared Profile, wallet, inbox, and order history per account;
- `buyer`, `creator`, `both`, and `admin` as account-level role summaries;
- Freelancer, Contest Participant, and Digital Seller as Creator activities/capabilities, not separate accounts;
- separate Showcase and Opportunities/Contest feeds;
- separate Post, Product, Service, Project, Contest, Proposal, Entry, and Order concepts;
- one universal Order with type-specific extensions;
- PostgreSQL as operational source of truth;
- object storage for binary assets;
- durable Ownership records for exclusive transfers;
- Chat as a commerce surface, not transaction truth;
- backend-enforced payment, access, order, and ownership decisions;
- idempotent operations and append-only material history.

### 0.1 Product dependencies

| Area | Established decision to preserve |
|---|---|
| Roles | `both` combines buying and selling capabilities; context switching changes the default surface, not permissions. |
| Profiles | One shared Profile, with optional CreatorProfile and BuyerProfile; FreelancerProfile is an optional specialization. |
| Showcase Feed | Heterogeneous discovery surface for creator posts, product/service cards, and eligible open project briefs. |
| Opportunities Feed | High-intent feed for contests and open project opportunities. |
| Marketplace | Products, services, direct projects, and contests have different commercial models. |
| Proposals | A proposal is an offer to complete a buyer project; it is not a contest entry, service booking, or order. |
| Contests | Prize funding, rules, entry selection, winner order, and rights transfer are distinct steps. |
| Orders | One universal Order; payment, delivery, ownership, refund, dispute, payout, and revision are separate dimensions. |
| Exclusive ownership | Ownership is server-enforced, idempotent, and unique; normal refunds do not silently relist exclusive work. |
| Database | PostgreSQL owns operational truth; caches, search, feeds, and analytics are projections. |

### 0.2 Scope boundary

Part 1 describes the backend boundary and workflows for Sections 1–12. It identifies Payment, Order, Wallet, Chat, Delivery, Review, and Dispute interactions but does not define their full service contracts. Those belong in Part 2 and must follow Order Architecture Parts 1–5.

---

# 1. Backend Architecture Strategy

## 1.1 Recommendation: modular monolith for MVP

Build NeuralMart as a **modular monolith** for the MVP:

```text
One deployable backend application
├── Explicit domain modules
├── Shared PostgreSQL database
├── Module-owned tables and services
├── In-process commands for synchronous work
└── Outbox + workers for asynchronous effects
```

The product has many domains, but the highest-risk workflows cross them:

- checkout crosses catalog, availability, payment, Order, Ownership, and access;
- project selection crosses Proposal, Project, contract, Payment, Order, and Conversation;
- contest winner selection crosses Contest, Entry, prize, Order, Ownership, and payout;
- delivery crosses Order, Media, AccessGrant, Chat, and notification.

Keeping those commands within one deployable application and one operational database makes atomicity, schema evolution, observability, and early product iteration simpler.

## 1.2 Why not microservices for MVP

Microservices would introduce:

- network failures between core transaction steps;
- distributed transactions or sagas before they are necessary;
- cross-service identity and authorization drift;
- duplicate data and eventual-consistency edge cases;
- independent deployment and monitoring burden;
- more difficult development and test environments.

They do not remove the need for a universal Order or shared integrity rules.

## 1.3 Why not a generic unstructured backend

A single undifferentiated route/service layer would couple unrelated product areas, make permission checks inconsistent, and encourage features to write directly to each other's tables.

The monolith must therefore have explicit domain ownership and internal contracts even before any module is extracted into a separate service.

## 1.4 Module boundaries

At MVP:

- modules are code-level boundaries, not separate network services;
- each module owns its domain rules and write operations;
- cross-module mutations use an application command/use-case layer;
- modules do not write directly to another module's tables except through declared internal interfaces;
- same-database transactions may span modules for critical workflows;
- events are used for asynchronous effects, not to hide synchronous integrity requirements.

## 1.5 Evolution path

```text
MVP:
Modular monolith + PostgreSQL + object storage + background worker

V2:
Add dedicated search, read replicas, specialized analytics storage,
and isolated worker pools when measured load requires them

Large-scale:
Extract high-load or independently operated modules behind stable contracts
only when there is a demonstrated need and a clear consistency boundary
```

Potential later extraction candidates:

- media processing;
- notification delivery;
- search indexing;
- analytics ingestion/reporting;
- high-volume feed candidate generation.

Payment, Order, and Ownership should not be split casually. Their consistency boundary must remain explicit if ever separated.

## 1.6 Request and job paths

Synchronous request:

```text
Client
→ API transport
→ authentication/session
→ authorization
→ application command/query
→ domain module(s)
→ PostgreSQL transaction
→ response
```

Asynchronous effect:

```text
Committed source transaction + outbox event
→ worker
→ notification/search/analytics/media job
→ idempotent result + job status
```

The client receives a committed result or an explicit pending/reconciling state. It must not be told that payment, ownership, or access succeeded before the authoritative state exists.

---

# 2. Core Backend Modules and Responsibilities

## 2.1 Module map

| Module | Responsibilities | Primary entities | Key dependencies |
|---|---|---|---|
| Identity & Session | Registration, login, sessions, verification references, recovery, device/session management | User, Session, Verification, LinkedAccount | Managed authentication provider, User |
| Authorization & Trust | Role/capability checks, restrictions, verification gates, resource policies, admin scope | UserRole, UserCapability, UserRestriction, Verification | All modules |
| Profile | Shared identity and role-specific profile data | Profile, CreatorProfile, FreelancerProfile, BuyerProfile | Identity |
| Social Content | Drafts, posts, comments, reactions, saves, shares, visibility, moderation hooks | Post, Media references, Comment, Reaction, Save | Profile, Media, Moderation |
| Media | Upload initiation/completion, scan, metadata, transforms, access policy | Media, typed attachment bridges | Object storage, Content, Marketplace, Delivery |
| Feed & Discovery | Showcase and Opportunities candidates, filtering, cursor pagination, ranking, visibility | FeedEligibility, FeedEntry projection, AnalyticsEvent | Content, Marketplace, Project, Contest, Search |
| Marketplace Catalog | Product/service/project/contest listing state, prices, categories, availability | Product, ProductVersion, ProductLicense, Service, Package, Project, Contest | Profile, Media, Search |
| Project & Proposals | Project lifecycle, proposal versions, shortlist, selection, contract handoff | Project, Proposal, ProposalVersion, Shortlist, ProjectSelection | Identity, Chat, Order |
| Contest | Contest setup, funding gate, entries, judging, winner selection, rights handoff | Contest, ContestEntry, ContestWinner, ContestPrize, ContestOwnership | Payment, Order, Ownership, Media |
| Commerce Orchestrator | Coordinates checkout/offer acceptance and type-specific commands without becoming a second Order store | Command state, idempotency references | Catalog, Payment, Order, Ownership, Access |
| Order | Universal commercial lifecycle and typed order extensions | Order, OrderItem, extensions, timeline | Payment, Delivery, Wallet, Chat, Review |
| Payment & Wallet | Payment provider integration, ledger, fees, earnings, withdrawals, refunds | Payment, Wallet, Transaction, LedgerEntry, SellerEarning | Order |
| Delivery & Access | Delivery versions, file grants, previews, download checks, revisions | Delivery, DeliveryVersion, AccessGrant, Revision | Media, Order, Ownership |
| Chat-Commerce | Conversations, participants, messages, offers, payment requests, order references | Conversation, Message, Offer, PaymentRequest | Identity, Order, Media |
| Trust & Reputation | Verified reviews, ratings, badges, reputation projections | Review, Rating, UserBadge, ReputationScore | Order, Identity |
| Notifications | Event mapping, preferences, channel delivery, deduplication | Notification, NotificationDelivery, Preference | All modules through outbox |
| Support & Moderation | Reports, support cases, moderation actions, restrictions, appeals | SupportTicket, Report, ModerationAction | All modules with scoped access |
| Settings & Policy | Account preferences, privacy/security settings, policy versions/acceptance | Settings, PolicyVersion, PolicyAcceptance | Identity, Commerce |
| Analytics & Reporting | Event ingestion, aggregates, dashboards, attribution | AnalyticsEvent, MetricSnapshot | Outbox, all domain events |

## 2.2 Ownership rules

- Identity owns account state and capability summaries.
- Profile owns shared public presentation.
- Catalog modules own listing terms and availability before purchase.
- Project/Contest modules own brief and participation lifecycles.
- Order owns the universal commercial lifecycle.
- Payment/Wallet owns money movement and balances.
- Ownership owns exclusive rights and transfer history.
- Delivery/Access owns fulfillment versions and protected-file grants.
- Chat owns communication and structured-message references, not transaction truth.
- Analytics owns only derived measurements and projections.

## 2.3 Cross-module contracts

Modules should exchange:

- commands for state-changing intent;
- queries for read-only retrieval;
- domain events for committed state changes;
- stable entity identifiers;
- explicit authorization context;
- idempotency/correlation identifiers for retryable actions.

Avoid importing another module's internal database model as the public contract. The API/application layer composes response DTOs from owned records.

---

# 3. Flexible User & Role Backend

## 3.1 One User, additive capabilities

The backend uses one authenticated User for:

- Creator;
- Freelancer/project bidder;
- Buyer/Client;
- Contest Participant;
- Digital Seller.

The approved account-level roles remain:

```text
buyer
creator
both
admin
```

Freelancer, Contest Participant, and Digital Seller are activity contexts derived from Creator capability and persisted actions:

- proposal record → freelancer activity on a Project;
- contest entry → participant activity in a Contest;
- published Product → digital-seller activity.

They do not create separate credentials, profiles, wallets, inboxes, or account records.

## 3.2 Role activation

At registration:

- a buyer starts with Buyer capability;
- a creator starts with Creator capability;
- corresponding role-specific profile extensions are provisioned as required;
- public identity stays in the shared Profile.

Later activation:

```text
Buyer capability
→ user requests Creator capability
→ backend validates account is eligible
→ create/activate CreatorProfile
→ record capability activation
→ summary becomes `both`
```

Default product decision remains self-service activation unless a separate verification or trust rule explicitly gates a specific action.

## 3.3 Pause and disable

Pausing Creator activity:

- does not delete the CreatorProfile;
- does not erase listings, reviews, or order history;
- prevents or hides new selling activity according to the pause policy;
- preserves existing Orders and fulfillment obligations;
- does not revoke completed buyer rights.

An account restriction may selectively block publishing, proposals, contest entry, purchases, messages, or withdrawals without changing the user's underlying identity.

## 3.4 Role switching and active context

For `both` users:

```text
activeContext = buying | selling
```

This is a UI preference controlling:

- default dashboard;
- default feed tab;
- composer shortcuts;
- notification grouping.

It is not authorization and never removes capabilities. Every API request derives permissions from the authenticated User and server-side capability state, not the active context sent by the client.

## 3.5 Role-aware dashboards

- Buyer Dashboard reads the user's projects/contests as host, buyer Orders, spending summaries, and buyer actions.
- Creator Dashboard reads creator Orders, listings, proposals, entries, earnings summaries, reputation, and creator actions.
- Both users use the same two dashboards with a context switch; do not build a third merged dashboard.
- Admin has a separate staff surface and scoped administrative permissions.

Dashboard summaries are read models. They do not own the state they summarize.

## 3.6 Feed access

- All regular users can browse Showcase and Opportunities surfaces, subject to privacy and account restrictions.
- Creator capability enables creator-specific CTAs: publish content, propose, enter contests, list products/services.
- Buyer capability enables buyer-specific CTAs: create projects/contests, purchase, hire, approve.
- Both sees additive actions, not a separate account or feed schema.
- Admin feed/dashboard access is staff-scoped and is not ordinary marketplace participation.

---

# 4. Authentication & Session Layer

## 4.1 Provider boundary

Use the project's configured authentication mechanism behind an adapter boundary. This specification does not assume a new identity provider or authorize replacing the current one.

The application database stores:

- internal User ID;
- opaque provider subject/reference;
- provider name;
- verification/account state;
- session and recovery references needed by application logic.

It does not store plaintext passwords, raw authentication tokens, or provider secrets.

## 4.2 Registration

Flow:

```text
Client submits registration intent
→ authentication provider validates identity
→ backend resolves/creates User
→ create shared Profile
→ provision requested capability/profile
→ record required policy acceptance
→ create session
→ return minimal authenticated account context
```

Account creation and profile/capability provisioning should be transactional where the user record is application-owned. Provider operations use idempotency/reconciliation so a retry does not create duplicate Users.

## 4.3 Login and logout

Login:

- authenticate through the configured provider;
- resolve provider subject to one User;
- reject suspended/disabled accounts according to policy;
- issue a secure session;
- record a security event/device session.

Logout:

- revoke the current session;
- clear secure client session state;
- optionally support “log out all devices” by revoking all active sessions.

## 4.4 Session security

Web sessions:

- server-managed or provider-managed opaque session;
- HttpOnly;
- Secure in production;
- SameSite policy appropriate to the authentication flow;
- bounded lifetime and rotation;
- CSRF protection for cookie-authenticated state-changing operations.

Mobile sessions:

- use the supported mobile authentication flow;
- retain tokens only in platform secure storage;
- rotate/revoke refresh credentials;
- do not treat device-provided role/context as authorization.

## 4.5 Password reset and account recovery

If the configured identity provider owns credentials:

- delegate password reset and credential recovery to it;
- accept only signed/verified recovery results;
- update the User's security state after confirmation;
- revoke affected sessions when policy requires.

Recovery flow must not reveal whether an email/phone belongs to an account. Recovery events and changes are auditable.

## 4.6 Verification

Keep distinct:

- email/phone/account contact verification;
- identity verification;
- seller/payout verification;
- product/content moderation;
- transaction eligibility checks.

One verified flag must not imply all forms of trust or eligibility.

## 4.7 Devices and session management

Session/device records may include:

- session ID;
- User;
- device class/platform;
- approximate last-used timestamp;
- creation/expiry/revocation;
- security event reference.

Collect minimal device data. A device label is informational and must not be treated as identity proof.

---

# 5. Authorization Architecture

## 5.1 Three-part authorization

Every protected operation checks:

1. **Identity:** Who is authenticated?
2. **Capability:** Does the account have the required Buyer/Creator/Admin capability and no blocking restriction?
3. **Resource relationship:** Does the user own, participate in, or have an explicit grant for this object?

For sensitive operations, also check:

4. **State:** Is the resource in a state where this action is allowed?
5. **Risk/verification:** Are payment, seller, safety, and verification rules satisfied?

## 5.2 Permission model

Use coarse role capabilities plus resource-level policy checks. Avoid creating a separate role for every marketplace action.

Examples:

| Action | Capability | Resource rule |
|---|---|---|
| Publish a post | Creator | User owns draft; media is cleared; account may publish |
| Create project | Buyer | User is project owner; buyer capability active |
| Submit proposal | Creator | Project open; creator is not disallowed by project policy; no duplicate active submission under configured rule |
| Enter contest | Creator | Contest open; entry eligibility and count rules pass |
| Buy product | Buyer or Creator-as-buyer | Listing purchasable; user is not prohibited from buying own listing; payment succeeds |
| Approve delivery | Buyer | Authenticated user is the Order buyer and delivery is reviewable |
| Download file | Participant/entitled owner | Active AccessGrant/Ownership and policy permit file |
| Select winner | Buyer/host | Authenticated user owns Contest; contest state permits selection |
| Moderate content | Admin/staff permission | Action is within assigned scope and is audited |

## 5.3 Resource-level authorization

Authorization must be evaluated from persisted relationships, for example:

```text
canEditProject(user, project)
→ project.ownerUserId == user.id
  AND user has buyer capability
  AND project is editable in current state
```

```text
canViewOrder(user, order)
→ user.id == order.buyerId
  OR user.id == order.sellerId
  OR user has scoped support/admin access
```

```text
canDownload(user, file)
→ AccessGrant/Ownership/creator-owner rule authorizes this file
  AND no refund, dispute, account, or policy block applies
```

Client-side hidden buttons are not security controls.

## 5.4 Admin and moderation permissions

Admin access is:

- separate from ordinary buyer/creator participation;
- capability-scoped (support, moderation, finance, policy, security);
- case/resource scoped;
- least privilege;
- audited with actor, reason, target, and timestamp.

Support staff do not receive blanket access to all private messages, files, or financial records.

## 5.5 Ownership and tenant boundaries

All queries that return user-private data must be scoped by:

- authenticated User;
- participant relationship;
- object owner;
- organization/team membership if enabled;
- explicit support assignment.

Never authorize by accepting a client-supplied `userId` as proof of ownership.

## 5.6 Abuse prevention

Backend interaction should include:

- rate limiting on login, registration, proposal/entry submission, messaging, and purchase attempts;
- abuse detection for repeated failed payment/access attempts;
- idempotency on high-impact commands;
- audit logging for role activation, moderation, and financial changes;
- safe, non-enumerating errors for sensitive identity lookup.

---

# 6. Feed Backend

## 6.1 Feed surfaces

NeuralMart keeps separate product surfaces:

### Creator Showcase Feed

Heterogeneous cards can reference:

- Creator Posts;
- Product listings;
- Service listings;
- eligible open Project briefs.

The Showcase remains discovery-first and social-paced.

### Opportunities/Contest Feed

High-intent, professional-paced cards can reference:

- open Contests;
- eligible open Project briefs.

The Opportunities Feed is opt-in and distinct from the Showcase Feed. Existing routes or UI labels may call it Contest Feed, but backend feed semantics remain contest plus project opportunities as approved.

### Marketplace search/catalog

Product/service grids and creator directories are discovery queries, not additional social feed source records.

## 6.2 Feed generation

MVP:

```text
query eligible source records in PostgreSQL
→ apply status, visibility, safety, relationship, and availability filters
→ combine supported card types
→ apply feed-specific lightweight ranking
→ return cursor-paginated card projections
→ record impressions asynchronously
```

The feed service can use source-specific queries or a rebuildable candidate projection. It must not create duplicate copies of Posts, Projects, Contests, Products, or Services.

## 6.3 Showcase ranking

Preserve the established direction:

- recency-first;
- modest quality/engagement adjustment;
- no opaque ML ranking requirement for MVP;
- avoid letting follower count or sales alone dominate exposure.

Any feed rank score is a projection. Source publication time, status, visibility, moderation, and ownership remain authoritative.

## 6.4 Opportunities ranking and filters

Preserve the established intent:

- value/prize and deadline urgency are prominent;
- contest and project cards are distinguishable;
- filters can include type, category, budget/prize, and deadline;
- opportunity eligibility depends on current state and permissions.

The exact ranking weights remain configurable; they are not persisted as source business truth.

## 6.5 Cursor pagination

Use opaque keyset cursors that encode stable ordering fields:

- rank key;
- published/created timestamp;
- source type;
- source ID tie-breaker.

Cursor validation is server-side. Reject malformed, expired, or cross-feed cursors. Avoid offset pagination for infinite scroll.

## 6.6 Filters and personalization

MVP personalization can use:

- followed creators;
- user-selected categories/skills;
- basic freshness;
- current role capability for CTA availability;
- exclude self where appropriate;
- exclude blocked/muted authors.

Personalization affects candidate order, not resource permissions or transaction eligibility.

Do not require inferred sensitive traits. Future recommendation systems must use consented, explainable signals and diversity controls.

## 6.7 Visibility and safety filtering

Before returning any card, apply:

- source status and publication window;
- public/follower/unlisted/private visibility;
- author account status and creator pause state;
- moderation restriction;
- block and mute relationships;
- participant-specific privacy;
- source ownership/availability state;
- user's own-content management behavior.

For an exclusive Project:

- exclude it from purchase/opportunity candidates if Ownership is transferred or an active exclusive reservation exists;
- do not trust a stale `status` alone;
- recheck current Ownership and availability before any action.

## 6.8 Feed response

Return a compact, typed feed item:

- source type and ID;
- card presentation fields;
- author/profile summary;
- media preview references;
- feed-specific action affordances;
- eligibility/availability presentation;
- stable item cursor.

Never include:

- private project attachments;
- order or payment internals;
- protected source files;
- hidden buyer information;
- permission decisions that the backend has not revalidated.

## 6.9 Performance evolution

At scale:

- cache public card fragments briefly;
- materialize eligibility/candidate projections;
- use hybrid fanout-on-read and fanout-on-write;
- continue to recheck privacy, moderation, availability, block, and ownership against authoritative state before serving/actions.

No fanout projection may make a sold exclusive project purchasable.

---

# 7. Content Management

## 7.1 Content records

The Content module manages:

- Posts and PostTypes;
- PostMedia relationships;
- visibility and lifecycle;
- links to Product, Service, Project, and Contest;
- Comments, Reactions, Saves, and Shares;
- moderation state.

Product, Service, Project, and Contest retain their dedicated domain models even when promoted in a Post.

## 7.2 Draft and publish lifecycle

```text
Draft
→ Scheduled (optional)
→ Published
→ Archived
→ Soft Deleted
```

Moderation is a separate overlay:

```text
Pending Review / Approved / Limited / Removed / Appealed
```

Publishing can update feed eligibility after the Post and media metadata are committed.

## 7.3 Create and edit

Create:

1. authenticate;
2. require Creator capability for public creator content;
3. validate text, media references, and typed links;
4. verify the user controls each linked object or has permission to reference it;
5. persist draft or publish command;
6. enqueue moderation/media processing and feed/search projection updates.

Edit:

- verify author or delegated permission;
- preserve created/published history;
- update only editable fields;
- append material audit/moderation events where required;
- invalidate stale projections.

## 7.4 Media upload

Backend flow:

```text
authorize upload intent
→ create pending Media metadata
→ issue bounded upload authorization
→ verify completion, size/type/checksum
→ scan and generate derivatives
→ mark Media available
→ attach to Post/listing/project/etc.
```

Large binaries stay in object storage. A client-supplied object key is never sufficient authorization.

## 7.5 Visibility and archive/delete

- visibility is checked on every read path;
- private/unlisted posts do not appear in public feed/search;
- archiving removes normal discovery but preserves history;
- soft delete removes public visibility and preserves required references;
- moderation removal and user deletion remain distinguishable;
- the same source Post remains used on profile, feed, and search surfaces.

## 7.6 Links to marketplace objects

Use typed links to:

- Product;
- Service;
- Project;
- Contest;
- contest entry/result;
- completed work where sharing is allowed.

The backend validates:

- object exists;
- user may link it;
- object is visible in this context;
- object is not sold/locked when the CTA implies availability;
- privacy and rights allow preview.

## 7.7 Mobile-first contract

For mobile clients:

- drafts can be saved incrementally;
- uploads expose resumable/pending state where supported;
- publishing is one explicit action;
- retrying publish is idempotent;
- media previews are generated server-side;
- upload failure does not silently publish broken content.

---

# 8. Marketplace Backend

## 8.1 Domain separation

The Marketplace module coordinates catalog listing and discovery but preserves separate models:

| Object | Commercial meaning |
|---|---|
| Product | Buy an existing digital asset/license |
| Service | Book bounded creator work under package/scope terms |
| Project | Buyer broadcasts custom work for proposals |
| Exclusive Project/Product | Sell Once ownership transfer |
| Contest | Fixed rules and prize; creators submit entries |

## 8.2 Product responsibilities

- product draft/publish/pause/archive;
- ProductVersion and file validation;
- ProductLicense selection and versioning;
- price and currency validation;
- regular vs exclusive availability;
- preview safety;
- purchase eligibility;
- search/feed eligibility.

Product purchase creates or references a universal Order and ProductPurchase/entitlement. It does not create a second product-specific order system.

## 8.3 Service responsibilities

- service and package CRUD;
- package pricing/delivery/revision/requirements;
- availability/capacity/pause state;
- public preview and portfolio proof;
- purchase eligibility;
- order package snapshot.

Pausing a service blocks new bookings but does not cancel existing Orders.

## 8.4 Exclusive project catalog responsibilities

- publish and expose eligible project/asset for exclusive purchase;
- validate seller authorization and project rights;
- return availability as a server-derived state;
- coordinate checkout with Payment, Order, and Ownership modules;
- set Sold/Locked only after atomic successful ownership assignment.

## 8.5 Pricing

The backend:

- loads price and license from authoritative listing records;
- recalculates total, fees, currency, and policy on checkout;
- validates discount and eligibility;
- snapshots purchased terms into Order/OrderItem;
- rejects client-submitted totals that differ from server calculation.

Use integer minor units for amounts. Preserve original currency.

## 8.6 Availability and inventory

For ordinary digital products:

- no finite inventory unless explicitly defined by listing policy;
- sale count is not the same as stock state.

For services:

- availability/capacity can pause new orders;
- existing orders remain valid.

For projects:

- status and selection rules govern proposal availability;
- a project can transition from open to selected/in progress.

For exclusive items:

- effective availability derives from listing state, reservations, policy, and Ownership;
- the client cannot set or override availability.

## 8.7 Search visibility

Search index writes happen asynchronously from committed source state. At result-serving/action time, the backend rechecks:

- published status;
- visibility;
- moderation;
- creator pause/restriction;
- sold/locked ownership;
- availability;
- blocked/muted relationships where applicable.

Search results never grant purchase, access, or ownership.

---

# 9. Exclusive Ownership

## 9.1 Canonical lifecycle

The complete server lifecycle is:

```text
Available
→ Checkout
→ Payment Validation
→ Ownership Lock
→ Sold
→ Ownership Transfer
```

The user may see a simpler sequence:

```text
Available
→ Purchase
→ Sold · Locked
→ Owned
```

The shorter UI sequence does not remove the backend phases.

## 9.2 Command ownership

The Commerce/Ownership orchestrator coordinates:

- current listing and rights validation;
- checkout idempotency;
- trusted Payment confirmation;
- exclusive item lock;
- Order/OrderItem creation;
- Ownership creation;
- Sold/Locked update;
- access/entitlement grants;
- timeline/outbox events.

Catalog owns listing truth before purchase. Ownership owns the post-transfer rights. Order owns the commercial transaction. Payment/Wallet owns money.

## 9.3 Payment validation

Payment validation must come from a trusted provider callback or verified provider query, not a client assertion.

The operation revalidates:

- current price/license/rights;
- item still available;
- no existing transferred owner;
- buyer eligibility;
- seller authorization;
- payment idempotency/reference;
- risk/policy holds.

## 9.4 Atomic ownership lock

After authoritative payment validation, the backend begins a database transaction:

1. Lock the exclusive Product/Project row or perform an atomic compare-and-set.
2. Recheck that no current transferred Ownership or live exclusive reservation exists.
3. Create or activate the universal Order and OrderItem.
4. Create Ownership and OwnershipTransfer records.
5. Set listing/project Sold/Locked summary.
6. Create entitlement/AccessGrant references required for the buyer.
7. Write timeline and outbox events.
8. Commit.

The Ownership record, Order linkage, and Sold/Locked state must commit together.

## 9.5 Race-condition prevention

Use all of:

- server-side idempotency key;
- payment provider idempotency;
- unique successful payment reference;
- row lock/compare-and-set;
- unique current Ownership constraint per exclusive object;
- unique successful exclusive Order/OrderItem constraint where applicable;
- retry that returns existing successful result;
- reconciliation for unknown outcomes.

## 9.6 Failure handling

### Payment fails

- no Ownership is committed;
- no Sold/Locked state is committed;
- failed PaymentAttempt is retained;
- the item remains available unless another purchase committed.

### Payment succeeds but ownership/order transaction fails

- do not claim ownership to the buyer;
- place transaction in pending reconciliation;
- retry with the same idempotency identity;
- if still unavailable, void authorization or issue a compensating refund for captured funds;
- record a timeline/financial outcome and notify the buyer.

### Timeout or unknown result

- query provider and authoritative Order/Ownership state;
- retry idempotently;
- block a second purchase attempt while unresolved;
- do not treat timeout as proof of failure.

## 9.7 Refund and reversal

An ordinary refund:

- can revoke/restrict access according to rights and policy;
- updates financial state;
- preserves Ownership and Sold/Locked history;
- does not relist the item.

An ownership reversal requires an explicit authorized OwnershipTransfer/reversal event, with audit and policy approval.

---

# 10. Project Backend

## 10.1 Responsibilities

The Project module owns:

- project draft and publication;
- brief, category, skills, budget, deadline, visibility;
- attachments and privacy;
- proposal intake eligibility;
- project status;
- shortlist and selection;
- conversion to accepted contract and universal Order;
- links to project conversations.

The Project module does not own:

- proposal negotiation details beyond references/status;
- payment ledger;
- Order fulfillment state after contract creation;
- ownership transfer unless the project itself is sold exclusively.

## 10.2 Project creation and publishing

Flow:

```text
Buyer capability check
→ create draft
→ validate required brief, category, budget/deadline rules
→ attach authorized Media
→ save/publish
→ assign project visibility/feed eligibility
→ notify/index asynchronously
```

Publishing requires:

- valid buyer/owner;
- complete required fields;
- legal/policy acceptance where applicable;
- attachment access rules;
- budget/deadline validity;
- no active restriction.

## 10.3 Editing

Before proposals:

- owner may edit allowed fields;
- material changes update project version or audit snapshot.

After proposals:

- preserve prior brief versions;
- notify affected proposers if terms materially change;
- avoid silently changing budget, deadline, rights, or deliverables relied on by proposals.

After selection/Order:

- Order/ProjectContract is the fulfillment source of truth;
- changes require an explicit change request/new accepted offer/new Order where appropriate;
- listing edits cannot mutate contracted terms.

## 10.4 Project statuses

Preserve established lifecycle:

```text
Draft
→ Open
→ Reviewing Proposals
→ Shortlisted
→ Creator Selected
→ In Progress
→ Awaiting Delivery
→ Revision Requested
→ Completed
→ Closed
```

Alternative states include Paused, Cancelled, Expired, and Disputed. Dispute is an overlay where appropriate and does not erase the prior primary state.

Project status and Order status are related but not interchangeable.

## 10.5 Shortlist and selection

Shortlist:

- buyer-private;
- references Proposal/ProposalVersion;
- can be changed without mutating the proposal;
- does not automatically notify the creator for every change.

Selection:

1. verify buyer owns project;
2. verify project accepts selection;
3. verify proposal/version is current and eligible;
4. record ProjectSelection with actor/time;
5. close or update competing proposal states according to policy;
6. create final contract/offer snapshot;
7. obtain buyer confirmation;
8. initiate payment;
9. create ProjectContract + universal Order only after required confirmation/payment state;
10. create/link fulfillment Conversation and publish status events.

Selecting a proposal is not equivalent to payment or order completion.

## 10.6 Project chat

Pre-selection conversations can link to Project and Proposal. After contract creation, add an Order/ProjectContract reference to the appropriate Conversation. Preserve prior messages and proposal versions.

Chat requests actions; Project/Order services validate and commit them.

## 10.7 Contest conversion

If a Project is converted into a Contest:

- create a distinct Contest and source-project reference;
- preserve the original Project and proposal history;
- do not transform proposals into entries;
- close or retain project proposal intake according to an explicit conversion action;
- require contest prize/rules/rights to be established before opening.

---

# 11. Bidding / Proposal Backend

## 11.1 Responsibilities

The Proposal module owns:

- submission eligibility;
- proposal draft and immutable versions;
- price/timeline/pitch/deliverables/samples;
- proposal status history;
- creator tracking;
- buyer response/shortlist/selection references;
- proposal-to-contract handoff.

## 11.2 Submission

Submission validates:

- authenticated User has Creator capability;
- Project is open and accepts proposals;
- user is not the project owner where self-bidding is prohibited;
- user has not been restricted from bidding;
- required proposal fields are present;
- price/currency and timeline are valid;
- attachments are authorized;
- project invitation/eligibility requirements pass;
- idempotency key has not already created this submission.

Duplicate proposal policy must be explicit. MVP recommendation:

- permit one active proposal per Creator per Project;
- edits create a new ProposalVersion on that proposal;
- if alternatives are later allowed, represent them explicitly as proposal variants rather than duplicate accidental submissions.

This is a backend policy recommendation, not a new account role.

## 11.3 Proposal versions and editing

Material edits create an immutable ProposalVersion:

- original price and scope remain auditable;
- buyer sees the current accepted version;
- buyer can compare negotiation versions where authorized;
- selected version is snapshotted into ProjectContract/Order.

After selection or order conversion, further commercial changes require an explicit offer/change path; do not overwrite the selected proposal.

## 11.4 Proposal status and tracking

Statuses may include:

```text
Draft
Submitted
Viewed
Shortlisted
Clarification Requested
Negotiating
Selected
Declined
Withdrawn
Expired
Superseded
```

Tracking:

- proposal views and outcomes may emit analytics;
- creator dashboards show their own submissions and status;
- buyers see proposals for their own projects only;
- private buyer shortlist notes remain private.

## 11.5 Acceptance and rejection

Acceptance:

- is initiated by authorized project owner;
- records selected proposal/version;
- triggers final contract/offer confirmation;
- requires payment/order workflow before fulfillment begins.

Rejection:

- records actor/time/reason category where policy allows;
- does not delete the Proposal or its versions;
- may notify the creator according to product policy.

## 11.6 Withdrawal

A creator may withdraw while the proposal is eligible and before an incompatible selected/contract state. Withdrawal:

- changes Proposal status;
- preserves versions and history;
- may invalidate shortlist/selection eligibility;
- emits a material event.

After contract/order creation, the creator uses Order cancellation/support workflows, not proposal withdrawal.

## 11.7 Proposal statistics

Use AnalyticsEvent and derived Bid Insights for:

- submitted;
- viewed;
- shortlisted;
- clarification requested;
- selected;
- converted to ProjectContract/Order.

Do not compute proposal success from client impressions alone or mix contest entries and product purchases into proposal metrics.

---

# 12. Contest Backend

## 12.1 Responsibilities

The Contest module owns:

- contest draft, rules, schedule, and visibility;
- prize structure and funding gate reference;
- entry eligibility and submissions;
- entry versions and files;
- shortlist/finalist state;
- winner selection and confirmation;
- contest completion state;
- transfer handoff to Contest Prize Order, Ownership, and payout modules.

## 12.2 Creation and publication

Creation captures:

- host/buyer;
- brief and deliverables;
- category/skills;
- visibility and entry access;
- entry deadline and judging dates/timezone;
- judging criteria;
- winner count/prize allocation;
- rights/ownership terms;
- cancellation/refund policy references.

Before opening:

- required fields validate;
- contest rules are versioned and accepted;
- prize funding is confirmed under the financial workflow;
- moderation/policy checks pass;
- entry and rights terms are visible to creators.

Contest prize funding and Contest status remain separate state dimensions.

## 12.3 Entry submission

Validate:

- Creator capability active;
- Contest accepts entries and deadline has not passed;
- creator meets eligibility rules;
- entry count/format limits;
- submission files are uploaded, scanned, and authorized;
- user is not restricted;
- idempotency prevents duplicate submit from retry.

Contest rules control multiple entries, updates, blind judging, and eligibility. The backend enforces the published rule version captured at submission.

## 12.4 Entry updates and withdrawal

Entry changes:

- create a new EntryVersion or append-only submission revision;
- preserve prior files/versions;
- follow the contest's published update rules;
- do not let a changed rule retroactively invalidate an accepted entry.

Withdrawals:

- preserve the entry history;
- prevent judging/selection if withdrawn under contest policy;
- record actor/time and reason category if supplied.

## 12.5 Shortlisting and judging

- shortlisting is distinct from winner selection;
- host/judge permissions are scoped to that Contest;
- private judge notes are not returned to entrants;
- entry files remain creator-controlled unless contest rights explicitly state otherwise;
- judging events are auditable;
- blind judging, multiple stages, and paid finalist rounds are future extensions, not MVP assumptions.

## 12.6 Winner selection

Selection must be atomic and idempotent:

1. verify host/judge authority;
2. verify Contest state and judging window;
3. verify selected Entry is eligible and not withdrawn/disqualified;
4. lock Contest/winner-selection scope;
5. ensure winner count and prize allocation remain valid;
6. create ContestWinner record(s);
7. create/activate Contest Prize Order(s);
8. record prize hold/funding reference;
9. notify participants through outbox;
10. commit the selection event.

A repeated selection command with the same idempotency key returns the existing result. Conflicting selections are rejected or resolved through an explicit admin procedure.

## 12.7 Prize, rights, and ownership

- winner selection does not itself transfer ownership;
- prize payment/payout state is managed by Payment/Wallet/Order;
- rights use the versioned Contest rules and winner terms;
- ContestOwnership and Ownership are created only when the rights-transfer conditions are met;
- non-winning entries remain creator-owned unless separately licensed or purchased.

## 12.8 Completion

Contest completion requires:

- judging/winner state resolved;
- prize Order fulfilled or explicitly resolved;
- final deliverables/rights complete where applicable;
- payout/hold state handled;
- no unresolved blocking dispute or safety hold.

Contest may be visually complete while a prize/dispute overlay remains unresolved; the backend must expose those states rather than falsely marking the transaction settled.

## 12.9 Invalid/duplicate submission safeguards

Use:

- unique entry submission idempotency keys;
- configured entry-count constraints;
- unique or policy-bounded active entry rules;
- server-side deadline/timezone evaluation;
- scanned Media required before final submission;
- eligibility and account restriction checks;
- immutable rule/version snapshot;
- atomic winner selection and prize allocation;
- append-only audit events for admin overrides.

---

## Mobile-First Backend Contract

Backend workflows should be simple to invoke from a mobile client:

- small purpose-specific commands;
- clear `nextAction` and current status in responses;
- cursor pagination for feeds and lists;
- resumable or retry-safe upload flows where supported;
- idempotency keys on checkout, publish, proposal, entry, and winner commands;
- explicit `pending/reconciling` responses for external processing;
- no client-side workflow assumptions that bypass server validation.

Clients may request actions; only the backend decides whether the action is valid.

---

## Handoff Summary for Part 2

Part 2 should continue by defining the backend services and transaction boundaries for:

1. Universal Order creation and lifecycle commands for every approved order type.
2. Payment-provider integration, idempotency, webhook verification, reconciliation, and compensation.
3. Wallet, immutable ledger, SellerEarning, PlatformFee, refunds, withdrawals, and payout holds.
4. Chat-commerce Offers and PaymentRequests that link to Orders without making Chat authoritative.
5. Locked file delivery, AccessGrant checks, DeliveryVersion, Revision, approval, and completion.
6. Order-level dispute integration, support escalation, and audit boundaries.
7. Verified Reviews/Ratings, Badge/Reputation updates, and notification/outbox processing.
8. Error contracts, retries, background jobs, observability, and operational safety.

All Part 2 workflows must use the modular-monolith boundaries here and preserve the database invariants in Prompt #36 Parts 1–3.

