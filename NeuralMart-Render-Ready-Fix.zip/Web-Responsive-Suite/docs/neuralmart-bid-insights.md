# NeuralMart — Bid Insights

**Document version:** 1.0  
**Primary route:** `/dashboard/creator/insights/opportunities`  
**Audience:** Creator and Both users; limited project-level view for Buyers

---

## 0. What Bid Insights Means

Bid Insights is the private performance layer for proposal-based work.

It explains the funnel:

```text
Eligible project views
→ Proposal starts
→ Proposals submitted
→ Proposal viewed
→ Buyer replies
→ Shortlisted
→ Accepted
→ Completed and paid
```

It is not a public creator score, a leaderboard, or a guarantee of winning.

### Difference from other analytics

- **Content Insights:** how Showcase content creates discovery and demand.
- **Bid Insights:** how creator offers perform after a project opportunity is found.
- **Contest Insights:** how contest entries perform under contest rules.

These can link together but should not be combined into one misleading win rate.

---

## 1. Access and Privacy

### Creator access

Creator and Both users can see their own proposal performance.

They can see:

- their own proposal funnel;
- their own response behavior;
- their own accepted work;
- aggregate project-category patterns;
- recommendation explanations.

They cannot see:

- another creator's private win rate;
- buyer-private selection notes;
- hidden buyer identities;
- internal marketplace risk scores.

### Buyer access

Buyers can see project-level analytics for projects they own:

- views;
- proposals received;
- proposals opened;
- shortlist count;
- average proposed price;
- time to first proposal;
- project response rate.

They do not see a creator's private cross-project performance or hidden Bid Insights.

### Admin access

Admin analytics are separate operational tooling and do not appear as creator-facing Bid Insights.

---

## 2. Where It Lives

### Creator Dashboard

```text
Creator Dashboard
├── Insights
│   ├── Overview
│   ├── Content
│   ├── Commerce
│   ├── Opportunities
│   │   ├── Bid Insights
│   │   └── Contest Insights
│   └── Recommendations
```

### Menu

```text
Menu
→ Work Center
→ My Proposals
→ Bid Insights
```

The dashboard route is canonical. Menu is a shortcut.

### Project-level access

From a proposal card:

```text
View proposal → See how this proposal is performing
```

From a buyer-owned project:

```text
Manage project → Project insights
```

---

## 3. Overview Metrics

Show four primary metrics:

| Metric | Meaning |
|---|---|
| **Proposals submitted** | Number of eligible submitted proposals |
| **Proposal view rate** | Percentage opened by buyers |
| **Shortlist rate** | Percentage shortlisted after review |
| **Win rate** | Percentage accepted, using a meaningful sample |

Secondary metrics:

- Buyer reply rate
- Median time to buyer reply
- Median proposed price
- Median delivery time
- Accepted project value
- Completed project value
- Withdrawal rate
- Proposal-to-chat rate

### Example

```text
BID INSIGHTS · LAST 90 DAYS

Proposals     Viewed         Shortlisted       Won
24            79%            29%               17%

Median offer  $1,150
Median delivery 8 days
Buyer reply rate 42%
```

If there are too few proposals:

```text
Not enough data for a reliable win rate.
Submit 5 more proposals to see a meaningful trend.
```

Do not present a 100% win rate from one proposal as a major success claim.

---

## 4. Funnel Views

### Proposal funnel

```text
42 matched projects
  28 opened
    24 proposals submitted
      19 viewed
        7 shortlisted
          4 accepted
            3 completed
```

### Drop-off interpretations

- Low project-to-proposal rate → opportunity fit or creator capacity issue.
- Low proposal view rate → title, first lines, price, or samples may need improvement.
- High views but low shortlist rate → pitch, price, delivery, or evidence may not match.
- High shortlist but low acceptance → follow-up, negotiation, or availability may be the issue.
- High acceptance but low completion → delivery planning or scope clarity may need work.

The system should distinguish observed data from recommendations.

---

## 5. Breakdown and Comparison

Allow filters:

- Date range
- Category
- Skill
- Project type
- Budget range
- Price position relative to buyer budget
- Delivery range
- New versus repeat buyer
- Proposal version

### Useful comparisons

```text
Proposal performance by category
Branding       24% win rate
UI/UX          14% win rate
Motion          8% win rate
```

```text
Price position
Below buyer range       18% win rate
Within buyer range      21% win rate
Above buyer range       11% win rate
```

Show minimum sample warnings and avoid implying that price alone causes selection.

### Buyer-facing project insights

For buyers:

- project views;
- proposals received;
- first proposal time;
- average/median price;
- proposal quality completion;
- shortlisted count;
- time to selection.

Buyer insight recommendations can include:

- clarify the brief;
- improve budget transparency;
- add reference assets;
- respond to shortlisted creators;
- reduce unnecessary required fields.

---

## 6. How Bid Insights Improve Win Rates

Recommendations should be attached to a measurable pattern:

```text
Your proposals are viewed often but shortlisted less often
than your category average.
Add one sentence explaining your approach and attach a more
relevant case study.
[Edit proposal template]
```

### Recommendation categories

- Pitch specificity
- Relevant sample selection
- Price positioning
- Timeline confidence
- Availability clarity
- Scope assumptions
- Follow-up timing
- Category selection
- Proposal completeness

### Creator experiments

Advanced:

- Test two pitch openings.
- Compare one versus three samples.
- Compare fixed price versus range.
- Compare shorter versus more detailed scope assumptions.
- Track outcomes by proposal template.

Experiments must not expose buyer information or encourage spam submissions.

### Healthy guidance

- Recommend fewer, better proposals.
- Do not reward mass applications.
- Include buyer response rate as context.
- Account for project quality and category fit.
- Separate a creator-controlled metric from a buyer-controlled metric.

---

## 7. MVP vs Advanced

### MVP

- Proposals submitted
- Proposal views
- Buyer replies
- Shortlists
- Accepted proposals
- Win rate with sample-size caveat
- Median proposed price
- Median delivery time
- Category breakdown
- Basic funnel
- One recommendation
- Creator-only privacy
- Buyer-owned project summary

### Advanced

- Proposal version analytics
- Price/timeline positioning
- Template experiments
- Category benchmarks
- Buyer response-quality adjustment
- Revenue and repeat-buyer attribution
- Forecasted opportunity fit
- Proposal quality checks
- Team/agency analytics
- Exports
- Opportunity alerts

## Final rule

Bid Insights should help a creator improve the next proposal, not make them chase a vanity win rate or submit more low-quality bids.
