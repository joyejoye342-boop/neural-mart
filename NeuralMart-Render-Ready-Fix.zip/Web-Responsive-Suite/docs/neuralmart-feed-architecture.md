# NeuralMart — Complete Feed Architecture

**Document version:** 1.0  
**Companion to:** `neuralmart-home-page-architecture.md` · `neuralmart-navigation-hub-system.md` · `neuralmart-ux-design-system.md`  
**API foundation:** `/api/feed/showcase` · `/api/feed/opportunities` · `/api/feed/home`

---

## 0. The Core Insight

Most platforms give every user the same feed. NeuralMart cannot do that cleanly because it has two distinct user modes with different production/consumption relationships:

- **Buyers** are consumers of creative work and producers of briefs (projects, contests).
- **Creators** are producers of creative work and consumers of briefs.

These are inverse relationships on the same platform. If you show a pure creator post feed to a buyer, they see beautiful content but no way to act on it commercially. If you show a pure project/contest feed to a creator, they see only buyer requests with no peer inspiration or community signal.

The resolution is **not** to build two different apps or two different home screens. It's to build **one unified home feed** that serves both roles simultaneously, with separate specialized feeds for high-intent, high-stakes actions that deserve their own focused surface.

**Design axiom:** The home feed is always a creative showcase. The opportunities feed is always opt-in. Role only changes what you can *do* from each feed, not what you *see*.

---

## 1. Full Feed System Map

NeuralMart has **three distinct feed surfaces**, each with its own purpose, URL, API endpoint, and visual identity. There is also one cross-cutting **search/filter surface** that is not a feed but surfaces feed-like results.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        NEURALMART FEED SYSTEM                           │
├─────────────────────────┬──────────────────────────────────────────────┤
│  FEED 1                 │  FEED 2                 │  FEED 3             │
│  SHOWCASE FEED          │  OPPORTUNITIES FEED     │  MARKET FEED        │
│  / (home)               │  /contest-feed          │  /products          │
│  /api/feed/showcase     │  /api/feed/opportunities│  /api/products      │
│                         │                         │                     │
│  Universal default      │  High-intent, opt-in    │  Purchase-first     │
│  Creator content        │  Briefs + competitions  │  Grid, not stream   │
│  Social pacing          │  Professional pacing    │  Not a true feed    │
│  All roles              │  All roles (role-aware) │  All roles          │
├─────────────────────────┴──────────────────────────────────────────────┤
│  CROSS-CUTTING: Search overlay · /explore creator directory             │
│  (Not feeds — discovery surfaces that draw from multiple feed sources)  │
└─────────────────────────────────────────────────────────────────────────┘
```

**What is a "feed" in this system:**  
A feed is a vertically scrolling, reverse-chronological (or ranking-weighted) stream of heterogeneous cards. It is not a grid, a directory, or a search results page. The Market (`/products`) is a grid/directory, not a feed — it's excluded from the feed architecture even though it shows dynamic content.

---

## 2. Feed 1 — Showcase Feed (Home)

### 2.1 Identity

| Property | Value |
|---|---|
| **Route** | `/` |
| **API endpoint** | `GET /api/feed/showcase` |
| **Default for** | All authenticated users on first open |
| **Visual identity** | Platform default — primary blue accent, standard card style |
| **Pacing** | Social (dense, scrollable, like Instagram or LinkedIn) |
| **Infinite scroll** | Yes |

### 2.2 Purpose

The Showcase Feed is NeuralMart's heartbeat. It serves three simultaneous goals:

1. **For Buyers:** Discover creator talent passively. See what's being made, who's doing great work, what's available to buy. Never need to search; talent comes to them.
2. **For Creators:** Broadcast their work, get social signals (likes, comments, follows), and build an audience. Peer inspiration — see what other creators are shipping.
3. **For the platform:** Create the social gravity that makes NeuralMart a destination, not just a transactional tool. The feed is what makes users open the app daily, not just when they have a project to post.

### 2.3 Who Sees It

**Everyone.** All authenticated roles (buyer, creator, both, admin) see the same Showcase Feed content. Role determines only what appears in the composer card above the feed, and what CTA buttons appear inside certain card types.

There is no "Buyer's Home Feed" vs "Creator's Home Feed" — that bifurcation would be a major product mistake. It would mean buyers only see buyer-relevant content (which isolates them from discovering creators) and creators only see creator content (which cuts them off from buyer briefs). The unified feed is the discovery engine for both directions.

### 2.4 Content Types in the Showcase Feed

The feed is heterogeneous — it contains four card types interleaved in a single stream. This is the key architectural decision: **the feed is not just creator posts.** Buyer project briefs appear here too, making the home feed the discovery mechanism for freelance opportunities without requiring a separate browse.

| Card type | % of feed (target) | Source | Created by |
|---|---|---|---|
| **Creator Post** | ~55% | `posts` table | Creators, Both |
| **Product listing** | ~20% | `products` table | Creators, Both |
| **Service listing** | ~10% | `services` table | Creators, Both |
| **Open Project brief** | ~15% | `projects` table (`status = 'open'`) | Buyers, Both |

**Why Open Project briefs in the Showcase Feed:**  
This is the answer to the brief's requirement that "creators should be able to access the audience project/contest ecosystem, but without making the home page messy." Projects in the feed look like a normal card — they don't interrupt the visual flow. But they let creators discover work opportunities *while they're in their normal browsing habit* (scrolling the home feed). The alternative (forcing creators to navigate to a separate Projects hub to discover work) creates friction and reduces proposal volume.

**What is NOT in the Showcase Feed:**
- Closed/completed projects (only `status = 'open'` projects appear)
- Contests (they have their own dedicated feed — Feed 2)
- Notifications or activity updates
- Platform announcements
- Promoted/sponsored content (in this version)
- Proposals or order updates (belong in Dashboard)

### 2.5 Card-Level Role Variance

The feed items are the same for all roles. Role changes only the CTA.

| Card type | Buyer sees | Creator sees | Both sees |
|---|---|---|---|
| Creator Post | Like · Comment · Share · [Follow creator] | Like · Comment · Share | Like · Comment · Share |
| Product card | **[Buy — $49 →]** · Save | View (own) or Buy (others') | Buy or View (own) |
| Service card | **[Book Now →]** · Save | View (own) or Book (others') | Book or View (own) |
| Open Project card | View Project → (read-only, no proposal CTA) | **[Send Proposal →]** · Save | **[Send Proposal →]** · Save |

The Open Project card is the clearest example of role-aware CTA logic: the card looks identical for all roles, but the action button differs based on who's viewing. Buyers can't propose on their own briefs or others' briefs (they're not the freelancer). Creators see the opportunity to bid. This is all controlled client-side by `user.role`.

### 2.6 Ranking & Sorting Logic

**Default sort:** Reverse-chronological with a mild recency-quality boost.

The full ranking formula (lightweight, not algorithmic ML):
```
score = created_at_unix_ms 
      + (like_count * 60000)           // +1 min per like
      + (comment_count * 120000)        // +2 min per comment
      - (hours_since_posted * 1800000)  // -30 min per hour old
```

This approximates "newest with viral boost." A post that's 6 hours old with 20 likes scores the same as a post from 2 hours ago with no engagement. After 24 hours, the engagement boost is effectively washed out by the time decay, returning the feed to pure chronological.

**Why not algorithmic / ML ranking:** NeuralMart is early-stage. Algorithmic ranking requires training data (clicks, dwell time, purchases attributed to feed position) that doesn't exist yet. The recency+engagement formula is transparent, predictable, and fair — creators know their content will be seen, which encourages them to post. Ship algorithmic ranking as a Phase 2 feature once click data exists.

**Filtering available to users:**
- None by default on the Showcase Feed home page — it's intentionally unsegmented to maximize serendipity and cross-role discovery.
- Within the `/explore` page (separate from the home feed), full creator filtering is available (by category, rating, price range).
- Users can follow specific creators — a "Following" tab is a planned addition to the home feed (see §10, Future State).

**Pagination:** Cursor-based. API returns `{ items: [...], nextCursor: "..." }`. Frontend requests `?cursor=X&limit=20`. Skeleton cards shown while loading next page.

### 2.7 Composer Integration (Role-Aware)

The composer sits above the feed, always first. It is the only role-differentiated element on the home page.

```
── Creator role ──────────────────────────────────────────────────────
[Avatar]  [  Share your latest work…  ]        ← taps → composer sheet
──────────────────────────────────────────────────────────────────────
[+ Post]           [🛍 Product]          [⚙ Service]

── Buyer role ────────────────────────────────────────────────────────
[Avatar]  [  What do you need help with?  ]    ← taps → project wizard
──────────────────────────────────────────────────────────────────────
[💼 Post Project]                 [🏆 Host Contest]

── Both role ─────────────────────────────────────────────────────────
[Avatar]  [  Share your latest work…  ]        ← creator prompt (primary)
──────────────────────────────────────────────────────────────────────
[+ Post]           [🛍 Product]          [⚙ Service]
[💼 Post a Project]               [🏆 Host a Contest]   ← outline strip
```

Buyer-posted projects feed into Feed 1 (the Showcase Feed) where creators discover them. Buyer-posted contests feed into Feed 2 (the Opportunities Feed) where they're given full contest-focused treatment. This routing is automatic — the user chooses "Post Project" or "Host Contest," the system places the content in the right feed.

### 2.8 Visual Identity

- **Primary accent:** Platform blue (`hsl(var(--primary))`)
- **Card style:** `bg-card border-border` with `rounded-2xl shadow-sm`
- **Post body:** `text-sm leading-relaxed text-foreground`
- **Timestamps:** `text-xs text-muted-foreground`
- **Project cards in this feed:** Uses a muted amber/warm tint for the card header badge (`[Open Project]`) to visually distinguish them from creator posts — but the card itself is the same white/card background, not a distinct colored card. Subtle differentiation, not jarring contrast.

---

## 3. Feed 2 — Opportunities Feed (Contest Feed)

### 3.1 Identity

| Property | Value |
|---|---|
| **Route** | `/contest-feed` |
| **API endpoint** | `GET /api/feed/opportunities` |
| **Default for** | Nobody — always opt-in navigation |
| **Visual identity** | **Amber / gold accent** throughout. Distinct from the primary blue home feed. |
| **Pacing** | Professional (less dense, more detail per card — prize amounts, deadlines, and entry counts are primary data) |
| **Infinite scroll** | Yes |

### 3.2 Purpose

The Opportunities Feed is the platform's high-intent surface. Every item in this feed represents an active financial opportunity — a buyer has put money or commitment on the table, and a creator can win or earn it.

This is a fundamentally different mode than the Showcase Feed:
- **Showcase Feed:** "What's being made?" — discovery, inspiration, community.
- **Opportunities Feed:** "What can I win or bid on?" — commercial intent, time-pressure, competition.

Separating these two pacing modes into separate surfaces is critical. If contests were in the home feed alongside portfolio posts, they'd create cognitive dissonance — the scrolling rhythm of "ooh, nice design post → ooh, beautiful photo → $500 logo contest ENDING IN 3 DAYS → nice video" is jarring. Contests demand attention and decision. Posts invite passive consumption. They belong in separate containers.

### 3.3 Who Sees It

**All roles** can access the Opportunities Feed. Role changes what they see and what actions are available.

| Role | What they see | Primary action |
|---|---|---|
| **Creator** | Full contest list + open project briefs | Submit entry · Send proposal |
| **Buyer** | Full contest list they've hosted + others' contests (read) + open projects (read) | Host Contest · Post Project |
| **Both** | Everything — can host and enter | Contextual (host own, enter others') |

**Navigation to the Opportunities Feed:**
1. Trophy icon in the mobile top app bar (fastest path — always visible)
2. "Contests" tab in the mobile bottom nav feature row
3. Desktop sidebar: "Contest Feed" secondary item (amber-styled, below divider)

### 3.4 Content Types in the Opportunities Feed

| Card type | % of feed (target) | Sort logic | Created by |
|---|---|---|---|
| **Active Contest** | ~70% | Prize amount DESC, then deadline ASC | Buyers, Both |
| **Open Project brief** | ~30% | Budget max DESC, then created_at DESC | Buyers, Both |

The Opportunities Feed combines both contests and open projects — they are both "someone with money is looking for a creator." Keeping them together makes this feed the single destination for a creator who is in "I want to earn" mode, without forcing them to check two separate pages (Contests page AND Projects page).

The 70/30 split is a starting target. It should be adjustable via an API weight parameter so the product team can tune it over time based on which content type drives more creator engagement.

**What is NOT in the Opportunities Feed:**
- Creator posts, products, or services (those are Showcase Feed content)
- Closed/completed contests
- Projects with status `in_progress`, `completed`, or `cancelled`
- Notifications

### 3.5 Card-Level Role Variance

| Card type | Buyer sees | Creator sees | Both sees |
|---|---|---|---|
| Contest card (own) | Manage → · View submissions | [Participate] → (if open) | Manage own · Enter others' |
| Contest card (others') | View (read-only) | **[Submit Entry →]** | **[Submit Entry →]** |
| Project card (own) | Manage → · View proposals | — (not shown if they're the owner) | Manage own · Bid on others' |
| Project card (others') | View (read-only) | **[Send Proposal →]** | **[Send Proposal →]** |

**Own content rule:** A user never sees their own contest or project with a participation CTA. If the logged-in user is the owner, the CTA becomes "Manage →" or "View Submissions →."

### 3.6 Sorting & Filtering

The Opportunities Feed is sorted **by urgency and value** by default, not by recency. This is the key difference from the Showcase Feed's recency-first ordering.

**Default sort:** `prize_amount DESC + budget_max DESC → deadline ASC (soonest first among equals)`

In practice: the most lucrative and most time-sensitive opportunities float to the top. A $5,000 contest ending in 2 days will always outrank a $100 contest ending next month, regardless of when they were posted.

**Available filters (filter row below the composer card):**

```
[All]  [Contests]  [Projects]  ──  [Category ▾]  [Budget ▾]  [Deadline ▾]
```

| Filter | Options |
|---|---|
| Type | All · Contests only · Projects only |
| Category | All · Branding · Motion · UI/UX · Photography · Writing · Music · Illustration · Video |
| Budget/Prize | Any · Under $100 · $100–$500 · $500–$2,000 · $2,000+ |
| Deadline | Any · This week · This month · No deadline |

Filters are additive (AND logic). Active filters show as filled chips; tapping a chip removes that filter.

### 3.7 Buyer Composer in the Opportunities Feed

Buyers and Both users see a composer card at the top of the Opportunities Feed:

```
┌─────────────────────────────────────────────────────────┐
│  [Avatar]  Ready to find your next creator?             │
│  ──────────────────────────────────────────────────────  │
│  [💼 Post a Project]         [🏆 Host a Contest]        │
└─────────────────────────────────────────────────────────┘
```

This is a simplified buyer composer (two buttons, no text input placeholder) that mirrors the home feed buyer composer. It's present here because the Opportunities Feed is the primary surface where buyers manage their hiring pipeline — they should be able to add new opportunities from within this feed.

Pure creators (role === 'creator') see the composer hidden or replaced by a heading: **"Active Opportunities — find work you love."** No composer appears for creators in this feed since they have nothing to publish here.

### 3.8 Visual Identity — Amber System

The Opportunities Feed uses amber/gold as its accent color throughout. This is not a cosmetic choice — it's a semantic one:

**Amber = money on the table.** Every amber element in the app carries the same meaning: there's a financial opportunity or transaction happening here. Consistent use of this semantic color makes the Opportunities Feed instantly recognizable as a different mode, even on peripheral vision.

Specific applications:
- Page header: Trophy icon in amber, "Opportunities" heading in foreground
- Contest card top border: `border-t-4 border-t-amber-500`
- Prize amount: `text-amber-500 font-bold font-serif text-2xl`
- Contest status badge: amber background
- "Submit Entry" CTA buttons: amber background (`bg-amber-500 text-white`)
- Project card budget: standard foreground (not amber — projects are less visually urgent than contests)
- "Send Proposal" buttons: primary blue (standard CTA color — proposals are a deliberate professional action, not a "grab this opportunity!" impulse)

---

## 4. Feed 3 — Market Feed (Products & Services)

### 4.1 Why This Is Classified as a Feed

The Market (`/products`, `/services`) is technically a grid/directory, not a social feed. It's included here because it shares the same data that appears as cards in Feed 1 (Product cards and Service cards in the Showcase Feed link directly to Market pages).

It is NOT a feed in the strict "vertically scrolling heterogeneous stream" sense. It behaves differently:
- Grid layout (2-column on mobile, 3-4 column on desktop) rather than single-column stream
- Filter-first interaction rather than scroll-first discovery
- Sorted by sales + rating rather than recency or engagement
- No composer — creators list products via the composer in Feed 1 or via `/products/new`

The Market is documented here for completeness and to clarify the content relationship between Feed 1 and the Market.

### 4.2 Relationship to the Showcase Feed

```
Showcase Feed (Feed 1)
  ↓ Creator posts a product
  ↓ Product card appears in Feed 1 feed stream
  ↓ Buyer taps the Product card
  ↓ Navigates to /products/:id (product detail page)
  ↓ From there, can tap [Buy Now] or navigate to creator's full Market via /creators/:id
  ↓ [Explore this creator's other work] → /creators/:id → their products tab
```

The Showcase Feed is the discovery mechanism. The Market is the destination after discovery. The two are linked but separate surfaces with separate purposes.

---

## 5. How Feed Switching Works

### 5.1 Mobile — Primary entry points

| From | To Showcase | To Opportunities |
|---|---|---|
| Anywhere in app | Tap **Home** in bottom nav | Tap **Contests** in bottom nav |
| Inside Showcase Feed | Already here | Tap **Trophy icon** in top bar |
| Inside Opportunities Feed | Tap **Home** in bottom nav | Already here |
| Inside any hub page | Tap **Home** in bottom nav | Tap **Contests** in bottom nav |

The Trophy icon in the top bar is a direct link to the Opportunities Feed — it is visible on every screen (top bar sticks to the top), making the Opportunities Feed accessible from anywhere in two taps maximum, even deep inside a product detail page.

### 5.2 Desktop — Primary entry points

| From | To Showcase | To Opportunities |
|---|---|---|
| Anywhere | Click **Home** in sidebar | Click **Contest Feed** in sidebar (secondary, amber) |

The desktop sidebar always shows both destinations simultaneously. "Contest Feed" sits below the main 5 nav items, separated by a thin divider, styled in amber. It's always visible but clearly secondary — it's not one of the main five destinations.

### 5.3 What switching feels like

Feed switches use the standard page transition: `fade-in + slide-in-from-bottom-4 at 500ms`. No horizontal swipe (swipe navigation is reserved for within-feed actions like dismissing a card, which may be added later). The transition is a soft page replace — the previous feed unmounts and the new one mounts.

**No pinned "Currently viewing: Showcase" indicator.** The visual identity of each feed (blue for Showcase, amber for Opportunities) makes it immediately clear which feed is active. The active nav item in the bottom bar and sidebar also provides confirmation.

### 5.4 No tab switcher on the home page

There is deliberately no tab bar at the top of the home page with "Showcase | Opportunities" tabs. Tabs on the home page create immediate visual clutter and split the user's attention on first open. The feeds are on separate routes (`/` and `/contest-feed`), not tabs of the same page. Navigation between them is via the nav bar, which is the correct mental model — these are different destinations, not views of the same content with a filter applied.

---

## 6. Role-Based Feed Visibility — Rules Without Confusion

### 6.1 The two confusion vectors to avoid

**Confusion vector 1: "I don't know which feed I'm looking at."**  
Resolved by: Visual identity differentiation (blue vs amber), URL differentiation (`/` vs `/contest-feed`), nav active state.

**Confusion vector 2: "Why am I not seeing my content in this feed?"**  
Resolved by: Clear documentation of what appears in each feed, and an empty state that explains why the feed is empty and what will populate it (e.g., "No open contests yet — host one or check back later").

### 6.2 Role visibility matrix

| Feed | Buyer | Creator | Both | Admin |
|---|---|---|---|---|
| Showcase Feed (Feed 1) | ✅ Can view | ✅ Can view + publish | ✅ Both | 👁 Read-only |
| Composer on Showcase | Buyer composer | Creator composer | Both composser | Hidden |
| Project cards in Showcase | View only | View + Propose | View + Propose | Read-only |
| Opportunities Feed (Feed 2) | ✅ Can view + host | ✅ Can view + participate | ✅ Both | 👁 Read-only |
| Composer on Opportunities | Buyer composer | Hidden (no publish action here) | Buyer composer shown | Hidden |
| Contest cards in Opportunities | View own contests + manage; view others' read-only | View all + participate in open ones | Full access both sides | Read-only |
| Market (Feed 3) | ✅ Browse + buy | ✅ Browse + sell | ✅ Both | 👁 Read-only |

**Admin visibility note:** Admin users see all feeds in read-only mode. They do not post content, place orders, or submit proposals through their admin account. If a staff member also wants to buy/sell, the design spec (role-permissions-model.md §2.1) recommends a separate personal account.

### 6.3 The "both" role — no context switch needed on feeds

`Both` users see the most complete experience on both feeds:
- Showcase Feed: Creator composer at top + Project cards with proposal CTA + buyer outline strip below composer.
- Opportunities Feed: Buyer composer at top + Contest cards with "Submit Entry" CTA + Project cards with "Send Proposal" CTA.

They never need to toggle a mode to access different actions. The feed surfaces all actions simultaneously based on the content card type, not on a global "I'm in buyer mode" toggle. This keeps the interface unified and avoids the multi-account feeling.

---

## 7. Creator Content Discovery for Buyers

### 7.1 The discovery loop

The Showcase Feed is designed so that buyers discover creators **passively, without intent.** They don't need to search, browse a category, or know what they're looking for. The feed brings creators to them.

```
Buyer opens app
  → Sees Showcase Feed (default landing)
  → Scrolls through creator posts, products, services
  → Sees a post by "Maya" — brand identity work for a fintech client
  → Taps "Maya"'s avatar
  → Lands on Maya's creator profile (/creators/:id)
  → Sees her services (Brand Identity Package, from $800)
  → Taps "Book Now →"
  → Enters the booking/order flow
```

This is the primary discovery loop. **No search required.** The buyer didn't know Maya existed; the feed surfaced her based on recency and engagement.

### 7.2 Secondary discovery: Search and Explore

For buyers with intent ("I need a motion designer for a product video"):
- **Search overlay** (top bar magnifier): type "motion designer" → see creators, services, products matching the term.
- **Explore hub** (`/explore`): browse creator categories → "Motion Design" → see all active motion creators.

### 7.3 Tertiary discovery: Open Project cards in the feed

Buyers who post projects get an interesting side effect: their project brief appears in the Showcase Feed where creators are browsing. The creator recognizes the need, proposes, and the buyer gets a proposal from someone whose work they hadn't seen before. This is reverse discovery — the buyer posts a brief and the feed connects them with talent who finds *them*.

This happens automatically when a buyer posts a project via the home composer. No additional action needed.

### 7.4 Feed-native conversion path (Post → Profile → Product → Checkout)

Every Post card has a direct path to commercial conversion:

```
[PostCard] → tap avatar/name → [CreatorProfile] 
                                    ↓
                              Products tab → [ProductCard] → [ProductDetail] → Buy
                              Services tab → [ServiceCard] → [ServiceDetail] → Book
```

And every Product/Service card in the feed goes directly to conversion:

```
[ProductCard in feed] → [Buy — $49 →] → [Checkout flow]
[ServiceCard in feed] → [Book Now →]  → [Booking flow]
```

The Showcase Feed has a 0-intermediate-step path to purchase for product cards, and a 1-intermediate-step path (service detail) for services. This is intentional — products are impulse purchases; services require more consideration.

---

## 8. Buyer Project Posting Integration

### 8.1 Where the buyer posts

Buyers can post projects from two surfaces:
1. **Home (Showcase Feed) composer** — "What do you need help with?" → [💼 Post Project]
2. **Projects hub** (`/projects`) — "Post a Project →" CTA at the hub top
3. **Opportunities Feed composer** — [💼 Post a Project] button

All three entry points go to the same flow: `/projects/new`. On success, `?returnTo=/` or `?returnTo=/contest-feed` sends the buyer back to the feed they came from.

### 8.2 Where the project appears after posting

A buyer-posted project appears in **two feeds simultaneously:**

| Feed | Appears as | Why |
|---|---|---|
| **Showcase Feed (Feed 1)** | Project card (`[Open Project]` badge) interspersed in the main creator stream | Creators discover it while doing their normal feed browsing |
| **Opportunities Feed (Feed 2)** | Project card in the full opportunities list | Creators who are in "active work hunting" mode also see it |

The project also appears on the Projects hub page (`/projects`) as a listed item for any creator who browses there directly.

### 8.3 Project card in the Showcase Feed — design constraints

The project card in the Showcase Feed has stricter design constraints than the full project detail card:

```
┌────────────────────────────────────────────────────────┐
│  [Avatar]  Maya's Company        [Open Project →]      │  ← header, muted amber badge
│  ────────────────────────────────────────────────────  │
│  Looking for a brand designer for our Series A         │  ← brief excerpt, 2 lines max
│  fundraise deck and investor materials.                 │
│                                                        │
│  Budget: $800 – $2,500  ·  Skills: Figma, Branding    │  ← key metadata, 1 line
│  ────────────────────────────────────────────────────  │
│  [💬 Send Proposal →]           12 proposals so far   │  ← CTA (creator) / count
└────────────────────────────────────────────────────────┘
```

**Constraints:**
- Maximum 2 lines of brief text — then truncated with "read more" that opens the project detail page
- No full skill list in the card — just the first 2–3 skills + "..." overflow
- No budget range histogram or proposal graph — that's for the detail page
- Proposal count shown ("12 proposals") signals competition level — helps creators decide whether to bother

**The card never shows the buyer's last name or company name unless publicly set** — buyer privacy is respected in the feed.

### 8.4 Project lifecycle in feeds

```
status = 'open'      → Appears in Showcase Feed + Opportunities Feed
status = 'in_progress' → Removed from both feeds (no longer recruiting)
status = 'completed'   → Removed from both feeds
status = 'cancelled'   → Removed from both feeds immediately
```

The feed API enforces the `status = 'open'` filter at the database level. Stale project cards never show in the feed.

---

## 9. How Creators Access the Opportunities Feed

### 9.1 Primary access path

The Opportunities Feed is opt-in for creators. They access it when they want to find work:

1. **Trophy icon in top bar** — most direct, always visible
2. **"Contests" tab in bottom nav** — standard navigation
3. **Desktop sidebar** — "Contest Feed" secondary nav item

The home feed passively surfaces open projects (§8.2), so creators can discover work without ever visiting the Opportunities Feed. The dedicated Opportunities Feed is for creators who are in active work-finding mode and want to see everything available.

### 9.2 Creator experience on the Opportunities Feed

When a creator lands on the Opportunities Feed, they see:

```
[Page header]
  🏆 Opportunities  
  "Find contests to enter and projects to bid on"

[Filter row]
  [All ▾]  [Contests]  [Projects]  |  [Category ▾]  [Prize/Budget ▾]  [Deadline ▾]

[Feed — sorted by prize amount DESC + deadline ASC]
  [Contest card — $1,500 Logo Design — ends in 4 days — 23 entries]
  [Contest card — $800 Motion Graphics — ends in 9 days — 7 entries]
  [Project card — $2,000 Brand Identity — open — 14 proposals]
  [Contest card — $500 Illustration — ends in 14 days — 41 entries]
  [Project card — $400 UI Design — open — 8 proposals]
  ...
```

There is no creator composer on this page — creators don't post here. The composer card is replaced by a subtle informational heading: **"Opportunities active now"** with a live count of open contests and projects.

### 9.3 Creator-specific feed personalization (future state)

Currently: All creators see all opportunities regardless of category.

**Phase 2 enhancement:** If a creator has set their category in `creator_profiles.category`, the Opportunities Feed can pre-filter to matching categories by default, with an "All categories" toggle to remove the filter. This reduces noise for a motion designer who doesn't want to see copywriting projects.

---

## 10. Ranking, Sorting, and Filtering — Per-Feed Specification

### Showcase Feed (Feed 1)

| Parameter | Default | Options |
|---|---|---|
| **Sort** | Recency + engagement boost | Chronological (future toggle) |
| **Filter** | None | None on home; full filters on `/explore` |
| **Personalization** | None (v1) | Following-only tab (Phase 2) |
| **Pagination** | Cursor-based, 20 items/page | — |
| **Content mix** | 55% posts, 20% products, 10% services, 15% projects | Platform-tunable weights |

**Ranking formula (v1):**
```
score = created_at_unix_ms 
      + (like_count × 60_000)      // +1 minute per like
      + (comment_count × 120_000)  // +2 minutes per comment  
      - (age_hours × 1_800_000)    // -30 minutes per hour of age
```

Applied per card type in the mix, then interleaved: don't show 5 product cards in a row even if they all score high. Enforce a "no more than 2 consecutive same-type cards" rule in the interleaving logic.

### Opportunities Feed (Feed 2)

| Parameter | Default | Options |
|---|---|---|
| **Sort** | Prize/budget DESC, deadline ASC | Prize ↑↓, Deadline ↑↓, Newest first |
| **Filter** | All types, all categories | Type, Category, Budget range, Deadline |
| **Personalization** | None (v1) | Category pre-filter based on creator profile (Phase 2) |
| **Pagination** | Cursor-based, 15 items/page | — |
| **Content mix** | 70% contests, 30% projects | Platform-tunable weights |

**Ranking formula (v1):**
```
score = (prize_amount × 1000)         // contests: prize amount
      + (budget_max × 500)            // projects: max budget weighted lower
      - (hours_until_deadline × 10)   // urgency bonus for approaching deadlines
                                      // (negative deadline = expired, filtered out by API)
```

---

## 11. Feed Cards — Component Specification

### PostCard (Showcase Feed)

```
┌──────────────────────────────────────────────────────┐
│  HEADER (48px)                                        │
│  [Avatar 36px]  [displayName · role-badge]  [⋯ more]│
│                 [timeAgo · "via NeuralMart"]          │
├──────────────────────────────────────────────────────┤
│  BODY                                                 │
│  [Post text — 1–5 lines, expand on tap]               │
│  [Cover image — aspect-[4/3], lazy load, bg-muted]   │
├──────────────────────────────────────────────────────┤
│  FOOTER (40px)                                        │
│  [♡ 24]  [💬 6]  [Share]  [Bookmark]                 │
└──────────────────────────────────────────────────────┘
```

Props: `post { id, content, imageUrl, createdAt, likeCount, commentCount, creator { id, displayName, avatarUrl, role } }`

### ProductCard (Showcase Feed, in-feed variant)

```
┌──────────────────────────────────────────────────────┐
│  HEADER (48px)                                        │
│  [Avatar 36px]  [displayName]  [[Product] badge]     │
├──────────────────────────────────────────────────────┤
│  THUMBNAIL — aspect-[4/3], always present            │
├──────────────────────────────────────────────────────┤
│  BODY (compact)                                       │
│  [Product Title — font-semibold]                     │
│  [Category tag]  ·  [$price — font-bold text-lg]    │
├──────────────────────────────────────────────────────┤
│  FOOTER                                               │
│  [♡ Save]              [(role-CTA) Buy → $49]        │
└──────────────────────────────────────────────────────┘
```

### ServiceCard (Showcase Feed, in-feed variant)

```
┌──────────────────────────────────────────────────────┐
│  HEADER (48px)                                        │
│  [Avatar 36px]  [displayName]  [[Service] badge]     │
├──────────────────────────────────────────────────────┤
│  BODY                                                 │
│  [Service Title — font-semibold]                     │
│  [Category] · [⭐ rating] [reviewCount reviews]      │
│  [From $price]                                       │
├──────────────────────────────────────────────────────┤
│  FOOTER                                               │
│  [♡ Save]              [(role-CTA) Book Now →]       │
└──────────────────────────────────────────────────────┘
```

Note: Service cards in the feed do NOT show a cover image by default (services are people/skills, not products). If the creator has set a `coverImageUrl` on the service, it shows as a compact banner. Otherwise, the category and rating metadata are the card's visual anchor.

### ProjectCard — Showcase Feed variant (compact)

```
┌──────────────────────────────────────────────────────┐
│  HEADER (48px)                                        │
│  [Avatar 36px]  [displayName]  [[Open Project →]]   │
│                                 ← muted amber badge  │
├──────────────────────────────────────────────────────┤
│  BODY                                                 │
│  [Brief excerpt — 2 lines max, truncated]            │
│  [Budget: $min – $max  ·  Skills: tag, tag, +N more] │
├──────────────────────────────────────────────────────┤
│  FOOTER                                               │
│  [N proposals · posted timeAgo]  [(CTA or View)]    │
│  Creator: [Send Proposal →]                          │
│  Buyer: [View Project →]                             │
└──────────────────────────────────────────────────────┘
```

### ContestCard — Opportunities Feed variant (full)

```
┌──────────────────────────────────────────────────────┐
│  AMBER TOP BORDER (4px, border-t-amber-500)           │
│  HEADER                                               │
│  [🏆 amber]  [Contest Title — font-bold]             │
│  [Category badge]  ·  [N entries]                    │
├──────────────────────────────────────────────────────┤
│  PRIZE HIGHLIGHT                                      │
│  Prize: [$amount — text-amber-500 text-3xl font-serif│
│          font-bold]                                   │
│  Hosted by: [Avatar mini] [displayName]              │
├──────────────────────────────────────────────────────┤
│  BRIEF                                                │
│  [2-line brief excerpt]                               │
│  Deadline: [📅 formatted date + days remaining]      │
├──────────────────────────────────────────────────────┤
│  FOOTER                                               │
│  Creator: [Submit Entry →  amber button]             │
│  Buyer (own): [Manage Contest →]                     │
│  Buyer (others'): [View →]                           │
└──────────────────────────────────────────────────────┘
```

### ProjectCard — Opportunities Feed variant (full)

```
┌──────────────────────────────────────────────────────┐
│  HEADER                                               │
│  [💼]  [Project Title — font-bold]                   │
│  [Category badge]  ·  [N proposals]                  │
├──────────────────────────────────────────────────────┤
│  BUDGET                                               │
│  Budget: [$min – $max — text-lg font-semibold]       │
│  Posted by: [Avatar mini] [displayName]              │
├──────────────────────────────────────────────────────┤
│  BRIEF                                                │
│  [3-line brief excerpt]                               │
│  Skills: [tag] [tag] [tag] [+N more]                 │
│  Deadline: [📅 date] or [No deadline]                │
├──────────────────────────────────────────────────────┤
│  FOOTER                                               │
│  Creator: [Send Proposal →  primary button]          │
│  Buyer (own): [Manage Project →]                     │
│  Buyer (others'): [View →]                           │
└──────────────────────────────────────────────────────┘
```

---

## 12. Visual Differentiation — Feed Identity System

The two feeds must be immediately distinguishable without reading any text. The differentiation operates on three levels:

### Level 1 — Accent color

| Feed | Accent color | Semantic meaning |
|---|---|---|
| Showcase Feed | Blue (`hsl(var(--primary))`) | Creative work, social, community |
| Opportunities Feed | Amber/gold (`amber-500`) | Money, competition, urgency, stakes |

Amber is applied consistently: Contest card top border, prize amounts, Submit Entry buttons, the Trophy icon, the "Contests" nav item hover/active state on desktop, and the Contest Feed page header.

### Level 2 — Card density and pacing

| Feed | Cards/screen | Card height | Primary data |
|---|---|---|---|
| Showcase | ~1.5 cards above fold | Variable (post body + image = ~280px) | Visual content, social signals |
| Opportunities | ~2–2.5 cards above fold | Consistent (~220px for contests, ~200px for projects) | Numbers: prize/budget, deadline, entry count |

The Opportunities Feed is deliberately more compact and number-forward. The Showcase Feed is more generous with image/visual space.

### Level 3 — Page header treatment

**Showcase Feed (Home):**
```
[No page header — composer card is the top element]
[Feed begins immediately after composer]
```

**Opportunities Feed:**
```
┌─────────────────────────────────────────────────────┐
│  🏆  Opportunities                    [N active now] │  ← amber icon, live count
│  "Find contests to enter and projects to bid on"    │  ← subtitle, muted
│  ─────────────────────────────────────────────────  │
│  [Filter row: All · Contests · Projects · Category ▾ · Budget ▾ · Deadline ▾]
└─────────────────────────────────────────────────────┘
```

The Opportunities Feed has a page header. The Showcase Feed does not. This reinforces the mode difference: the home feed is an ambient discovery surface (no heading needed, just scroll and see); the Opportunities Feed is a purposeful tool (context setting helps users orient before filtering and acting).

---

## 13. Feature Overlap Rules

These rules prevent the same content from appearing confusingly in multiple places or from creating contradictory experiences when a user navigates between feeds.

### Rule 1: Contests never appear in the Showcase Feed

Even though open contests are buyer-created content (similar to open projects), they do not appear in the Showcase Feed. Contests have deadlines, prize amounts, and entry counts — information that creates urgency and decision pressure. That pressure is appropriate in the Opportunities Feed and jarring in the leisure-browse Showcase Feed.

### Rule 2: Projects appear in BOTH feeds with different card variants

Open projects are surfaced in both feeds because they serve both passive discovery (Showcase) and active work-hunting (Opportunities). The card variant differs: compact in Showcase (2-line brief), fuller in Opportunities (3-line brief + skills + deadline). Both link to the same `/projects/:id` detail page.

### Rule 3: Creator posts, products, and services appear ONLY in the Showcase Feed

A creator's portfolio content never appears in the Opportunities Feed. The Opportunities Feed is buyer-generated (briefs and contests). Creator content in the Opportunities Feed would be irrelevant noise — a creator looking for work does not want to see other creators' portfolio posts when they're trying to find contests to enter.

### Rule 4: Own content appearance

| User type | Sees own open project in Showcase Feed? | Sees own contest in Opportunities Feed? |
|---|---|---|
| Buyer | Yes (can manage from card) | Yes (with "Manage →" CTA, not participation CTA) |
| Creator | N/A (can't post projects) | N/A (can't host contests) |
| Both | Yes (own projects shown with Manage CTA) | Yes (own contests shown with Manage CTA) |

A `both` user never sees their own content with a participation CTA. The system always detects owner status (`item.hostId === user.id` or `item.buyerId === user.id`) and swaps the CTA to "Manage →."

### Rule 5: Stale content removal

| Event | Showcase Feed | Opportunities Feed |
|---|---|---|
| Project status changes from 'open' → anything else | Removed immediately on next API call | Removed immediately |
| Contest status changes from 'open' → 'judging' or 'closed' | N/A (contests not in Showcase) | Removed from active list; moved to "Closed" section if user has a submission |
| Contest deadline passes but status still 'open' | N/A | Shown with "⚠ Past deadline" warning until status is updated |

### Rule 6: The "following" personalization is Feed 1 only

When the "Following" tab is added (Phase 2), it applies only to the Showcase Feed. Following is a social graph concept — you follow creators you like, you see their posts and products. The Opportunities Feed has no following concept — all opportunities are visible to all creators regardless of follow graph.

---

## 14. Phase 2 — Future Feed Enhancements

These are explicitly NOT in the v1 build but should be designed for from the start so the v1 architecture accommodates them.

| Enhancement | Which feed | What it does |
|---|---|---|
| **"Following" tab** | Showcase Feed | Second tab on the home feed — shows only posts/products/services from creators the user follows. Default tab remains "For You" (current feed). |
| **Creator category pre-filter** | Opportunities Feed | If `creator_profiles.category` is set, pre-filter Opportunities Feed to that category. Shows "Filtered for: Motion Design [✕ clear]" chip at the top. |
| **Feed item save/bookmark** | Both feeds | Bookmark icon on all card types. Saved items appear in `/menu → Saved` collection. |
| **Feed item report** | Both feeds | "⋯" overflow on all cards → "Report this content". Sends to admin moderation queue. |
| **ML-based ranking** | Showcase Feed | Replace the formula-based score with a trained ranking model once click/purchase data exists. |
| **Infinite refresh / "New posts" pill** | Showcase Feed | When new items arrive while the user is mid-scroll, show a floating pill "↑ 12 new posts" that taps to scroll-to-top and refresh. Don't auto-insert — it breaks reading flow. |
| **Contest submission tracker** | Opportunities Feed | For contests the user has entered, show a "My Submissions" section at the top of the Opportunities Feed (or as a Dashboard widget). |
| **Promoted opportunities** | Opportunities Feed | Buyers can pay to pin their contest or project to the top of the Opportunities Feed for 24h. Shown with "Promoted" label. Never in Showcase Feed. |

---

## 15. API Contract Summary

| Endpoint | Feed | Returns | Key params |
|---|---|---|---|
| `GET /api/feed/showcase` | Feed 1 | `{ items: FeedItem[], nextCursor }` | `cursor`, `limit` (default 20) |
| `GET /api/feed/opportunities` | Feed 2 | `{ items: OpportunityItem[], nextCursor }` | `cursor`, `limit` (default 15), `type` (all/contest/project), `category`, `minBudget`, `maxBudget`, `deadline` |
| `GET /api/feed/home` | Legacy | `{ items: [...] }` | Deprecated in favor of `/showcase` |

**FeedItem shape (Feed 1):**
```typescript
type FeedItem = {
  id: string;           // composite: "post-123", "product-456", "project-789"
  type: 'post' | 'product' | 'service' | 'project';
  score: number;        // ranking score, used server-side for sorting
  createdAt: string;    // ISO 8601
  post?: Post;
  product?: Product;
  service?: Service;
  project?: Project;
}
```

**OpportunityItem shape (Feed 2):**
```typescript
type OpportunityItem = {
  id: string;           // composite: "contest-123", "project-456"
  type: 'contest' | 'project';
  score: number;        // prize/budget + urgency score
  createdAt: string;
  contest?: Contest;
  project?: Project;
}
```

---

*End of document.*  
*Companion docs: `neuralmart-home-page-architecture.md` · `neuralmart-navigation-hub-system.md` · `neuralmart-ux-design-system.md` · `neuralmart-role-permissions-model.md`*
