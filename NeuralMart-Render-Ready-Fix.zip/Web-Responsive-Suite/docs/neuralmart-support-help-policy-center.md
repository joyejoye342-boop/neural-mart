# NeuralMart — Support, Help Center & Policy Center

**Document version:** 1.0  
**Scope:** Help discovery, self-service support, contact/ticket workflows, reports, disputes/refunds, and public policy access.  
**Entry points:** Menu → Help & Support · contextual Help links · payment/order/project/contest flows.

---

## 0. Product Goal

NeuralMart combines social discovery, creator services, projects, contests, payments, and chat-commerce. Users need help in very different moments:

- a Buyer cannot find a suitable creator;
- a Creator has a payout question;
- a project has a delivery or proposal dispute;
- a contest needs to be cancelled;
- a user wants to report unsafe content;
- someone needs to understand ownership or licensing.

These should not all open the same generic contact form. The support system uses progressive disclosure:

```text
Search answer
→ Use a guided self-service flow
→ Contact support with context already attached
→ Escalate to a dispute or safety workflow when required
```

The Help Center explains. Support resolves. The Policy Center defines the rules. They are related, but they are not the same destination.

---

## 1. Support Center Architecture

### Primary route tree

```text
/help
├── /search
├── /getting-started
├── /buying
├── /creating-and-selling
├── /projects
├── /contests
├── /payments
├── /orders
├── /messages
├── /account-and-security
├── /safety
├── /contact
├── /tickets
├── /tickets/:id
├── /report
├── /disputes
│   ├── /new
│   └── /:id
└── /policies
    ├── /terms
    ├── /privacy
    ├── /payments
    ├── /creator-rules
    ├── /contest-rules
    ├── /licensing
    └── /community-guidelines
```

### Support landing page

```text
┌────────────────────────────────────────────┐
│ How can we help?                           │
│ [Search help articles and policies      ]  │
├────────────────────────────────────────────┤
│ QUICK HELP                                 │
│ [Payment issue] [Order problem] [Account]  │
│ [Report content] [Project/contest issue]   │
├────────────────────────────────────────────┤
│ YOUR OPEN REQUESTS                          │
│ Payment question · Waiting for reply   ›   │
├────────────────────────────────────────────┤
│ BROWSE HELP                                │
│ Getting started                         ›  │
│ Buying and orders                        ›  │
│ Selling and creator work                 ›  │
│ Projects and proposals                   ›  │
│ Contests and submissions                 ›  │
│ Payments and wallet                      ›  │
│ Safety and account security              ›  │
├────────────────────────────────────────────┤
│ TRUST & POLICY                             │
│ Safety Center                            ›  │
│ Policies and agreements                   ›  │
└────────────────────────────────────────────┘
```

The landing page should show no more than four quick-help actions and six browse categories. Everything else is found through search or a category page.

---

## 2. Help Article Structure

### Article template

Every help article follows one predictable structure:

```text
Breadcrumb
Article title
Short answer / summary
Last updated date
Applies to: Buyer · Creator · Both

What to do
1. Step one
2. Step two
3. Step three

What happens next
Common questions
Related articles
[Was this helpful? Yes / No]
[Still need help? Contact support]
```

### Article requirements

- The first paragraph answers the question directly.
- Steps use numbered actions and exact UI labels.
- Payment and policy articles show the applicable policy link.
- Every article has an owner, review date, and version.
- The article identifies whether the behavior applies to Buyer, Creator, Both, or all users.
- A support CTA appears at the bottom and preserves the article context.
- Avoid technical language unless the user is troubleshooting a developer-facing integration.

### Help categories

| Category | Article topics |
|---|---|
| Getting started | Account creation, roles, profile setup, finding creators |
| Buying and orders | Product purchases, services, delivery, downloads, order completion |
| Creator work | Listings, availability, proposals, payouts, reviews |
| Projects | Posting briefs, proposals, selecting a creator, project lifecycle |
| Contests | Hosting, submissions, judging, winners, prize handling |
| Payments | Wallet, add funds, payment sharing, refunds, withdrawals |
| Messages | Conversations, payment requests, safety in chat |
| Account and security | Password, sessions, 2FA, recovery, privacy |
| Safety | Reporting, blocking, scams, harassment, suspicious activity |
| Policies | Terms, privacy, creator rules, licensing, contest rules |

### Search article behavior

- Search titles, headings, aliases, and structured tags.
- Start after two characters.
- Rank exact phrase matches first.
- Show a category label and a one-line answer preview.
- Offer filters for `Buying`, `Creating`, `Payments`, `Account`, and `Policies`.
- Include common user language: `money back`, `can't withdraw`, `remove account`, `someone copied my work`.
- Never expose private ticket content in public search.

---

## 3. Self-Service Help Flows

Before opening a ticket, the Support Center should offer guided flows for common problems:

### Payment issue

```text
What happened?
[Payment failed] [Charged but order missing]
[Refund question] [Wallet balance looks wrong]
[Withdrawal problem] [Payment request issue]
```

The flow checks relevant transaction/order state, explains the next step, and offers `Contact support` with the transaction attached if unresolved.

### Order issue

```text
Select order
→ What is wrong?
   [Not delivered] [Not as described]
   [Need a refund] [Cannot download]
   [Seller/buyer is unresponsive]
→ Recommended resolution
→ Contact seller or open dispute
```

### Account issue

```text
[Can't log in] [Password] [Email/phone]
[Suspicious activity] [Account restricted]
[Privacy question] [Delete account]
```

Security issues should route to secure recovery flows rather than asking users to include sensitive information in a ticket.

---

## 4. Contact Support / Ticket Flow

### Entry points

- Help Center → Contact support
- Menu → Help & Support → Contact support
- Bottom of every help article
- Payment/order/project/contest detail → contextual `Get help`
- Error states → `Report a problem` or `Contact support`

### Ticket flow

```text
1. Choose topic
2. Choose affected object, if applicable
3. Read suggested help articles
4. Describe the issue
5. Add evidence
6. Review privacy reminder
7. Submit
8. Track request in My support
```

### Topic selector

- Payments and wallet
- Product or service order
- Project or proposal
- Contest or submission
- Account and security
- Content and community
- Technical problem
- Other

### Ticket fields

| Field | Required | Notes |
|---|---:|---|
| Topic | Yes | Determines routing and suggested articles |
| Related object | When applicable | Order, project, contest, post, or transaction |
| Subject | Yes | Suggested from topic; editable |
| Description | Yes | Minimum useful description, plain language |
| Attachments | No | Screenshot, receipt, or relevant file |
| Preferred reply channel | Yes | In-app, email, or both |

The system should attach safe context automatically:

- user ID internally;
- related order/project/contest ID;
- current route;
- relevant status;
- client/browser diagnostics for technical reports.

Do not ask the user to paste passwords, card numbers, bank details, tokens, or session data.

### Ticket states

```text
Submitted
→ In review
→ Waiting for user
→ Waiting for third party
→ Resolved
→ Closed
```

Users can reopen a recently resolved ticket if the issue remains unresolved. Closed tickets become read-only after the retention window.

### Ticket view

Each ticket shows:

- topic and status;
- support replies;
- user replies;
- attached object summary;
- expected next step;
- last updated time;
- `Add information`;
- `Close request`;
- `Still not resolved` escalation action.

Support replies should appear in the existing Messages model only if the product intentionally treats support as a conversation. Otherwise, keep tickets separate and link to them from Messages.

---

## 5. Report a Problem Flow

Reporting is distinct from requesting help. A report may involve platform safety, content moderation, fraud, or a technical defect.

### Entry points

- Card overflow → Report
- User profile → Report
- Message → Report
- Help Center → Report a problem
- Error page → Report technical problem

### Step 1 — identify report type

```text
What would you like to report?
[Unsafe or abusive behavior]
[Scam or suspicious payment]
[Copyright or ownership concern]
[Inappropriate content]
[Spam or misleading listing]
[Technical bug]
[Other]
```

### Step 2 — attach context

The report automatically attaches the card, profile, message, order, or route from which it began. The user can add screenshots and an explanation.

### Step 3 — privacy and expectations

Show:

```text
Reports are reviewed by NeuralMart.
The person you report is not told who submitted the report,
except where required by law or a formal dispute process.
```

For urgent safety or account-compromise reports, show an immediate security action such as changing the password or revoking sessions.

### Report outcomes

Users receive a private confirmation and can track status where appropriate. Do not expose moderation decisions about another user's account. The reporter may receive only:

- received;
- under review;
- action taken where disclosure is allowed;
- no action or insufficient information.

---

## 6. Refund and Dispute Help Flow

Refunds and disputes need a guided path because product, service, project, and contest transactions have different evidence and deadlines.

### Unified entry

```text
Help → Payments and orders → Select transaction/order
→ Choose issue
→ Recommended resolution
→ Contact other party or open dispute
```

### Issue types

- Duplicate charge
- Unauthorized purchase
- Product unavailable or download failure
- Service not delivered
- Service materially not as described
- Project delivery dispute
- Contest cancellation or prize issue
- Payment request mismatch
- Refund already approved but not received

### Resolution ladder

```text
1. Explain the transaction state
2. Offer self-service fix
3. Encourage buyer/creator conversation where safe
4. Open a formal dispute if unresolved
5. Escalate to specialist review
6. Issue refund, partial refund, replacement, or close dispute
```

Do not force users to contact the other party first for unauthorized payments, harassment, fraud, or safety concerns.

### Dispute form

- Related order/transaction/project/contest
- Issue type
- Desired resolution
- Timeline of what happened
- Evidence upload
- Communication history, attached automatically where permitted
- Confirmation that the information is accurate

### Dispute states

```text
Draft
→ Submitted
→ Other party response
→ Specialist review
→ Decision issued
→ Appeal window
→ Closed
```

### Funds and communication safeguards

- Hold or protect unsettled funds while a qualifying dispute is active.
- Never release contest escrow during a prize dispute without review.
- Preserve relevant messages and transaction history for the retention period.
- Show deadlines clearly.
- Explain whether a refund returns to the wallet or original payment method.
- Distinguish platform fees from the underlying purchase amount.

The exact refund rules belong in the Payments, Fees & Refunds policy and should be linked from every refund decision.

---

## 7. Policy Center

### Purpose

The Policy Center is a searchable, versioned library of the rules governing NeuralMart. It is not a support ticket list and should not be buried under generic legal links.

### Policy Center structure

```text
POLICY CENTER
├── Terms of Service
├── Privacy Policy
├── Payments, Fees & Refunds
├── Marketplace and Creator Rules
├── Community and Content Guidelines
├── Contest Rules
├── Ownership and Licensing
├── Safety and Prohibited Conduct
├── Data Retention and Account Deletion
└── Agreement History
```

### Policy page template

```text
Policy title
Effective date · Last updated
Applies to
Short plain-language summary
Table of contents
Full policy
Related help articles
Download/print
Agreement status
```

### Essential launch policies

These should exist before public marketplace launch:

1. **Terms of Service** — account use, platform role, limitations, termination, dispute framework.
2. **Privacy Policy** — collection, use, sharing, retention, user rights, cookies/session data.
3. **Payments, Fees & Refunds** — wallet, platform fee, payout timing, withdrawals, refunds, disputes.
4. **Marketplace and Creator Rules** — listing quality, prohibited services/products, truthful claims, seller obligations.
5. **Community and Content Guidelines** — harassment, spam, abuse, illegal content, impersonation, moderation.
6. **Ownership and Licensing** — exclusive ownership, digital asset rights, buyer/creator responsibilities, future multi-license rules.
7. **Contest Rules** — prize funding, deadlines, submissions, judging, cancellation, winner selection.
8. **Safety and Prohibited Conduct** — scams, off-platform payment pressure, account abuse, manipulation.
9. **Data Retention and Account Deletion** — export, deactivation, deletion, transaction-record retention.

### Versioning and acceptance

- Every policy has an effective date and version.
- Store the policy version accepted by each user.
- Material changes create an in-app action-required notice.
- Users can view their agreement history.
- Registration and relevant actions link directly to the applicable policy.

---

## 8. Fast Help from the Menu

The Menu / Control Center should contain:

```text
HELP & TRUST
Help Center                              ›
Contact support                          ›
Report a problem                         ›
Safety & disputes                        ›
Policies and agreements                  ›
```

### Contextual shortcuts

When the user has a relevant unresolved state, show one compact status row:

- `Withdrawal needs attention`
- `Order delivery is overdue`
- `You have an open support request`
- `Policy review required`

Do not create a permanent notification wall in Menu. Action-needed rows disappear when resolved.

### Search integration

Menu search should return Help Center and Policy Center destinations alongside settings:

| Query | Result |
|---|---|
| `refund` | Refund help flow, Payments policy |
| `can't withdraw` | Withdrawal help, Payout settings, Contact support |
| `copied my work` | Ownership & Licensing, Report a problem |
| `contest prize` | Contest rules, Contest support |
| `scam` | Safety Center, Report a problem |
| `delete account` | Account deletion guide, Danger Zone |

Search results should show whether the destination is an article, guided flow, policy, or contact route.

---

## 9. Role-Aware Support

| Topic | Buyer emphasis | Creator emphasis | Both |
|---|---|---|---|
| Payments | Funding, purchases, refunds | Earnings, payouts, fees | Both |
| Orders | Buying and delivery | Fulfillment and completion | Both |
| Projects | Posting and hiring | Proposals and delivery | Both |
| Contests | Hosting and prize | Entries and judging | Both |
| Profile | Privacy and account identity | Storefront and reputation | Both |
| Safety | Buyer protection | Creator protection | Both |

The Help Center shell and search remain identical. Suggested articles and quick actions adapt to role and current context.

---

## 10. Accessibility, Privacy, and Performance

- Every article and form is keyboard accessible.
- Search results have clear semantic labels and focus management.
- Sensitive ticket details require authentication.
- Attachments show filename, size, and removal control before submission.
- Do not include private financial details in notification previews.
- Load article content first; lazy-load related articles and ticket history.
- Use compact skeletons instead of a blank support page.
- Preserve user input after validation or upload errors.
- Never request secrets, passwords, full payment numbers, or authentication tokens.

## Final rule

Self-service should be the fastest path, but users must never be trapped in a help article loop. Every relevant article and guided flow ends with a contextual, pre-filled support or dispute path.
