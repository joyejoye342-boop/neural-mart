# NeuralMart — Main Home Page Architecture

**Document version:** 1.0  
**Scope:** Complete home page design specification — structure, layout, components, UX logic, content hierarchy, and role variance.  
**Platform:** Mobile-first (390px canvas). Desktop ≥ 768px is an enhancement.  
**Design philosophy:** *"Social simplicity on the surface, marketplace power underneath."*

---

## 0. The Central Problem This Document Solves

NeuralMart has at least six distinct feature areas (creator marketplace, freelancing, contests, products, services, messaging). The home page must surface all of them without becoming a dashboard. The resolution: **the home page is a social feed, not a control panel.** Every major feature is accessible from home but none of them live *on* home except as cards within the feed or as one-tap launch points from a single composer row.

The result a user should feel: *"This is like Instagram, but I can hire people, buy things, and run contests too."*

---

## 1. Page Structure — The Three Zones

The home page has exactly **three vertical zones**, in priority order. Nothing else.

```
┌────────────────────────────────────────────────┐
│  ZONE 1 — COMPOSER (sticky intent layer)       │  ← Always first. Role-aware.
│  Composer card + quick-action chips/buttons    │
├────────────────────────────────────────────────┤
│  ZONE 2 — FEATURE GATEWAY (optional, thin)     │  ← Shown to new/unfamiliar users only.
│  Horizontal scroll row of hub shortcuts        │  ← Disappears once user is active.
├────────────────────────────────────────────────┤
│  ZONE 3 — SHOWCASE FEED (infinite scroll)      │  ← The whole product in one surface.
│  Creator posts → Products → Services →         │
│  Projects (open briefs) interspersed           │
└────────────────────────────────────────────────┘
```

**What is NOT on the home page:**
- Notification panels, activity summaries, or "you have X pending" cards.
- Dashboard widgets (earnings, analytics, proposal counts).
- Tab bars switching between Creator mode and Buyer mode.
- Separate feed columns.
- Trending hashtag sidebars.

All of those belong in Dashboard, Explore, or Menu — one tap away.

---

## 2. Top App Bar

### 2.1 Mobile (≤ 767px)

```
┌─────────────────────────────────────────────────┐
│  [Hexagon Logo] NeuralMart     [🏆] [🔔] [Av]  │
│  (14px safe-area top padding)                   │
└─────────────────────────────────────────────────┘
  h-14 · sticky · backdrop-blur · bg-background/80
```

| Slot | Element | Behavior |
|---|---|---|
| Left | Logo (Hexagon icon + "NeuralMart" wordmark) | Taps to `/` scroll-to-top if already home |
| Right cluster — 1 | **Trophy icon** (Contest Feed toggle) | Navigates to `/contest-feed`; turns amber when active |
| Right cluster — 2 | **Bell icon** (Notifications) | Opens notification tray (future slide-in sheet); shows a 1px red dot badge when unread |
| Right cluster — 3 | **Avatar** (current user) | Navigates to own profile `/creators/:id` |

**Bar height:** 56px (`h-14`).  
**Spacing rules:** Logo at 16px from left edge. Right cluster at 8px from right edge, 4px gap between items.  
**Border:** 1px bottom border (`border-border`) always visible — no scroll-triggered appearance. The top bar is a permanent anchor.  
**Backdrop:** `bg-background/80 backdrop-blur-md` — content scrolls behind it, feels native.

### 2.2 Desktop (≥ 768px)

There is **no top app bar on desktop.** The sidebar replaces it. The left sidebar holds:
- Logo at top
- Nav items (Home · Explore · Messages · Dashboard · Menu)
- Contest Feed as a secondary accent item (below a divider, amber color)
- User card anchored at bottom (avatar + name + role badge)

The desktop layout is already built. The document focuses on mobile as the design canvas.

---

## 3. Bottom Navigation (Mobile only)

Five items. Always visible. No auto-hide on scroll.

```
┌──────┬──────┬──────┬──────┬──────┐
│  🏠  │  🔍  │  💬  │  📊  │  ☰  │
│ Home │Explor│ Msgs │ Dash │ Menu │
└──────┴──────┴──────┴──────┴──────┘
  h-14 · fixed bottom · pb-safe · bg-card · border-t
```

| Tab | Icon | Path | Active color |
|---|---|---|---|
| Home | `Home` | `/` | Primary |
| Explore | `Search` | `/explore` | Primary |
| Messages | `MessageSquare` | `/messages` | Primary |
| Dashboard | `LayoutDashboard` | `/dashboard/creator` or `/dashboard/buyer` | Primary |
| Menu | `Menu` | `/menu` | Primary |

**Active state:** Icon + label text goes to `text-primary`. No background pill on bottom nav (too small).  
**Tap target:** Each tab occupies 20% of bar width (`flex-1`), full height (56px). Minimum 44×44px target is met.  
**Label size:** 9px (`text-[9px]`). This is not a typo — at 9px, labels act as confirmation of the icon without competing with the icon itself.  
**Contest Feed is NOT here.** It lives in the top-right header cluster to reinforce that it's a content-mode switch, not a destination category.

---

## 4. First Screen — Above the Fold Layout

Everything visible without scrolling on a 390×844px (iPhone 15) viewport.

```
┌────────────────────────────────────────┐  ← Top: 56px bar (sticky)
│  NeuralMart Logo        🏆  🔔  [Av] │
├────────────────────────────────────────┤  ← 16px top padding
│                                        │
│  ┌──────────────────────────────────┐  │
│  │  [Av]  [  Share your work...  ]  │  │  ← Composer card (role-aware)
│  │  ─────────────────────────────── │  │
│  │  [Post]  [Product]  [Service]    │  │  ← Creator chips (creator role)
│  └──────────────────────────────────┘  │
│                                        │
│  ─ ─ ─ ─ ─ Feature Gateway ─ ─ ─ ─   │  ← Optional row (conditional)
│  [💼 Projects] [🏆 Contests] [🛍 Shop]│
│                                        │
│  ┌──────────────────────────────────┐  │
│  │  [Av]  Creator Name · 2h ago     │  │  ← First feed card
│  │                                  │  │
│  │  Just finished this brand        │  │
│  │  identity for a fintech client   │  │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━     │
│  │  [cover image or color bg]       │  │
│  └──────────────────────────────────┘  │
│                                        │
└────────────────────────────────────────┘  ← Bottom: 56px nav (fixed)
```

**Vertical budget breakdown (844px viewport, 56px top bar, 56px bottom nav):**
- Available content height: 732px
- Composer card: ~112px
- Feature Gateway row (conditional): ~68px (16px margin + 48px pill row + 4px margin)
- First feed card (average): ~280px
- Remaining visible: ~272px (shows the top of the second card — "peek" pattern that signals scroll)

The "peek" of the second card below the fold is intentional. It signals: *there's more below.* Never show a full blank area below the first card.

---

## 5. Zone 1 — The Composer (Role-Aware)

The composer is the home page's single interactive entry point. It is always the first element after the top bar. It is **never paginated, tabbed, or collapsed.**

### 5.1 Creator role (`role === 'creator'`)

```
┌────────────────────────────────────────────────┐
│  [Avatar]  [  Share your latest work…       ]  │  ← tappable → opens Post composer
│  ─────────────────────────────────────────────  │
│  [+ Post]   [🛍 Product]   [⚙ Service]          │  ← quick-action chips
└────────────────────────────────────────────────┘
```

**Chip behavior:** Each chip is a ghost button. Tapping "Post" navigates to `/posts/new` (or opens an inline sheet — TBD in implementation). Tapping "Product" → `/products/new`. Service → `/services/new`.  
**Prompt text:** "Share your latest work…" — signals creative showcase, not status update.  
**Why three chips and not more:** Creators have exactly three types of publishable content (posts, products, services). Adding a fourth would require a "More" overflow — which is the first sign a composer has become a toolbar. Stay at three.

### 5.2 Buyer role (`role === 'buyer'`)

```
┌────────────────────────────────────────────────┐
│  [Avatar]  [  What do you need help with?    ]  │  ← tappable → opens Project wizard
│  ─────────────────────────────────────────────  │
│  [💼 Post Project]         [🏆 Host Contest]    │  ← two CTA buttons, equal weight
└────────────────────────────────────────────────┘
```

**Prompt text:** "What do you need help with?" — frames buyers as clients with a need, not passive browsers.  
**Two buttons only.** Buyers have two ways to source creative work: Projects (direct hire brief) and Contests (competition). These are the only two actions they can take from the feed. Anything else (browsing products, managing orders) goes to the respective hub page.  
**Button style:** Ghost buttons with icon + label. `hover:text-foreground` for Project, `hover:text-accent` for Contest. Keep them visually equal — neither is a "primary action."

### 5.3 Both role (`role === 'both'`)

```
┌────────────────────────────────────────────────┐
│  [Avatar]  [  Share your latest work…       ]  │  ← Creator prompt (primary)
│  ─────────────────────────────────────────────  │
│  [+ Post]   [🛍 Product]   [⚙ Service]          │  ← Creator chips (primary)
└────────────────────────────────────────────────┘
[💼 Post a Project]         [🏆 Host a Contest]    │  ← Buyer strip (secondary, below card)
```

**Design decision:** `both` users are still *primarily creators on the home feed.* The creator composer takes the card. The buyer strip sits directly below the card as two outline buttons — same width, same height, but outside the card's visual boundary. This makes the buyer actions available without giving them equal visual weight as the creator publishing flow.  
**Rationale:** If you're a `both` user on the home feed, you're most likely consuming or publishing creative content. If you want to post a project, you know where the buttons are — they're right there, just not the first thing you see.

### 5.4 Universal rules for all composer variants

- **Maximum card height: 120px.** If a variant needs more vertical space, it has too many actions.
- **Never show inputs inline in the composer card on the home page.** The composer is a launch point, not an inline form. It opens a full sheet/page when tapped.
- **Avatar is always present.** It signals "you are the author here" and reinforces the social context.
- **No placeholder for role explanation.** Never show text like "You're a Buyer — post a project below." Role-appropriate content speaks for itself.

---

## 6. Zone 2 — Feature Gateway Row (Conditional)

**Shown only to:** Users who have been active for fewer than 7 days OR have zero purchases/listings/posts.  
**Hidden when:** User has any recorded activity (any post, any order, any listing, any proposal).  
**Purpose:** Orient new users to what NeuralMart can do beyond the feed, without cluttering experienced users' home.

```
  [💼 Projects]  [🏆 Contests]  [🛍 Products]  [⚙ Services]  [👥 Creators]
  ← horizontal scroll, no wrapping, pill style ───────────────────────────→
```

**Pill style:** `h-10 px-4 rounded-full border border-border bg-card text-sm`. Icon (16px) + label. Left-aligned, first pill fully visible, last pill half-visible to signal scrollability.  
**Scroll behavior:** `overflow-x-auto scrollbar-hide`. No snap points — free scroll.  
**Tap target:** Full pill height/width. Navigates to the hub page.  
**Labels for each:**

| Pill | Icon | Route |
|---|---|---|
| Projects | `Briefcase` | `/projects` |
| Contests | `Trophy` | `/contest-feed` (amber accent color for this pill only) |
| Products | `ShoppingBag` | `/products` |
| Services | `Settings` (gear) | `/services` |
| Creators | `Users` | `/explore` |

**Section label:** No section header. The pills speak for themselves. A "Discover NeuralMart" heading adds visual weight without adding information.

---

## 7. Zone 3 — Showcase Feed

### 7.1 Feed composition

The Showcase Feed is a **unified, chronological social feed** of creator-published content. It is the same feed for all roles. Role changes only the *composer above*, not the *feed below.*

**Feed item types (in order of frequency):**

| Type | Visual | Frequency |
|---|---|---|
| `post` | Standard social post with optional cover image | Most common ~60% |
| `product` | Product card with thumbnail, name, price, Buy button | ~20% |
| `service` | Service card with category badge, starting price, Book button | ~10% |
| `project` (open brief) | Project request card — buyer's brief, budget, skills needed | ~10% |

**Projects in the Showcase Feed are the key to buyer/creator cross-pollination.** Buyers don't publish "posts" — they publish projects. When a buyer posts a project, it appears in the same feed a creator is browsing. The creator sees an opportunity. This is the discovery loop that makes the feed useful for both roles simultaneously without showing them a different page.

### 7.2 Feed card anatomy

**Post card:**
```
┌───────────────────────────────────────┐
│  [Av] Creator Name    Role badge  [⋯] │  ← header (48px)
│       2h ago                          │
│───────────────────────────────────────│
│  Post body text (1–3 lines + expand)  │  ← body
│                                       │
│  [Cover image / color background]     │  ← optional media (aspect-[4/3])
│───────────────────────────────────────│
│  [♡ 24]  [💬 6]  [Share]             │  ← footer (40px)
└───────────────────────────────────────┘
```

**Product card:**
```
┌───────────────────────────────────────┐
│  [Av] Creator Name    [Product] badge │  ← header
│───────────────────────────────────────│
│  [Product thumbnail, aspect-[4/3]]    │  ← image (always present)
│  Product Title                        │
│  $29 · "Figma UI Kit"                 │
│───────────────────────────────────────│
│  [♡ Save]              [Buy — $29 →]  │  ← footer with CTA
└───────────────────────────────────────┘
```

**Service card:**
```
┌───────────────────────────────────────┐
│  [Av] Creator Name    [Service] badge │
│───────────────────────────────────────│
│  Service Title                        │
│  Branding · Logo Design               │
│  ⭐ 4.9 (42 reviews)                  │
│  From $150                            │
│───────────────────────────────────────│
│  [♡ Save]             [Book Now →]    │
└───────────────────────────────────────┘
```

**Project card (buyer brief in creator's feed):**
```
┌───────────────────────────────────────┐
│  [Av] Buyer Name   [Open Project] →   │  ← amber or muted badge, NOT primary
│───────────────────────────────────────│
│  "Looking for a brand designer…"      │  ← brief excerpt (2 lines)
│  Budget: $500–$2,000                  │
│  Skills: Figma, Branding, Motion      │
│───────────────────────────────────────│
│  [💬 Send Proposal →]   12 proposals  │  ← CTA only for creators
└───────────────────────────────────────┘
```

**Project card CTA rules:**
- Creator role: shows "Send Proposal →" button.
- Buyer role: shows "View Project" (read-only).
- `both` role: "Send Proposal →" (creator capability takes precedence for an open brief).
- The CTA never says "Apply" — "Send Proposal" is more intentional and professional.

### 7.3 Feed ordering logic

Default ordering: **reverse-chronological with engagement boost.** Simple recency first, but posts with above-average like/comment velocity in the first 6 hours get a mild recency boost (not algorithmic enough to bury chronological posts, just enough to surface breakout content slightly higher).

**No pagination controls.** Infinite scroll only. A loading skeleton of 3 cards appears at the bottom when the next page is fetching.

**Empty state:**
```
┌───────────────────────────────────────┐
│           (Hexagon illustration)      │
│  "The feed is warming up."            │
│  Follow some creators to see their    │
│  work first in your feed.             │
│                                       │
│  [Explore Creators →]                 │
└───────────────────────────────────────┘
```
Never show a blank feed. Always show a CTA that makes the feed non-empty.

### 7.4 What the feed does NOT show

- Notifications ("X followed you", "Your post got 10 likes") — these go to the notification tray.
- Platform announcements or tips — these go to a pinned card mechanism (future), not polluting the main feed.
- Ads — not in the feed at this stage.
- Promoted/Sponsored listings — not in the feed at this stage.

---

## 8. How Major Feature Hubs Are Exposed Without Clutter

NeuralMart has 6 feature hubs: Explore, Messages, Dashboard, Projects, Contests, Menu (Wallet/Settings). None of them are on the home page as permanent sections. They are exposed through three lightweight mechanisms:

### 8.1 Bottom nav (always visible, 5 destinations)

`Home · Explore · Messages · Dashboard · Menu`

Each nav item *is* a hub. Tapping Explore opens the creator discovery hub. Tapping Messages opens the inbox hub. Tapping Dashboard opens the role-specific analytics hub. **The nav is the primary hub-access pattern.** Don't duplicate it by adding shortcuts on the home page.

### 8.2 Contest Feed — top-bar icon (secondary feed mode)

The Trophy icon in the top bar is the only *in-feed* context switch. It navigates to `/contest-feed`, which is a full page of buyer-posted contests. This is separated from the main feed because:

- Contests are time-limited, high-intent signals — they deserve their own focused surface.
- They would feel out of place interspersed with portfolio posts in the Showcase Feed (different pacing, different response type).
- Having a dedicated icon makes "Contests" a distinct mental category, which improves recall.

### 8.3 Feed-native discovery (the richest mechanism)

Because the feed contains Products, Services, and Projects interspersed with creator posts, **browsing the home feed is also browsing the marketplace.** A creator's post links to their profile. A Product card links to the product detail page. A Project card links to the project detail page with a proposal form.

This means every feature hub can be reached organically from the feed without a dedicated home-page shortcut:
- See a cool creator post → tap their avatar → go to their profile → see their Services → Book one.
- See an Open Project card in the feed → tap → send a proposal.
- See a Product card → tap Buy → product detail → checkout.

The feed *is* the hub shortcut for all buying/hiring interactions.

### 8.4 Feature Gateway row (new users only)

As specified in Zone 2 above — a horizontal pill row for first-week users who haven't yet discovered the hubs via the nav.

---

## 9. Role Variance — How the Page Changes

### Summary table

| Page element | Buyer | Creator | Both |
|---|---|---|---|
| **Composer card prompt** | "What do you need help with?" | "Share your latest work…" | "Share your latest work…" (creator primary) |
| **Composer chips** | Post Project + Host Contest | Post + Product + Service | Post + Product + Service (card) |
| **Buyer strip below composer** | (is the whole composer) | Hidden | Post a Project + Host a Contest (outline buttons, below card) |
| **Feature Gateway row** | ✅ if new user | ✅ if new user | ✅ if new user |
| **Feed content** | Identical — sees all posts, products, services, projects | Identical | Identical |
| **Project card CTA** | "View Project" (read only) | "Send Proposal →" | "Send Proposal →" |
| **Product card CTA** | "Buy →" | "View" (can't buy from self) or "Buy →" (from other creators) | Same as creator |
| **Service card CTA** | "Book Now →" | "View" (own) or "Book →" (other creators) | Same as creator |
| **Empty feed CTA** | "Explore Creators →" | "Post your first work →" | "Post your first work →" |

### What does NOT change by role

- The feed itself — content is universal.
- The nav bar (5 items, same for all).
- The top bar layout.
- The Feature Gateway pills (same destinations, same order).
- Card visual design — role doesn't change how cards look, only what the action button says.

### The `both` user experience in detail

A `both` user lands on the home page and sees:
1. A creator composer (their primary publishing intent — they have a storefront and creative work to share).
2. Two subtle outline buttons immediately below: "Post a Project" and "Host a Contest." These are secondary — they're there when needed, not competing for attention.
3. The universal feed with all card types.
4. Project cards with the "Send Proposal →" CTA (creator capability surfaces for open opportunities).

The home page never shows a `both` user a toggle like "Switch to Buyer view." That would be a context switch that fragments their identity. They are one person; the page adapts both composer variants simultaneously, stacked, and keeps the feed unified.

---

## 10. Complete Component List & Priority Order

Listed in render order (top to bottom), with implementation status.

### Shell components (AppLayout — already built)

| Component | Status | Notes |
|---|---|---|
| `AppLayout` | ✅ Built | Desktop sidebar + mobile header + bottom nav |
| Mobile top header | ✅ Built | Logo · Trophy · Bell · Avatar |
| Desktop sidebar | ✅ Built | Logo · Nav 5 · Contest Feed secondary · User card |
| Mobile bottom nav | ✅ Built | 5 items, pb-safe, fixed |

### Home page components (home.tsx)

| Priority | Component | Status | Notes |
|---|---|---|---|
| 1 | `CreatorComposer` | ✅ Built | Avatar + prompt + 3 chips |
| 2 | `BuyerComposer` | ✅ Built | Avatar + prompt + 2 CTA buttons |
| 3 | `BuyerComposerSecondary` | ✅ Built | Outline button strip for `both` users |
| 4 | `FeatureGatewayRow` | 🔲 **Not yet built** | Conditional pill row for new users |
| 5 | `ShowcaseFeed` | ✅ Built (basic) | Fetches `/api/feed/showcase` |
| 6 | `PostCard` | ✅ Built | Creator post with like/comment/share |
| 7 | `ProductCard` (feed variant) | ✅ Built (basic) | Needs "Buy →" CTA wired |
| 8 | `ServiceCard` (feed variant) | 🔲 **Not yet built** | Similar to ProductCard but for services |
| 9 | `ProjectCard` (feed variant) | ✅ Built via OpportunityCard | Role-aware CTA (Proposal vs View) |
| 10 | `FeedSkeleton` | ✅ Built | 3 skeleton cards |
| 11 | `FeedEmptyState` | ✅ Built (basic) | Needs role-aware CTA refinement |
| 12 | `InfiniteScrollTrigger` | 🔲 **Not yet built** | Intersection observer → load next page |

### Supporting components (to be built)

| Component | Where | Purpose |
|---|---|---|
| `NotificationTray` | Slides in from right | Bell icon → notification list |
| `ComposerSheet` (mobile) | Bottom sheet | Post composer modal on mobile |
| `ProjectDetailSheet` (mobile) | Bottom sheet | Quick-view project from feed card |
| `FeedItemTypeTag` | Inside cards | Small `[Post]` / `[Product]` / `[Service]` / `[Project]` label |

---

## 11. Content Hierarchy — Visual Weight Rules

Every pixel of the home page competes for attention. These rules enforce a clear hierarchy:

**Level 1 — Most important (highest visual weight):**
- The composer card (top of page, always first)
- The active/focused feed card (hovered/tapped)

**Level 2 — Important (clear but not dominant):**
- Creator name + avatar in feed cards
- Primary CTA buttons within feed cards ("Buy →", "Book →", "Send Proposal →")
- Post body text (first 2 lines)

**Level 3 — Useful (present, not prominent):**
- Post timestamps ("2h ago")
- Like/comment counts
- Role badges on cards (`[Product]`, `[Service]`, `[Project]`)
- Buyer strip outline buttons (below creator composer)

**Level 4 — Available (visible on hover/focus, or very small):**
- Share button on posts
- "…" overflow menus on cards
- Feature Gateway pills (only visible if user is new)
- Scroll-triggered second-page loads

**Rules:**
- Never give a secondary action (like, share) the same visual weight as a primary action (Buy, Book, Proposal).
- Never put a "View All" link at a level higher than the content it points to.
- Timestamps always in `text-muted-foreground text-xs` — they are orientation, not content.

---

## 12. Mobile-First Layout Notes

### Grid and spacing
- Content area: `max-w-2xl mx-auto` (672px max) centered within the feed column.
- Feed card inner padding: `p-4` (16px all sides) on mobile; `p-5` on ≥ md.
- Gap between feed cards: `space-y-5` (20px). This is tighter than a typical card grid because feed cards already have internal whitespace. 20px gives the sensation of a scrollable list, not isolated widgets.
- Composer card to first feed card: `mb-6` (24px).

### Typography scale (mobile)
- Creator name in card header: `text-sm font-semibold` (14px)
- Post body: `text-sm leading-relaxed` (14px, 1.625 line height)
- Timestamps / secondary labels: `text-xs text-muted-foreground` (12px)
- CTA buttons in cards: `text-sm font-medium` (14px)
- Composer prompt placeholder: `text-sm text-muted-foreground` (14px)
- Feature Gateway pill labels: `text-sm` (14px, the minimum for pill labels)

### Scroll behavior
- Page scroll: native browser scroll (`overflow-y-auto` on `body`).
- Top bar: `sticky top-0` — scrolls with the page until it reaches the top, then sticks.
- Bottom nav: `fixed bottom-0` — always visible, never scrolls.
- Feed infinite scroll: uses `IntersectionObserver` on a sentinel div at the bottom of the feed. No "Load More" button.
- No `overflow: hidden` anywhere that would break native scroll momentum (rubber-banding on iOS).

### Images in feed
- Always use `aspect-[4/3]` for cover images in post cards. Never free-height images that cause layout jumps.
- Lazy load images below the fold: `loading="lazy"` on `<img>` tags.
- Skeleton placeholder during load: bg-muted rounded, same aspect ratio as the image.
- Never show broken image icons — always have an `AvatarFallback` or color background as a fallback.

### Performance targets
- First Contentful Paint: < 1.2s (skeleton visible)
- Feed cards visible without scroll: ≥ 1 complete card + peek of second
- No layout shifts after hydration (reserve space for images with aspect-ratio)

---

## 13. Implementation Priority Order

Build in this order to get value fast:

1. ✅ Composer cards (all 3 role variants) — already done.
2. ✅ Showcase Feed with PostCard — already done.
3. **ProjectCard in the showcase feed** — buyers' open briefs visible in the creator feed. (This is the killer cross-role feature — it should be priority 1 if not yet fully working.)
4. **ServiceCard feed variant** — currently only ProductCard exists in the feed.
5. **FeatureGatewayRow** — conditional pill row for new users. Implement with a simple `hasActivity` flag from the `useGetMe` response or a separate API call.
6. **InfiniteScrollTrigger** — feed pagination currently loads all at once; add `?page=N` support to the showcase feed endpoint.
7. **Role-aware empty state** — "Post your first work →" vs "Explore Creators →" depending on role.
8. **NotificationTray** — Bell icon is present but currently a no-op. Opens a slide-in panel.
9. **ComposerSheet** — inline prompt in the composer currently navigates to a new page; should open a sheet on mobile for a more native feel.
10. **ProductCard "Buy" CTA** — wired to product detail / cart flow.

---

## 14. What This Page Deliberately Does Not Try to Do

These are explicit non-goals for the home page. Pressure to add them should be redirected to their appropriate hub:

| Temptation | Where it belongs instead |
|---|---|
| "Show my earnings on the home page" | Dashboard |
| "Show pending proposals/orders" | Dashboard |
| "Show active conversations" | Messages |
| "Show who followed me today" | Notifications tray |
| "Show trending hashtags" | Explore |
| "Show a map of creator categories" | Explore |
| "Show a counter of active contests" | Contest Feed |
| "Show wallet balance on the home page" | Menu (Wallet summary) |
| "Show onboarding steps/checklists" | First-time user flow (separate overlay), not home page |
| "Add a 'For You' vs 'Following' tab" | If needed in future, a tab *within* the feed, not a new section |

The home page has one job: show a beautiful, active creator feed with exactly the right entry point to act on it, based on who you are.

---

*End of document. This spec grounds the current build (`home.tsx` + `AppLayout.tsx`) and defines what to build next.*
