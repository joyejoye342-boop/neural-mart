# NeuralMart — Badge Display Architecture

**Document version:** 1.0  
**Scope:** Placement, density, explanation, and responsive behavior for creator and buyer badges across NeuralMart.

---

## 0. Display Principle

Badges are trust shorthand, not decoration. They should help a user decide whether to open a profile, start a conversation, submit a proposal, or make a purchase.

The display hierarchy is:

```text
Current level
→ Verified identity
→ One context-relevant specialty badge
→ Additional earned badges on detail
```

The system uses the badge layers already defined:

- **Level:** New Creator, Rising Creator, Trusted Creator, Top Rated Creator, Elite Creator.
- **Specialty badges:** Verified Creator, Fast Responder, Reliable Delivery, Top Seller, Project Pro, Contest Winner, and similar.
- **Buyer badges:** Verified Buyer, Reliable Buyer, Trusted Employer, Repeat Client, Contest Host.

---

## 1. Shared Badge Anatomy

Every displayed badge has:

- icon or mark;
- short label;
- accessible text alternative;
- optional one-line explanation;
- source/eligibility state;
- `earned`, `active`, or `paused` status internally.

### Display components

```text
LevelMark
VerifiedMark
SpecialtyBadge
BadgeGroup
BadgeExplanation
```

### Visual hierarchy

| Badge type | Visual weight | Default label |
|---|---|---|
| Current level | Strongest | `Top Rated Creator` |
| Verification | Strong, compact | `Verified Creator` |
| Reliability badge | Medium | `Reliable Delivery` |
| Achievement badge | Medium/quiet | `3× Contest Winner` |
| Buyer trust badge | Compact | `Trusted Employer` |

Never show a level, verification badge, and four specialty badges as equal-weight pills in one row.

---

## 2. Public Profile Placement

### Header

The profile header shows:

```text
Maya Johnson
Brand identity designer
✓ Verified Creator · Top Rated Creator
Available · Responds in under 4 hours
```

Maximum header badge load:

- one level badge;
- one Verified Creator mark;
- no more than one availability/reliability signal in the same row.

The rating belongs beside the trust summary, not inside a badge pile:

```text
4.9 ★ · 42 verified reviews
28 completed orders
```

### Overview

The Overview may show up to three specialty badges:

```text
Top Seller · Reliable Delivery · 3× Contest Winner
[View all badges]
```

Badge order:

1. Relevant to the creator's primary offer
2. Reliability/trust
3. Achievement

### Reviews and About

The Reviews tab can explain badges that depend on review or delivery evidence. The About section can explain `Verified Creator`, category credentials, and public work history.

### Mobile behavior

- Header shows level and verification compactly.
- Specialty badges appear in a horizontally scrollable row or a two-line wrap.
- Show no more than three without `View all`.
- Tapping any badge opens a bottom sheet explanation.

---

## 3. Feed Card Placement

Feed cards must remain content-first.

### Creator content cards

```text
[avatar] Maya Johnson · Top Rated Creator
         Branding · 2h
```

Show:

- level mark next to creator name;
- Verified Creator mark if active;
- no specialty badge by default.

Show one relevant specialty badge only when it helps the card's decision:

- `Contest Winner` on a contest-related recommendation;
- `Reliable Delivery` on a service card;
- `Top Seller` on a product card.

### Project cards

Show buyer trust badges in the author row:

```text
Maya's Startup · Verified Buyer
```

For a project/hiring request, `Reliable Buyer` or `Trusted Employer` may appear if the project is otherwise relevant.

### Contest cards

Show host verification and `Contest Host` only when the contest is active and the host has completed a prior contest. The prize-funded state is a status, not a badge.

### Density rule

- One level/verification signal in an author row.
- One context badge maximum.
- Never add a badge row below every feed card.

---

## 4. Chat Placement

### Conversation header

```text
[avatar] Maya Johnson
        Top Rated Creator · ✓ Verified
        Usually responds in under 4 hours
```

Show:

- current level;
- verification;
- one relevant reliability badge;
- availability when current.

### Payment-request context

When a payment request is shared, show the relevant trust context without implying a guarantee:

```text
Verified Creator
Secure NeuralMart payment request
```

The badge explanation must state that verification confirms account information, not work quality or refund eligibility.

### Mobile behavior

- Use a compact 16px mark beside the name.
- Tapping opens a small sheet with badge meaning and `View profile`.
- Do not interrupt the chat with a full credential panel.

---

## 5. Search Results Placement

Creator search cards show:

```text
Maya Johnson
Top Rated Creator · ✓ Verified
4.9 ★ · 42 reviews
Reliable Delivery
```

### Search ranking rules

Badges can be filters and tie-breakers, but not the main ranking factor:

```text
Category fit
→ Availability
→ Quality/reviews
→ Search relevance
→ Badge level as supporting evidence
```

### Search filters

Optional:

- Verified Creator
- Top Rated or Elite
- Reliable Delivery
- Fast Responder
- Contest Winner

Do not expose filters that encourage creators to game a badge at the expense of relevance.

### Buyer/project result cards

Project and contest search results may show:

- Verified Buyer;
- Reliable Buyer;
- Trusted Employer;
- Contest Host.

Do not expose buyer spending totals.

---

## 6. Dashboard Placement

The Creator Dashboard is the most detailed badge surface.

### Home

```text
REPUTATION
Top Rated Creator
4.9 ★ · 42 reviews

[Top Seller] [Reliable Delivery] [Fast Responder]
Next level: Elite Creator · 72% complete
[View reputation →]
```

### Reputation page

Show:

- current level;
- all earned badges;
- inactive/paused badges with explanation;
- progress toward next level;
- each criterion's current value and target;
- rolling evaluation period;
- quality warnings;
- appeal/review status;
- perk eligibility.

### Badge detail

```text
Reliable Delivery
Active
Based on 22 eligible deliveries in the last 90 days.
Your on-time rate: 95%
Target: 95% or higher
```

Dashboard can show exact metrics. Public surfaces should show summarized labels.

### Buyer dashboard

Buyers see their own buyer badges and progress, not creator-level progress. Both users can see both layers in their respective Buying/Selling contexts.

---

## 7. Tooltip and Explanation Behavior

### Trigger

- Desktop: hover or focus on the badge.
- Mobile: tap the badge.
- Keyboard: Enter/Space opens the explanation.

### Explanation content

Every tooltip or sheet answers:

1. What does this badge mean?
2. What verified behavior supports it?
3. Is it current?
4. What does it not guarantee?

Example:

```text
Top Rated Creator
Based on verified marketplace reviews and sustained completed work.
This reflects platform activity; it does not guarantee a specific result.
```

### Tooltip limits

- Desktop tooltip: maximum 2–3 lines.
- Mobile sheet: title, explanation, source, and `View profile`/`View reputation`.
- Never reveal hidden risk flags or private metrics.
- Never expose an exact threshold publicly if doing so enables gaming; show the meaning rather than the formula.

### Accessibility

- Badge meaning is available to screen readers.
- Icon-only marks have labels.
- Tooltips do not appear only on hover.
- Color is never the sole indicator.

---

## 8. Keeping Badges Premium and Clean

1. Show one level per identity.
2. Keep verification visually distinct.
3. Limit specialty badges to three on profiles and one in compact contexts.
4. Use earned badges only; hide progress badges publicly.
5. Use consistent icon family and restrained color.
6. Do not use large emoji clusters.
7. Use `View all badges` instead of an endless row.
8. Show context badges only when they help the current decision.
9. Keep rating and operational metrics separate from decorative badge art.
10. Remove or pause badges immediately when the underlying status changes.

### Recommended public treatment

```text
Top Rated Creator · ✓ Verified
[Reliable Delivery] [Top Seller] [3× Contest Winner]
```

### Not recommended

```text
🏆 ⭐ 🔥 💎 ✅ 🚀 🎨 💬 🥇
```

## Final rule

Badges should feel like quiet evidence attached to a real identity. If removing a badge would not change a buyer's decision, it should probably live in the dashboard rather than the public interface.
