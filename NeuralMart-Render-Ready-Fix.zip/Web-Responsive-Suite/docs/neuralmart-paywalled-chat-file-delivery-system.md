# NeuralMart — Paywalled File Delivery Inside Chat

**Document version:** 1.0  
**Scope:** Locked file and custom-asset delivery inside commerce conversations  
**Primary surfaces:** Chat thread · Checkout sheet · Order detail · Secure file access

---

## 0. System Definition

Paywalled delivery lets a creator place a file, custom asset, or final work inside a chat while keeping the original locked until the buyer completes payment.

The buyer can see enough to understand what is being purchased, but cannot access the protected file before the payment state is confirmed.

```text
Creator prepares delivery
→ Safe preview appears in chat
→ Original file remains locked
→ Buyer reviews price, scope, license, and preview
→ Buyer pays
→ Order and entitlement activate
→ Secure file access is granted immediately
```

The chat message is the user-facing surface. The order, payment, asset, entitlement, and access-grant records remain the system of record.

---

## 1. Delivery Flow

### 1.1 Creator flow

```text
Open eligible conversation
→ Choose Deliver / Request payment
→ Upload or select asset
→ Add preview
→ Define price, scope, and license
→ Select delivery type
→ Review buyer-facing card
→ Send locked delivery
```

The creator can deliver:

- A completed custom asset
- A source file
- A product file or bundle
- A service-order milestone
- A paid add-on
- A project deliverable
- A final revision

### 1.2 Delivery type

The creator chooses one:

| Delivery type | Typical use | Payment behavior |
|---|---|---|
| New custom delivery | One-off asset created in chat | Creates a new paid order |
| Service order delivery | Work under an existing package | Uses the existing order |
| Project milestone | Agreed proposal milestone | Creates/updates milestone payment |
| Product unlock | Existing digital product | Creates product entitlement |
| Paid add-on | Extra revision or scope | Creates an add-on order or offer |

The delivery type controls which fields are editable. A creator cannot silently convert an active service delivery into a new unrelated charge.

### 1.3 Buyer flow

```text
Receive locked delivery card
→ Open preview
→ Review contents and terms
→ Tap Unlock / Pay
→ Confirm checkout
→ Payment succeeds
→ Delivery unlocks in the same thread
→ Download or access file
```

The buyer sees:

- Creator
- Delivery title
- Preview
- File type and size
- Included files
- Price
- License/usage summary
- Linked order/project/service
- Payment protection
- Expiration, if applicable

### 1.4 Successful result

After confirmed payment:

```text
Locked delivery
→ Payment confirmed
→ Order paid
→ Entitlement active
→ Access granted
→ Chat card changes to Download / Open
```

The buyer does not need to refresh the page or leave Chat. The access button becomes available immediately after the server confirms payment.

---

## 2. File Locking Logic

### 2.1 Private storage

Original delivery files are stored privately. The client never receives a permanent public URL before payment.

The message stores references such as:

- `deliveryId`
- `assetId`
- `previewAssetId`
- `orderId`
- `entitlementId`, after payment

It should not treat a raw `fileUrl` as an authorization mechanism.

### 2.2 Delivery states

```text
Draft
→ Scanning
→ Ready to send
→ Locked / Awaiting payment
→ Payment processing
→ Paid / Unlocking
→ Unlocked
→ Completed
```

Alternative states:

- Payment expired
- Cancelled
- Refunded
- Disputed
- Access revoked
- Removed for policy
- Failed scan

### 2.3 Access rules

| State | Preview | Original file | Download |
|---|---:|---:|---:|
| Draft | Creator only | Creator only | No |
| Scanning | Creator only | Creator only | No |
| Locked | If allowed | No | No |
| Payment processing | Existing preview | No | No |
| Paid/unlocking | Yes | Server-authorized | After grant |
| Unlocked | Yes | Yes | Yes |
| Refunded | Yes or restricted | Policy-dependent | Usually revoked |
| Disputed | Yes | Existing access policy | May remain temporarily |
| Revoked | Yes or unavailable | No | No |

### 2.4 Server authorization

Every preview and original-file request checks:

1. Current authenticated user
2. Conversation participation
3. Delivery status
4. Payment status
5. Entitlement/license status
6. Refund/dispute/access-revocation status
7. File permission

The API returns a short-lived signed URL only after authorization succeeds.

### 2.5 Replay and sharing protection

- Signed download URLs expire.
- URLs are scoped to the authorized asset and action.
- Access grants are checked again when the URL is issued.
- Download events are logged.
- Suspicious repeated downloads can trigger a safety review.
- A copied pre-payment preview URL cannot reveal the original file.

No system can prevent a buyer from copying a file after lawful access. The platform protects the access boundary and preserves the license/order audit trail.

---

## 3. Preview Logic

### 3.1 Preview modes

The creator selects:

1. **No preview**
   - Only metadata and a protected thumbnail/icon.
   - Useful for sensitive source files.

2. **Watermarked preview**
   - Image/video/audio preview with visible watermark.

3. **Reduced-quality preview**
   - Lower resolution, shortened duration, or compressed audio.

4. **Sample preview**
   - Selected pages, frames, layers, or prompt examples.

5. **Partial bundle preview**
   - A small subset of files from the delivery.

6. **Progressive preview**
   - Low-resolution preview first, with a larger preview after the user opens it.

### 3.2 Preview separation

Preview files are separate assets from delivery files.

```text
Original source.zip       → locked
Watermarked sample.mp4    → preview
File list screenshot      → preview
Read-me sample.pdf        → preview
```

Never generate a preview by exposing the original delivery URL and relying only on UI controls.

### 3.3 File-specific preview rules

#### Images and graphics

- Watermarked image
- Reduced resolution
- Optional crop
- No editable source layer access

#### Video

- Short clip or first segment
- Watermark/overlay
- Reduced resolution
- No original export download

#### Audio

- Short excerpt
- Watermark or audible preview mark where appropriate
- Stream-only before payment

#### PDFs and templates

- Selected pages
- Watermarked screenshots
- Hidden editable layers

#### Source files

- File tree or layer screenshot
- Sample export
- Application/version metadata
- No raw source access

#### Prompt packs

- Sample prompts
- Topic index
- A few representative examples
- No complete pack export

### 3.4 Preview labels

Display clear labels:

```text
Preview
Watermarked sample
Low-resolution preview
Full files unlock after payment
```

The buyer should never mistake a preview for the final file.

---

## 4. Payment Trigger Behavior

### 4.1 Locked delivery card

The card has one primary action:

```text
[Unlock for $120]
```

Secondary actions:

- View details
- Ask a question
- View license
- Report delivery

For an existing order:

```text
[Pay milestone]
```

For an existing product:

```text
[Buy and unlock]
```

### 4.2 Checkout confirmation

The checkout sheet confirms:

- Creator
- Delivery title
- Included files
- Price
- Fees/taxes where applicable
- License
- Refund/dispute terms
- Linked order/project/service
- Payment method or wallet source

The final action must be explicit:

```text
Pay $120 and unlock files
```

Do not use ambiguous labels such as `Continue` at the final payment step.

### 4.3 Payment state machine

```text
Awaiting payment
→ Checkout started
→ Payment processing
→ Payment confirmed
→ Unlock requested
→ Access grant created
→ Unlocked
```

Failure states:

- Payment declined
- Payment cancelled
- Payment expired
- Duplicate payment prevented
- Access grant failed

### 4.4 Idempotency

The payment action must be idempotent:

- Double taps do not create duplicate orders.
- Refreshing checkout does not create a second charge.
- A retried confirmation resolves the same payment attempt.
- Access is granted once even if the confirmation callback is repeated.

### 4.5 Failed unlock recovery

If payment succeeds but access is not immediately available:

```text
Payment confirmed
Files are being unlocked securely...
```

The platform retries the access grant server-side. The buyer sees:

```text
Payment received. We are preparing your files.
[View order] [Contact support]
```

The buyer must not be charged again.

---

## 5. Order Record Creation

### 5.1 When to create the order

Create a pending order when the creator sends the locked delivery or when the buyer starts checkout, depending on the source flow:

- Custom delivery: create `Pending payment` when the creator sends it.
- Existing service/project order: attach a delivery to the existing order.
- Product purchase: create a product order at checkout.
- Milestone/add-on: create a new child order or milestone record before payment.

The buyer-facing locked card always has a durable order/payment reference before payment completes.

### 5.2 Order states

```text
Pending payment
→ Payment processing
→ Paid
→ Delivery available
→ Downloaded / accessed
→ Completed
```

Alternative states:

- Payment failed
- Cancelled
- Expired
- Refunded
- Partially refunded
- Disputed
- Resolved
- Access revoked

### 5.3 Order snapshot

At the time of sending/payment, preserve an immutable snapshot of:

- Delivery title
- Description
- Seller and buyer
- File list and sizes
- Version
- Price
- Currency
- License
- Scope/deliverables
- Preview mode
- Refund terms
- Linked conversation
- Linked product/service/project/proposal

Later creator edits must not rewrite the buyer's purchased terms.

### 5.4 Delivery items

An order may contain multiple delivery items:

```text
Order
├── Main video export
├── Editable source file
├── Thumbnail pack
└── Read-me/license guide
```

Each item has:

- asset reference;
- preview reference;
- lock status;
- access status;
- version;
- license scope;
- download history.

### 5.5 Entitlement

After payment:

```text
Order paid
→ Entitlement created
→ Access grant created for buyer
→ Delivery message updated
```

The entitlement records:

- buyer;
- asset/product/order;
- license;
- version;
- grant date;
- update eligibility;
- current access status.

---

## 6. Refund and Dispute Implications

### 6.1 Before payment

The buyer can cancel or ignore a locked delivery. No entitlement exists and no access has been granted.

Expired or withdrawn deliveries become:

```text
Payment expired
```

The creator can issue a replacement delivery without exposing the old file.

### 6.2 After payment, before access

If payment succeeds but the buyer has not accessed the file:

- creator cancellation can trigger a refund;
- system failure can trigger an automatic refund;
- the entitlement remains inactive;
- the file remains inaccessible after refund.

### 6.3 After access

Refund eligibility depends on product/service policy and local requirements. The platform should distinguish:

- File not as described
- Corrupted or inaccessible file
- Unauthorized or incomplete delivery
- Duplicate charge
- Creator failed to fulfill
- Buyer changed mind
- Suspected fraud or chargeback

A refund does not erase the transaction record.

### 6.4 Refund behavior

When a refund is approved:

```text
Order refunded
→ Entitlement marked refunded
→ Future access revoked where policy permits
→ Download links invalidated
→ Chat system event recorded
```

The platform cannot retrieve files already downloaded. The buyer's license can be marked revoked, and future access can be blocked.

For service/project work, already delivered previews or work may remain available as dispute evidence. They are not automatically treated as a transferable purchased asset after refund.

### 6.5 Dispute behavior

```text
Buyer opens dispute
→ Delivery/order frozen for review
→ Evidence window opens
→ Buyer and creator submit context/files
→ Support resolves
→ Refund, partial refund, release, or replacement
```

During a dispute:

- preserve the locked delivery;
- preserve chat/system events;
- preserve file hashes and versions;
- prevent destructive deletion;
- keep access behavior explicit.

Default access rule:

- If the buyer already had lawful access, access may remain temporarily available while the dispute is reviewed unless fraud, abuse, or safety risk requires immediate revocation.
- If the delivery was never accessed, support can keep it locked.
- A full refund can revoke future access.

### 6.6 Creator payout

For custom work and service/project deliveries, funds should remain pending or protected until:

- buyer approval;
- review window expiration;
- or dispute resolution.

For low-risk digital products, settlement may be faster, but refund and abuse controls still apply.

---

## 7. Mobile UX Behavior

### 7.1 Locked delivery card

On mobile, use a compact card:

```text
┌──────────────────────────────┐
│ [preview]  Final reel export │
│            1 video · 240 MB  │
│            Watermarked view  │
│                              │
│            $120               │
│        [Unlock for $120]      │
└──────────────────────────────┘
```

The card should show the status without requiring the user to open a separate order page.

### 7.2 Preview behavior

- Tap preview to open a full-screen viewer.
- Keep watermark and preview restrictions visible.
- Use stream-first video/audio.
- Allow pinch-to-zoom only for the preview asset.
- Show file metadata in a bottom sheet.
- Never expose a shareable original URL.

### 7.3 Payment behavior

Use a bottom-sheet checkout:

```text
Delivery summary
License
Price and fees
Payment source
Refund terms
[Pay and unlock]
```

Keep the conversation visible behind the sheet so the buyer retains context.

### 7.4 After payment

Immediately update the same card:

```text
Payment confirmed
[Download] [Open order]
```

For multiple files:

```text
[Download all]
```

and an expandable file list with individual download actions.

### 7.5 Download UX

- Show progress.
- Support background download where the platform allows it.
- Explain when a large file requires Wi-Fi or additional confirmation.
- Show downloaded/accessed state.
- Route permanently to Purchases/Orders for later access.
- Do not promise offline access unless the client explicitly supports it.

### 7.6 Mobile failure states

#### Payment failed

```text
Payment did not go through.
[Try again] [Change payment method]
```

#### Unlock pending

```text
Payment received. Preparing your files...
```

#### File unavailable

```text
This file is temporarily unavailable.
[Retry] [Contact support]
```

#### Refund/revocation

```text
Access is unavailable because this order was refunded.
[View order] [Contact support]
```

---

## 8. System Messages and Audit Trail

The chat thread records structured system events:

- `Locked delivery sent`
- `Preview opened`
- `Checkout started`
- `Payment confirmed`
- `Files unlocked`
- `Download started`
- `Delivery approved`
- `Refund requested`
- `Dispute opened`
- `Access revoked`

Users see a concise human-readable version. The backend retains:

- actor;
- timestamp;
- order/payment/delivery IDs;
- file/version hashes;
- state transition;
- authorization result.

Audit events cannot be edited or deleted by ordinary participants.

---

## 9. Recommended Data Model Extensions

The current conversation and message model can be extended with dedicated records rather than placing all commerce data into a message row.

### Delivery

- `id`
- `conversationId`
- `senderId`
- `orderId`
- `deliveryType`
- `title`
- `description`
- `status`
- `expiresAt`
- `createdAt`

### Delivery item

- `deliveryId`
- `assetId`
- `previewAssetId`
- `fileName`
- `mimeType`
- `size`
- `version`
- `lockStatus`
- `accessStatus`

### Payment

- `orderId`
- `amount`
- `currency`
- `status`
- `idempotencyKey`
- `paidAt`
- `refundedAt`

### Entitlement/access grant

- `orderId`
- `buyerId`
- `assetId`
- `license`
- `status`
- `grantedAt`
- `revokedAt`
- `lastAccessedAt`

The chat message references the delivery/order. It should not be the sole place where file authorization or payment status lives.

## Final rule

A paywalled delivery is successful only when the buyer can understand the offer before payment, the original remains genuinely inaccessible until payment confirmation, the order and entitlement are created atomically, and the same chat card becomes a usable secure download immediately after payment.
