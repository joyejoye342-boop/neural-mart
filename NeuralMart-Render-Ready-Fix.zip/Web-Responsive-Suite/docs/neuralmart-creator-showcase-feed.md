# NeuralMart — Creator Showcase Feed

**Document version:** 1.0  
**Primary route:** `/`  
**API foundation:** `GET /api/feed/showcase`

---

## 0. Feed Definition

The Creator Showcase Feed is NeuralMart's social and commercial discovery surface for work creators want buyers and audiences to see.

It answers:

```text
What is this creator making?
What can I buy or hire them for?
Why should I view their profile?
```

It is different from the Opportunities Feed:

| Showcase Feed | Opportunities Feed |
|---|---|
| Discover work and creators | Find work to apply for |
| Social and visual | Structured and high-intent |
| Creator-led publishing | Buyer-led opportunities |
| Passive discovery plus contextual CTA | Proposal/entry decision |

The Showcase Feed is the default Home surface for all roles. Its CTA changes based on the viewer and card type.

---

## 1. Feed Structure

```text
SHOWCASE
├── App header
│   ├── Search
│   ├── Notifications
│   ├── Messages
│   └── Menu
├── Role-aware composer
├── Optional discovery chips
├── Personalized feed
│   ├── Creator showcase cards
│   ├── Product cards
│   ├── Service cards
│   ├── Project cards
│   └── Recommendation blocks
└── Empty/loading/error states
```

### Creator composer

```text
Share your latest work…
[Post] [Product] [Service]
```

### Buyer composer

```text
What are you looking to create?
[Post a project]
```

### Both users

Both users see the creator composer first and a smaller buyer action strip below:

```text
[Post a project] [Host a contest]
```

This keeps one shared home rather than switching between separate products.

---

## 2. Supported Post Types

### 2.1 Reel/video

- Short-form motion
- Video edit
- Animation
- Process clip
- Before/after

Primary buyer CTA:

```text
View creator
```

If linked to a service:

```text
View related service
```

### 2.2 Thumbnail showcase

- YouTube thumbnail
- Campaign thumbnail
- Video cover
- Multiple variation gallery

CTA:

- View portfolio
- Hire creator
- View related service

### 2.3 Graphic/showcase image

- Illustration
- Brand graphic
- UI visual
- Poster
- Social asset

CTA:

- View creator
- Start a project
- View related service/product

### 2.4 Case study/portfolio post

- Problem
- Process
- Deliverables
- Outcome

Case studies receive stronger commercial CTA treatment because they are decision-support content:

```text
View case study
→ View creator
→ Start a project
```

### 2.5 Digital product showcase

- Template
- Asset pack
- Preset
- Course/tool
- Exclusive project asset

CTA:

- Buy now
- View product
- Owned / Sold · Locked

The product remains a commerce object linked to the post.

### 2.6 Service showcase

- Service announcement
- Package preview
- Availability post
- Offer or launch

CTA:

- View service
- Book service
- Message creator

### 2.7 Promotional creator post

- New product launch
- Service availability
- Client work announcement
- Milestone
- Open-for-work update

Promotional posts must be labeled when they contain a commercial action. They should not look like hidden ads.

### 2.8 Availability post

```text
Available for work
Open for 2 branding projects in April
```

CTA:

- View profile
- Start a project
- Message creator

Availability is a post subtype, not a separate feed family.

---

## 3. Shared Card Structure

All content uses the shared NeuralMart card shell:

```text
Author header
→ Type label
→ Content/media
→ Trust and decision metadata
→ Social actions
→ One primary CTA
```

### Creator header

```text
[avatar] Maya Johnson · Top Rated Creator
         Brand identity · 2h
```

Show only compact trust:

- current creator level;
- verification;
- one relevant specialty badge at most.

### Card metadata by type

| Type | Metadata |
|---|---|
| Reel/video | Duration, category, linked service |
| Graphic/thumbnail | Category, format, linked offer |
| Case study | Deliverables, category, outcome |
| Product | Price, sales/reviews, ownership state |
| Service | Starting price, delivery time, rating |
| Availability | Capacity, category, response summary |
| Project | Budget, deadline, proposal count |

---

## 4. Ranking and Discovery Logic

The feed balances social discovery and commercial usefulness.

### Ranking signals

```text
Followed creators
→ Relevant category/skills
→ Freshness
→ Meaningful engagement
→ Buyer intent
→ Creator diversity
→ Content quality and eligibility
```

### Content diversity

Do not show five near-identical posts from one creator in a row. Use:

- creator frequency caps;
- format diversity;
- category diversity;
- commercial-card spacing;
- recommendation spacing.

### Engagement interpretation

Weight actions by intent:

```text
Purchase/order
→ Service/product click
→ Chat/profile visit
→ Save/follow
→ Comment/like
→ Impression
```

High likes alone should not outrank work that creates qualified buyer actions.

### Buyer-aware personalization

For buyers, ranking can use:

- saved categories;
- viewed creators;
- opened services/products;
- previous orders;
- project categories;
- creator availability.

For creators/general audiences, ranking emphasizes:

- followed creators;
- category interests;
- peer discovery;
- relevant products/services.

### What does not appear in Showcase

- Closed contests
- Expired projects
- Private project briefs
- Proposal details
- Private buyer notes
- Creator-only performance metrics

Open project cards may appear as compact opportunities for buyers to understand marketplace activity, but the full work-seeking surface remains Opportunities.

---

## 5. Buyer-Facing CTA Strategy

### CTA matrix

| Card | General audience | Buyer | Creator |
|---|---|---|---|
| Reel/video | View creator | View creator / Start project | View creator |
| Graphic/thumbnail | View creator | Start project | View creator |
| Case study | View case study | Start project | View case study |
| Product | View product | Buy now | View/buy |
| Service | View service | Book service | View service |
| Availability | View profile | Message / Start project | View profile |
| Promotional post | View offer | View offer | View offer |
| Own content | Manage post | — | Manage post |

### CTA rules

- One primary CTA per card.
- `Message creator` is secondary unless the creator explicitly invites inquiries.
- `Start a project` routes to the buyer project flow with creator context attached.
- `Book service` routes to service order flow.
- `Buy now` routes to product detail/checkout.
- A CTA should preserve the referring post for attribution.

### Buyer context handoff

When a buyer starts a project from a Showcase card:

```text
Start project
→ Draft created
→ Creator attached as invite/suggested creator
→ Buyer completes brief
→ Creator receives invitation or project visibility according to settings
```

This is different from directly hiring without a project brief.

---

## 6. Creator Posting Controls

### Create flow

```text
Choose type
→ Upload/select media
→ Add caption and tags
→ Link product/service/project
→ Choose audience
→ Preview
→ Publish or save draft
```

### Creator controls

- Publish
- Save draft
- Schedule, advanced
- Edit
- Duplicate
- Pin to profile
- Archive
- Delete
- Disable comments
- Restrict replies
- Hide from feed while keeping on profile
- Link/unlink product or service
- Promote, advanced
- View performance

### Visibility options

- Public feed and profile
- Profile only
- Followers
- Unlisted link
- Draft/private

Commercial product/service posts should be public or profile-visible to support discovery. Private content must not appear in recommendations.

### Pinned content

- Up to three pinned Showcase items.
- One featured item may appear in public profile Overview.
- Pinning changes prominence, not ranking integrity.

### Archive behavior

Archived posts leave public feed recommendations but preserve analytics and can be restored as drafts.

---

## 7. Feed-to-Profile Connection

Every creator content card links to the public profile, but the destination depends on intent:

- Reel → Profile Showcase with Reels filter
- Graphic/thumbnail → Profile Showcase with matching filter
- Product → Profile Products or product detail
- Service post → Profile Services or service detail
- Case study → Profile Overview/Showcase
- Availability → Profile Overview with hiring CTA

### Profile signals

The public profile can use Showcase content for:

- featured/pinned work;
- Overview preview;
- Showcase tab;
- category filters;
- service/product proof;
- trust and credibility context.

Removing a post from the feed does not remove it from the creator's profile unless the creator archives it.

---

## 8. Creator Feed Analytics

Per-content insights connect to the Creator Analytics hub:

- impressions/views;
- saves;
- follows;
- profile visits;
- service/product clicks;
- chat leads;
- project-start actions;
- purchases/orders;
- attributed revenue.

The feed should show only a compact preview:

```text
1,240 views · 86 saves · 3 profile visits
[View insights]
```

Full analytics remain private.

### Proposal connection

Showcase content can be attached to proposals as relevant samples. Bid Insights can then show:

```text
Proposal with case-study sample
→ View rate
→ Shortlist rate
→ Win rate
```

This connection is measured, not treated as proof of causation.

---

## 9. Feed Moderation and Quality

- All public posts pass content policy checks.
- Commercial claims must be accurate.
- Client work requires appropriate permission.
- Creator-owned source files remain private.
- Duplicate or spam posts are rate-limited.
- Promotional content is labeled.
- Paid promotion is separated from organic performance.
- Reports are available from overflow.
- Content that is removed retains appropriate moderation/audit state.

Do not optimize the feed by rewarding posting volume alone.

---

## 10. MVP vs Advanced

### MVP

- Shared Showcase Feed
- Creator composer
- Reels/videos
- Graphics/thumbnails
- Product showcases
- Service showcases
- Promotional posts
- Availability posts
- Public/profile-only visibility
- Pin/archive/edit
- Buyer-facing contextual CTAs
- Basic ranking using follows, relevance, freshness, and engagement
- Basic content analytics

### Advanced

- Case-study builder
- Scheduled publishing
- Collections
- Saved audience segments
- Paid promotion
- Content experiments
- Format recommendations
- Advanced attribution
- Draft collaboration
- Reusable templates
- Asset library integration
- Cross-posting

## Final rule

The Creator Showcase Feed should make good work discoverable and commercially useful without turning every post into an advertisement. The strongest path is:

```text
See the work
→ Understand the creator
→ View the relevant offer
→ Start a project, book, buy, or message
```
