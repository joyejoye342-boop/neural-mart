# NeuralMart — Menu / Control Center Architecture

**Document version:** 1.0  
**Scope:** The control-center page opened from the universal three-dot menu.  
**Companion documents:** `neuralmart-navigation-hub-system.md` · `neuralmart-role-permissions-model.md` · `neuralmart-ux-design-system.md`

---

## 0. Product Definition

The NeuralMart Menu is not a miscellaneous settings page. It is the user's **personal control center**:

- a fast place to take common account and money actions;
- a clear directory to deeper business tools;
- a safe place for security, support, policies, and sign-out.

It should feel familiar like a Facebook-style Menu page, but more intentional for a marketplace:

> **Top: what needs action now. Middle: money and work. Bottom: account, help, and policy.**

The page should never expose every platform capability at once. It should expose a short set of high-frequency actions and route everything else to focused pages.

### Menu entry point

The canonical mobile entry point is a `MoreHorizontal` three-dot icon in the app bar:

```text
[NeuralMart]                         [•••]
```

Tapping it opens `/menu`. On desktop, the same destination is available from the sidebar's `Menu` item and the user's account menu. The avatar remains the profile shortcut; the three-dot button is the control-center shortcut.

If the app already uses a five-item bottom navigation bar, Menu can remain there during migration, but the three-dot icon should always open the same `/menu` page. There must be one Menu destination, not separate mobile and desktop menus.

---

## 1. Information Architecture

The page has six layers, ordered by urgency and frequency:

```text
1. Identity header
2. Menu search
3. Quick actions
4. Financial and business snapshot
5. Account and platform sections
6. Support, policies, and sign out
```

### Full structure

```text
MENU / CONTROL CENTER
│
├── Identity header
│   ├── Avatar, display name, role/capabilities
│   ├── Verification/profile completion state
│   └── View profile · Edit profile
│
├── Search account and settings
│
├── Quick actions
│   ├── Add funds
│   ├── Withdraw funds
│   ├── Payment sharing
│   └── Transaction history
│
├── Money
│   ├── Wallet & earnings
│   ├── Financial dashboard
│   ├── Payment methods
│   ├── Transaction history
│   └── Payout settings
│
├── Work and marketplace
│   ├── Orders
│   ├── Bid insights (Creator/Both)
│   ├── My projects / hosted contests
│   ├── Listings and availability (Creator/Both)
│   └── Saved items
│
├── Account and preferences
│   ├── Profile and portfolio
│   ├── Creator settings
│   ├── Notifications
│   ├── Privacy and visibility
│   ├── Security and password
│   └── Language, currency, and appearance
│
├── Help and trust
│   ├── Help center
│   ├── Contact support
│   ├── Report a problem
│   ├── Safety and disputes
│   └── Policies
│
└── Sign out
```

The page may show summaries for these areas, but the full functionality belongs in dedicated pages.

---

## 2. First Screen Structure

The first screen should answer three questions:

1. Who am I signed in as?
2. What can I do immediately?
3. Where is my money?

### Mobile layout

```text
┌──────────────────────────────────────┐
│  Menu                         [✕]    │
├──────────────────────────────────────┤
│ [Avatar]  Alex Carter                │
│           Creator · Buyer            │
│           [View profile] [Edit]      │
├──────────────────────────────────────┤
│ [⌕ Search settings and tools      ]  │
├──────────────────────────────────────┤
│ QUICK ACTIONS                         │
│ [＋ Add funds] [↓ Withdraw]           │
│ [↗ Share payment] [Receipt History]  │
├──────────────────────────────────────┤
│ WALLET                                │
│ Available             Pending         │
│ $1,240.00             $180.00         │
│ [Open financial dashboard →]          │
├──────────────────────────────────────┤
│ WORK CENTER                          │
│ Orders                         ›     │
│ Bid insights                   ›     │
│ My projects                   ›     │
│ Listings & availability       ›     │
└──────────────────────────────────────┘
```

The user can see the beginning of Account, Help, and Sign out after a short scroll. No dashboard charts, full transaction tables, or long descriptions are placed above the fold.

### Desktop layout

At `md` and above, use a centered two-column layout:

```text
┌─────────────────────────────────────────────────────────┐
│ Control Center                                  [Search] │
├──────────────────────────────┬──────────────────────────┤
│ Identity + Quick Actions     │ Wallet + Money snapshot  │
│                              │                          │
│ Work Center                  │ Account & preferences    │
│                              │ Help, safety & policies  │
└──────────────────────────────┴──────────────────────────┘
```

The columns are a presentation enhancement only. The information hierarchy remains the same as mobile.

---

## 3. Section 1 — Identity Header

### Purpose

Provide orientation and a direct path to the user's public identity without treating the profile as a settings screen.

### Content

- Avatar
- Display name
- Capability label:
  - `Buyer`
  - `Creator`
  - `Creator · Buyer`
  - `Admin`
- Verification badge when earned
- Profile completion progress only when incomplete
- `View profile`
- `Edit profile`

### Interaction

- Tapping the identity area opens the public profile/storefront.
- `Edit profile` opens `/profile/edit`.
- A low-pressure `Become a Creator` banner appears only for Buyer accounts and only until dismissed or completed.
- Both users do not see a role-switching control here. Their capabilities are additive, not separate accounts.

### Visual rule

The identity area is one calm card with no more than two actions. Do not include follower counts, earnings, orders, and badges here; those belong in the relevant hubs.

---

## 4. Section 2 — Menu Search

### Search purpose

Menu search is for finding **tools, settings, and account destinations**, not marketplace content. Global content search remains in the app-bar magnifier.

The placeholder should be:

```text
Search settings and tools
```

### Search behavior

1. Tapping the search field expands it to a focused search surface.
2. Search begins after two characters.
3. Results are grouped by destination family.
4. Results show an icon, title, short description, and destination.
5. Selecting a result navigates directly to its page and closes the search.
6. The last three searches appear when the field is empty.
7. A clear button resets the query.
8. Search state is not persisted in the URL unless the user opens a destination.

### Searchable items

| Query examples | Result |
|---|---|
| `wallet`, `balance`, `money` | Wallet & earnings |
| `add`, `top up`, `fund` | Add funds |
| `withdraw`, `payout` | Withdraw funds |
| `payment`, `share`, `request` | Payment sharing |
| `receipt`, `history`, `transaction` | Transaction history |
| `bid`, `proposal`, `insight` | Bid insights |
| `password`, `login`, `security` | Security & password |
| `notification`, `email`, `alerts` | Notification preferences |
| `privacy`, `visibility` | Privacy & visibility |
| `policy`, `terms`, `privacy policy` | Policies |
| `help`, `contact`, `support` | Help & support |

### Result ranking

Rank in this order:

1. Exact title match
2. Synonym match
3. User's recent destinations
4. Most frequently used destination
5. Alphabetical tie-breaker

Results must respect role visibility. A Buyer should not receive a Creator-only `Bid insights` result unless the account has Creator capability.

### Empty and no-result states

```text
No menu tools match “payouts”.
Try wallet, withdraw, or payment.
```

The empty state offers no marketplace content recommendations. It can offer `Contact support` only when the query looks like a problem report, such as `can't withdraw`.

---

## 5. Section 3 — Quick Actions

Quick actions are the only part of Menu that behaves like a dashboard. They are high-frequency, high-intent actions and should be visible without opening a section.

### Final quick-action set

| Action | Destination | Visibility |
|---|---|---|
| **Add funds** | `/wallet/add-funds` | Buyer, Creator, Both |
| **Withdraw funds** | `/wallet/withdraw` | Creator, Both; hidden or disabled for Buyer with no withdrawable balance |
| **Payment sharing** | `/payments/share` | Buyer, Creator, Both |
| **Transaction history** | `/wallet/history` | Buyer, Creator, Both |

### Card design

Use four compact action tiles on desktop and a 2×2 grid on mobile:

```text
[＋ Add funds]       [↓ Withdraw]
[↗ Share payment]   [▤ History]
```

Each tile contains:

- 20px icon
- Short label
- Optional one-line status, such as `No payout method`
- Minimum 56px visual height and 44px hit target

### Quick-action rules

- `Add funds` is primary blue.
- `Withdraw` is primary only for creators with available earnings; otherwise it is neutral with helper text.
- `Payment sharing` uses a neutral payment icon and never implies that a payment has been made.
- `Transaction history` is always available but remains visually secondary.
- Do not add `Add product`, `Post project`, `Host contest`, or `Message` to this row. Those actions already have contextual entry points in the feed, hubs, and app bar.

---

## 6. Section 4 — Money and Financial Tools

Financial tools are grouped under **Money**, with the Wallet summary shown early because it provides useful status. The full financial dashboard is a dedicated page.

### 6.1 Wallet summary card

The summary card shows:

- Available balance
- Pending balance
- Withdrawable earnings, for Creator/Both
- Funding-needed state, for Buyers
- One link: `Open financial dashboard →`

It should not show a chart, full ledger, or several competing buttons.

### 6.2 Financial destinations

| Destination | Purpose | Quick access? |
|---|---|---:|
| Wallet & earnings | Balance, pending funds, wallet activity | Yes, via summary |
| Financial dashboard | Earnings/spend trends, payout status, financial overview | Link from summary |
| Add funds | Add money to the platform wallet | Yes |
| Withdraw funds | Move eligible earnings to a payout method | Yes for Creator/Both |
| Payment sharing | Share/request a secure payment link or payment request | Yes |
| Transaction history | Searchable record of wallet and order transactions | Yes |
| Payment methods | Add/remove funding and payout methods | Deeper |
| Payout settings | Payout schedule, destination, tax/verification state | Deeper |

### 6.3 Payment sharing definition

Payment sharing is a controlled flow for sending a secure payment request or payment link from NeuralMart:

- Creator can share a payment request for a client engagement.
- Buyer can share a payment request with a collaborator or return to a payment flow.
- Both can use the same destination.
- The recipient sees a safe NeuralMart payment page, never raw banking details.

The Menu card should label this `Share payment` or `Payment sharing`, with helper text:

```text
Send a secure payment request
```

Do not place card numbers, bank details, or sensitive payment data on the Menu page.

### 6.4 Money states

| State | Menu behavior |
|---|---|
| No balance | Show `$0.00` and `Add funds` |
| Pending funds | Show pending amount with `Why is this pending?` on financial detail |
| Creator with earnings | Show `Withdrawable` amount and active Withdraw action |
| Missing payout method | Show `Withdraw funds` with `Set up payout method` helper |
| Failed verification | Show a non-blocking warning and route to verification |
| Payment issue | Show `Resolve payment issue` in the summary, not a generic error |

Financial alerts are shown only when they require action. Informational ledger details stay in the financial dashboard.

---

## 7. Section 5 — Work Center and Business Tools

This section differs by capability but uses one shared group called **Work center**. It is where users manage work after discovering it through feeds.

### Buyer

| Item | Destination | Purpose |
|---|---|---|
| Orders | `/orders` | Purchases, bookings, delivery, completion |
| My projects | `/projects` | Projects posted by the buyer |
| Hosted contests | `/contest-feed` or contest management | Contests hosted by the buyer |
| Saved creators | `/saved/creators` | Shortlisted talent |

### Creator

| Item | Destination | Purpose |
|---|---|---|
| Orders | `/orders` | Active and completed client work |
| Bid insights | `/dashboard/creator/bids` | Proposal views, response rates, win rates, category trends |
| Listings & availability | `/dashboard/creator/listings` | Products, services, availability state |
| My submissions | `/dashboard/creator/submissions` | Contest entries and outcomes |
| Saved opportunities | `/saved/opportunities` | Bookmarked projects and contests |

### Both

Show a compact segmented choice inside Work center:

```text
[Buying] [Selling]
```

This is not a global app mode switch. It filters the Work center list only:

- `Buying`: Orders, My projects, Hosted contests, Saved creators
- `Selling`: Orders, Bid insights, Listings & availability, My submissions

Both users still retain access to both sides and do not lose navigation when changing the segment.

### Bid insights

Bid insights is Creator/Both-only and should not be a raw analytics dump. The Menu row should show a compact status:

```text
Bid insights                         ›
12 active proposals · 3 viewed
```

The full page can contain:

- Proposal views
- Response rate
- Shortlist rate
- Win rate
- Average time to response
- Performance by category and budget range
- Suggestions such as improving portfolio relevance

Do not show bid insights on the Buyer Menu. Buyers should see project performance inside their dashboard instead.

---

## 8. Section 6 — Account and Preferences

Account tools are grouped by user intent rather than by implementation ownership.

### Profile and identity

- Profile and portfolio → `/creators/:id` or `/profile/edit`
- Creator settings → `/settings/creator` for Creator/Both
- Become a Creator → `/settings/creator-upgrade` for Buyer
- Pause Creator activity → `/settings/creator` for Both

### Preferences

- Notifications → `/settings/notifications`
- Privacy and visibility → `/settings/privacy`
- Appearance → `/settings/appearance`
- Language and currency → `/settings/preferences`

### Security

- Security and password → `/settings/security`
- Active sessions → `/settings/security/sessions`
- Two-step verification → `/settings/security/2fa` when available
- Account deletion → `/settings/danger-zone`

### Grouping rule

Do not show all preference rows expanded on initial load. Use three compact section cards:

```text
Profile & identity                  ›
Preferences                         ›
Security                            ›
```

Each opens a dedicated settings page or a focused sub-menu. This is the main defense against a long settings dump.

---

## 9. Section 7 — Support, Safety, and Policies

Support tools are separated from account settings because their intent is different: users come here when they need help or need to understand their rights.

### Support

- Help Center → searchable help articles
- Contact support → support conversation/ticket flow
- Report a problem → issue category + optional screenshot/context
- Check service status → platform status when relevant

### Safety and disputes

- Trust & safety → reporting, blocking, safe transactions
- Dispute an order → dispute flow scoped to an order
- Contest or project issue → issue flow scoped to an opportunity
- Report content → available from card overflow and linked here

### Policies

Use one `Policies` row that opens a policy index rather than listing every document on Menu:

```text
Policies                             ›
Terms · Privacy · Payments · Creator rules
```

The policy index contains:

- Terms of Service
- Privacy Policy
- Payments and refunds
- Creator and marketplace rules
- Contest rules
- Community and content policy
- Licensing and ownership rules

Policies should be versioned and display an `Updated` date. The Menu page should never present policy copy inline.

---

## 10. Logout and Destructive Actions

Sign out is always last, visually separated by a divider.

```text
──────────────────────────────────────
[↪] Sign out
```

Behavior:

1. Tap `Sign out`.
2. Show a lightweight confirmation sheet: `Sign out of NeuralMart?`
3. Confirm → terminate the session and route to `/login`.
4. Cancel → return to Menu without changing scroll position.

Account deletion is not placed beside logout. It belongs in `Security → Danger zone` and requires a separate confirmation flow explaining what is retained, removed, or irreversible.

---

## 11. Role-Based Menu Variations

The page structure remains stable for every role. Only content, helper text, and available actions change.

| Area | Buyer | Creator | Both | Admin |
|---|---|---|---|---|
| Identity | Buyer label | Creator label | Creator · Buyer | Admin label |
| Add funds | Visible | Visible | Visible | Staff policy |
| Withdraw | Hidden or unavailable | Visible | Visible | Staff policy |
| Payment sharing | Visible | Visible | Visible | Support-only |
| Transaction history | Visible | Visible | Visible | Audit tools |
| Financial dashboard | Spend view | Earnings view | Toggle spend/earnings | Platform finance |
| Bid insights | Hidden | Visible | Visible | Moderation/read-only |
| My projects | Visible | Hidden | Buying segment | Admin tools |
| Hosted contests | Visible | Hidden | Buying segment | Moderation |
| Listings/availability | Hidden | Visible | Selling segment | Moderation |
| Become a Creator | Visible | Hidden | Hidden | Hidden |
| Creator settings | Hidden | Visible | Visible | Hidden |
| Trust & safety | Visible | Visible | Visible | Admin moderation |
| Admin controls | Hidden | Hidden | Hidden | Visible |

### Buyer experience

Prioritize:

1. Add funds
2. Payment sharing
3. Orders
4. My projects
5. Financial/spend history

Use helper text such as `Fund your wallet to hire creators` when balance is zero.

### Creator experience

Prioritize:

1. Withdraw funds
2. Financial dashboard
3. Bid insights
4. Listings & availability
5. Orders

Use helper text such as `Set up a payout method` when earnings cannot yet be withdrawn.

### Both experience

Use one identity and one wallet. Do not duplicate the entire page into `Buyer Menu` and `Creator Menu`. Keep shared rows shared and group the two work contexts behind a small Buying/Selling segment.

### Admin experience

Admin accounts receive a separate `Admin tools` section near the top or bottom depending on the platform's operational needs:

- Moderation queue
- Disputes
- Reports
- User safety
- Platform financial audit

Admin tools must be clearly labeled and never appear for marketplace accounts.

---

## 12. Quick Access vs Deeper Settings

### Quick-access cards

These should be visible on the first screen or immediately below the identity header:

- Add funds
- Withdraw funds
- Share payment
- Transaction history
- Wallet summary
- Financial dashboard link

They are either money actions or high-frequency account actions.

### List rows

Use compact rows for destinations users may need regularly but not every session:

- Orders
- Bid insights
- My projects
- Listings & availability
- Saved items
- Notification preferences

### Deeper settings

Nest behind grouped rows:

- Payment methods
- Payout settings
- Privacy
- Security
- Appearance
- Language/currency
- Legal policies

### Never expose as a top-level Menu item

- Individual order details
- Every notification category
- Every policy document
- Raw analytics metrics
- Product/service creation
- Project/contest creation
- Full proposal management
- Admin-only tools for non-admins

These belong in their own hubs or contextual flows.

---

## 13. Searchable Settings Index

The Menu should maintain a small destination registry with aliases:

```ts
type MenuDestination = {
  id: string;
  title: string;
  aliases: string[];
  description: string;
  section: 'money' | 'work' | 'account' | 'support' | 'policy';
  href: string;
  roles: Array<'buyer' | 'creator' | 'both' | 'admin'>;
  priority: number;
};
```

Search indexes destinations, not arbitrary page copy. This keeps results fast, predictable, and easy to permission-filter.

Recommended behavior:

- client-side index for instant results;
- route-level authorization remains server-side;
- show unavailable destinations only when a user needs to understand why they cannot access them;
- use `aria-label="Search settings and account tools"`;
- support keyboard navigation on desktop;
- support recent searches and escape-to-close on mobile.

---

## 14. Visual Design Language

### Section hierarchy

Use a calm vertical stack rather than a dense settings table:

```text
Identity card
Search field
Quick-action grid
Wallet card
Section row group
Section row group
Section row group
Sign-out row
```

### Card and row rules

- One visual treatment for all section cards: `bg-card`, `border-border`, `rounded-2xl`.
- Quick-action cards can use subtle semantic tints.
- Row groups use dividers, not separate floating cards for every item.
- Each row contains icon, title, optional helper text, and chevron.
- Keep descriptions to one line on mobile.
- Use no more than two accent colors in the first screen: primary blue and financial green/amber status.

### Semantic accents

| Element | Accent |
|---|---|
| Add funds | Primary blue |
| Withdrawable earnings | Green |
| Pending funds | Amber |
| Payment issue | Red |
| Support/safety | Violet or neutral |
| Sign out | Destructive red text, no red-filled card |

### Typography

- Page title: 28–32px serif or display face
- Section heading: 11–12px uppercase muted label
- Row title: 14–16px medium
- Helper/status text: 12–13px muted
- Wallet balance: 32–40px display face

---

## 15. Mobile Interaction Notes

- Menu opens as a full route rather than a cramped popover because it contains financial and security destinations.
- The page scrolls naturally; no nested scroll containers.
- The header may remain sticky with `Menu` and close/back controls.
- Search expands in place and can become a full-screen search sheet.
- Quick actions remain near the top; do not make users scroll past settings to reach money tools.
- Use bottom sheets for confirmation and small choices, not for the whole control center.
- Preserve scroll position when returning from a child setting.
- Make every row at least 52px high with a 44px interactive target.

---

## 16. Desktop Interaction Notes

- Menu is a full page in the main content area, not a tiny dropdown.
- The desktop sidebar remains visible for primary hubs.
- The Menu page can use a two-column layout, but groups must preserve the same order as mobile.
- Search stays visible at the top of the page and supports keyboard focus.
- Hover states may reveal descriptions, but important status should not depend on hover.
- Financial cards can use a wider summary layout, but detailed charts remain on the Financial Dashboard page.

---

## 17. Empty, Loading, and Error States

### Loading

Show:

- identity skeleton;
- four quick-action skeletons;
- wallet balance skeleton;
- three section-group skeletons.

Do not show a blank page or a full-page spinner if identity data is available.

### Wallet unavailable

```text
Wallet information is temporarily unavailable.
[Retry]
```

The rest of Menu must remain usable if the wallet request fails.

### Search failure

```text
Search is temporarily unavailable.
Browse account and support tools below.
```

### Missing role capability

Do not show dead links. Either hide a capability-specific item or show a disabled row with an explicit reason and a route to upgrade, such as `Become a Creator`.

---

## 18. Performance and Safety Rules

- Fetch identity and wallet summary in parallel.
- Lazy-load detailed analytics only after the user opens Financial Dashboard or Bid Insights.
- Do not load transaction history into Menu; show only a summary.
- Cache the destination index locally; never cache financial values beyond the active query policy.
- Never render payment method numbers, bank account details, or secrets on Menu.
- Every child page must perform its own authorization check.
- Logging out must invalidate the session server-side, not only clear local UI state.
- Payment-sharing links must use platform-generated identifiers and safe expiration rules.

---

## 19. Final Menu Blueprint

```text
MENU / CONTROL CENTER

[Avatar] Alex Carter
        Creator · Buyer · Verified
        [View profile] [Edit profile]

[Search settings and tools                         ]

QUICK ACTIONS
[Add funds]       [Withdraw]
[Share payment]   [History]

WALLET
$1,240 available       $180 pending
[Open financial dashboard →]

WORK CENTER
Orders                                      ›
Bid insights · 12 active proposals          ›  Creator/Both
My projects                                ›  Buyer/Both
Listings & availability                    ›  Creator/Both
Saved items                                ›

ACCOUNT & PREFERENCES
Profile & identity                         ›
Preferences                                ›
Security                                   ›

HELP & TRUST
Help center                                ›
Contact support                            ›
Safety & disputes                          ›
Policies                                   ›

────────────────────────────────────────────
[Sign out]
```

## Final UX Simplification Strategy

The Menu stays clean by applying four boundaries:

1. **Money is visible, but detail is not.** Show balance and four financial actions; route ledger, methods, and analytics deeper.
2. **Work is grouped by capability.** Buyers see buying tools; Creators see selling and bid tools; Both users see a small Buying/Selling filter.
3. **Settings are grouped by intent.** Profile, Preferences, and Security are three destinations, not fifteen rows.
4. **Support and policies are a separate exit path.** Users looking for help should not have to scan account settings, and policy documents should not overwhelm the operational controls.

The Menu should make common actions obvious in seconds and make uncommon tools findable in one search — without becoming another dashboard.
