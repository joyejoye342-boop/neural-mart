# NeuralMart — User Role & Permissions Model

Grounded in the current schema (`users.role` enum: `buyer | creator | both | admin`, plus a separate `creator_profiles` table) and the route/page map in `docs/neuralmart-page-map.md`.

---

## 0. Design principle

NeuralMart is **not** a multi-account platform (like having separate "Fiverr seller" and "Fiverr buyer" logins). It's **one identity, flexible capabilities**. A single person is a Creator on Monday selling templates, a Buyer on Tuesday hiring a video editor, and a Contest participant on Wednesday — all under one profile, one wallet, one inbox. The permissions model has to reflect that reality instead of forcing a binary choice.

This means: **role is a capability flag, not an identity silo.** The account record (`role` column) is best understood as "which capability set is currently switched on," not "what kind of user this is forever."

---

## 1. All User Roles

There are exactly **four account-level roles** stored on `users.role`, plus **one activity-level distinction** that isn't a stored role at all but matters for permissions.

| Role (stored) | Who they are | Capabilities unlocked |
|---|---|---|
| **Buyer** (`buyer`) | Hires freelancers, buys products, posts projects/contests | Buying, hiring, posting briefs, chat-commerce as a client |
| **Creator** (`creator`) | Sells products/services, posts portfolio content, takes on work | Selling, portfolio publishing, bidding, badges/reputation |
| **Both** (`both`) | A user who has switched on both capability sets | Everything Buyer + everything Creator, unified |
| **Admin** (`admin`) | Platform staff | Moderation, disputes, financial oversight, platform config — no marketplace participation by default |

The activity-level distinction that is **not** a separate stored role:

| Activity role | What it means | Why it's not a stored role |
|---|---|---|
| **Contest Participant** | Any Creator (or Both) who has submitted to a contest | It's an *action*, not a *permission tier* — anyone with Creator capability can do this the moment they submit. Tracked via `contest_submissions` rows, not a role flag. |
| **Freelancer** (proposal-based project work) | Any Creator (or Both) who submits Proposals to Projects | Same reasoning — it's a Creator capability, not a separate permission tier. Tracked via `proposals` rows. |
| **Digital Seller** (product sales) | Any Creator (or Both) who lists Products | Same — a Creator capability, not a separate tier. |

**Why collapse these into "Creator"?** Freelancing, contest entry, and product selling all require the exact same trust surface: a public storefront, a rating/review system, payout ability, and a seller side of the Order model. Splitting them into separate roles would triple the permission surface for zero practical gain — a Creator profile already gates all three. Where they *do* need to differ is in **UI framing** (see §7 and §10), not in **access control**.

---

## 2. Separate or Flexible?

**Flexible, with one identity.** Concretely:

- `role` lives on the single `users` row — there is one login, one password, one session, one wallet balance, one inbox.
- `buyer` and `creator` are **additive**, not exclusive: `both` is a first-class enum value, not a UI-only concept layered on top of two accounts.
- A `creator_profiles` row is a **capability record**, not a second account — it's created the moment a user turns on Creator capability (at registration or later) and is simply absent/unused if they never do.
- `admin` is the one genuinely separate track: an admin is platform staff, not a marketplace participant, and does not also hold buyer/creator capabilities in the same account (see §2.1 for how staff who also want to shop/sell should be handled).

### 2.1 Admin is structurally different — why
Admin needs to be trusted to moderate disputes between Buyers and Creators, see other users' financials, and change platform-wide settings. Letting `admin` also equal `both` on the same row would mean a platform employee's personal purchases/sales are entangled with their moderation permissions — a real conflict-of-interest and audit-trail risk. **Recommendation:** admins who want to also buy/sell on the platform do so from a **second, ordinary account** (allowed, just like an employee could be a customer of their own company under a personal email), while their staff account stays `admin`-only.

---

## 3. How a Single User Switches or Combines Roles

Three flows, all changing the same `users.role` field:

### 3.1 At Registration (current, built)
The Register page's "I want to..." selector (`buyer` / `creator`) sets the initial `role`. Choosing Creator immediately provisions a `creator_profiles` row (`onConflictDoNothing`, already implemented in `POST /api/auth/register`).

### 3.2 Upgrading later — "Become a Creator" (Planned)
A Buyer-only account gets a persistent, low-pressure prompt (not a blocking modal) to activate Creator capability:
- **Entry points:** Menu → "Become a Creator" banner; Edit Profile → "Add Creator capability" toggle; contextual nudge the first time a Buyer tries to reply to a job posting as a bidder, or clicks "Sell your own products."
- **Flow:** Short form (category, skills, optional portfolio links) → `PATCH /api/users/:id` sets `role = 'both'` and provisions `creator_profiles` → user is dropped into a lightweight Creator onboarding checklist (finish profile, list first product/service) rather than being silently upgraded with an empty storefront.
- **No approval gate by default** — self-serve, matching the "powerful but easy" mandate. (A `isVerified` flag already exists on `users` for an optional trust badge, not a gate.)

### 3.3 Downgrading / hiding capability — "Pause Creator mode" (Planned)
A `both` user who no longer wants to sell doesn't need to delete anything: a **"Pause Creator activity"** toggle in Settings sets a `creatorProfiles.isPaused` flag (schema addition) rather than destroying the role. This:
- Hides their storefront/listings from Explore and search.
- Removes the Creator-only nav items and dashboard.
- Keeps their `role` as `both` and preserves history/reviews/earnings so re-activating is instant.
- Full role *reversion* to plain `buyer` (removing `creator_profiles` entirely) is a separate, rarer, destructive action gated behind a confirmation ("this removes your public storefront and Creator stats — your order history is kept").

### 3.4 The Switcher UI (Planned) — how `both` users move between contexts
Rather than a global "mode switch" that hides half the app (which reintroduces the multi-account feeling this model is designed to avoid), `both` users get:
- A **persistent, small context toggle** in the top nav — "Selling view / Buying view" — that only changes **which dashboard and which Home feed tab is default**, not what's reachable. Everything stays one click away regardless of toggle state; it only sets the *default landing surface* for that session.
- This is a preference, stored client-side (or as `users.lastActiveContext`), not a permission change — switching it never calls an API that changes `role`.

---

## 4. Default Feature Visibility Per Role

| Feature | Buyer | Creator | Both | Admin |
|---|---|---|---|---|
| Browse Explore/Creators/Products/Services | ✅ | ✅ | ✅ | ✅ (read-only, no purchase) |
| Post a Project | ✅ | ❌ | ✅ | ❌ |
| Host a Contest | ✅ | ❌ | ✅ | ❌ |
| Submit a Proposal to a Project | ❌ | ✅ | ✅ | ❌ |
| Submit a Contest Entry | ❌ | ✅ | ✅ | ❌ |
| List a Product | ❌ | ✅ | ✅ | ❌ |
| List a Service | ❌ | ✅ | ✅ | ❌ |
| Publish a Post (portfolio/update) | ❌ | ✅ | ✅ | ❌ |
| Follow creators | ✅ | ✅ | ✅ | ❌ |
| Be followed | ❌ (no public storefront) | ✅ | ✅ | ❌ |
| Messages / chat-commerce | ✅ | ✅ | ✅ | ✅ (support threads only) |
| Send a payment request in chat | ❌ | ✅ | ✅ | ❌ |
| Buy / pay in chat | ✅ | ✅ (can also buy from other creators) | ✅ | ❌ |
| Wallet: add funds | ✅ | ✅ | ✅ | ❌ |
| Wallet: withdraw earnings | ❌ (nothing to withdraw) | ✅ | ✅ | ❌ |
| Earn badges | ❌ (badges are a Creator-reputation system) | ✅ | ✅ | ❌ |
| Moderation tools | ❌ | ❌ | ❌ | ✅ |
| Platform settings | ❌ | ❌ | ❌ | ✅ |

Note: a Buyer *can* end up on the receiving end of features like "be followed" the moment they flip to `both` — the table describes **default** visibility per role, gated purely by `role`, not by any secondary approval step.

---

## 5. Feed Per Role

Already implemented in `home.tsx` / `feed.ts`, and it's the cleanest expression of this whole model:

| Role | Feed shown | Composition |
|---|---|---|
| **Buyer** | **Combined Feed** (`GET /api/feed/home`) | Interleaved posts (from followed/discovered creators) + open Projects, sorted by recency. One scroll, because a Buyer's two interests — "what's good work look like" and "who needs work" — are actually the same browsing moment for them. |
| **Creator** | **Tabbed Feed**: **Showcase** (`/api/feed/showcase`) + **Opportunities** (`/api/feed/opportunities`) | Showcase = other creators' posts (peer inspiration/competition awareness). Opportunities = open Projects + open Contests they could bid/submit on. Split into tabs because these are two *different jobs-to-be-done* for a Creator (get inspired vs. find paid work), and merging them the way Buyer's feed does would bury opportunities under content noise. |
| **Both** | **Creator's tabbed feed by default**, with a third implicit source folded into Showcase: their own followed creators' posts (same as Buyer would see) — so nothing is lost, it's additive, not a fork of the UI. The context toggle (§3.4) can flip the *default landing tab*, not the available tabs. |
| **Admin** | No consumer feed. Admin's "Home" is the Admin Dashboard (§ role-permissions §8 below / page-map §7.1) — platform metrics, not marketplace content. |

---

## 6. Dashboard Modules Per Role

| Dashboard | Access | Modules |
|---|---|---|
| **Creator Dashboard** (`/dashboard/creator`) | Creator, Both | Earnings summary, follower/rating/sales stat cards, active Projects (proposals pending/accepted), active Contests entered, recent Orders as seller, recent Posts performance, badge progress, quick actions (New Post / New Product / New Service) |
| **Buyer Dashboard** (`/dashboard/buyer`) | Buyer, Both | Wallet balance summary, active Projects posted (with proposal counts), active Contests hosted, recent Orders as buyer, followed creators' latest posts, quick actions (Post a Project / Host a Contest) |
| **Both — unified view** | Both | Not a third dashboard. The nav's single "Dashboard" link targets whichever dashboard matches the current context toggle (§3.4); a small persistent switcher pill at the top of either dashboard ("Switch to Buying view" / "Switch to Selling view") jumps to the other one without leaving the Dashboard section conceptually. This avoids building and maintaining a third merged layout that would be busier than either single-role version. |
| **Admin Dashboard** (`/admin`) | Admin only | Total users/creators/buyers, GMV, open disputes count, flagged content count, DAU chart — entirely separate shell, no shared chrome with the consumer dashboards (per page-map §7.1). |

---

## 7. Posting Capabilities Per Role

"Posting" spans four different content types in NeuralMart — this is where framing (not access) is doing the work described in §1:

| Content type | Who can create | Where | Framing shown |
|---|---|---|---|
| **Portfolio Post** (image/case-study/update) | Creator, Both | Posts Hub / Home Showcase | "Share your work" |
| **Product listing** | Creator, Both | Products Hub | "List a digital product" |
| **Service listing** (tiered) | Creator, Both | Services Hub | "Offer a service" |
| **Project brief** | Buyer, Both | Projects Hub | "Post a project" / "Hire someone" |
| **Contest brief** | Buyer, Both | Contests Hub | "Host a contest" |
| **Proposal** (bid on a Project) | Creator, Both | Project Detail | "Submit a proposal" — this is the concrete moment a Creator becomes a "Freelancer" for that thread |
| **Contest submission** | Creator, Both | Contest Detail | "Submit an entry" — this is the concrete moment a Creator becomes a "Contest Participant" for that contest |

A **Both** user therefore sees *all seven* posting affordances, but they are never all presented in one place — each lives on the hub page that matches its purpose, so nothing feels like an undifferentiated firehose (see §10).

---

## 8. Financial Tools Per Role

The **Wallet** (single balance, single ledger per user — no separate buyer-wallet/seller-wallet split, matching "one identity") gates tools by role:

| Tool | Buyer | Creator | Both | Admin |
|---|---|---|---|---|
| View wallet balance | ✅ | ✅ | ✅ | ❌ (views others', not own marketplace wallet) |
| Add funds (top-up) | ✅ | ✅ | ✅ | ❌ |
| Spend (purchases, project payments, contest prizes funded) | ✅ | ✅ (as a buyer of others' products/services too) | ✅ | ❌ |
| Receive payouts (sales, completed proposals, contest wins) | ❌ | ✅ | ✅ | ❌ |
| Withdraw to bank/PayPal | ❌ | ✅ | ✅ | ❌ |
| View own transaction ledger | ✅ | ✅ | ✅ | ❌ |
| View *any* user's ledger / financial overview | ❌ | ❌ | ❌ | ✅ (Admin → Finance) |
| Approve/reject withdrawal requests | ❌ | ❌ | ❌ | ✅ |
| Adjust platform fee % | ❌ | ❌ | ❌ | ✅ |
| Issue refunds / force-release escrow | ❌ | ❌ | ❌ | ✅ |

Buyers see **no "Withdraw" button at all** (not a disabled one) — an empty/disabled financial action a Buyer will never use is exactly the kind of clutter §10 is about avoiding.

---

## 9. Profile Information That Differs by Role

The `users` table holds identity fields shared by everyone; `creator_profiles` holds the fields that only make sense once Creator capability is on.

| Field | Buyer-only account | Creator / Both account |
|---|---|---|
| Display name, avatar, cover, bio | ✅ shown | ✅ shown |
| Wallet balance (private, self-view only) | ✅ | ✅ |
| Followers / Following counts | Following only — followers stays at 0 and the "Followers" stat is hidden, not shown-as-zero | Both shown prominently |
| **Category** (e.g. "Graphic Design", "Video Editing") | — not applicable | ✅ shown on profile header |
| **Skills tags** | — | ✅ shown, filterable in Explore |
| **Rating & review count** | — (buyers aren't publicly rated in v1) | ✅ prominent |
| **Total sales / total earnings** | — | ✅ (earnings private to owner; sales count public) |
| **Response time** | — | ✅ shown ("Responds in < 1 hour") |
| **Completion rate** | — | ✅ shown |
| **Badges** | — | ✅ shown, tied to the 7-tier system |
| **Public storefront tabs** (Posts / Products / Services) | Profile is not publicly browsable as a storefront at all — a pure-Buyer visiting their own profile sees only account settings, no public-facing profile page exists for them | ✅ full tabbed storefront |

**Recommendation:** a pure Buyer should not get a public `/creators/:id`-style profile page at all — visiting `/creators/{buyerId}` should 404 or redirect, rather than rendering an empty storefront shell. This is a real gap worth fixing: it keeps Explore/Creators search results honest (only real storefronts appear) and avoids a confusing "ghost profile" experience.

---

## 10. Preventing UI Clutter for Multi-Role (`Both`) Users

This is the crux of "powerful but easy." Five concrete mechanisms:

1. **Context toggle, not mode-switch overload.** (§3.4, §6) One small persistent control sets the *default landing surface* (which dashboard, which feed tab) for the session. It never hides functionality — a Both user is never "locked out" of buying just because they're in "Selling view." This avoids the classic dual-sided-marketplace mistake of forcing users to pick a lane every session.

2. **Hub-based information architecture, not a single unified inbox of everything.** (§7) Each action lives on the hub that matches its purpose (Products Hub for listing, Projects Hub for hiring). A Both user's nav bar looks *identical* to a single-role user's nav bar — five items (Home, Explore, Messages, Dashboard, Menu) regardless of role. Capability differences show up *inside* those hubs (an extra "+ List a Product" button appears on Products Hub only if Creator capability is active), never as extra top-level nav items.

3. **One dashboard at a time, with a one-click switch, not a merged mega-dashboard.** (§6) Rather than cramming Buyer stat cards and Creator stat cards onto one screen — which is the single biggest clutter risk for `both` accounts — each dashboard stays exactly as focused as it is for a single-role user. The switcher pill costs one click and keeps both views legible.

4. **Progressive disclosure on financial tools.** (§8) Withdraw/payout UI simply doesn't render for accounts with no earning history, even if `role = both` — e.g. a Both user who has never sold anything sees no "Withdraw" button until their first sale creates a payout-eligible balance. Reduces empty-state clutter without adding a permissions branch.

5. **Notification and badge grouping by context, not by type.** (Planned, `settings/notifications`) Notifications for a Both user are grouped "As a Buyer" / "As a Creator" in settings and in the notification feed itself, so a message about a new proposal received doesn't visually compete for attention with a message about their own project payment — same inbox, clearly labeled sub-context.

The unifying rule: **role changes what appears inside a surface; it never changes how many surfaces exist.** A Both user's app skeleton (nav, page count, route count) is byte-for-byte identical to a single-role user's. Only the content and available actions *inside* each screen flex with capability.

---

## 11. Recommended Role Labels

Internal/schema names can stay as-is (`buyer`, `creator`, `both`, `admin`) since changing the enum is a larger migration than needed — but **user-facing copy** should never say "Buyer" or "Creator" as a badge of identity in a way that feels like a locked-in tier. Recommended labels:

| Context | Internal value | User-facing label | Why |
|---|---|---|---|
| Registration role picker | `buyer` | **"Hire & Buy"** *(already implemented copy — keep it)* | Describes the *action*, not a permanent identity — lowers commitment anxiety at signup |
| Registration role picker | `creator` | **"Sell & Earn"** *(already implemented copy — keep it)* | Same — action-oriented framing |
| Account with both active | `both` | **"Creator+"** or simply show *no combined label at all* — display both individual badges ("Buyer" pill + "Creator" pill) side by side on the profile instead of inventing a third identity word | Avoids implying a hierarchical "upgraded tier" (which "+", "Pro", "Elite" naming risks); two small pills read as "this person does both," not "this person leveled up" |
| Nav context toggle (§3.4) | n/a (client preference) | **"Buying view" / "Selling view"** | Plain-language, task-oriented, matches how real freelance marketplaces (Upwork, Fiverr) label the equivalent switch — proven to be immediately understood |
| Activity badges (not roles) | n/a | **"Freelancer"**, **"Contest Entrant"**, **"Top Seller"** — awarded as achievement badges on a Creator profile, not as account roles | Keeps the badge system (already built, 7-tier) as the place where these labels live, satisfying the desire to *recognize* freelance/contest/selling activity without multiplying the permission model |
| Staff | `admin` | **"NeuralMart Team"** (in any user-visible context, e.g. support replies) | Never expose the word "Admin" to end users in support/moderation interactions — reads as more approachable and less bureaucratic |

**Overall naming philosophy:** name the *account-level* concepts (`buyer`/`creator`) after the action a first-time visitor is trying to take ("Hire & Buy" / "Sell & Earn"), and reserve identity-flavored words ("Freelancer," "Seller," "Contest Entrant") for the **achievement/badge layer**, where they're earned through activity rather than assigned at signup. This is what makes the system feel modern: nobody is boxed into a permanent label, and the badges people *do* wear are ones they earned.
