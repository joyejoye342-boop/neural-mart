# NeuralMart — Chat / Messaging Commerce System

**Document version:** 1.0  
**Scope:** Conversations, files, previews, offers, payment, order/project linkage, and commerce notifications

---

## 0. Chat Definition

NeuralMart Chat is not only a messaging inbox. It is the relationship layer where users can:

- discuss work;
- exchange references and custom files;
- preview work;
- send proposals or custom offers;
- trigger payment;
- unlock purchased files;
- manage service/project delivery;
- continue order communication;
- request support or escalate a dispute.

The system should make commerce feel conversational while keeping payment, ownership, and order states explicit.

---

## 1. Conversation Architecture

### Conversation object

Every conversation has:

- participants;
- context type;
- context ID;
- title/subject;
- last message;
- unread count per participant;
- order/project/proposal/service/product links;
- archived/muted state;
- created/updated timestamps;
- moderation/safety state.

### Context types

```text
Direct relationship
Product inquiry
Product support
Service inquiry
Service order
Project proposal
Project delivery
Contest clarification
Contest finalist
Payment/offer
Order support
Platform support
```

The existing order-linked conversation model should expand to support project, proposal, service, product, contest, and support references.

### Conversation identity

Use one conversation per participant set and context:

```text
Buyer + Creator + Service Order A
Buyer + Creator + Project B
Buyer + Creator + General relationship chat
```

Do not merge unrelated orders or projects into one ambiguous thread.

### Participants

MVP supports one buyer and one creator. Advanced conversations can support:

- buyer team members;
- creator team members;
- invited collaborators;
- support agents;
- contest judging teams.

Roles and permissions are stored per participant.

---

## 2. Conversation Types and Behavior

### 2.1 Direct relationship chat

Used for:

- general questions;
- creator introductions;
- profile-based inquiries;
- pre-commerce discussion.

Commerce actions are available but not forced.

### 2.2 Product inquiry/support

Shows:

- product card;
- price/license;
- owned state;
- purchase/download action;
- support/report action.

After purchase, the thread can become product support without losing context.

### 2.3 Service inquiry

Shows:

- service card;
- package selector;
- requirements prompt;
- custom quote action;
- `Book service` action.

### 2.4 Service order conversation

Shows a pinned order strip:

```text
Brand identity · Standard package · In progress
Due Apr 18 · 1 revision remaining
[Open order]
```

The thread becomes the communication space for requirements, delivery, revisions, and approval.

### 2.5 Project proposal conversation

Shows:

- project brief;
- proposal version;
- price/timeline;
- shortlist or selection state;
- `Open project`;
- `Accept proposal` for the buyer;
- `Withdraw proposal` for the creator.

Material changes require an explicit updated proposal or offer card.

### 2.6 Contest finalist conversation

Available only according to contest rules:

- finalist revision request;
- clarification;
- winner confirmation;
- rights and delivery;
- follow-on paid work.

Other entrants' private conversations and host notes never appear here.

### 2.7 Payment/offer conversation

Used for:

- custom offers;
- add-ons;
- milestone payments;
- source-file unlocks;
- paid follow-on work.

Payment cards are structured objects, not plain text promises.

### 2.8 Support/dispute conversation

Support is a separate context with:

- issue category;
- linked order/project/payment;
- evidence attachments;
- status;
- response expectations.

Do not mix a support case into a private buyer/creator relationship thread unless the user explicitly links it.

---

## 3. Role-Based Chat Behaviors

### Buyer

Can:

- initiate creator conversations;
- attach a project brief;
- attach references;
- request a custom quote;
- accept offers;
- pay;
- receive files;
- approve/revise deliveries;
- review orders;
- report or dispute.

### Creator

Can:

- respond to inquiries;
- send service/custom offers;
- share portfolio previews;
- attach work previews;
- send delivery files;
- request missing requirements;
- request payment for approved work;
- update order/project status;
- ask for a review.

### Both

Capabilities are additive. The same identity can buy in one thread and sell in another.

### Admin/support

Can access only assigned support/dispute contexts, with visible staff identity and audit logging.

### Permission rules

- Users can only access conversations they participate in.
- Context-linked actions require permission on the linked object.
- A creator cannot mark a buyer's order complete.
- A buyer cannot unlock creator-private source files.
- Payment actions require server-side authorization.
- UI-hidden actions must also be rejected by the API.

---

## 4. Chat List Structure

### Inbox layout

```text
MESSAGES
├── Search conversations
├── Filters
│   ├── All
│   ├── Unread
│   ├── Needs action
│   ├── Orders
│   ├── Projects
│   ├── Offers/payments
│   └── Archived
├── Conversation list
└── Selected thread
```

### Conversation row

```text
[avatar] Maya Johnson · Brand identity
         Offer accepted · Payment pending
         “I’ve attached the revised direction...”
         2m                                    [2]
```

Show:

- participant/avatar;
- context title;
- last message preview;
- last activity time;
- unread count;
- action-required state;
- order/project status chip.

### Sorting

Default:

```text
Needs action
→ Unread
→ Recent activity
```

Users can switch to chronological order.

### Needs action states

- Buyer needs to pay
- Creator needs to respond
- Requirements missing
- Delivery ready for review
- Revision requested
- Offer expiring
- Project deadline approaching
- Dispute/support reply pending

---

## 5. Message Composer

### Base composer

```text
[Attach] [Preview] [Offer] [Product/Service]   Write a message...
                                              [Send]
```

### Capabilities

#### Text

- Plain text
- Links with safe preview
- Reply/quote
- Mention participants in group threads, advanced

#### File attachment

- Images
- Videos
- Audio
- PDFs
- ZIPs
- Design/source files

Show:

- filename;
- type;
- size;
- upload progress;
- scan status;
- access state.

#### Work preview

Creators can send a preview card with:

- thumbnail;
- version;
- description;
- watermark/private state;
- related order/project;
- `Request approval` or `View order`.

#### Product/service share

Users can share:

- product card;
- service card;
- package;
- creator profile;
- project brief.

Shared commerce objects preserve price and availability at the time of sending.

#### Offer

A custom offer contains:

- title;
- scope;
- deliverables;
- price;
- currency;
- timeline;
- revisions;
- usage/license;
- expiry;
- linked context.

#### Payment request

A payment request contains:

- amount;
- description;
- linked offer/order;
- due/expiry;
- payment status;
- invoice/receipt reference.

### Context-aware composer

The composer should change based on the thread:

| Context | Prominent actions |
|---|---|
| Product inquiry | Share product, answer, Buy now |
| Service inquiry | Choose package, request quote, Book service |
| Project proposal | Update proposal, attach sample, accept/decline |
| Service order | Attach delivery, request revision, approve |
| Contest finalist | Send revision, confirm rights, continue as paid work |
| Support | Attach evidence, view policy, escalate |

---

## 6. Commerce Actions Inside Chat

### 6.1 Preview work

```text
Creator uploads preview
→ Buyer views watermarked version
→ Buyer requests revision or approves
→ Creator delivers final files through order
```

Preview messages are not automatically downloadable source files.

### 6.2 Send custom offer

```text
Creator or buyer creates offer
→ Other participant reviews scope
→ Accept / decline / request change
→ Accepted offer creates payment/order state
```

The offer card remains immutable after acceptance. Changes create a new version or change request.

### 6.3 Trigger payment

```text
Offer accepted
→ Payment checkout
→ Payment confirmed
→ Order or milestone activated
→ System message in chat
```

Do not treat a message saying “paid” as payment confirmation.

### 6.4 Unlock files

```text
Payment confirmed
→ Entitlement/order updated
→ Secure file access granted
→ Download/access event logged
```

For digital products, the chat can include:

```text
Purchase confirmed · Download product
```

For service/project delivery, access follows the order state and buyer permissions.

### 6.5 Continue order communication

Every order-linked thread has:

- pinned order context;
- delivery timeline;
- status;
- files;
- revision count;
- payment state;
- support/dispute entry point.

---

## 7. Order, Project, and Product Linkage

### Context header

At the top of a linked thread:

```text
Brand identity project
Proposal accepted · In progress
$1,200 · Due Apr 18
[Open project] [Open order]
```

### System events

Important state changes create system messages:

- Proposal submitted
- Proposal shortlisted
- Offer accepted
- Payment confirmed
- Order started
- Requirements received
- Delivery sent
- Revision requested
- Delivery approved
- Order completed
- Refund/dispute opened
- File access granted

System messages cannot be edited like ordinary text.

### Context transitions

```text
Service inquiry
→ Custom offer
→ Payment/order
→ Delivery
→ Completion
→ Review/repeat order
```

The same thread may transition context state, but the underlying linked objects remain separately auditable.

### Product purchase

Product conversations may be created from:

- product detail;
- order page;
- download/support issue.

The purchase entitlement is the source of truth for file access, not the chat.

---

## 8. Notification Logic

### In-app

- unread count per conversation;
- global message badge;
- action-required badge;
- context status changes;
- file/offer/payment alerts.

### Push/email

Default notifications:

- new message;
- offer received;
- payment request;
- payment confirmed;
- delivery received;
- revision requested;
- deadline/order status change;
- support/dispute reply.

### Notification priority

```text
Payment/order action
→ Delivery/revision deadline
→ Direct message
→ Social or informational activity
```

### Preferences

Users can configure:

- push;
- email;
- in-app;
- quiet hours;
- per-context mute;
- thread archive;
- digest for low-priority activity.

Do not send a push for every system event. Group low-priority events into a digest.

### Read state

- Conversation unread count is per participant.
- Opening a thread marks visible messages read.
- Payment and order actions can remain “needs action” even after the message is read.
- Read receipts are optional per privacy settings.

---

## 9. Safety, Privacy, and Commerce Controls

- Never ask users to send passwords, tokens, full card numbers, or private keys.
- Scan uploaded files before making them downloadable.
- Use private storage and expiring access links.
- Warn about off-platform payment requests.
- Allow report, block, mute, and support escalation.
- Preserve evidence for disputes.
- Hide private buyer/client identities from unrelated participants.
- Keep source files private until payment and license rules allow access.
- Display clear limits on what verification and payment confirmation guarantee.

### Off-platform warning

If a message appears to request external payment or sensitive credentials:

```text
Keep payments inside NeuralMart to preserve order protection.
Never share passwords, tokens, or full payment information in chat.
[Report message]
```

---

## 10. MVP vs Advanced

### MVP

- One-to-one conversations
- Text messages
- File uploads
- Product/service/project context links
- Basic previews
- Custom payment requests
- Payment-confirmed system messages
- Order-linked threads
- Delivery and revision messages
- Unread counts
- Search and basic filters
- Push/in-app notifications
- Report/block/mute

### Advanced

- Group/team conversations
- Structured custom offers
- Milestone payments
- Escrow and partial releases
- Rich work-preview versions
- Voice/video calls
- Read receipts and typing indicators
- Saved replies
- Translation
- File version comparison
- Automated requirements checklist
- AI-assisted conversation summaries
- Advanced dispute evidence timeline
- Team inbox routing

## Final rule

NeuralMart Chat should let users move from “Can you make this?” to “Here is the offer,” “Payment is confirmed,” “Here is the preview,” and “The final files are unlocked” without leaving the protected marketplace context. 
