# NeuralMart — Complete Page Map / Route Map

## NeuralMart Summary

NeuralMart is a social creator marketplace + freelancing platform + chat-commerce system. It merges three things that are normally separate products:

1. **A social feed** where Creators post work (images, case studies, updates) that Buyers and other Creators can browse, like, and follow.
2. **A marketplace** where Creators sell fixed-price digital **Products** and tiered **Services** (Basic/Standard/Premium), and Buyers can post **Projects** (freelance briefs) that Creators bid on via **Proposals**, or run **Contests** that Creators submit entries to for a prize.
3. **Chat-commerce** — buyers and creators negotiate and transact inside **Conversations**, including in-chat **payment requests**.

Every user has a **role**: `buyer`, `creator`, or `both`, chosen at registration, which determines their home feed and dashboard. All monetary activity (product purchases, service bookings, project payouts, contest prizes, platform fees) flows through an internal **Wallet** with a transaction ledger. Creators build reputation through **follower counts, ratings, sales counts, and a 7-tier badge system**. Auth is session-based (email/password, bcrypt + `express-session` + Postgres session store), dark-mode-first, and fully responsive for desktop and mobile browsers.

Core entities: Users, Creator Profiles, Follows, Posts (+ Likes), Products, Services, Projects (+ Proposals), Contests (+ Submissions), Orders, Conversations (+ Participants + Messages), Wallet Transactions, Badges (+ User Badges).

---

## How to read this document

- **Access** uses these labels: `Public` (no login), `Auth` (any logged-in user), `Buyer` (role = buyer or both), `Creator` (role = creator or both), `Owner` (only the record's creator/buyer), `Admin` (platform staff — not yet built, specified for completeness).
- **Entry points** describe realistic navigation paths, not just URLs.
- Routes shown as currently implemented in `artifacts/neuralmart/src/App.tsx` are marked **[Built]**; everything else is **[Planned]** — required by the product vision but not yet wired up as a route/component.

---

## 1. Group Overview

| Group | Purpose |
|---|---|
| **Main Home** | The first screen a session lands on — role-aware feed/landing, login/register |
| **Feature Hub Pages** | Top-level listing pages for each major feature (Explore, Creators, Products, Services, Projects, Contests, Messages, Wallet, Menu) |
| **Sub-pages / Workflows** | Detail pages, creation flows, multi-step forms nested under a hub |
| **Dashboard Pages** | Role-specific command centers (Creator Dashboard, Buyer Dashboard) |
| **System Pages** | Auth, errors, legal, settings, support — infrastructure the whole app depends on |

---

## 2. Public-Facing Pages

These are reachable without a session. Today the app redirects any unauthenticated visitor straight to Login (per `AppLayout.tsx`), so items marked **[Planned]** below describe the pre-login marketing surface a production launch should add.

### 2.1 Landing / Marketing Page — `/` (unauthenticated) — **[Planned]**
- **Purpose:** Convert visitors; explain the buyer/creator/both value prop before they commit to signing up.
- **Access:** Public.
- **Sections:** Hero with role toggle preview (Buyer view vs Creator view), trending creators strip, featured products/services carousel, "How it works" (Post → Propose → Pay → Deliver), testimonials/badges showcase, CTA footer (Sign up / Log in).
- **Entry:** Direct URL, marketing links, social shares of public profiles/products.
- **Actions:** Click "Create an account" → Register; "Sign in" → Login; browse public creator/product previews (read-only, no purchase without auth).

### 2.2 Public Creator Profile (preview mode) — `/creators/:id` (unauthenticated) — **[Planned — currently Auth-gated]**
- **Purpose:** Let a shared profile link work for non-logged-in visitors (referral/virality).
- **Access:** Public (read-only), full interactivity requires Auth.
- **Sections:** Cover + avatar, bio, stats (followers, rating, sales), badges, tabs for Posts/Products/Services (read-only), "Follow" and "Message" CTAs that prompt login.
- **Entry:** Shared link, search engines, social media.
- **Actions:** View content; clicking Follow/Message/Buy triggers Register/Login redirect with return-to URL.

### 2.3 Public Product/Service Detail (preview mode) — `/products/:id`, `/services/:id` (unauthenticated) — **[Planned — currently Auth-gated]**
- **Purpose:** SEO-friendly, shareable listing pages that convert cold traffic.
- **Access:** Public (read-only preview: title, price, description, creator card); purchase/booking requires Auth.
- **Entry:** Shared links, search, "View Product" from feed shares.
- **Actions:** View details; "Buy"/"Book" → Login/Register with return-to.

### 2.4 Login — `/login` — **[Built]**
- **Purpose:** Authenticate returning users.
- **Access:** Public.
- **Components:** Email + password form, "Forgot password?" link, "Create an account" link, form validation, error toast on 401.
- **Entry:** Direct nav, redirect from any protected route when session is missing, link from Register.
- **Actions:** Submit credentials → `POST /api/auth/login` → session cookie set → redirect to Home (`/`).

### 2.5 Register — `/register` — **[Built]**
- **Purpose:** Create a new account with role selection.
- **Access:** Public.
- **Components:** Name, email, password fields; role selector (Buyer "Hire / Buy" vs Creator "Sell / Earn"); link to Login.
- **Entry:** Direct nav, "Create an account" link from Login/Landing.
- **Actions:** Submit → `POST /api/auth/register` → user + (if creator/both) creator profile row created → session set → redirect to Home. Role chosen here drives the Home feed layout and Dashboard type forever after (changeable later in Edit Profile — see 8.3).

### 2.6 Forgot Password — `/forgot-password` — **[Planned]**
- **Purpose:** Self-service password recovery.
- **Access:** Public.
- **Components:** Email input, "check your email" confirmation state.
- **Entry:** "Forgot password?" link on Login.
- **Actions:** Submit email → send reset link (requires email delivery integration) → user follows link to Reset Password screen (`/reset-password/:token` — Planned) → sets new password → redirect to Login.

### 2.7 Legal Pages — `/legal/terms`, `/legal/privacy`, `/legal/community-guidelines` — **[Planned]**
- **Purpose:** Compliance and trust; linked from footer and registration.
- **Access:** Public.
- **Components:** Static long-form content, table of contents, last-updated date.
- **Entry:** Footer links, "By signing up you agree to..." on Register, Menu → Legal.
- **Actions:** Read-only.

---

## 3. Main Home

### 3.1 Home Feed — `/` (authenticated) — **[Built]**
- **Purpose:** Role-aware landing screen shown immediately after login; the daily-use hub.
- **Access:** Auth (content varies by role).
- **Components:**
  - **Creator/Both view:** Tabs — **Showcase** (creator posts feed) and **Opportunities** (open projects + contests feed).
  - **Buyer view:** Combined feed (posts + open projects interleaved by recency) + prominent "Post a Project" CTA button.
  - Greeting header ("Welcome back, {name}"), Post/Product/Opportunity cards, empty states per tab.
- **Entry:** Default route after login; nav bar "Home" icon/link.
- **Actions:** Like a post, click into a creator profile/product/project/contest from a card, start a new project (Buyer), switch feed tabs (Creator).
- **APIs:** `GET /api/feed/home`, `GET /api/feed/showcase`, `GET /api/feed/opportunities`.

---

## 4. Feature Hub Pages (+ their sub-pages)

### 4.1 Explore — `/explore` — **[Built]**
- **Purpose:** Search/discovery hub across creators, products, services, projects, and contests.
- **Access:** Auth.
- **Components:** Global search bar, type filter chips (All/Creators/Products/Services/Projects/Contests), trending section, result grid/list.
- **Entry:** Nav bar "Explore" icon.
- **Actions:** Type-ahead search (`GET /api/explore/search`), view trending (`GET /api/explore/trending`), click any result to its detail page.

### 4.2 Creators Hub — `/creators` — **[Built]**
- **Purpose:** Browse/discover all creators, primary path for Buyers to find talent.
- **Access:** Auth.
- **Components:** Filter/sort bar (rating, sales, category), creator cards (avatar, name, rating, tags, follower count).
- **Entry:** Nav → Explore → "Browse Creators", Home feed CTA, direct link.
- **Actions:** Click a card → Creator Profile.

#### 4.2.1 Creator Profile — `/creators/:id` — **[Built]**
- **Purpose:** A creator's full public storefront + portfolio.
- **Access:** Auth (Public preview per §2.2 once built).
- **Components:** Cover photo, avatar, display name, bio, badges row, stats (followers/following, rating, sales, response time), Follow/Message buttons, tabs: **Posts**, **Products**, **Services**; "Edit Profile" button if `Owner`.
- **Entry:** Creators Hub, search results, feed post author link, order/message threads.
- **Actions:** Follow/unfollow (`POST /api/creators/:id/follow`), start a Message conversation, browse their Products/Services tabs, view individual Posts.

### 4.3 Posts Hub — `/posts` — **[Built]**
- **Purpose:** Standalone browsing surface for all creator posts (broader than the Home showcase tab — e.g. filterable by type/tag).
- **Access:** Auth.
- **Components:** Post type filter (image/case-study/update), grid/list of `PostCard`s, infinite scroll or pagination.
- **Entry:** Nav → Menu → "All Posts", or a "See all posts" link from Home Showcase tab.
- **Actions:** Like, open creator profile, open linked product/service if a post references one.

### 4.4 Products Hub — `/products` — **[Built]**
- **Purpose:** Digital product marketplace listing.
- **Access:** Auth.
- **Components:** Category filter, price sort, search-within, `ProductCard` grid (image, price, creator, rating).
- **Entry:** Nav → Explore → Products, Home feed card, Creator Profile "Products" tab "see all".
- **Actions:** Click into Product Detail.

#### 4.4.1 Product Detail — `/products/:id` — **[Built]**
- **Purpose:** Purchase decision + checkout for a single digital product.
- **Access:** Auth.
- **Components:** Preview image/gallery, title, price, rating + review count, sales count, category tag, full description, tags, creator card, "Buy Now" button, breadcrumb.
- **Entry:** Products Hub, Creator Profile, Explore search, feed card, shared link.
- **Actions:** Purchase (`POST /api/products/:id/purchase` — wallet debit from buyer, credit to creator minus 10% platform fee) → Order created → success toast → (Planned) redirect to Orders / download link reveal. If `Owner`, see Edit/Delete controls instead of Buy.

#### 4.4.2 Create/Edit Product — `/products/new`, `/products/:id/edit` — **[Planned]**
- **Purpose:** Let Creators list/manage products.
- **Access:** `Creator` (own products only for edit).
- **Components:** Title, description, price, category, tags, preview image upload, save/publish/unpublish toggle.
- **Entry:** Creator Dashboard "Add Product" CTA, Product Detail (Owner) "Edit" button.
- **Actions:** Create/update/delete (`POST/PATCH/DELETE /api/products/:id`), publish toggle.

### 4.5 Services Hub — `/services` — **[Built]**
- **Purpose:** Freelance service marketplace (tiered offerings, like "gigs").
- **Access:** Auth.
- **Components:** Category filter, `ServiceCard` grid showing starting price (Basic tier), delivery time, creator.
- **Entry:** Nav → Explore → Services, Creator Profile "Services" tab.
- **Actions:** Click into Service Detail.

#### 4.5.1 Service Detail — `/services/:id` — **[Built]**
- **Purpose:** Compare Basic/Standard/Premium tiers and order one.
- **Access:** Auth.
- **Components:** Gallery, title/description, three-column tier comparison table (price, delivery days, revisions, features per tier), creator card, "Order Now" per tier, FAQ (Planned).
- **Entry:** Services Hub, Creator Profile, search, shared link.
- **Actions:** Order a tier → order created + wallet transaction → (Planned) redirects into a Conversation with the creator to kick off delivery. If `Owner`, Edit/Delete controls instead.

#### 4.5.2 Create/Edit Service — `/services/new`, `/services/:id/edit` — **[Planned]**
- **Purpose:** Let Creators publish/manage tiered service offerings.
- **Access:** `Creator` (own only for edit).
- **Components:** Title/description/category, three tier editors (price, delivery days, revisions, feature bullets each), gallery upload, publish toggle.
- **Entry:** Creator Dashboard "Add Service" CTA, Service Detail (Owner) "Edit".
- **Actions:** Create/update/delete.

### 4.6 Projects Hub — `/projects` — **[Built]**
- **Purpose:** Freelance job board — Buyers' briefs Creators can bid on.
- **Access:** Auth.
- **Components:** Status filter (Open/In Progress/Completed), category/budget filter, project cards (title, budget range, deadline, proposal count).
- **Entry:** Nav → Explore → Projects, Home "Opportunities" tab "see all", Buyer Dashboard.
- **Actions:** Click into Project Detail; Buyer sees "+ Post a Project" CTA here too.

#### 4.6.1 Project Detail — `/projects/:id` — **[Built]**
- **Purpose:** View a brief and either submit a proposal (Creator) or manage proposals (Buyer/Owner).
- **Access:** Auth. Proposal submission = `Creator`; proposal management = `Owner` (the posting Buyer).
- **Components:** Title, description, budget range, deadline, category/skills tags, buyer card, status badge; **Creator view:** proposal submission form (cover letter, proposed price, delivery days); **Owner view:** list of received proposals with accept/reject actions and each proposer's profile snippet.
- **Entry:** Projects Hub, Home Opportunities tab, Explore, notification (Planned) of new proposal.
- **Actions:** Submit proposal (`POST` to project proposals), Owner accepts a proposal (`PATCH` proposal status → creates an Order + likely opens a Conversation), reject others.

#### 4.6.2 New Project — `/projects/new` — **[Built]**
- **Purpose:** Buyer posts a new freelance brief.
- **Access:** `Buyer`.
- **Components:** Title, description, category, budget min/max, deadline picker, skill tags.
- **Entry:** "Post a Project" CTA on Home (Buyer view) and Projects Hub.
- **Actions:** Submit → creates Project (status `open`) → redirect to Project Detail.

### 4.7 Contests Hub — `/contests` — **[Built]**
- **Purpose:** Browse creative contests with cash prizes.
- **Access:** Auth.
- **Components:** Status filter (Open/Judging/Closed), contest cards (title, prize amount, deadline, submission count, host avatar).
- **Entry:** Nav → Explore → Contests, Home Opportunities tab.
- **Actions:** Click into Contest Detail; hosts (Buyers) see "+ Host a Contest" CTA.

#### 4.7.1 Contest Detail — `/contests/:id` — **[Built]**
- **Purpose:** View brief, submit an entry (Creator), or review submissions and pick a winner (Owner/host).
- **Access:** Auth. Submitting = `Creator`; judging = `Owner`.
- **Components:** Title, brief, prize amount, deadline, entry gallery/grid, submission upload form (Creator), winner-selection controls (Owner) with per-submission preview + "Select Winner" action.
- **Entry:** Contests Hub, Home Opportunities tab.
- **Actions:** Submit entry, host selects winner (`PATCH` submission/contest → triggers Order of type `contest_prize` and wallet payout to winner).

#### 4.7.2 New Contest — `/contests/new` — **[Built]**
- **Purpose:** Buyer/host creates a new contest.
- **Access:** `Buyer` (or any host role).
- **Components:** Title, brief, category, prize amount, deadline picker, submission guidelines.
- **Entry:** "Host a Contest" CTA on Contests Hub.
- **Actions:** Submit → creates Contest (status `open`) → wallet hold/escrow (Planned) → redirect to Contest Detail.

### 4.8 Messages / Chat-Commerce Hub — `/messages` — **[Built]**
- **Purpose:** Inbox listing all conversations; entry to the chat-commerce experience.
- **Access:** Auth.
- **Components:** Conversation list (participant avatar/name, last message preview, unread indicator, timestamp), search/filter, empty state.
- **Entry:** Nav bar "Messages" icon, "Message" button from any Creator Profile/Order.
- **Actions:** Open a conversation thread.

#### 4.8.1 Conversation Thread — `/messages/:conversationId` — **[Planned — currently only list view built]**
- **Purpose:** Real-time (or polling) 1:1 chat where negotiation and commerce happen.
- **Access:** `Owner` (participant only).
- **Components:** Message list (text bubbles, timestamps, read receipts — Planned), **payment request** message type (amount + description + Pay button rendered inline), attachment support (Planned), message composer, participant header linking to their profile.
- **Entry:** Messages Hub list item, "Message" CTA from Creator Profile/Order/Service Detail.
- **Actions:** Send message, Creator sends a payment request (`POST` payment-request message), Buyer pays inline (deducts wallet, creates Order, posts a confirmation message back into thread).

#### 4.8.2 New Conversation — triggered inline, no dedicated route — **[Planned]**
- **Purpose:** Start a thread from a profile/order context rather than browsing the inbox.
- **Access:** Auth.
- **Entry:** "Message" button on Creator Profile, Order detail, Project/Contest detail (to discuss before proposing).
- **Actions:** Creates/finds existing conversation with that participant, then routes to 4.8.1.

### 4.9 Wallet Hub — `/wallet` — **[Planned — currently summary lives inside Menu]**
- **Purpose:** Central financial dashboard: balance, pending balance, transaction history, funding/withdrawal.
- **Access:** Auth.
- **Components:** Available balance card, pending balance card, "Add Funds" / "Withdraw" buttons, transaction ledger table (type, amount, counterparty, date, status), filters (by type: purchase/payout/withdrawal/fee).
- **Entry:** Nav → Menu → Wallet, Dashboard "Wallet" summary card "See all".
- **Actions:** View history (`GET /api/wallet/transactions`), Add Funds (`POST /api/wallet/add-funds`), Withdraw (`POST /api/wallet/withdraw`).

#### 4.9.1 Add Funds — modal or `/wallet/add-funds` — **[Planned]**
- **Purpose:** Top up wallet balance (would need a payment integration — e.g. Stripe — not yet connected).
- **Access:** Auth.
- **Components:** Amount input, payment method selector, confirm button.
- **Entry:** Wallet Hub "Add Funds" button.
- **Actions:** Submit → external payment charge → wallet balance credited + ledger entry.

#### 4.9.2 Withdraw Funds — modal or `/wallet/withdraw` — **[Planned]**
- **Purpose:** Cash out earnings (Creators primarily).
- **Access:** `Creator`/`Both` with balance > 0.
- **Components:** Amount input, payout method (bank/PayPal — needs integration), confirm.
- **Entry:** Wallet Hub "Withdraw" button.
- **Actions:** Submit → payout request created → ledger entry (pending → completed).

### 4.10 Orders Hub — `/orders` — **[Built]**
- **Purpose:** Purchase/sale history across products, services, and contest prizes.
- **Access:** Auth.
- **Components:** Buyer/Seller role tabs, order list (item thumbnail, counterparty, amount, status, date), download/receipt link for digital products, "Message seller/buyer" shortcut.
- **Entry:** Nav → Menu → Orders, post-purchase redirect, Dashboard "Recent Orders" widget.
- **Actions:** View order detail, download purchased files, mark a service order complete (`POST /orders/:id/complete`), open related conversation.

#### 4.10.1 Order Detail — `/orders/:id` — **[Planned — currently inline in list]**
- **Purpose:** Full detail on a single transaction.
- **Access:** `Owner` (buyer or seller party).
- **Components:** Item summary, price breakdown (subtotal, platform fee, total), status timeline, related conversation link, download/deliverable area, dispute/support link (Planned).
- **Entry:** Orders Hub row click.
- **Actions:** Complete order, download deliverable, open dispute (Planned), message counterparty.

---

## 5. Dashboard Pages

### 5.1 Creator Dashboard — `/dashboard/creator` — **[Built]**
- **Purpose:** Command center for Creators — performance, active work, earnings at a glance.
- **Access:** `Creator`.
- **Components:** Earnings summary (this month/all-time), follower/rating/sales stat cards, active Projects (proposals pending/accepted), active Contests entered, recent Orders (as seller), recent Posts performance, badge progress, quick actions (New Post, New Product, New Service).
- **Entry:** Nav bar "Dashboard" icon (auto-targets this route for creator/both roles).
- **Actions:** Jump into any listed item's detail page, trigger quick-create flows.
- **API:** `GET /api/dashboard/creator`.

### 5.2 Buyer Dashboard — `/dashboard/buyer` — **[Built]**
- **Purpose:** Command center for Buyers — spend, active hires, contests hosted.
- **Access:** `Buyer`.
- **Components:** Wallet balance summary, active Projects posted (with proposal counts), active Contests hosted, recent Orders (as buyer), followed creators' latest posts, quick action "Post a Project"/"Host a Contest".
- **Entry:** Nav bar "Dashboard" icon (auto-targets this route for buyer role).
- **Actions:** Jump into any listed item, trigger quick-create flows.
- **API:** `GET /api/dashboard/buyer`.

---

## 6. Menu / Settings / Support / Policy Pages

### 6.1 Menu — `/menu` — **[Built]**
- **Purpose:** Catch-all navigation drawer for secondary destinations (mirrors a mobile "More" tab).
- **Access:** Auth.
- **Components:** User summary card (avatar, name, role, wallet snippet), link list: Edit Profile, Orders, Wallet (Planned dedicated page), Badges, Notifications settings (Planned), Legal (Planned), Support/Help (Planned), Logout button.
- **Entry:** Nav bar "Menu" icon (desktop sidebar footer / mobile bottom nav).
- **Actions:** Navigate to any linked page; Logout (`POST /api/auth/logout` → redirect to Login).

### 6.2 Edit Profile — `/profile/edit` — **[Built]**
- **Purpose:** Update personal info and (for creators) profile-facing details.
- **Access:** `Owner` (self only).
- **Components:** Avatar/cover upload, display name, bio, role display (and change — Planned), category/skills tags (Creator), save button.
- **Entry:** Menu → Edit Profile, Creator Profile (Owner) "Edit Profile" button.
- **Actions:** Save changes (`PATCH /api/users/:id`).

### 6.3 Badges — `/badges` — **[Planned — currently shown as a row on profiles/dashboard]**
- **Purpose:** Explain the 7-tier badge system and show progress toward the next tier.
- **Access:** Auth.
- **Components:** Full badge gallery (earned vs locked), criteria per badge, current tier progress bar.
- **Entry:** Menu → Badges, Creator Profile badge row "See all".
- **Actions:** Read-only; (Planned) share a badge achievement.

### 6.4 Notification Settings — `/settings/notifications` — **[Planned]**
- **Purpose:** Control email/push/in-app notification preferences.
- **Access:** Auth.
- **Components:** Toggle list grouped by category (Messages, Orders, Proposals, Contests, Marketing).
- **Entry:** Menu → Settings → Notifications.
- **Actions:** Toggle + save preferences.

### 6.5 Account & Security Settings — `/settings/account` — **[Planned]**
- **Purpose:** Change password/email, manage active sessions, delete account.
- **Access:** `Owner`.
- **Components:** Change password form, change email form, active sessions list with revoke, "Delete my account" danger zone.
- **Entry:** Menu → Settings → Account.
- **Actions:** Update credentials, revoke a session, request account deletion.

### 6.6 Help / Support Center — `/support` — **[Planned]**
- **Purpose:** Self-serve help + contact support/dispute a transaction.
- **Access:** Auth (some FAQ content could be Public).
- **Components:** FAQ accordion, "Contact Support" form, "Report a user/order" flow, dispute status tracker.
- **Entry:** Menu → Help, Order Detail "Dispute" link.
- **Actions:** Submit support ticket, track ticket status.

### 6.7 Legal / Policy Pages (authenticated mirror) — `/legal/*` — **[Planned]**
- Same content as §2.7, linked again from Menu for logged-in users who want to review terms.

### 6.8 Not Found — `*` (any unmatched route) — **[Built]**
- **Purpose:** Friendly 404 fallback.
- **Access:** Public/Auth (renders regardless of session).
- **Components:** Illustration/message, "Back to Home" button.
- **Entry:** Any invalid/typo'd URL, stale deep link.
- **Actions:** Return to Home.

---

## 7. Admin Pages — **[Planned — none built yet]**

All admin routes are internal-only and require `Admin` access (new role/permission layer needed — not present in current schema, which only has buyer/creator/both).

### 7.1 Admin Dashboard — `/admin`
- **Purpose:** Platform health at a glance.
- **Components:** Total users/creators/buyers, GMV (gross merchandise value), open disputes count, flagged content count, daily active users chart.
- **Entry:** Admin-only nav (separate admin shell, not the consumer app chrome).

### 7.2 User Management — `/admin/users`, `/admin/users/:id`
- **Purpose:** Search, view, suspend/ban, or verify users.
- **Components:** Searchable/filterable user table, user detail drawer (profile, order history, wallet balance, flags), verify/suspend/ban actions, manual badge grant.

### 7.3 Content Moderation — `/admin/moderation`
- **Purpose:** Review flagged posts, products, services, messages.
- **Components:** Report queue, content preview, approve/remove/warn actions, audit log.

### 7.4 Order & Dispute Management — `/admin/orders`, `/admin/disputes/:id`
- **Purpose:** Resolve payment disputes, force-refund, investigate fraud.
- **Components:** Order search, dispute detail (both parties' messages, transaction trail), refund/release-funds actions.

### 7.5 Financial / Payouts Overview — `/admin/finance`
- **Purpose:** Platform fee revenue, pending payouts queue, manual payout approval.
- **Components:** Revenue charts, pending withdrawal queue with approve/reject, transaction export.

### 7.6 Contest Oversight — `/admin/contests`
- **Purpose:** Monitor active contests for fairness/abuse; force-close if needed.
- **Components:** Contest list with status, submission counts, "force close & refund" action.

### 7.7 Platform Settings — `/admin/settings`
- **Purpose:** Configure platform-wide values.
- **Components:** Platform fee percentage, badge tier thresholds, featured creators/curation controls, maintenance-mode toggle.

### 7.8 Admin Team Management — `/admin/team`
- **Purpose:** Manage who has admin access and at what permission level.
- **Components:** Admin user list, role assignment (super-admin, moderator, support), invite new admin.

---

## 8. Full Route Table (implementation reference)

| Route | Page | Group | Access | Status |
|---|---|---|---|---|
| `/` (logged out) | Landing/Marketing | Main Home | Public | Planned |
| `/` (logged in) | Home Feed | Main Home | Auth | Built |
| `/login` | Login | System | Public | Built |
| `/register` | Register | System | Public | Built |
| `/forgot-password` | Forgot Password | System | Public | Planned |
| `/reset-password/:token` | Reset Password | System | Public | Planned |
| `/explore` | Explore | Feature Hub | Auth | Built |
| `/creators` | Creators Hub | Feature Hub | Auth | Built |
| `/creators/:id` | Creator Profile | Sub-page | Auth (Public preview planned) | Built |
| `/posts` | Posts Hub | Feature Hub | Auth | Built |
| `/products` | Products Hub | Feature Hub | Auth | Built |
| `/products/:id` | Product Detail | Sub-page | Auth (Public preview planned) | Built |
| `/products/new` | Create Product | Sub-page | Creator | Planned |
| `/products/:id/edit` | Edit Product | Sub-page | Owner (Creator) | Planned |
| `/services` | Services Hub | Feature Hub | Auth | Built |
| `/services/:id` | Service Detail | Sub-page | Auth (Public preview planned) | Built |
| `/services/new` | Create Service | Sub-page | Creator | Planned |
| `/services/:id/edit` | Edit Service | Sub-page | Owner (Creator) | Planned |
| `/projects` | Projects Hub | Feature Hub | Auth | Built |
| `/projects/new` | New Project | Sub-page | Buyer | Built |
| `/projects/:id` | Project Detail | Sub-page | Auth (role-gated actions) | Built |
| `/contests` | Contests Hub | Feature Hub | Auth | Built |
| `/contests/new` | New Contest | Sub-page | Buyer | Built |
| `/contests/:id` | Contest Detail | Sub-page | Auth (role-gated actions) | Built |
| `/messages` | Messages Hub (inbox) | Feature Hub | Auth | Built |
| `/messages/:conversationId` | Conversation Thread | Sub-page | Owner | Planned |
| `/wallet` | Wallet Hub | Feature Hub | Auth | Planned |
| `/wallet/add-funds` | Add Funds | Sub-page | Auth | Planned |
| `/wallet/withdraw` | Withdraw Funds | Sub-page | Creator/Both | Planned |
| `/orders` | Orders Hub | Feature Hub | Auth | Built |
| `/orders/:id` | Order Detail | Sub-page | Owner | Planned |
| `/dashboard/creator` | Creator Dashboard | Dashboard | Creator | Built |
| `/dashboard/buyer` | Buyer Dashboard | Dashboard | Buyer | Built |
| `/menu` | Menu | System | Auth | Built |
| `/profile/edit` | Edit Profile | Sub-page | Owner | Built |
| `/badges` | Badges | Sub-page | Auth | Planned |
| `/settings/notifications` | Notification Settings | System | Auth | Planned |
| `/settings/account` | Account & Security | System | Owner | Planned |
| `/support` | Help / Support Center | System | Auth (partial Public) | Planned |
| `/legal/terms`, `/legal/privacy`, `/legal/community-guidelines` | Legal Pages | System | Public | Planned |
| `*` | Not Found | System | Public/Auth | Built |
| `/admin` | Admin Dashboard | System (Admin) | Admin | Planned |
| `/admin/users`, `/admin/users/:id` | User Management | System (Admin) | Admin | Planned |
| `/admin/moderation` | Content Moderation | System (Admin) | Admin | Planned |
| `/admin/orders`, `/admin/disputes/:id` | Order & Dispute Mgmt | System (Admin) | Admin | Planned |
| `/admin/finance` | Financial Overview | System (Admin) | Admin | Planned |
| `/admin/contests` | Contest Oversight | System (Admin) | Admin | Planned |
| `/admin/settings` | Platform Settings | System (Admin) | Admin | Planned |
| `/admin/team` | Admin Team Management | System (Admin) | Admin | Planned |

---

## 9. Navigation Shell Reference (for implementation)

- **Desktop:** Fixed left sidebar — logo, Home / Explore / Messages / Dashboard (role-aware target) / Menu, user card at bottom (avatar → Creator Profile).
- **Mobile:** Bottom tab bar mirroring the same five destinations; sticky top header with logo + notification bell + avatar.
- **Redirect rules:** Unauthenticated users are redirected to `/login` from any non-auth route; authenticated users on `/login` or `/register` are redirected to `/`. The "Dashboard" nav target is computed from `user.role` (`creator`/`both` → `/dashboard/creator`, else → `/dashboard/buyer`).
- **Deep-link pattern:** Detail pages (`/products/:id`, `/projects/:id`, etc.) should support a `?returnTo=` or referrer-based back-navigation once public preview pages are added, so unauthenticated visitors can complete Login/Register and land back where they intended to act.
