# NeuralMart — API Architecture & Contract Design
## Part 3 of 3: Security, API Standards, Scalability & Final Architecture

**Document version:** 1.0  
**Depends on:** Prompts #1–#37 and API Architecture Parts 1 and 2  
**Part 1:** `docs/neuralmart-api-architecture-part-1.md` — Sections 1–14  
**Part 2:** `docs/neuralmart-api-architecture-part-2.md` — Sections 15–29  
**Scope:** Sections 30–41 and final integration  
**Implementation status:** Engineering specification only; no production code

---

## 0. Final Integration Statement

Parts 1–3 are one versioned REST contract for the NeuralMart modular monolith, not separate APIs. Parts 1 and 2 remain the detailed source for their endpoint request/response examples. This Part finalizes shared response, pagination, validation, security, event, realtime, documentation, roadmap, and integration rules.

The canonical client base remains `/api/v1`. The workspace's existing unversioned `/api/...` endpoints, if still consumed, are temporary adapters to the same application commands and authorization logic. The backend architecture's schematic `/api/webhooks/{provider}` route is a diagram-level shorthand; Prompt #38's canonical provider callback path is `/api/v1/webhooks/{provider}`. No webhook uses end-user session authentication.

### 0.1 Established authority boundaries

| Concern | Authoritative module/record | API rule |
|---|---|---|
| Identity and capabilities | Identity & Session | One User; active buying/selling context is not permission |
| Content and listings | Content/Marketplace source records | Feed and search results are projections; source endpoint rechecks visibility/state |
| Commercial relationship | Universal Order | One Order with typed extensions; no parallel chat-only or product-only transaction state |
| Provider charge/refund state | Payment | Client redirects and client-supplied status are never payment evidence |
| Money owed/held/released | Wallet/Ledger | Ledger is financial truth; balance is a derived view |
| Exclusive rights | Ownership | Sold/Locked state and unique Ownership are committed server-side |
| Fulfillment | Delivery/Revision | Delivery is versioned; approval/revision is a structured Order action |
| Protected retrieval | Entitlement/AccessGrant | Every protected access request rechecks current authorization |
| Communication | Chat-Commerce | Messages preserve context but do not set payment, Order, delivery, or ownership state |
| Reputation | Review/Rating/Badge | Only eligible Order outcomes may change verified reputation |
| Discovery and reporting | Feed/Search/Analytics projections | Projections are rebuildable and cannot authorize a transaction |

---

# 30. Analytics APIs

Analytics ingestion and private reporting are separate from both public discovery and financial source records. User-visible metrics are scoped to the authenticated account or an explicitly authorized staff view.

## 30.1 Client event ingestion

### `POST /api/v1/analytics/events`

**Permission:** Optional authentication for consent-allowed public behavior; authenticated for account-linked creator/buyer actions. Anonymous collection, where enabled, uses a pseudonymous session identifier and the approved consent policy.

Request is a bounded batch of allowlisted events:

```json
{
  "events": [
    {
      "eventId": "event_opaque_random_id",
      "type": "product_viewed",
      "target": { "type": "product", "id": "product_opaque_id" },
      "occurredAt": "2026-10-21T09:15:00Z",
      "surface": "showcase_feed",
      "sessionId": "session_opaque_id",
      "attribution": {
        "source": "creator_post",
        "sourceId": "post_opaque_id"
      },
      "clientContext": { "platform": "web", "appVersion": "1.0" }
    }
  ]
}
```

The server validates event type, target visibility, event size, timestamp bounds, consent, actor/session association, and attribution references. It deduplicates by `eventId`; client analytics do not directly create purchases, revenue, completed Orders, verified reviews, or badge eligibility. Those facts are emitted only from committed server-side domain events.

Response: `202 Accepted` with accepted/deduplicated counts and an ingestion reference. The endpoint is best-effort for ordinary impressions/views and never blocks feed or checkout. It must not accept message bodies, private file contents, raw payment data, or another user's private metrics.

## 30.2 Private dashboard analytics

The `GET /api/v1/analytics/me/...` namespace is private to the authenticated account. Each query validates the requested period, timezone, dimensions, and aggregation level; private metrics are never exposed by a public profile endpoint.

- `GET /api/v1/analytics/me/creator/overview?from=...&to=...&timeZone=...`
- `GET /api/v1/analytics/me/creator/content?from=...&to=...&cursor=...`
- `GET /api/v1/analytics/me/creator/products?from=...&to=...&cursor=...`
- `GET /api/v1/analytics/me/creator/proposals?from=...&to=...`
- `GET /api/v1/analytics/me/creator/contests?from=...&to=...`
- `GET /api/v1/analytics/me/buyer/overview?from=...&to=...`

Creator overview may include views, impressions, clicks, saves, follows, profile visits, product views, paid/completed Orders, conversion, repeat Buyers, proposal funnel, contest participation/results, refund/dispute rates, and earnings summaries. Buyer overview may include posted Projects, proposal activity, contest activity, purchases, and completion status. Aggregates must label attribution and time windows; low-volume cohorts may be suppressed to protect privacy.

Revenue, fees, refunds, pending seller earnings, and withdrawable funds must reconcile to Wallet/Ledger and Order records. Analytics summaries are not the financial dashboard source of truth. For authoritative balance/history use Wallet APIs in Part 2.

**Response:** `200` with `data.period`, `data.metrics`, optional `series`, `attribution`, `generatedAt`, and `freshness: "current"|"updating"`, in the Part 1 success envelope. No client-supplied creator ID is accepted for `/me` metrics.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 ANALYTICS_OWNER_REQUIRED`, `400 DATE_RANGE_INVALID`, `422 DIMENSION_NOT_SUPPORTED`, `429 ANALYTICS_QUERY_RATE_LIMITED`, `503 ANALYTICS_TEMPORARILY_UNAVAILABLE`.

## 30.3 Internal and admin analytics

Admin analytics use staff-scoped aggregate endpoints only; access is purpose/case logged. They must minimize direct identifiers and exclude private message contents and protected files. Cross-user Creator analytics are never available to ordinary accounts, including accounts with both Buyer and Creator capabilities.

---

# 31. Support & Report APIs

Support Tickets handle help requests and platform cases. Reports submit a safety/moderation concern against a typed target. Neither resource replaces the Order dispute lifecycle or exposes internal investigations to the reporter.

## 31.1 Support tickets

- `POST /api/v1/support/tickets` — authenticated account; an unauthenticated recovery route, if enabled, must use a separate abuse-controlled flow and must not disclose whether an account exists.
- `GET /api/v1/support/tickets?cursor=...&status=...` — current user's tickets only.
- `GET /api/v1/support/tickets/{ticketId}` — ticket owner or assigned staff.
- `POST /api/v1/support/tickets/{ticketId}/messages` — owner or assigned staff; message body and safe attachment references.
- `POST /api/v1/support/tickets/{ticketId}/close` — ticket owner; may close only if policy permits. Staff can reopen with a case-linked action.

Ticket creation request:

```json
{
  "category": "order_help",
  "subject": "I cannot access my delivered files",
  "description": "The order is complete but the download link has expired.",
  "relatedResource": { "type": "order", "id": "order_opaque_id" },
  "attachmentMediaIds": []
}
```

Response returns `ticketId`, `status: "open"`, `createdAt`, and a safe next step. The server verifies ownership/participation of any related Order/resource. Ticket messages are append-only for history; edits/deletions follow the support retention policy.

## 31.2 User reports

- `POST /api/v1/reports` — authenticated; creates a report against `user`, `post`, `product`, `service`, `project`, `contest`, `message`, or `order`.
- `GET /api/v1/me/reports?cursor=...` — reporter's own submissions and safe status only.
- `GET /api/v1/me/reports/{reportId}` — reporter only; shows received/under_review/action_taken/no_action/closed at the level safe to disclose.

Request:

```json
{
  "target": { "type": "message", "id": "message_opaque_id" },
  "reasonCode": "harassment",
  "description": "The message asks me to pay outside the platform.",
  "evidenceReferences": ["message_opaque_id"]
}
```

The API validates the target type, reporter access to the target, reason code, evidence references, and duplicate-report limits. Reporting an Order does not itself open a refund or dispute; those are separate Order commands.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 REPORT_TARGET_NOT_ACCESSIBLE`, `404 TARGET_NOT_FOUND`, `409 TICKET_ALREADY_CLOSED`, `409 DUPLICATE_ACTIVE_REPORT`, `422 REASON_REQUIRED`, `422 EVIDENCE_NOT_AUTHORIZED`, `429 SUPPORT_OR_REPORT_RATE_LIMITED`.

---

# 32. Admin APIs

Admin endpoints are isolated under `/api/v1/admin/...` and require a separately authenticated staff identity, scoped permission, and (for sensitive actions) step-up authentication. Ordinary Buyer/Creator capabilities and a client-side `admin` value never grant access. The server records staff actor, scope, case/reason, outcome, and trace ID in append-only audit history.

## 32.1 Administrative resource groups

| Capability | Representative endpoints | Default access |
|---|---|---|
| User management | `GET /api/v1/admin/users`; `GET /api/v1/admin/users/{userId}`; `POST /api/v1/admin/users/{userId}/restrictions` | Scoped trust/safety staff |
| Content moderation | `GET /api/v1/admin/moderation/queue`; `POST /api/v1/admin/posts/{postId}/actions` | Assigned moderation case |
| Product moderation | `POST /api/v1/admin/products/{productId}/actions` | Marketplace moderation scope |
| Project moderation | `POST /api/v1/admin/projects/{projectId}/actions` | Project/safety scope |
| Contest moderation | `POST /api/v1/admin/contests/{contestId}/actions` | Contest/safety scope |
| Order inspection | `GET /api/v1/admin/orders/{orderId}` | Order-support case scope; sensitive fields minimized |
| Financial review | `GET /api/v1/admin/financial/transactions/{transactionId}` | Finance scope, read-only by default |
| Dispute case work | `GET /api/v1/admin/disputes/{disputeId}`; `POST /api/v1/admin/disputes/{disputeId}/decisions` | Assigned dispute reviewer |
| Badge management | `GET /api/v1/admin/badges/users/{userId}`; `POST /api/v1/admin/badges/users/{userId}/actions` | Trust scope; no unlogged manual award |
| Reports | `GET /api/v1/admin/reports`; `POST /api/v1/admin/reports/{reportId}/actions` | Assigned moderation/safety scope |
| System settings | `GET /api/v1/admin/settings`; `PATCH /api/v1/admin/settings/{settingKey}` | Explicit settings scope; versioned and audited |
| Audit logs | `GET /api/v1/admin/audit-logs?cursor=...` | Restricted security/compliance scope |

The examples reserve consistent route shapes; each operation must require a named permission such as `moderation.case.read`, `finance.review.read`, or `settings.update`. Staff scopes are not inferred from a UI route.

## 32.2 Moderation and financial actions

Mutations use explicit action commands and include:

```json
{
  "action": "temporarily_restrict",
  "reasonCode": "credible_safety_report",
  "caseId": "case_opaque_id",
  "duration": { "kind": "policy_defined", "until": "2026-10-28T00:00:00Z" }
}
```

Responses include action ID, target ID, outcome, effective timestamps, and safe next action. Sensitive financial, Ownership, badge, dispute, account, or file-access overrides require a reason and case reference. High-impact actions require step-up authentication and, when policy requires, secondary approval. Staff cannot edit historical ledger entries or rewrite past ownership; they issue auditable compensating actions.

The separate Dispute System remains the future owner of dispute evidence and adjudication workflows. These Admin APIs provide scoped integration to its case records and Order-level effects; they do not redefine the Dispute System.

Errors: `401 STAFF_AUTHENTICATION_REQUIRED`, `403 ADMIN_SCOPE_REQUIRED`, `404 RESOURCE_NOT_FOUND`, `409 CASE_NOT_ASSIGNED`, `409 RESOURCE_STATE_CONFLICT`, `422 REASON_OR_CASE_REQUIRED`, `428 STEP_UP_AUTHENTICATION_REQUIRED`, `429 ADMIN_ACTION_RATE_LIMITED`.

---

# 33. API Response Standard

Part 1's response envelope is canonical. This section resolves metadata and error-category naming for all three Parts.

## 33.1 Success

Single-resource and command responses:

```json
{
  "data": {
    "id": "opaque_resource_id",
    "status": "pending"
  },
  "meta": {
    "requestId": "opaque_request_id"
  }
}
```

List responses:

```json
{
  "data": {
    "items": [],
    "nextCursor": null
  },
  "meta": {
    "requestId": "opaque_request_id",
    "hasMore": false
  }
}
```

Rules:

- Use stable opaque IDs and camelCase JSON. Do not expose database keys or provider secrets.
- Use lower `snake_case` resource statuses/type enums. Error `category` and `code` values are upper `SNAKE_CASE`.
- Use ISO 8601 UTC timestamps; deadlines include the applicable `timeZone`.
- Use integer money minor units with explicit currency.
- Return only fields authorized for the requesting actor. Do not serialize hidden fields for UI-side filtering.
- A successful `201` includes `Location` where a stable resource URL exists. A mutable resource may include `ETag` or `resourceVersion`.
- A `202` identifies the durable resource/operation and current `pending`/`reconciling` state, plus a polling resource path or `Retry-After` where appropriate.
- `204` is reserved for successful operations where no updated representation is needed.
- `meta` carries transport metadata (request ID, pagination metadata, bounded warnings); domain facts belong in `data`.

## 33.2 Error response

```json
{
  "type": "https://api.neuralmart.example/problems/validation",
  "title": "Request validation failed",
  "status": 422,
  "category": "VALIDATION_ERROR",
  "code": "PRICE_INVALID",
  "detail": "Enter a price in the supported range.",
  "instance": "/api/v1/marketplace/products",
  "traceId": "opaque_trace_id",
  "retryable": false,
  "fieldErrors": [
    {
      "field": "price.amountMinor",
      "code": "OUT_OF_RANGE",
      "message": "Enter a valid amount."
    }
  ]
}
```

`category` is an additive v1 field: new API responses should populate it, while clients continue accepting older compatibility responses that omit it. `code` remains the specific stable machine-readable identifier used by endpoint contracts. `type` is a stable problem-category URI. Optional fields include `Retry-After`, safe `currentState`/`nextActions` for conflicts, and field-level errors.

No response exposes SQL, stack traces, provider payloads, secrets, full internal risk decisions, private content, or existence details where enumeration is unsafe. Success and error examples in Parts 1 and 2 inherit this consolidated standard.

---

# 34. Pagination Strategy

Use cursor/keyset pagination for live, high-volume, or changing collections. Offset pagination is simple for static lists but can skip or duplicate records during inserts/deletes and becomes expensive at high offsets.

| Collection | Recommendation | Reason / notes |
|---|---|---|
| Showcase and Opportunities feeds | Cursor | Stable infinite scroll under ongoing publication |
| Unified search | Cursor | Binds to query/filter/sort snapshot; avoids deep offsets |
| Products and Services | Cursor | Catalog changes while browsing; relevance and availability projections |
| Projects and Contests | Cursor | Deadlines/status change while users browse |
| Messages | Cursor by server sequence/time | Reliable history and unread boundaries |
| Notifications | Cursor | New events arrive while reading; supports read watermark |
| Wallet transactions and withdrawals | Cursor | Immutable append history, auditable ordering |
| Reviews | Cursor | New/moderated reviews change lists |
| Proposals, entries, Orders | Cursor | Status updates and activity continue during pagination |
| Admin queues/audit logs | Cursor by default | Stable review queues and append-only audit chronology |
| Small static taxonomies/settings | No pagination or bounded offset | Small, slowly changing reference data only |

Requirements:

- Default page size is `20`; maximum is `50`, except where a route documents a smaller cap.
- Use opaque signed cursors bound to filter, sort, actor visibility scope, and stable ordering key(s); cursors are not authorization credentials.
- Return `nextCursor` and `hasMore`; an empty page uses `items: []` and `nextCursor: null`.
- Use deterministic tie-breakers such as immutable ID/sequence. For search ranking, use a stable result snapshot or ranking version in the cursor.
- Do not promise exact `totalCount` on high-volume or privacy-filtered result sets unless it is cheap and safe; optional counts may be approximate and labeled.
- Reject malformed/expired cursors with `400 CURSOR_INVALID` or `409 CURSOR_SNAPSHOT_EXPIRED`, with a safe instruction to restart the list.
- Offset pagination may be used only for bounded, static/admin tables where stable snapshots and low cardinality are guaranteed. It is not the default for mobile lists.

---

# 35. Validation & Error Architecture

Validation is layered: transport/schema validation, authorization validation, then domain invariant validation inside the owning module. Passing request-schema validation does not imply permission or state eligibility.

## 35.1 Validation responsibilities

| Layer | Checks |
|---|---|
| API boundary | Required/unknown fields, JSON types, lengths, enums, query allowlists, body size, ID format, cursor shape |
| Identity/authorization | Session/account state, capability, resource owner/participant relationship, staff scope, block/restriction, policy acceptance |
| Domain command | Current state, availability, price snapshot, deadline, uniqueness, rights/license, revision allowance, review eligibility, refundable amount |
| Media/storage | MIME allowlist plus file signature, size/duration/dimensions, checksum, scan status, private/public access scope |
| Provider adapter | Provider event identity, signature, amount/currency, payment reference, status transitions, replay/duplicate event |

Validate price in integer minor units against the server's current supported currency, min/max, and immutable terms. Never accept a client-computed fee, seller earning, wallet balance, ownership assignment, or final state.

Validate deadlines as future/past according to state and preserve both UTC instant and business timezone. Validate file types/sizes against policy returned to the client by the upload-intent API; exact limits remain centrally configurable, not duplicated as hard-coded client assumptions.

## 35.2 Standard error categories

| `category` | Typical HTTP | Example specific `code` | Client behavior |
|---|---:|---|---|
| `AUTHENTICATION_ERROR` | 401 | `AUTHENTICATION_REQUIRED` | Sign in or refresh; do not expose account existence |
| `PERMISSION_DENIED` | 403 or privacy-safe 404 | `ORDER_PARTICIPANT_REQUIRED` | Stop; do not retry without authorized access |
| `VALIDATION_ERROR` | 400/422 | `PRICE_INVALID` | Correct the fields indicated by `fieldErrors` |
| `RESOURCE_NOT_FOUND` | 404 | `PROJECT_NOT_FOUND` | Treat as unavailable; hidden resources may intentionally use 404 |
| `RESOURCE_CONFLICT` | 409 | `PROJECT_CLOSED` | Refresh current state; only retry if a valid transition remains |
| `PAYMENT_ERROR` | 409/422; `202` for a durably pending operation | `PAYMENT_PENDING` or `PAYMENT_DECLINED` | Query the same Payment/Order; never submit a second charge |
| `RATE_LIMITED` | 429 | `PROPOSAL_RATE_LIMITED` | Back off using safe `Retry-After` guidance |
| `SERVER_ERROR` | 500/503 | `INTERNAL_ERROR` or `DEPENDENCY_UNAVAILABLE` | Use trace ID; retry only idempotently or when marked retryable |

Preserve the endpoint-specific codes already defined in Parts 1 and 2. The category groups errors; it does not replace the detailed `code`.

## 35.3 HTTP status and privacy rules

- `400`: malformed request syntax/query/cursor.
- `401`: no valid authentication.
- `403`: authenticated but not authorized, unless resource existence itself is sensitive.
- `404`: absent or intentionally undisclosed resource.
- `409`: conflict with authoritative resource state, concurrency version, or uniqueness rule.
- `413`/`415`: payload too large or unsupported content type.
- `422`: well-formed input violates business validation.
- `429`: rate/abuse control, optionally with `Retry-After`.
- `202`: durable command accepted but still pending/reconciling.
- `503`: dependency unavailable and command was not durably accepted.

Never convert unexpected exceptions into successful fallback DTOs. Log trace IDs and normalized codes rather than raw credentials, payment payloads, or full private request bodies.

---

# 36. Idempotency & Transaction Safety

Idempotency protects against client retries and at-least-once provider/event delivery; it does not replace database uniqueness, locks, or authorization.

## 36.1 Required idempotency operations

| Operation | Idempotency/concurrency requirement |
|---|---|
| Product/Service/Exclusive Project checkout | Required key; unique pending/successful Order per valid source/Buyer policy |
| Universal Order creation | Required key scoped to actor + source + operation |
| Payment attempt, confirmation refresh, provider callback | Provider idempotency key and unique provider event/reference; callback dedupe |
| Exclusive sale/Ownership creation/transfer | Required key plus database lock/unique active Ownership; one winner per asset |
| Wallet funding/ledger posting | Required key plus unique source reference and balanced journal invariant |
| Withdrawal creation/cancel | Required key; atomic funds reservation and unique payout reference |
| Refund request/execution | Required key; cumulative refund cannot exceed captured refundable amount |
| Offer acceptance/PaymentRequest checkout | Required key and immutable OfferVersion reference |
| Contest winner selection/finalization/prize payout | Required key; unique finalized selection and prize allocation per published rule |
| File unlock/AccessGrant creation | Required key or unique Order/File/Version entitlement; no duplicate grants |
| Delivery submit, revision, approval, cancellation, dispute open | Idempotent command identity and state/version lock |
| Review submission | Unique eligible review per Order/target/direction; duplicate returns existing review or stable conflict |
| Notification/event consumers | Deduplicate by source event/resource and recipient; no duplicate visible side effects |

## 36.2 Key behavior

- Client sends `Idempotency-Key` for high-impact POST commands. Scope by authenticated actor, route/operation, and relevant source resource; store a request fingerprint.
- Same key + same effective request returns the original resource/response or its current pending state. Same key + different request returns `409 IDEMPOTENCY_KEY_REUSED`.
- Retention must cover the payment/checkout lifetime and provider reconciliation window; exact duration is an operational policy, not a client assumption.
- A network timeout is an unknown outcome. The client queries the existing resource or retries with the same key.
- Use database unique constraints and compare-and-set/row locks for exclusive ownership, unique successful purchase, wallet journal source, Order creation, and contest winner allocation.
- Write source change, timeline/audit record, idempotency result, and transactional outbox event together where they share the PostgreSQL boundary.
- Call external providers outside the database transaction. Verify callback/query result, then commit the local authoritative transition. Reconciliation repairs unknown outcomes without creating a second charge.
- Workers assume at-least-once event delivery; every consumer is idempotent. “Exactly once” network delivery is not assumed.

---

# 37. API Security

## 37.1 Authentication and session boundary

Use one NeuralMart User identity with additive Buyer/Creator capabilities. Browser sessions follow the backend baseline: Secure, HttpOnly cookies in production, appropriate SameSite setting, rotation after authentication/privilege changes, and revocation on logout, recovery, restriction, or compromise. Cookie-authenticated unsafe methods require CSRF token and/or strict Origin/host checks. Credentialed CORS uses an explicit allowlist.

Native mobile must use the same domain APIs and authorization but needs a documented credential lifecycle and secure OS storage. Prompt #39 must settle the exact mobile session/token format, refresh/revocation behavior, and recovery policy; do not invent a second role identity or weaken web controls.

Admin/staff authentication and identity are separate from ordinary marketplace user capabilities. Step-up authentication applies to high-risk staff, payout, account recovery, and sensitive finance/ownership actions according to policy.

## 37.2 Authorization and privacy

- Enforce identity + capability + resource relationship + current state + policy/risk checks on every protected read and write.
- Prevent IDOR/BOLA with resource-scoped queries; never authorize from a client-provided `userId`, active context, hidden UI button, cursor, or opaque-looking ID.
- Use privacy-safe 404 where revealing resource existence is unsafe.
- Restrict private buyer profiles, conversations, drafts, proposals, contest entries, financial data, analytics, and files to authorized actors.
- Staff scopes are explicit and case-scoped. Sensitive reads are audited as well as mutations.
- Do not return private fields and expect the client to hide them.

## 37.3 Input, abuse, and transport controls

- Validate all path/query/body values with shared schemas and domain rules; allowlist sort/filter fields.
- Use parameterized database access; sanitize/escape user-generated text at rendering boundaries; protect against injection, XSS, SSRF, unsafe redirects, and request smuggling.
- Apply layered route/account/session/resource/provider rate limits. Tune thresholds using production telemetry and abuse outcomes; do not hard-code policy numbers in client contracts.
- Use idempotency for legitimate retries so duplicate protection does not become a false-positive rate-limit event.
- Apply throttles and abuse controls to registration, reset/recovery, proposals, contest entries, messages, search, upload, checkout, refunds, withdrawals, download grants, and admin commands.
- Return safe 429 guidance without exposing fraud thresholds or internal risk signals.

## 37.4 File, payment, and sensitive-field protection

- Direct uploads use short-lived, object-scoped permissions; quarantine and validate file signature, size, type, and scan result before use.
- Store originals privately. Serve only authorized short-lived URLs/streams after a fresh AccessGrant/Ownership/Order check. Separate previews and originals.
- Never store raw payment-card data; use provider tokens/references and hosted collection where possible.
- Encrypt sensitive data in transit and at rest; apply least privilege and retention policy to PII, identity verification, messages, finance, and staff investigation data.
- Redact secrets, signed URLs, private message content, and payment/provider payloads from logs, analytics, error details, cache keys, and realtime messages.

## 37.5 Untrusted frontend claims

The server never trusts client assertions of:

- payment success, refund completion, chargeback status, fee, or seller earning;
- wallet balance, withdrawal eligibility, or ledger result;
- exclusive availability, Sold/Locked state, buyer/seller ownership, or transfer;
- Order acceptance, delivery, revision count, buyer approval, completion, or dispute resolution;
- file entitlement, download completion, or access expiration;
- badge/reputation status, verification, eligibility, or admin scope.

The server loads current records, verifies provider evidence, enforces transition/uniqueness rules, and writes audit/timeline/outbox state. A cache, search result, notification, analytics event, or realtime message cannot authorize a transaction.

## 37.6 Audit and incident handling

Durable append-only audit is required for payment, ledger, refund, payout, Ownership, Order override, dispute decisions, staff scope changes, restrictions, sensitive data/file reads, badge changes, and security/session events. Corrections use reversal/compensating records, never silent history rewrites. Audit payloads exclude secrets and raw sensitive content.

---

# 38. Real-Time API Layer

REST remains the durable source of truth for all resources. Realtime transports deliver low-latency updates or invalidate client views; they cannot commit payment, Order, ownership, delivery, or access state.

## 38.1 MVP recommendation

- Use REST for conversation history, send/edit/read commands, Offers, Orders, Delivery, notifications, and contest state.
- Use an authenticated WebSocket connection for Chat message fan-out, typing, and presence where available. The Part 2 `POST /api/v1/conversations/{conversationId}/realtime-ticket` returns a short-lived conversation-scoped connection ticket. Recheck participant access at connect and subscription time.
- Typing/presence are ephemeral, rate-limited signals; they are not persisted as business events and are not included in dispute evidence as proof of contract.
- Use the same realtime connection for small `notification.created`, `order.updated`, `contest.updated`, or `payment.status_changed` invalidation messages only if the actor is authorized for the referenced resource. Client then refetches canonical REST state.
- In-app notification inbox and push/email delivery remain the offline fallback. If WebSocket is unavailable, Chat and Order APIs continue to work with refresh/polling.
- Do not require Kafka, a separate realtime microservice, or a second event store for MVP. A managed or self-hosted WebSocket gateway can be added behind the same ticket/authorization contract when operationally needed.

## 38.2 Event envelope and delivery semantics

Realtime messages carry `eventId`, `eventType`, `occurredAt`, `resource: { type, id }`, and a minimal safe summary/version. No raw provider payload, full private message body, secret, or unfiltered admin data is broadcast.

Order/payment/contest notifications are emitted only after the database/outbox commit. Delivery is at-least-once; clients deduplicate by event ID and fetch the resource on reconnect. Ordering is guaranteed only within the relevant conversation/aggregate where supported. Missed events are recovered through REST list/timeline/read-cursor APIs.

Payment providers call the server webhook endpoint, never the client WebSocket. A `PAYMENT_CONFIRMED` realtime message is merely a hint that a trusted server-side transition committed.

## 38.3 Later evolution

If event fan-out grows, use a broker-neutral event transport and scale WebSocket delivery workers independently. Introduce generic scoped realtime tickets for Orders/notifications only if client demand and measured connection load justify them. Preserve the same REST read/write contracts and reauthorization behavior.

---

# 39. API Documentation

Use **OpenAPI 3.1** as the machine-readable HTTP contract and rendered developer reference. The existing shared request-schema package is the validation/type source; document any generation or synchronization boundary so OpenAPI and runtime schemas cannot drift.

Every endpoint entry documents:

1. canonical method/path and API version;
2. purpose and owning domain module;
3. authentication/session requirement;
4. capability, resource, participant, staff scope, and policy permissions;
5. path/query/header/body request schemas, required/optional fields, constraints, and examples;
6. success status/envelope/response schema, resource IDs, timestamps, status dimensions, and pagination;
7. stable error categories/codes and HTTP statuses;
8. rate-limit class and retry behavior;
9. idempotency requirement/scope and `If-Match`/concurrency behavior;
10. related resources, event side effects, and whether work is synchronous or asynchronous.

Security schemes distinguish browser cookie sessions, the mobile credential scheme selected in Prompt #39, and provider webhook signatures. Never publish real secrets, production callback payloads, private examples, or internal risk rules. Admin endpoints are tagged and documented separately with staff scopes. Webhook schemas and domain event schemas have independent versions from `/api/v1`.

Maintain:

- API changelog and deprecation notices;
- canonical examples for pending/failed/conflict/permission responses;
- generated client compatibility checks for web and mobile;
- contract tests for payment, ownership, refund, file access, role authorization, and idempotency;
- a sandbox/test environment with non-production provider credentials.

---

# 40. MVP vs V2 vs Advanced API Scope

The API grows by adding endpoints and compatible fields; it does not replace the universal Order, User, Wallet/Ledger, Ownership, Delivery, or Chat boundaries.

## 40.1 MVP

MVP should launch the minimum complete end-to-end flows:

- authentication, account recovery, one User, profiles, roles/capabilities, follow/block, privacy;
- Showcase and Opportunities feeds, posts, media upload/scan/preview;
- products, services, exclusive projects, availability and checkout;
- Buyer Projects, proposal versions, shortlist/selection, Contest creation/entries/winner/prize flow;
- universal Order list/detail/timeline and allowed actions;
- verified payment callbacks, ledger Wallet, earnings, basic withdrawal/refund paths;
- permanent exclusive Ownership and Sold/Locked status;
- Chat, basic Offers/PaymentRequests, conversation-scoped realtime, locked-file access, versioned delivery, essential revisions;
- verified reviews and basic badges/reputation;
- in-app notifications and critical push/email events;
- basic analytics ingestion and private core creator/buyer summaries;
- support tickets, reports, moderation, and scoped audited Admin functions;
- OpenAPI/typed contracts, structured errors, cursor pagination, idempotency, audit/outbox, and basic rate limiting.

MVP uses REST, the existing modular monolith, PostgreSQL as operational source, private object storage, durable outbox/workers, simple database-backed search, and a minimal realtime layer. No GraphQL requirement or microservice fleet.

## 40.2 V2

Add when MVP source records and event semantics are stable:

- richer creator/buyer analytics, attribution, Bid Insights, and dashboard dimensions;
- recommendations with consent, fairness controls, and explainable signals;
- improved search, facets, synonyms, ranking experiments, and dedicated search when measured;
- richer milestone/order/project/contest workflows, revisions, delivery versioning, partial refunds, and dispute tooling;
- notification digests, quiet hours, expanded channel preferences, and delivery health;
- advanced fraud/risk signals, abuse management, badge progress/history/appeals;
- shared cache, read replicas, isolated worker pools, and analytics storage when evidence supports them.

## 40.3 Advanced / scale-dependent

Only when required by scale, business, regulation, or partner demand:

- scoped external developer/partner APIs, OAuth clients, usage quotas, and partner webhooks;
- enterprise organizations/delegated roles and complex compliance workflows;
- event streaming, independently deployed services, regional infrastructure, and selected sharding;
- warehouse/lakehouse, advanced recommendations, and automated marketplace intelligence;
- complex split/milestone settlement, escrow-like workflows, and high-assurance transaction automation.

These capabilities require explicit identity, data-access, event-versioning, financial, and operational controls; they are not MVP prerequisites.

---

# 41. Final NeuralMart API Map

## 41.1 Runtime map

```text
Web client ─┐
Mobile app ─┼── HTTPS JSON REST /api/v1 ── Realtime WebSocket (scoped ticket)
Admin UI ───┘                 │
                              ▼
                 API edge / Express application
                 routing · request IDs · shared schemas
                 response/error envelopes · pagination
                              │
                 Authentication / Session
                 Authorization / capability / policy
                 CSRF / Origin / rate limits / validation
                              │
                              ▼
                 Modular Monolith Domain APIs
     ┌─────────────────────────────────────────────────────────┐
     │ Identity · Profiles · Roles · Content · Media            │
     │ Feed · Search · Catalog · Projects · Proposals · Contests│
     │ Commerce · Universal Order · Payment · Wallet/Ledger     │
     │ Ownership · Delivery/Access · Chat-Commerce              │
     │ Reviews · Reputation · Badges · Notifications            │
     │ Analytics · Support · Reports · Moderation · Admin       │
     └─────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼────────────────────┐
          ▼                   ▼                    ▼
 PostgreSQL primary     Private object storage   Replaceable search
 operational truth      file bytes/previews      projection/index
          │                   │                    │
          ├──────────────┬────┴────────────────────┘
          ▼              ▼
 Read cache (optional)   Transactional outbox + durable workers
                         media scan · payment reconciliation
                         access grants · notifications · analytics
                         feed/search/badge projections · archival
                              │
                              ▼
 Payment provider · email/push · storage/CDN · identity provider
 (narrow adapters; callbacks verified and deduplicated server-side)
```

API and worker processes may be separate deployable processes from the same MVP modular codebase. They call the same domain commands and share data ownership rules. Cache/search/realtime are not sources of financial or ownership truth.

## 41.2 Consolidated primary endpoint inventory

The detailed schemas, permissions, errors, and examples are in the linked Part. This inventory is the canonical route-family index; route examples do not imply that every domain can be accessed without resource checks.

| Domain | Primary route families and commands | Detailed contract |
|---|---|---|
| Auth/session | `/auth/register`, `/auth/login`, `/auth/logout`, `/auth/session/refresh`, `/auth/password-reset/*`, `/auth/recovery/*`, `/auth/verifications`, `/auth/sessions` | Part 1 §§4 |
| Users/profiles | `/me`, `/profiles/{userId}`, `/creators/{creatorId}`, `/freelancers/{creatorId}`, `/me/*-profile`, `/users/{userId}/follow`, `/users/{userId}/block` | Part 1 §§5 |
| Roles/capabilities | `/me/roles`, `/me/capabilities`, `/me/active-context`, `/me/capabilities/{role}/activate` | Part 1 §6 |
| Feeds | `/feed/showcase`, `/feed/opportunities` (legacy `/feed/home` only as compatibility adapter) | Part 1 §§7–8 |
| Posts/social | `/posts`, `/posts/{postId}/publish`, `/archive`, `/restore`, reactions, comments, saves, shares | Part 1 §9 |
| Media/uploads | `/media/uploads`, `/media/uploads/{uploadId}/complete`, `/media/{mediaId}/access` | Part 1 §10; Part 2 §21 |
| Products | `/marketplace/products`, `/publish`, `/archive`, `/availability`, `/preview`, `/files`, `/pricing`, `/checkout` | Part 1 §11 |
| Exclusive projects/ownership | `/exclusive-projects`, `/{projectId}/availability`, `/{projectId}/checkout`, `/me/ownership`, `/ownership/{ownershipId}`, `/ownership/verify` | Part 1 §12; Part 2 §25 |
| Services | `/marketplace/services`, `/publish`, `/pause`, `/resume`, `/requirements`, `/checkout` | Part 1 §13 |
| Projects | `/projects`, `/publish`, `/attachments`, `/close`, `/reopen`, `/selection`, `/shortlist/{proposalId}` | Part 1 §14 |
| Proposals | `/projects/{projectId}/proposals`, `/proposals/{proposalId}`, `/withdraw`, `/reject`, project shortlist and compare | Part 2 §15 |
| Contests | `/contests`, `/{contestId}/publish`, `/close-entries`, `/winner-selections`, `/finalize`, contest entries/shortlist | Part 2 §§16–17 |
| Orders | `/orders`, `/orders/{orderId}`, `/timeline`, `/accept`, `/start`, `/deliveries`, `/revisions`, `/approve`, `/cancellations`, `/refund-requests`, `/disputes` | Part 2 §18 |
| Chat | `/conversations`, `/messages`, `/read-state`, `/attachments`, `/order-links`, `/realtime-ticket` | Part 2 §19 |
| Offers/custom commerce | `/conversations/{conversationId}/offers`, `/offers/{offerId}/send`, `/versions`, `/accept`, `/reject`, `/payment-requests` | Part 2 §20 |
| Paywalled files | `/conversations/{conversationId}/locked-files`, `/orders/{orderId}/locked-files`, `/locked-files/{id}/checkout`, `/media/{id}/access`, `/me/download-history` | Part 2 §21 |
| Delivery/revisions | `/orders/{orderId}/deliveries`, `/deliveries/{deliveryId}`, `/versions`, `/submit`, `/orders/{orderId}/revisions`, `/revisions/{id}/respond` | Part 2 §22 |
| Wallet/ledger | `/wallet`, `/wallet/transactions`, `/wallet/earnings`, `/wallet/fundings`, `/wallet/withdrawals`, payment method setup/list | Part 2 §23 |
| Payments | `/checkouts`, `/payments/{paymentId}`, `/verify`, `/refunds`, `/webhooks/{provider}` | Part 2 §24; Part 3 §37 |
| Reviews/trust | `/orders/{orderId}/review-eligibility`, `/orders/{orderId}/reviews`, `/reviews`, creator/product/service rating summaries | Part 2 §26 |
| Badges | `/me/badges`, `/me/badges/progress`, `/me/badges/history`, `/badges/{badgeId}`, `/users/{userId}/badges` | Part 2 §27 |
| Notifications | `/notifications`, `/unread-count`, `/{notificationId}/read`, `/read-all`, `/notification-preferences` | Part 2 §28 |
| Search | `/search` | Part 2 §29 |
| Analytics | `/analytics/events`, `/analytics/me/creator/*`, `/analytics/me/buyer/*` | Part 3 §30 |
| Support/reports | `/support/tickets`, `/support/tickets/{ticketId}/messages`, `/reports`, `/me/reports` | Part 3 §31 |
| Admin/moderation | `/admin/users`, `/admin/moderation`, `/admin/{products,projects,contests,orders,financial,disputes,badges,reports,settings,audit-logs}` | Part 3 §32 |
| Realtime | Conversation-scoped `/conversations/{conversationId}/realtime-ticket`; optional future scoped domain ticket | Part 2 §19; Part 3 §38 |

The canonical route prefix is always `/api/v1`, even where table shorthand omits it. Admin routes and provider webhook routes have separate authentication mechanisms and authorization scope.

## 41.3 Primary transaction flows

### Marketplace/chat-commerce purchase

```text
Discover in Showcase/Market/Search
→ GET listing/profile and recheck current visibility/availability
→ Contextual Conversation (optional)
→ Versioned Offer or listing checkout
→ Idempotent pending Order + Payment attempt
→ Provider action
→ Verified webhook/server status query
→ Payment + ledger allocation + Order payment state commit
→ Entitlement/Ownership/AccessGrant where required
→ Chat and notification receive committed references
→ Versioned Delivery/Revision if fulfillment applies
→ Buyer approval or policy-allowed auto-completion
→ Verified review eligibility, payout eligibility, reputation/badge projections
```

### Project contract

```text
Discover Project
→ Buyer creates/publishes Project
→ Creator submits versioned Proposal
→ Buyer shortlists/compares
→ Buyer selects Proposal (not yet a paid contract)
→ Conversation and versioned Offer finalize agreed terms
→ Buyer accepts exact Offer version and pays
→ Universal Project Contract Order
→ Seller accepts/starts work
→ Delivery → allowed Revision → Buyer approval/completion
```

### Contest prize

```text
Discover Contest
→ Host publishes only after prize funding/moderation gates
→ Creator submits a versioned Entry under published rights/deadline
→ Entry period closes → judging/shortlist
→ Host proposes and finalizes winner allocation atomically
→ Contest Prize Order(s) and winner confirmation
→ Verified prize payment/payout + required Delivery/rights transfer
→ Contest completion after all required gates
```

### Exclusive Sell Once

```text
Available listing → checkout/payment validation
→ trusted payment result
→ database lock/compare-and-set and uniqueness check
→ Universal Order + permanent Ownership + Sold/Locked state atomically
→ access/rights and timeline/outbox commit
```

If payment succeeds but local ownership/order commit is delayed, return `pending`/`reconciling`; do not expose Sold/Owned success until authoritative records commit, and never accept a second buyer as owner.

## 41.4 Synchronous vs asynchronous boundaries

| Synchronous API result | Asynchronous/event work |
|---|---|
| Authentication and request validation | Email/push delivery |
| Resource permission and current state check | Media scan, transcode, thumbnail and preview generation |
| Durable command commit and returned current state | Search/feed/badge/reputation/analytics projection updates |
| Order/payment attempt creation | Payment provider callback/query and reconciliation |
| Ledger/ownership/access grant commit where same DB transaction applies | External payout/refund completion and reconciliation |
| Chat message acceptance and history write | Realtime fan-out, notification creation, delivery retries |
| Search response from current projection | Projection rebuild and indexing |

If the command is not durably accepted, a dependency failure is a safe `503`. If committed state exists but downstream processing remains, return `202` or the committed resource with a `pending`/`reconciling` state and a polling path. Never return successful payment, ownership, access, or completion state before the owning records commit.

Canonical cross-module events originate from committed changes and use the Prompt #37 transactional outbox: `USER_REGISTERED`, `POST_PUBLISHED`, `PRODUCT_PURCHASED`, `PROJECT_SOLD`, `ORDER_CREATED`, `PAYMENT_CONFIRMED`, `FILE_UNLOCKED`, `CONTEST_WINNER_SELECTED`, `ORDER_COMPLETED`, `REVIEW_SUBMITTED`, and `BADGE_EARNED`, plus related `OWNERSHIP_TRANSFERRED`, `REFUND_RECORDED`, `DELIVERY_SUBMITTED`, `REVISION_REQUESTED`, and `DISPUTE_OPENED`. Events are versioned, at-least-once, deduplicated by ID, and never replace an authoritative resource read.

## 41.5 Security boundaries

1. Client → API: TLS, bounded payloads, request validation, rate limit, CSRF/Origin/CORS controls as applicable.
2. API → domain module: identity, capability, resource ownership/participant relationship, current state, policy, and risk checks.
3. Domain module → PostgreSQL: parameterized access, transactions, uniqueness, optimistic version/row lock for critical races, append-only ledger/audit/history.
4. API → object storage: short-lived scoped upload/download grants; originals private, each retrieval reauthorized.
5. API → payment provider: narrow adapter, provider idempotency, signed callback validation, event dedupe, reconciliation.
6. Domain → worker/realtime/search/cache: outbox-driven, at-least-once, idempotent projection; never grants transactional authority.
7. Admin → sensitive data: separately authenticated staff scope, case purpose, step-up/dual control where required, access and action audit.

## 41.6 Explicit unresolved dependencies

The API contract does not silently choose:

- mobile credential format/lifetime/refresh/revocation details, device binding, or recovery policy — Prompt #39 must finalize these against the existing web session baseline;
- identity-verification provider, payment provider, supported markets/currencies, payout rails, tax treatment, and jurisdiction-specific refund/retention obligations — configure through approved provider/legal policy;
- exact per-route rate thresholds, file-size/type/duration limits, review-window durations, and idempotency retention duration — publish server policy/metadata and tune from operational evidence;
- standalone Dispute System schema/adjudication workflow — Parts 1–2 define only Order integration references and safe endpoints;
- whether wallet top-ups are enabled in MVP — Part 2 defines them as conditional; direct payment checkout remains available independently;
- whether dedicated realtime infrastructure or search service is needed at launch — start with REST, WebSocket Chat, database-backed discovery, and upgrade only against measured need.

These dependencies do not block the established domain API boundaries. Changes require compatible, documented contract updates rather than client-side assumptions.

## 41.7 Canonical specification index

Together, these files form the complete Prompt #38 API Architecture & Contract Specification:

1. [`docs/neuralmart-api-architecture-part-1.md`](neuralmart-api-architecture-part-1.md) — Sections 1–14: API foundations, authentication, profiles, roles, feeds, posts, uploads, products, exclusive projects, services, and Buyer Projects.
2. [`docs/neuralmart-api-architecture-part-2.md`](neuralmart-api-architecture-part-2.md) — Sections 15–29: proposals, contests/entries, Orders, Chat-Commerce, files, Delivery, Wallet/Payments, Ownership, Reviews, Badges, Notifications, and Search.
3. This file — Sections 30–41: analytics, Support/Reports, Admin, unified standards, security, realtime, documentation, roadmap, endpoint inventory, flow map, and final handoff.

Earlier contracts remain in force unless an additive refinement is explicitly identified here. The only response-shape refinement is the backward-compatible broad error `category` added alongside the stable endpoint-specific `code`.

---

## Backend & API Handoff — Prompt #39: Authentication, Security & Identity Architecture

Prompt #39 must treat the following as established API requirements:

1. Versioned REST `/api/v1` is the shared web/mobile/admin API; existing unversioned routes are temporary adapters, not parallel implementations.
2. One NeuralMart User identity has additive Buyer/Creator capabilities; Freelancer, Contest Participant, and Digital Seller remain Creator activity contexts. Admin/staff identity and scopes are separate.
3. Authentication establishes a principal; every request still checks resource ownership/participation, capability, current state, policy, restrictions, and staff scope.
4. Browser session baseline is Secure/HttpOnly cookie sessions with rotation/revocation, CSRF/Origin protection for unsafe requests, and strict credentialed CORS.
5. Mobile credential/session format, refresh and revocation behavior, device security, and recovery flow are the key unresolved identity decisions for Prompt #39.
6. Preserve the Part 1 success/error envelopes, optional additive error `category`, stable specific `code`, opaque IDs, UTC timestamps, minor-unit money, cursor pagination, and shared schema validation.
7. Protected files, payment webhooks, Wallet/Ledger, Orders, exclusive Ownership, delivery/access, and admin operations require the server-side security and audit boundaries in Section 37.
8. Never trust frontend claims about payment, balances, ownership, badges, delivery, or Order status; protect high-impact transitions with idempotency, uniqueness, transactional consistency, verified provider events, and audit.
9. Realtime/WebSocket tickets are short-lived and resource-scoped; REST remains canonical and realtime events are hints from committed outbox events.
10. Define authentication, sessions, account recovery, verification, device/session management, step-up authentication, identity provider boundaries, privacy, and threat controls without creating separate buyer/creator accounts or bypassing established domain rules.

