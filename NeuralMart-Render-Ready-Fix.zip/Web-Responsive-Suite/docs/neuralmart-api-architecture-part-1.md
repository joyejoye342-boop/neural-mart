# NeuralMart — API Architecture & Contract Design
## Part 1 of 3: API Foundations & Core Marketplace APIs

**Document version:** 1.0  
**Depends on:** NeuralMart architecture from Prompts #1–#37, especially Backend Architecture Part 1 Sections 1–12 and Part 3 Sections 25–38  
**Continues in:** Part 2 — Proposals, Contests, Orders, Payments, Wallet, Ownership, Chat, Files, Reviews, Badges, and Notifications  
**Scope:** Sections 1–14  
**Implementation status:** API architecture and contract specification only; no production code

---

## 0. Shared API Contract Conventions

These conventions apply to Sections 1–14 and are the baseline for Parts 2 and 3.

### 0.1 Base path and methods

Canonical client APIs use:

```text
/api/v1/...
```

Examples in existing NeuralMart routes use unversioned `/api/...` paths. During adoption, preserve those paths as temporary compatibility aliases to the same v1 command/query implementation where clients already depend on them. Do not maintain two independent behaviors or separate authorization logic.

Use standard HTTP methods:

- `GET` for reads;
- `POST` for commands that create an action/resource or cause a transition;
- `PATCH` for partial edits to mutable resource content;
- `PUT` for idempotent set/activate/follow operations where the target state is explicit;
- `DELETE` for idempotent removal/unfollow/unblock or soft-delete requests.

Protected state transitions use named command endpoints, not generic status patches.

### 0.2 Identifiers, names, timestamps, money

- Public API IDs are opaque strings. Clients must not infer database type, sort order, ownership, or meaning from an ID.
- Use camelCase JSON field names.
- Use stable lower `snake_case` values for API status/type enums. The existing account role enum remains `buyer | creator | both | admin`.
- Return timestamps in ISO 8601 UTC. If a deadline has a business timezone, return both `dueAt` and `timeZone`.
- Represent money as `{ "amountMinor": 4900, "currency": "USD" }`; never return floating-point values as transaction amounts.
- Distinguish `createdAt`, `updatedAt`, `publishedAt`, `dueAt`, and event/decision timestamps rather than overloading one timestamp.
- Return the user's public role/capability context only when needed. Do not treat an `activeContext` value as an authorization credential.

### 0.3 Success envelope

All successful JSON responses use:

```json
{
  "data": {},
  "meta": {
    "requestId": "opaque-request-id"
  }
}
```

List responses use:

```json
{
  "data": {
    "items": [],
    "nextCursor": "opaque-cursor-or-null"
  },
  "meta": {
    "requestId": "opaque-request-id",
    "hasMore": false
  }
}
```

Endpoint-specific metadata may be added under `data` or `meta`, but clients should not depend on undocumented fields. Empty collections return `items: []`, not `null`.

### 0.4 Error envelope

Errors use a consistent Problem Details-style JSON representation. As an additive v1 refinement consolidated in Part 3, new responses also include a broad `category`; the existing specific `code` remains the stable endpoint-level identifier. During compatibility migration, clients must tolerate older errors that omit `category`.

```json
{
  "type": "https://api.neuralmart.example/problems/validation",
  "title": "Request validation failed",
  "status": 422,
  "category": "VALIDATION_ERROR",
  "code": "VALIDATION_FAILED",
  "detail": "One or more fields need attention.",
  "instance": "/api/v1/projects",
  "traceId": "opaque-trace-id",
  "retryable": false,
  "fieldErrors": [
    {
      "field": "budget.amountMinor",
      "code": "OUT_OF_RANGE",
      "message": "Enter a budget within the allowed range."
    }
  ]
}
```

`detail` and field messages are safe for the current user. Never return stack traces, SQL, provider payloads, secrets, raw risk rules, or private data about another account.

### 0.5 Standard status codes

| HTTP status | Meaning |
|---|---|
| `200` | Read or command completed successfully |
| `201` | Resource created |
| `202` | Accepted; durable work remains pending or reconciling |
| `204` | Successful operation with no response body, used only where no updated representation is needed |
| `400` | Malformed request or invalid query syntax |
| `401` | No valid authentication |
| `403` | Authenticated but not allowed; use privacy-safe `404` where existence itself is sensitive |
| `404` | Resource absent or intentionally not disclosed |
| `409` | Current resource state conflicts with requested action |
| `413` | Request/upload exceeds configured limit |
| `415` | Unsupported media type |
| `422` | Valid JSON but invalid business/input values |
| `429` | Rate limit or abuse control applied; may include `Retry-After` |
| `503` | Required dependency unavailable and operation was not durably accepted |

When a payment or other external result is unknown, return the existing resource in a pending state or `202`; do not suggest that the user start a second transaction.

### 0.6 Pagination, concurrency, and retries

- List/feed endpoints use opaque keyset cursors, not offset pagination.
- `limit` is bounded; default `20`, maximum `50` unless a route defines a smaller limit.
- Cursors are opaque, bound to filters/sort/context, and must not be accepted as authorization.
- Mutable resources return an `ETag` or `resourceVersion`. Updates may send `If-Match`; stale writes return `409 RESOURCE_VERSION_CONFLICT`.
- High-impact commands send an `Idempotency-Key` with a client-generated random value. Scope keys to actor + action + source resource; replay returns the original result.
- A client timeout is an unknown result. It must query the same Order/payment/upload resource and retry with the same idempotency key.

### 0.7 Authentication and permission labels

Endpoint descriptions use:

- **Public:** no session required; only public fields and records.
- **Optional auth:** public result; authenticated context may add safe action flags or personalization.
- **Authenticated:** valid user session required.
- **Buyer capability:** account has Buyer capability and passes resource/state checks.
- **Creator capability:** account has Creator capability and passes resource/state checks.
- **Owner:** authenticated actor owns or controls the resource.
- **Participant:** authenticated actor is a valid participant in the linked resource.
- **Admin scope:** separately authorized staff capability and assigned resource/case scope.

The API always checks resource ownership, current state, restrictions, and relevant policy on the server. A role label alone is never enough.

---

# 1. API Architecture Strategy

## 1.1 Recommendation: REST-first

Use **versioned JSON REST** as NeuralMart's primary API for web, mobile, admin, and future clients.

Why it fits:

- **MVP:** aligns with the existing Express API, route groups, shared Zod contract package, and React API client.
- **Mobile:** predictable, small purpose-built responses; cursor pagination; retry-safe commands; and explicit pending states.
- **Admin:** resource-scoped endpoints use the same domain commands while applying separate staff authorization.
- **Marketplace transactions:** explicit commands make payment, Order, ownership, delivery, and refund boundaries easier to enforce and audit.
- **Feed performance:** dedicated Showcase and Opportunities query endpoints return compact typed cards rather than forcing clients to join multiple resources.
- **Future growth:** stable domain contracts allow independent web/mobile clients and later infrastructure changes without exposing database tables.

GraphQL is not required for MVP. A hybrid design is not recommended at launch because it would create two client contracts and duplicate authorization, caching, testing, and observability work.

If future clients demonstrate materially different query-shape needs that cannot be met by REST read models, GraphQL may be added as a read facade. GraphQL resolvers must call the same module queries and commands. Payment, ownership, Order, file access, and moderation mutations must not bypass REST/domain command invariants.

Representative REST contracts:

| Use | Example | Contract note |
|---|---|---|
| Mobile feed read | `GET /api/v1/feed/showcase?limit=20&cursor={cursor}` | Optional authentication; compact cards in the shared list envelope |
| Marketplace command | `POST /api/v1/exclusive-projects/{projectId}/checkout` | Authenticated Buyer capability; idempotency key; server revalidates availability and payment |
| Conflict response | `409 PROJECT_UNAVAILABLE` | Uses the shared error envelope; client refreshes availability rather than retrying as a new purchase |

## 1.2 Client guidance

- Web and mobile use the same domain routes and authorization model.
- Mobile receives compact list/card DTOs and uses cursor pagination rather than downloading full objects.
- Dashboard/feed aggregation belongs in purpose-built read endpoints, not in client-side multi-resource orchestration.
- Admin tools use `/api/v1/admin/...` with staff-only authorization; staff access does not make private resources public.
- Payment, identity, email, push, and storage webhooks use isolated server-to-server endpoints, not the consumer API session.

---

# 2. API Versioning

## 2.1 Canonical version

New stable client contracts use:

```text
/api/v1/...
```

Examples:

```text
GET  /api/v1/feed/showcase
GET  /api/v1/projects/{projectId}
POST /api/v1/orders/{orderId}/approve
```

If unversioned `/api/...` routes are currently consumed, keep them as compatibility aliases during migration and route both forms to one implementation. New mobile clients should use `/api/v1`.

## 2.2 Backward compatibility

Compatible v1 changes:

- add optional response fields;
- add new endpoints;
- add optional request fields with stable defaults;
- add new enum values only when older clients can safely ignore or render an unknown value.

Breaking changes include:

- changing field meaning/type;
- changing required inputs or state-transition semantics;
- changing permission or visibility behavior;
- removing fields, status values, or endpoints;
- changing money, identifier, or timestamp representation.

Breaking changes require a new version or a documented migration window.

## 2.3 Deprecation and future v2

- Publish a deprecation notice, replacement path, affected client versions, and removal date.
- Monitor use of old routes/fields without logging sensitive request data.
- Keep old and new clients supported for a deliberate transition interval.
- `/api/v2` is introduced only when a breaking contract change cannot be made compatibly.
- Do not duplicate domain logic across versions; adapters translate DTOs to the same application commands/queries.
- Webhook provider schema versions and event schema versions are managed independently from HTTP API versions.

---

# 3. API Domain Structure

Each domain has a stable API boundary because it owns different state, authorization rules, and lifecycle. Related resources may be nested for navigation, but nested routes do not transfer domain ownership.

| Domain | Canonical route group | Owner / boundary |
|---|---|---|
| Auth | `/auth`, `/auth/sessions`, `/auth/verifications` | Identity & Session; login, recovery, session lifecycle |
| Users | `/users`, `/me` | Identity; private account data and current-user summary |
| Profiles | `/profiles`, `/creators`, `/freelancers`, `/buyers` | Profile; public/shared profile and role-specific extensions |
| Roles | `/me/roles`, `/me/capabilities` | Identity/Authorization; one User with additive capabilities |
| Feed | `/feed/showcase`, `/feed/opportunities`, `/feed/home` compatibility | Feed & Discovery; read projections, not source content |
| Posts | `/posts` | Social Content; post lifecycle and interactions |
| Media | `/media`, `/media/uploads` | Media; metadata, upload state, and access authorization |
| Products | `/marketplace/products` | Catalog; digital listing, version, license, availability |
| Services | `/marketplace/services` | Catalog; service packages, requirements, availability |
| Projects | `/projects`, `/exclusive-projects` | Project/Catalog; briefs and exclusive Sell Once listings remain distinct modes |
| Proposals | `/projects/{projectId}/proposals`, `/proposals` | Project & Proposals; proposal state/version, not contest entries |
| Contests | `/contests`, `/feed/opportunities` | Contest; host rules, entries, winner and prize references |
| Orders | `/orders` | Universal Order; commercial lifecycle |
| Payments | `/payments`, `/checkouts`, `/webhooks/{provider}` | Payment; provider lifecycle and verified callbacks |
| Wallet | `/wallet`, `/wallet/transactions`, `/wallet/withdrawals` | Wallet/Ledger; user balances and financial records |
| Ownership | `/ownership`, `/me/ownership` | Ownership; exclusive rights and transfer history |
| Chat | `/conversations`, `/messages`, `/offers` | Chat-Commerce; messages and structured commerce references |
| Files | `/files`, `/media/{mediaId}/access` | Delivery/Access; protected retrieval and access grants |
| Reviews | `/reviews`, `/orders/{orderId}/review-eligibility` | Trust; verified Order-linked review eligibility |
| Badges | `/badges`, `/me/badges` | Trust; definitions, public summary, private progress |
| Notifications | `/notifications`, `/notification-preferences` | Notifications; inbox/read state/channel preferences |
| Search | `/search` (legacy `/explore/search` compatibility) | Search projection; public discovery only |
| Analytics | `/analytics/events`, `/analytics/...` | Analytics; event ingestion and authorized summaries |
| Support | `/support/tickets` | Support; case creation/status and replies |
| Reports | `/reports` | Safety/Moderation; user-submitted reports |
| Admin | `/admin/...` | Admin/Moderation; scoped staff tools and audited operations |

Representative method patterns:

- `GET /api/v1/creators/{creatorId}` reads a public profile; `PATCH /api/v1/me/profile` updates the current user's editable profile fields.
- `POST /api/v1/posts` creates a draft; `POST /api/v1/posts/{postId}/publish` is an explicit state transition.
- `GET /api/v1/marketplace/products?categoryId=...` reads a discovery projection; `POST /api/v1/marketplace/products/{productId}/checkout` initiates a purchase command.
- `POST /api/v1/projects` creates a project; `POST /api/v1/projects/{projectId}/proposals` submits a proposal as a separate resource.
- `POST /api/v1/contests/{contestId}/entries` submits a contest entry; entry submission is not a proposal or an Order.

All domains use Section 0's success and error envelopes, status codes, opaque IDs, timestamps, pagination, and concurrency/idempotency rules. Each mutation validates authorization and current resource state server-side. The route groups here reserve domain ownership; Parts 2–3 provide the remaining detailed contracts.

Rules:

- Use canonical nesting for ownership of a child resource; e.g. project proposals are submitted under a project.
- Use stable top-level routes for retrieval/action of an already-known resource; e.g. `GET /proposals/{proposalId}`.
- Use typed IDs/references rather than duplicating product/service/project/contest records in Posts, Feeds, Orders, or Chat.
- Parts 2 and 3 define the complete contracts for domains beyond Sections 4–14; the route groups above reserve their names and boundaries.

---

# 4. Authentication APIs

## 4.1 Registration

### `POST /api/v1/auth/register`

Creates one User identity and starts a session. Public; rate-limited; no admin registration through this endpoint.

Request:

```json
{
  "email": "person@example.com",
  "password": "user-supplied-secret",
  "displayName": "Maya Johnson",
  "initialCapability": "creator",
  "acceptedPolicies": [
    { "policyKey": "terms", "version": "current-server-version" },
    { "policyKey": "privacy", "version": "current-server-version" }
  ],
  "client": { "platform": "web", "displayName": "Chrome on laptop" }
}
```

`initialCapability` is `buyer` or `creator`; `both` is enabled by adding the other capability after account creation. The server validates current policy versions and records acceptance. `client` metadata is descriptive only, not authorization.

Success: `201`.

```json
{
  "data": {
    "user": {
      "id": "user_opaque_id",
      "displayName": "Maya Johnson",
      "accountRole": "creator",
      "enabledCapabilities": ["creator"],
      "verificationState": "unverified"
    },
    "session": {
      "id": "session_opaque_id",
      "expiresAt": "2026-10-21T12:00:00Z",
      "transport": "cookie"
    },
    "nextActions": ["verify_email", "complete_creator_profile"]
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

For web, set the session cookie; never return the cookie secret in JSON. For a native client, the same semantic session response uses the approved native token transport and returns only its credential bundle to that client. Admin capabilities cannot be self-selected.

Validation: normalized email; unique active account policy; password policy; display-name bounds; allowed initial capability; required policy acceptance; registration abuse checks.

Errors: `400 MALFORMED_REQUEST`, `422 VALIDATION_FAILED`, `409 ACCOUNT_ALREADY_EXISTS` only if account enumeration policy permits (otherwise generic response), `429 RATE_LIMITED`, `503 IDENTITY_PROVIDER_UNAVAILABLE`.

## 4.2 Login and current session

### `POST /api/v1/auth/login`

Public; rate-limited by account/IP and abuse signals.

Request:

```json
{
  "identifier": "person@example.com",
  "password": "user-supplied-secret",
  "client": { "platform": "web", "displayName": "Chrome on laptop" }
}
```

Success: `200`, rotates/creates the session and returns the same safe User/session shape as registration.

Errors: generic `401 INVALID_CREDENTIALS` (do not reveal whether account exists or is disabled); `403 ACCOUNT_RESTRICTED` only with safe user guidance; `429 RATE_LIMITED`; `422 VERIFICATION_REQUIRED` only where policy permits disclosure.

### `GET /api/v1/auth/me`

Authenticated. Returns the current private account summary, capabilities, active context, verification summary, and safe session metadata. Does not return password hashes, provider credentials, reset tokens, payment data, or internal risk fields.

### `POST /api/v1/auth/logout`

Authenticated. Revokes current session; clears cookie for browser. Idempotent; `204` or `200` with `{ "loggedOut": true }`.

### `POST /api/v1/auth/logout-all`

Authenticated; re-authentication/step-up may be required. Revokes all sessions except an explicitly retained current session only if the product specifies that behavior; otherwise revokes all and requires login again.

## 4.3 Refresh and device/session management

### `POST /api/v1/auth/session/refresh`

Web: authenticated renewable session cookie. Native: rotating refresh credential sent in the request body over TLS and stored only in OS secure storage.

Request (native form):

```json
{ "refreshToken": "opaque-rotating-secret" }
```

Success: new session expiry and, for native clients, new short-lived access/rotated refresh credentials. A reused or revoked refresh token revokes the affected token family and requires reauthentication.

Errors: `401 SESSION_EXPIRED`, `401 REFRESH_TOKEN_REVOKED`, `429 RATE_LIMITED`.

### `GET /api/v1/auth/sessions`

Authenticated. Lists the actor's active sessions/devices only: session ID, display name, platform, last activity, created time, current-session flag. Never returns session tokens or secrets.

### `DELETE /api/v1/auth/sessions/{sessionId}`

Authenticated; self-owned session only. Revokes that device/session. `404` if not owned or not found.

## 4.4 Password reset and account recovery

### `POST /api/v1/auth/password-reset/request`

Public; rate-limited. Request `{ "email": "person@example.com" }`. Always returns a generic `202` confirmation so the endpoint does not disclose account existence.

### `POST /api/v1/auth/password-reset/confirm`

Public; rate-limited; one-time expiring reset token.

Request:

```json
{ "resetToken": "single-use-secret", "newPassword": "new-user-supplied-secret" }
```

Success: `200` with `{ "passwordUpdated": true, "sessionsRevoked": true }`. Reset tokens are hashed at rest, single use, and never logged.

### `POST /api/v1/auth/recovery/start`

Public; starts recovery for lost authentication access. Request carries a non-enumerating identifier and recovery context. Response is generic `202`.

### `POST /api/v1/auth/recovery/complete`

Requires verified recovery proof, not a user-provided account ID alone. Response completes the authorized recovery, rotates credentials, revokes prior sessions, and returns a safe next action. High-risk recovery can require support/manual review.

Errors across recovery: generic `401 RECOVERY_PROOF_INVALID`, `409 RECOVERY_ALREADY_USED`, `429 RATE_LIMITED`.

## 4.5 Email, phone, and identity verification

### `POST /api/v1/auth/verifications`

Authenticated. Starts an allowed verification:

```json
{ "type": "email", "destination": "person@example.com" }
```

For identity verification, request a provider flow/reference rather than submitting identity document bytes to the general API:

```json
{ "type": "identity", "returnUrl": "https://client.example/verification/return" }
```

Success: `202` with `{ "verificationId": "...", "type": "identity", "status": "pending", "nextAction": { "type": "open_provider_flow", "url": "short_lived_url" } }`.

### `POST /api/v1/auth/verifications/{verificationId}/confirm`

Authenticated and owner-bound. Request `{ "code": "user-supplied-code" }` for code-based methods; identity-provider results are validated server-to-server. Response shows only `pending | verified | failed | expired`.

### `GET /api/v1/auth/verifications`

Authenticated. Returns the current user's safe verification summaries only.

Verification codes and identity checks are rate-limited; never return full document numbers or provider evidence. Errors include `404 VERIFICATION_NOT_FOUND`, `409 VERIFICATION_EXPIRED`, `422 VERIFICATION_CODE_INVALID`, `429 RATE_LIMITED`.

---

# 5. User & Profile APIs

## 5.1 Public and private data boundary

Public profile data may include, subject to profile visibility:

- display name, handle, avatar, cover, public bio;
- creator category, public skills, portfolio/posts, published products/services;
- verified trust badges, review/rating summary, public availability signals;
- public follower/following counts and contest/project achievement summaries.

Never include in a public profile response:

- email, phone, authentication references, session/device data;
- private wallet/earnings, payout destination, payment instruments;
- identity documents, verification evidence, internal risk/restriction flags;
- private buyer projects, private messages, hidden analytics, or private purchase history.

A pure Buyer has no public creator storefront by default. A Buyer/Client profile is private by default; if a product surface supports an explicitly public buyer identity, only consented contextual fields are returned. Otherwise a lookup that would reveal a buyer-only account returns privacy-safe `404`.

## 5.2 Current user and public profiles

### `GET /api/v1/me`

Authenticated. Equivalent to the safe private account summary in `GET /auth/me`; canonical profile/account screen may use this route. Does not return secrets or sensitive provider state.

### `GET /api/v1/profiles/{userId}`

Public or optional auth. Returns only fields allowed by the target's privacy setting. For buyer-only/private profiles, return privacy-safe `404`.

### `GET /api/v1/creators/{creatorId}`

Public. Requires an active public Creator profile. A creator who paused/hid their storefront may be omitted or returned in a limited state according to visibility policy. Buyer-only users receive `404`.

### `GET /api/v1/freelancers/{creatorId}`

Public. Returns the creator's freelancer-focused profile projection (skills, proposal-relevant portfolio, availability) only when Creator capability and visibility permit it. Freelancer is not a separate account or account role.

### `GET /api/v1/me/buyer-profile`

Authenticated. Returns the current user's private Buyer/Client profile and project-posting preferences.

### `GET /api/v1/me/creator-profile`

Authenticated with Creator capability. Returns the current user's private Creator profile settings and storefront controls.

## 5.3 Editing profiles

### `PATCH /api/v1/me/profile`

Authenticated; updates shared profile fields.

Request:

```json
{
  "displayName": "Maya Johnson",
  "handle": "maya-design",
  "bio": "Brand identity and motion design.",
  "avatarMediaId": "media_opaque_id",
  "coverMediaId": "media_opaque_id",
  "resourceVersion": 3
}
```

Response: updated shared profile and new `resourceVersion`.

Validation: unique normalized handle; field length limits; referenced Media must be owned/authorized, scan-ready, and permitted for profile use; bio/link safety; no account-role changes through profile fields.

### `PATCH /api/v1/me/creator-profile`

Authenticated with Creator capability. Updates category, skills, public portfolio selection, availability, public creator-specific biography, and storefront presentation. It cannot directly edit ratings, sales, earnings, badges, or completed-order metrics.

### `PATCH /api/v1/me/freelancer-profile`

Authenticated with Creator capability. Updates proposal/hiring-focused fields such as service categories, skills, and availability preferences. This is an optional specialization on the Creator identity, not a Freelancer account.

### `PATCH /api/v1/me/buyer-profile`

Authenticated with Buyer capability. Updates private client preferences and, where explicitly supported, consented public organization/display fields. Cannot edit verified buyer/reputation status.

All edits support `If-Match`/`resourceVersion`; stale version returns `409 RESOURCE_VERSION_CONFLICT`. Errors include `422 VALIDATION_FAILED`, `403 CAPABILITY_REQUIRED`, `409 HANDLE_TAKEN`, `404 MEDIA_NOT_FOUND`.

## 5.4 Visibility, follow, and block

### `PATCH /api/v1/me/profile-visibility`

Authenticated. Request:

```json
{
  "creatorProfileVisibility": "public",
  "buyerProfileVisibility": "private"
}
```

Supported values are policy-defined, such as `public`, `limited`, `private`. The default for Buyer identity is private. Creator visibility cannot override a safety restriction or active moderation takedown.

### `PUT /api/v1/users/{userId}/follow`

Authenticated. Idempotently follows a visible/eligible account. Cannot follow self, blocked accounts, or an ineligible buyer-only profile where follow capability is not enabled.

### `DELETE /api/v1/users/{userId}/follow`

Authenticated. Idempotently removes the follow relationship.

### `PUT /api/v1/users/{userId}/block`

Authenticated. Blocks the target according to safety policy. Enforces feed/search/chat visibility changes and blocks new interaction where defined. Cannot block self.

### `DELETE /api/v1/users/{userId}/block`

Authenticated; removes the actor's block only.

Follow/block responses return the actor's relationship state, not private target details. Errors: `401 AUTHENTICATION_REQUIRED`, `404 USER_NOT_FOUND`, `409 SELF_ACTION_NOT_ALLOWED`, `429 RATE_LIMITED`.

---

# 6. Role & Permission APIs

## 6.1 Role representation

One User has a single account and shared wallet, inbox, profile, and Orders. API responses distinguish:

- `accountRole`: current summary `buyer | creator | both | admin`;
- `enabledCapabilities`: additive `buyer` and/or `creator`;
- `activeContext`: `buying | selling`, a preference for default dashboard/navigation only;
- activity such as Freelancer, Digital Seller, or Contest Participant, derived from Creator capability and relevant records—not separate roles.

Admin is a separate staff identity class; it is not combined with marketplace Buyer/Creator capability.

## 6.2 Retrieve enabled roles and capabilities

### `GET /api/v1/me/roles`

Authenticated. Response:

```json
{
  "data": {
    "accountRole": "both",
    "enabledCapabilities": ["buyer", "creator"],
    "activeContext": "selling",
    "availableContexts": ["buying", "selling"]
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

### `GET /api/v1/me/capabilities`

Authenticated. Returns coarse capability flags for the current account, such as `canPublishPosts`, `canListProducts`, `canPostProjects`, `canSubmitProposals`, `canEnterContests`, and `canWithdrawEarnings`. Resource-specific permissions are returned with that resource/action response and rechecked during mutation.

This endpoint is not a permission oracle for another user or arbitrary resource.

## 6.3 Switch active context

### `PUT /api/v1/me/active-context`

Authenticated; idempotent preference update.

Request:

```json
{ "activeContext": "buying" }
```

Response: updated `activeContext`. This changes default feed tab/dashboard framing only. It does not change `accountRole`, create an account, revoke permissions, or grant new permissions.

## 6.4 Activate Creator capability

### `POST /api/v1/me/capabilities/creator/activate`

Authenticated. Adds Creator capability to the same account, provisions/activates CreatorProfile, and sets `accountRole` to `both` when Buyer capability already exists. It may return a `nextActions` onboarding list.

Request may include initial category/skills; those fields are profile data, not capability proof:

```json
{
  "categoryIds": ["category_opaque_id"],
  "skillIds": ["skill_opaque_id"]
}
```

Activation is self-serve unless a separate verification/policy gate applies. It does not create a second User, wallet, session, or inbox.

### `POST /api/v1/me/capabilities/buyer/activate`

Authenticated; adds Buyer capability to the existing account and sets summary role to `both` when Creator capability already exists. Applies required terms/policy acceptance and buyer eligibility.

### `POST /api/v1/me/creator-profile/pause`

Authenticated with Creator capability. Pauses creator storefront/activity without deleting Creator capability, history, reviews, Orders, or earnings. Returns current `creatorStatus`.

### `POST /api/v1/me/creator-profile/resume`

Authenticated with Creator capability. Re-enables eligible public creator activity after policy checks.

No role endpoint may promote an account to `admin`. Capability removal/full role reversion is a separate high-impact account action and is not exposed as an ordinary role switch.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 RESTRICTED_ACCOUNT`, `409 CAPABILITY_ALREADY_ENABLED`, `422 POLICY_ACCEPTANCE_REQUIRED`, `429 RATE_LIMITED`.

---

# 7. Home Feed APIs — Creator Showcase Feed

## 7.1 Canonical endpoint and behavior

### `GET /api/v1/feed/showcase`

Authenticated; Admin receives read-only card content. This is the default Home feed for all regular roles. Role changes available actions and personalized ranking context, not the underlying identity or ownership of feed content.

The same Post/Product/Service/eligible open Project source records can appear in multiple discovery surfaces without duplicating the underlying content. Contests remain out of Showcase and belong to Opportunities.

The legacy `GET /api/feed/home` and `GET /api/feed/showcase` routes may be compatibility aliases. Canonical v1 behavior uses the Showcase contract; existing clients that expected a combined feed continue to receive the same eligible source types through the compatibility adapter rather than a separate content system.

## 7.2 Query parameters

| Parameter | Meaning |
|---|---|
| `cursor` | Opaque continuation cursor; omit for first page/refresh |
| `limit` | Default 20, maximum 50 |
| `categoryId` | Optional category filter supported by eligible source types |
| `contentType` | Repeated or comma-delimited `post`, `product`, `service`, `project` filter |
| `sort` | `default` or `recent`; default uses the approved modest recency/quality ranking |
| `followingOnly` | Boolean; requires authenticated account |
| `personalization` | `default` or `off`; server applies only allowed, consent-aware signals |

The client cannot submit arbitrary ranking weights or internal quality scores. Default Showcase ranking remains recency-first with modest quality/engagement adjustment; personalization cannot override privacy, block/mute, moderation, sold status, or relevance eligibility.

## 7.3 Response contract

```json
{
  "data": {
    "items": [
      {
        "feedItemId": "feed_opaque_id",
        "cardType": "product",
        "source": { "type": "product", "id": "product_opaque_id" },
        "author": {
          "id": "user_opaque_id",
          "displayName": "Maya Johnson",
          "handle": "maya-design",
          "avatar": { "mediaId": "media_opaque_id", "url": "short-lived-or-public-derivative-url" },
          "trustSummary": { "rating": 4.8, "reviewCount": 42, "badgeLabels": ["Trusted Creator"] }
        },
        "media": [{ "mediaId": "media_opaque_id", "role": "thumbnail", "url": "approved-derivative-url" }],
        "summary": {
          "title": "Motion toolkit",
          "description": "A creator-ready template bundle.",
          "price": { "amountMinor": 4900, "currency": "USD" },
          "availability": "available"
        },
        "signals": { "reactionCount": 32, "commentCount": 4 },
        "availableActions": ["open", "save", "purchase"],
        "publishedAt": "2026-10-20T10:30:00Z"
      }
    ],
    "nextCursor": "opaque-cursor-or-null",
    "rankingMode": "default",
    "generatedAt": "2026-10-21T08:00:00Z"
  },
  "meta": { "requestId": "req_opaque_id", "hasMore": true }
}
```

Each `cardType` is a typed compact DTO; avoid putting full Post/Product/Service/Project records in every feed item. `availableActions` is computed by the server for the current actor and is only a UX hint; the endpoint for the action still reauthorizes.

## 7.4 Refresh, pagination, and errors

- Initial load and pull-to-refresh call the endpoint without `cursor`; refresh returns the current first page and a new pagination cursor.
- Infinite scroll sends the returned `nextCursor` and same filter parameters.
- Cursor is invalid if filters or sort change; client restarts at first page.
- Apply visibility, blocked/muted relationships, account restrictions, published status, contest exclusion, and sold-exclusive availability before returning cards.
- For a stale cursor or removed item, return a valid page with eligible items; do not fail the whole feed.

Errors: `401 AUTHENTICATION_REQUIRED`, `400 INVALID_CURSOR`, `422 INVALID_FILTER`, `429 RATE_LIMITED`, `503 FEED_TEMPORARILY_UNAVAILABLE`.

---

# 8. Contest Feed APIs — Opportunities

## 8.1 Canonical endpoint

### `GET /api/v1/feed/opportunities`

Authenticated; Admin read-only. This dedicated high-intent feed includes:

- active contests/competitions;
- open project requests and hiring opportunities;
- no creator Posts, products, or services.

The UI name may be “Contest Feed,” while the API name remains `/feed/opportunities` because it also returns project/hiring opportunities. Existing `/api/feed/opportunities` and client route names can be retained as compatibility aliases.

## 8.2 Filters and sorting

| Parameter | Validation/behavior |
|---|---|
| `type` | `all`, `contest`, or `project`; default `all` |
| `categoryId` | Valid public category ID |
| `minAmountMinor`, `maxAmountMinor`, `currency` | Non-negative range; currency required for monetary range filters |
| `deadlineBefore`, `deadlineAfter` | ISO timestamps; server validates ordering |
| `skillIds` | Bounded list of known skill IDs |
| `location.countryCode`, `location.regionCode` | Optional coarse region only; no precise location required |
| `sort` | `default`, `deadline`, `value`, or `newest`; default preserves approved urgency/value ranking |
| `creatorEligibility` | `eligible`, `all_visible`; returns only visibility-safe reasons |
| `cursor`, `limit` | Opaque keyset cursor; default 20, maximum 50 |

Do not accept raw location coordinates as an implicit requirement. A listing must explicitly expose coarse location eligibility for it to be filtered or shown.

## 8.3 Response contract

```json
{
  "data": {
    "items": [
      {
        "feedItemId": "feed_opaque_id",
        "cardType": "contest",
        "source": { "type": "contest", "id": "contest_opaque_id" },
        "title": "Short-film title sequence",
        "category": { "id": "category_opaque_id", "label": "Motion Design" },
        "host": { "id": "user_opaque_id", "displayName": "Studio North" },
        "prize": { "amountMinor": 100000, "currency": "USD" },
        "deadline": { "dueAt": "2026-11-10T18:00:00Z", "timeZone": "Asia/Dhaka" },
        "eligibility": { "canParticipate": true, "reasonCode": null },
        "availableActions": ["open", "submit_entry"],
        "publishedAt": "2026-10-18T11:00:00Z"
      },
      {
        "feedItemId": "feed_opaque_id_2",
        "cardType": "project",
        "source": { "type": "project", "id": "project_opaque_id" },
        "title": "Hire a motion designer",
        "projectKind": "hiring_opportunity",
        "budget": {
          "minAmountMinor": 50000,
          "maxAmountMinor": 90000,
          "currency": "USD"
        },
        "deadline": { "dueAt": "2026-11-02T18:00:00Z", "timeZone": "Asia/Dhaka" },
        "skills": [{ "id": "skill_opaque_id", "label": "Motion Design" }],
        "location": { "countryCode": "BD", "regionCode": null, "remote": true },
        "eligibility": { "canSubmitProposal": true, "reasonCode": null },
        "availableActions": ["open", "submit_proposal"]
      }
    ],
    "nextCursor": "opaque-cursor-or-null",
    "appliedFilters": { "type": "all", "sort": "default" }
  },
  "meta": { "requestId": "req_opaque_id", "hasMore": true }
}
```

`eligibility` and `availableActions` are computed from persisted role/capability, ownership, block state, account restrictions, contest/project state, and configured eligibility rules. They do not disclose private host or risk data.

Errors: `401 AUTHENTICATION_REQUIRED`, `400 INVALID_CURSOR`, `422 INVALID_FILTER_RANGE`, `429 RATE_LIMITED`, `503 DISCOVERY_UNAVAILABLE`.

---

# 9. Post APIs

## 9.1 Create, draft, edit, and publish

### `POST /api/v1/posts`

Authenticated with Creator capability. Creates a draft by default unless `publishNow: true` is explicitly supported and all publish checks pass.

Request:

```json
{
  "text": "A short project update.",
  "mediaIds": ["media_opaque_id"],
  "links": [
    { "type": "product", "id": "product_opaque_id" },
    { "type": "service", "id": "service_opaque_id" }
  ],
  "visibility": "public",
  "status": "draft"
}
```

Allowed typed links include `product`, `service`, `project`, and `contest`; each target is referenced, never copied into the Post. The server confirms the actor may link the target and that it is visible/eligible.

Response: `201` with Post ID, status, `resourceVersion`, typed links, and safe media summaries.

### `PATCH /api/v1/posts/{postId}`

Authenticated Creator and Post owner. Edits draft or published Post if current policy permits. Request accepts changed fields and `If-Match`/`resourceVersion`.

### `POST /api/v1/posts/{postId}/publish`

Authenticated Creator and owner. Validates ready media, content length, link ownership/visibility, account status, moderation state, and publishing limits. Response includes `publishedAt`, status, and resulting feed visibility.

### `POST /api/v1/posts/{postId}/archive`

Authenticated owner. Removes Post from active feed eligibility without deleting historical interactions/order references.

### `DELETE /api/v1/posts/{postId}`

Authenticated owner; soft delete/tombstone unless retention, dispute, or moderation policy requires preservation. Response `200` includes `status: "deleted"` and `deletedAt`.

### `POST /api/v1/posts/{postId}/restore`

Authenticated owner only while restoration is allowed and no moderation/legal hold prevents it. Restored content re-enters feeds only after visibility/moderation checks; old counters and audit history are preserved.

## 9.2 Retrieve and list

### `GET /api/v1/posts/{postId}`

Public or optional auth. Returns content only if visibility allows; private/draft Posts are visible only to their owner and scoped staff.

### `GET /api/v1/users/{userId}/posts`

Public/optional auth. Cursor-paginated published Posts allowed by profile visibility and current blocks/mutes.

## 9.3 Reactions, comments, saves, shares

### `PUT /api/v1/posts/{postId}/reactions/{reactionType}`

Authenticated. Idempotently sets the actor's reaction type. Valid types are server-configured; one active reaction per user/Post/type policy.

### `DELETE /api/v1/posts/{postId}/reactions/{reactionType}`

Authenticated; idempotent removal.

### `GET /api/v1/posts/{postId}/comments?cursor=...&limit=20`

Public/optional auth if Post visibility permits. Returns cursor-paginated comments with safe author summaries and moderation/deletion placeholders.

### `POST /api/v1/posts/{postId}/comments`

Authenticated. Request `{ "text": "Useful work—congratulations.", "parentCommentId": null }`. Enforces length, nesting, rate limits, block state, and Post visibility.

### `PATCH /api/v1/comments/{commentId}`

Authenticated author only; editable within policy and concurrency version.

### `DELETE /api/v1/comments/{commentId}`

Authenticated author or scoped moderator; soft-deletes, preserving thread integrity and audit history.

### `PUT /api/v1/posts/{postId}/save` / `DELETE /api/v1/posts/{postId}/save`

Authenticated. Idempotent save/unsave for the current user; does not expose another user's saved collection.

### `POST /api/v1/posts/{postId}/shares`

Authenticated or public only if product policy allows. Returns a safe share URL and records a share event only under the approved product/analytics policy. Do not reveal private Posts through generated links.

Response:

```json
{
  "data": {
    "postId": "post_opaque_id",
    "shareUrl": "https://neuralmart.example/posts/post_opaque_id",
    "visibility": "public"
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

## 9.4 Post errors and security

Relevant errors: `401 AUTHENTICATION_REQUIRED`, `403 CREATOR_CAPABILITY_REQUIRED`, `403 NOT_POST_OWNER`, `404 POST_NOT_FOUND`, `409 RESOURCE_VERSION_CONFLICT`, `409 POST_NOT_PUBLISHABLE`, `413 MEDIA_LIMIT_EXCEEDED`, `422 INVALID_LINK_TARGET`, `422 MEDIA_NOT_READY`, `429 RATE_LIMITED`.

All mutations enforce ownership and visibility server-side. A public feed or client-supplied link never proves permission to edit the referenced Product/Service/Project/Contest.

---

# 10. Media Upload APIs

## 10.1 Upload flow

Large files upload directly to private object storage through a short-lived, scoped upload authorization rather than streaming through the API process:

```text
Upload request
→ server validates actor/purpose/quota and creates Media + upload session
→ server returns temporary storage permission
→ client uploads bytes to quarantine storage
→ client signals completion
→ server verifies object metadata/checksum and scans/processes
→ Media becomes ready or rejected
→ authorized parent resource attaches the Media reference
```

Supported purposes include:

`avatar`, `cover`, `post_media`, `product_thumbnail`, `product_preview`, `product_file`, `project_attachment`, `contest_entry`, `delivery_file`, and `chat_attachment`.

## 10.2 Initiate upload

### `POST /api/v1/media/uploads`

Authenticated. Some purposes require Creator capability, project ownership, contest participation, Order participation, or Conversation membership.

Request:

```json
{
  "purpose": "product_file",
  "fileName": "motion-pack.zip",
  "declaredMimeType": "application/zip",
  "sizeBytes": 73400320,
  "checksum": {
    "algorithm": "sha256",
    "value": "client-computed-checksum"
  },
  "parent": { "type": "product_draft", "id": "product_opaque_id" }
}
```

`parent` is a typed reference, not proof of ownership. Server verifies it. The client checksum is an integrity hint and must be checked against observed uploaded bytes/object metadata.

Success: `201` with:

```json
{
  "data": {
    "uploadId": "upload_opaque_id",
    "mediaId": "media_opaque_id",
    "status": "upload_authorized",
    "upload": {
      "method": "PUT",
      "url": "short-lived-signed-upload-url",
      "expiresAt": "2026-10-21T08:20:00Z",
      "requiredHeaders": { "Content-Type": "application/zip" }
    },
    "limits": { "maxBytes": 104857600 }
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

Signed upload URLs and required credential-bearing headers are secrets: do not log, persist in analytics, or return them from unrelated endpoints.

## 10.3 Complete and check processing

### `POST /api/v1/media/uploads/{uploadId}/complete`

Authenticated upload owner. Request `{ "clientChecksum": "...optional..." }`; object key and actual byte size are resolved server-side from the upload session/storage provider, not accepted as arbitrary paths from the client.

Response: `202`:

```json
{
  "data": {
    "mediaId": "media_opaque_id",
    "status": "scanning",
    "nextAction": "poll_upload_status"
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

### `GET /api/v1/media/uploads/{uploadId}`

Authenticated upload owner or authorized parent participant. Returns `upload_authorized | uploaded | scanning | processing | ready | rejected | expired`, safe failure code, dimensions/duration where allowed, and generated derivative references. It does not expose private storage paths.

### `POST /api/v1/media/{mediaId}/access`

Authenticated and authorized by Media/Delivery/Access rules. Returns a short-lived scoped preview/download URL only after checking current grant, parent, scan, payment/Order, ownership/license, refund/dispute, and restriction state. Part 2 defines the complete file/access API.

## 10.4 Validation, errors, and security

- Check purpose-specific allowed types, actual file signature, MIME, size, duration/page count, archive expansion, and user quotas.
- Store initial uploads in private quarantine. A client cannot mark a file `ready`, `public`, or `paid`.
- Virus/malware scanning and safe preview generation complete before publishing or buyer access.
- Attach only a `ready` Media ID the actor is allowed to use.
- `413 UPLOAD_TOO_LARGE`, `415 UNSUPPORTED_MEDIA_TYPE`, `403 UPLOAD_PURPOSE_FORBIDDEN`, `404 UPLOAD_NOT_FOUND`, `409 UPLOAD_ALREADY_COMPLETED`, `422 CHECKSUM_MISMATCH`, `422 MEDIA_SCAN_REJECTED`, `429 UPLOAD_RATE_LIMITED`, `503 STORAGE_UNAVAILABLE`.

---

# 11. Product APIs

## 11.1 Create and manage products

Products are versioned digital marketplace listings; product files and license terms are not embedded in Posts or Orders.

### `POST /api/v1/marketplace/products`

Authenticated with Creator capability. Creates a draft.

Request:

```json
{
  "title": "Motion Toolkit",
  "description": "Editable motion design templates.",
  "categoryId": "category_opaque_id",
  "productKind": "template_bundle",
  "price": { "amountMinor": 4900, "currency": "USD" },
  "licenseIds": ["license_opaque_id"],
  "thumbnailMediaId": "media_opaque_id",
  "previewMediaIds": ["media_opaque_id_2"],
  "fileMediaIds": ["media_opaque_id_3"]
}
```

Supported product kinds include thumbnails, graphics, templates, AI reels, prompt packs, source files, and creative bundles. Type-specific validation applies; a source file must not be attached as a public preview.

### `PATCH /api/v1/marketplace/products/{productId}`

Authenticated owner; draft or permitted live listing fields only. Edits create/update a product version as appropriate. Published purchase terms are not rewritten for prior Orders.

### `POST /api/v1/marketplace/products/{productId}/publish`

Authenticated owner. Requires ready media, valid license/pricing, category, policy eligibility, and no moderation hold.

### `POST /api/v1/marketplace/products/{productId}/archive`

Authenticated owner. Stops new purchases while preserving Orders, Ownership, and entitlements.

### `GET /api/v1/marketplace/products/{productId}`

Public/optional auth when listing visibility allows. Returns safe public details, version/availability summary, preview references, creator summary, and supported purchase action.

### `GET /api/v1/marketplace/products`

Public/optional auth. Search/list query uses category, creator, price range/currency, product kind, availability, cursor, and limit; dedicated Search behavior is finalized in Part 3.

## 11.2 Previews, pricing, availability, and files

### `GET /api/v1/marketplace/products/{productId}/preview`

Public/optional auth. Returns only approved preview assets; never original ProductFile/source files.

### `GET /api/v1/marketplace/products/{productId}/availability`

Returns a server-derived summary:

```json
{
  "data": {
    "status": "available",
    "canPurchase": true,
    "reasonCode": null,
    "price": { "amountMinor": 4900, "currency": "USD" }
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

Availability is informational and may change before checkout. Checkout always revalidates.

### `PUT /api/v1/marketplace/products/{productId}/files`

Authenticated owner. Associates scanned, owned Media IDs with the draft/product version and role (`preview`, `download`, `source`, `documentation`, `license`). This endpoint does not make files public.

### `PATCH /api/v1/marketplace/products/{productId}/pricing`

Authenticated owner. Updates future listing price/license options. Existing Order snapshots remain unchanged. Exclusive products use their own locked availability rules.

## 11.3 Purchase

### `POST /api/v1/marketplace/products/{productId}/checkout`

Authenticated Buyer capability (Creators may buy from other creators). Requires `Idempotency-Key`.

Request:

```json
{
  "productVersionId": "product_version_opaque_id",
  "licenseId": "license_opaque_id",
  "paymentMethodReference": "provider-token-reference"
}
```

Server validates listing/version/license, current price/currency, buyer eligibility, self-purchase policy, moderation state, and payment source. Client cannot supply the authoritative price or seller.

Response: `202` while payment is pending, with Order ID, checkout action/status, and next step. `200` if the platform can confirm completion synchronously; never return `purchased` until authoritative payment and entitlement state commit.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 BUYER_CAPABILITY_REQUIRED`, `404 PRODUCT_NOT_FOUND`, `409 PRODUCT_UNAVAILABLE`, `409 IDEMPOTENCY_KEY_REUSED`, `422 LICENSE_NOT_AVAILABLE`, `402 PAYMENT_REQUIRED_OR_DECLINED` only for a confirmed safe failure, `202 PAYMENT_RECONCILING`, `429 PURCHASE_RATE_LIMITED`.

---

# 12. Exclusive Project APIs

## 12.1 Resource distinction

An exclusive Sell Once project remains a Project record with an exclusive listing/rights mode and file references. It is not a normal hiring brief, not a proposal, and not a second project entity.

## 12.2 Create, publish, retrieve

### `POST /api/v1/exclusive-projects`

Authenticated with Creator capability as the asset/listing owner. Creates an exclusive project listing in draft.

Request:

```json
{
  "title": "Editorial Brand System",
  "description": "A complete visual identity project offered once.",
  "categoryId": "category_opaque_id",
  "skillIds": ["skill_opaque_id"],
  "price": { "amountMinor": 85000, "currency": "USD" },
  "rightsSnapshot": {
    "transferType": "exclusive",
    "sourceFilesIncluded": true
  },
  "previewMediaIds": ["media_opaque_id"],
  "projectFileMediaIds": ["media_opaque_id_2"]
}
```

Rights choices and required disclosure must be server-approved policy options, not arbitrary legal text supplied as structured truth.

### `POST /api/v1/exclusive-projects/{projectId}/publish`

Authenticated listing owner. Requires ready previews/files, seller authority, validated rights/price, active account, and no moderation restriction.

### `GET /api/v1/exclusive-projects/{projectId}`

Public/optional auth while public. After sale, show `sold_locked`/unavailable state and public listing summary; never expose buyer identity unless the buyer consented to public attribution.

### `GET /api/v1/exclusive-projects/{projectId}/availability`

Returns current server-derived availability and safe reason:

```json
{
  "data": {
    "availability": "available",
    "canPurchase": true,
    "price": { "amountMinor": 85000, "currency": "USD" },
    "ownershipState": "not_transferred"
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

This endpoint is informational only; purchase revalidates within the ownership transaction.

## 12.3 Purchase and ownership retrieval

### `POST /api/v1/exclusive-projects/{projectId}/checkout`

Authenticated Buyer capability; requires `Idempotency-Key`.

Request:

```json
{
  "paymentMethodReference": "provider-token-reference",
  "acceptedRightsVersion": "rights-version-id"
}
```

The server must:

1. Validate actor, seller, listing, current rights/price, payment source, account restrictions, and eligibility.
2. Create/reuse one pending checkout/Order and payment attempt.
3. Verify trusted provider result; ignore any client assertion of payment success.
4. Lock or compare-and-set the exclusive project after payment validation.
5. In one PostgreSQL transaction, recheck availability; link/create Order/OrderItem and durable Ownership/OwnershipTransfer; mark Sold/Locked; create required entitlement/AccessGrant; write timeline/audit and outbox.
6. Return `owned` only after commit; otherwise return `payment_pending`/`reconciling` and prevent a duplicate charge.

Race response: `409 PROJECT_UNAVAILABLE` if another successful purchase committed first. If payment was captured but ownership cannot be assigned, hold/reconcile and void/refund through the payment workflow; never assign to both buyers. A replay with the same idempotency key returns the original Order result.

### `GET /api/v1/me/ownership`

Authenticated. Lists current user's Ownership records with item, rights summary, source Order, acquisition date, and access state. Cursor-paginated.

### `GET /api/v1/ownership/{ownershipId}`

Authenticated owner or scoped staff only. Returns rights/transfer receipt and authorized file-access references, not permanent file URLs.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 BUYER_CAPABILITY_REQUIRED`, `404 PROJECT_NOT_FOUND`, `409 PROJECT_UNAVAILABLE`, `409 OWNERSHIP_ALREADY_EXISTS`, `409 IDEMPOTENCY_KEY_REUSED`, `202 PAYMENT_RECONCILING`, `402 PAYMENT_DECLINED`, `429 PURCHASE_RATE_LIMITED`.

---

# 13. Service APIs

## 13.1 Service resource and packages

A Service is a scoped creator offering. It may contain one or more versioned packages with price, delivery time, requirements, included revisions, and deliverables. Order creation snapshots the selected package.

## 13.2 Create, edit, publish, pause, archive

### `POST /api/v1/marketplace/services`

Authenticated with Creator capability. Creates a draft.

Request:

```json
{
  "title": "Short-form video editing",
  "description": "Editing for social and launch videos.",
  "categoryId": "category_opaque_id",
  "skillIds": ["skill_opaque_id"],
  "mediaIds": ["media_opaque_id"],
  "packages": [
    {
      "name": "Starter",
      "price": { "amountMinor": 12000, "currency": "USD" },
      "deliveryDays": 5,
      "includedRevisions": 1,
      "deliverables": ["One edited video"]
    }
  ],
  "requirements": [
    { "key": "footage", "label": "Upload your footage", "required": true, "type": "file" }
  ]
}
```

Response: `201` draft Service with `resourceVersion`.

### `PATCH /api/v1/marketplace/services/{serviceId}`

Authenticated owner. Updates editable fields and package versions; cannot rewrite terms of active/paid Orders.

### `POST /api/v1/marketplace/services/{serviceId}/publish`

Authenticated owner. Validates package, price, delivery time, requirement schema, ready media, category, and policy eligibility.

### `POST /api/v1/marketplace/services/{serviceId}/pause`

Authenticated owner. Stops new bookings while preserving existing Orders.

### `POST /api/v1/marketplace/services/{serviceId}/resume`

Authenticated owner. Rechecks availability and moderation state before offering bookings again.

### `POST /api/v1/marketplace/services/{serviceId}/archive`

Authenticated owner. Removes the listing from discovery without deleting transaction history.

## 13.3 Retrieve and requirements

### `GET /api/v1/marketplace/services/{serviceId}`

Public/optional auth when visible. Returns public description, creator summary, active packages, requirements schema, estimated delivery, revision terms, and safe action flags.

### `GET /api/v1/marketplace/services`

Public/optional auth. Cursor-paginated listing query with category, skill, creator, package price/currency, availability, and sort filters.

### `GET /api/v1/marketplace/services/{serviceId}/requirements`

Public/optional auth for the published buyer-facing requirement definition. Does not expose seller-only notes or another buyer's answers.

## 13.4 Order a service

### `POST /api/v1/marketplace/services/{serviceId}/checkout`

Authenticated Buyer capability; requires `Idempotency-Key`.

Request:

```json
{
  "packageId": "service_package_opaque_id",
  "requirements": [
    { "key": "footage", "mediaIds": ["media_opaque_id"] },
    { "key": "style", "text": "Fast, energetic pacing" }
  ],
  "paymentMethodReference": "provider-token-reference"
}
```

The server validates active package/version/price, purchase eligibility, requirement fields and Media access, creator availability/capacity, and payment source; it creates a pending Service Order snapshot. The server derives the delivery deadline from the accepted package and timezone policy. Revisions are limited by the purchased package/Order snapshot, not the current listing.

Response is `202` while payment is pending and includes Order ID, payment state, and next action. A service booking is not marked active until the required payment/order transition commits.

Errors: `403 BUYER_CAPABILITY_REQUIRED`, `404 SERVICE_NOT_FOUND`, `409 SERVICE_PAUSED`, `409 PACKAGE_CHANGED`, `422 REQUIREMENTS_INVALID`, `422 MEDIA_NOT_READY`, `402 PAYMENT_DECLINED`, `202 PAYMENT_RECONCILING`, `429 PURCHASE_RATE_LIMITED`.

---

# 14. Buyer Project APIs

## 14.1 One Project model, two buyer intents

Use one Project resource and one proposal/selection lifecycle. Distinguish:

- `project_request`: a normal brief describing work needed;
- `hiring_opportunity`: a clearly presented hiring post optimized for creator discovery.

Both can appear as eligible project cards in Showcase and Opportunities. They are not Contests and do not become proposals until a Creator submits one.

## 14.2 Create, retrieve, edit, and publish

### `POST /api/v1/projects`

Authenticated with Buyer capability. Creates a draft.

Request:

```json
{
  "projectKind": "project_request",
  "title": "Create a launch animation",
  "description": "We need a short product launch animation.",
  "categoryId": "category_opaque_id",
  "skillIds": ["skill_opaque_id"],
  "budget": {
    "minAmountMinor": 50000,
    "maxAmountMinor": 90000,
    "currency": "USD"
  },
  "deadline": {
    "dueAt": "2026-11-02T18:00:00Z",
    "timeZone": "Asia/Dhaka"
  },
  "visibility": "public",
  "attachmentMediaIds": ["media_opaque_id"]
}
```

Response: `201` with `status: "draft"`, project ID, `resourceVersion`, and safe next actions.

### `PATCH /api/v1/projects/{projectId}`

Authenticated project owner while editable. Updates draft or open brief fields; checks resource version. Changes after proposals exist may require an explicit change notice/version snapshot and creator notification. Do not silently rewrite a selected proposal or active Order contract.

### `POST /api/v1/projects/{projectId}/publish`

Authenticated project owner. Validates title/description/category, budget and currency, deadline/timezone, skills, attachment ownership/scan state, project kind, buyer eligibility, and policy.

### `GET /api/v1/projects/{projectId}`

Public/optional auth for a public open brief. Participant/owner receives additional private fields such as proposal status or management actions. Other viewers do not receive proposal contents or private buyer data.

### `GET /api/v1/projects`

Public/optional auth for discoverable briefs; owner may request own managed projects. Cursor-paginated filters include status, project kind, category, skill, budget/currency, deadline, and coarse public location where configured.

## 14.3 Attach files and manage status

### `PUT /api/v1/projects/{projectId}/attachments`

Authenticated owner. Sets the attachment list using ready Media IDs. Enforces configured file count/size and private/public attachment policy; existing Order/dispute evidence is not deleted by replacing the project brief's current attachments.

### `POST /api/v1/projects/{projectId}/close`

Authenticated owner. Closes proposal intake; preserves existing proposals and any selected/active Order. Response returns `status: "closed"` and `closedAt`.

### `POST /api/v1/projects/{projectId}/reopen`

Authenticated owner; allowed only when no completed/cancelled/active contract state prevents reopening, deadlines and policy remain valid, and the project has not been sold as an exclusive asset. Reopening revalidates budget/deadline/visibility and may notify eligible creators. It does not reset proposal history.

## 14.4 Shortlist and creator selection

### `PUT /api/v1/projects/{projectId}/shortlist/{proposalId}`

Authenticated project owner. Idempotently shortlists an eligible proposal on an open/selection-stage project. Does not accept the Proposal, create an Order, or transfer rights.

### `DELETE /api/v1/projects/{projectId}/shortlist/{proposalId}`

Authenticated owner. Removes the shortlist relationship; preserves Proposal history and creator notification/audit policy.

### `POST /api/v1/projects/{projectId}/selection`

Authenticated owner. Selects one eligible Proposal/ProposalVersion for final contract confirmation.

Request:

```json
{
  "proposalId": "proposal_opaque_id",
  "proposalVersionId": "proposal_version_opaque_id"
}
```

Success: `202` or `200` with:

```json
{
  "data": {
    "projectId": "project_opaque_id",
    "selectionId": "selection_opaque_id",
    "selectedProposalId": "proposal_opaque_id",
    "status": "awaiting_contract_confirmation",
    "conversationId": "conversation_opaque_id",
    "nextAction": "confirm_final_terms"
  },
  "meta": { "requestId": "req_opaque_id" }
}
```

Selection is not payment, contract completion, or work start. Final accepted terms and payment create/activate the Project Contract Order through the commerce/order API defined in Part 2. Proposal history remains intact.

## 14.5 Validation and errors

- Creator cannot edit, close, shortlist, or select on another user's Project.
- Project owner cannot select a withdrawn, expired, rejected, or otherwise ineligible Proposal.
- One accepted selection path is active at a time; concurrent selections use a resource lock/version check and return `409 SELECTION_ALREADY_IN_PROGRESS`.
- Closing a project blocks new proposals but does not erase existing ones.
- Reopening preserves historical proposal states and does not duplicate a Project.
- Project attachments remain private unless explicitly published/visible under project policy; final Order delivery files use Delivery/Access APIs, not the brief attachment endpoint.

Errors: `401 AUTHENTICATION_REQUIRED`, `403 BUYER_CAPABILITY_REQUIRED`, `403 NOT_PROJECT_OWNER`, `404 PROJECT_NOT_FOUND`, `409 PROJECT_NOT_EDITABLE`, `409 PROJECT_CLOSED`, `409 RESOURCE_VERSION_CONFLICT`, `409 SELECTION_ALREADY_IN_PROGRESS`, `422 BUDGET_INVALID`, `422 DEADLINE_INVALID`, `422 ATTACHMENT_NOT_READY`, `422 PROPOSAL_NOT_ELIGIBLE`, `429 PROJECT_ACTION_RATE_LIMITED`.

---

## Part 1 Continuity Rules for Parts 2–3

1. Use the common response/error envelopes, opaque identifiers, UTC timestamps, minor-unit money, cursor pagination, and scoped idempotency described in Section 0.
2. Continue the same `/api/v1` resource namespace and maintain legacy route aliases only as adapters to the same implementation.
3. Preserve the one-User additive capability model; Freelancer, Contest Participant, and Digital Seller remain Creator activity contexts.
4. Keep Showcase and Opportunities separate. Showcase may include Posts, Products, Services, and eligible open Projects; Opportunities includes active Contests and Projects/hiring opportunities.
5. Keep Posts, Products, Services, Projects, Proposals, Contests, and Orders as distinct source resources linked by typed IDs.
6. Universal Order, Payment/Wallet, Ownership, Delivery/Access, Chat, Reviews, and Disputes keep their Prompt #37 source-of-truth boundaries.
7. No API request can directly set a successful payment, Sold/Locked state, Ownership, AccessGrant, Order completion, rating, badge, or moderation result.
8. Parts 2 and 3 must add endpoint contracts for the remaining domains without redefining these conventions.

---

## Handoff Summary for Part 2

Part 2 should continue this exact `/api/v1` contract and define concrete endpoint/request/response schemas for:

1. Project Proposals and contest creation, entries, judging, winner selection, and prize-order conversion.
2. Universal Order detail/list/actions, timelines, delivery, revisions, cancellation, refund, dispute references, and completion.
3. Payment initiation/provider callbacks, wallet/ledger, withdrawals, refunds, and payout operations.
4. Ownership and exclusive transfer APIs beyond the checkout/list/lookup operations in Section 12.
5. Conversations, messages, Offer versions, payment requests, and Order linking.
6. File access, paywalled delivery, order-linked review eligibility/submission, Badges, and Notifications.

Part 3 should finalize shared webhook/error/event schemas, search and analytics contracts, admin/support/report endpoints, rate limits, audit, and the complete client/versioning contract.
