# NeuralMart — Top Navigation & Core Feature Hub System

**Document version:** 1.0  
**Companion to:** `neuralmart-home-page-architecture.md`, `neuralmart-ux-design-system.md`  
**Design reference:** Facebook's top-nav clarity applied to a creator marketplace. No hamburger menus for primary features. No buried hubs. Every major destination is one tap from anywhere in the app.

---

## 0. The Governing Principle

Facebook solved a hard problem in 2010: how do you give 500 million people access to News Feed, Groups, Marketplace, Watch, Notifications, and Messenger — without making the app feel like a control panel? Their answer: **a flat, icon-based top bar + one persistent navigation row.** Every feature is at the same depth (one tap from the bar). Nothing is buried more than two taps from the home screen.

NeuralMart borrows that insight and adapts it for a dual-role creator marketplace:

> **"Every major feature hub is one tap from anywhere. Secondary tools are two taps. Config is three."**

The difference from Facebook: NeuralMart has *two types of primary users* (Buyers and Creators) with different primary intents. The navigation must serve both without splitting into two apps or showing different nav bars by role.

The resolution: **the nav bar is identical for all roles. Role variance lives in the hub pages themselves and in the composer card, not in what's visible in the nav.**

---

## 1. Final Navigation Architecture — Three Layers

NeuralMart navigation is organized into exactly three horizontal layers of importance. Each layer has a strict item budget.

```
┌────────────────────────────────────────────────────────────┐
│  LAYER 1 — TOP APP BAR (always visible, 6 slots max)       │
│  Logo · [space] · Search · Notifications · Messages · Me   │
├────────────────────────────────────────────────────────────┤
│  LAYER 2 — FEATURE ROW (always visible, 5–6 icon tabs)     │
│  Home · Explore · Projects · Contests · Market · Dashboard │
├────────────────────────────────────────────────────────────┤
│  LAYER 3 — MENU / DRAWER (on-demand, unlimited depth)      │
│  Wallet · Orders · Settings · Profile edit · Help · Logout │
└────────────────────────────────────────────────────────────┘
```

**Layer 1** handles identity, utility, and real-time status.  
**Layer 2** handles primary feature destinations.  
**Layer 3** handles account management, financial tools, and configuration.

Nothing crosses between layers. If a feature belongs in Layer 3, it does not also appear in Layer 2. This prevents the "every team wanted their feature in the nav" sprawl.

---

## 2. Layer 1 — Top App Bar

### 2.1 Mobile (≤ 767px)

```
┌───────────────────────────────────────────────────────┐
│  [⬡ NeuralMart]              [🔍] [🔔] [💬] [Av]    │
│  ← Logo                      ← Utility cluster →      │
└───────────────────────────────────────────────────────┘
  height: 56px · sticky top · bg-background/80 backdrop-blur
```

| Slot | Element | Icon | Tap behavior | Badge |
|---|---|---|---|---|
| Left | Logo wordmark | Hexagon + "NeuralMart" | Scroll-to-top if on home; navigate to `/` if elsewhere | — |
| Right 1 | **Search** | `Search` (magnifier) | Opens full-screen search overlay | — |
| Right 2 | **Notifications** | `Bell` | Opens notification tray (slide-in sheet from right) | Red dot (unread count > 0) |
| Right 3 | **Messages** | `MessageSquare` | Navigates to `/messages` (inbox hub) | Blue dot (unread threads > 0) |
| Right 4 | **Avatar** | User's avatar image | Navigates to own profile `/creators/:id` | — |

**Why Messages is in the top bar and also in the feature row:**  
Messages is the only hub that appears in *both* layers. This mirrors Facebook Messenger's treatment: the inbox is a primary destination (feature row) AND a real-time status indicator (top bar badge). The badge on the top-bar icon is what tells users they have unread messages — the feature row icon is how they navigate there. Both are needed; neither is redundant.

**Search is not in the feature row.** Search is a utility, not a content destination. It deserves instant access (top bar) but not a named "hub" alongside Explore and Projects. Search across creators, products, services, posts, and projects is surfaced within the Search overlay itself, organized by category.

### 2.2 Desktop (≥ 768px)

On desktop, Layer 1 collapses into the sidebar header. The sidebar replaces the entire top bar:

```
┌──────────────────────────────────────┐
│  [⬡] NeuralMart                     │  ← Logo, top of sidebar
│  ─────────────────────────────────── │
│  [Feature row items, vertical]       │  ← Layer 2 becomes sidebar items
│                                      │
│  [User card, bottom of sidebar]      │  ← Avatar + name + role badge
└──────────────────────────────────────┘
```

On desktop, the top bar Search/Notifications/Messages utility cluster moves to:
- **Search:** A search bar embedded at the top of the sidebar, always visible.
- **Notifications:** A bell icon in the sidebar, above the user card, or in a thin persistent strip.
- **Messages:** Listed as one of the sidebar nav items (same as feature row).

---

## 3. Layer 2 — Feature Row (Primary Navigation)

### 3.1 The final feature row — six items

After evaluating all NeuralMart features against the "one tap from anywhere" rule, the feature row has **six destinations** — the maximum before the row becomes crowded on a 390px viewport.

```
Mobile bottom bar (always visible):
┌────────┬────────┬─────────┬────────┬────────┬────────┐
│   🏠   │   🔭   │   💼    │   🏆   │   🛍   │   📊   │
│  Home  │Explore │Projects │Contests│ Market │  Dash  │
└────────┴────────┴─────────┴────────┴────────┴────────┘
```

| # | Label | Icon | Route | Hub purpose |
|---|---|---|---|---|
| 1 | **Home** | `Home` | `/` | Showcase Feed — creator content stream, universal default |
| 2 | **Explore** | `Telescope` or `Compass` | `/explore` | Discovery — find creators, browse categories, trending content |
| 3 | **Projects** | `Briefcase` | `/projects` | Freelance marketplace — open briefs, proposals, hiring |
| 4 | **Contests** | `Trophy` | `/contest-feed` | Competition hub — open contests, entries, prize board |
| 5 | **Market** | `ShoppingBag` | `/products` | Product + Service marketplace — buy digital goods, book services |
| 6 | **Dashboard** | `LayoutDashboard` | `/dashboard/creator` or `/dashboard/buyer` | Personal HQ — analytics, earnings, active work, orders |

**Six is the limit.** Any further feature (Wallet, Orders, Messages, Settings, Profile) belongs in Layer 3 or is accessible as a sub-page of one of these six hubs. The only exception is Messages, which is in both Layer 1 (top bar badge) and Layer 3 (hub page accessible via the top bar icon).

### 3.2 Why these six and not others

| Feature considered | Decision | Reason |
|---|---|---|
| Messages | **Top bar only** (not feature row) | It's a utility/communication layer, not a content destination. Real-time badge in top bar is more important than a nav slot. |
| Wallet | **Layer 3 (Menu)** | Financial tools are accessed intentionally, not constantly. Putting Wallet in the feature row would imply it needs to be checked constantly — wrong mental model. |
| Profile | **Top bar (Avatar)** | Profile is reached via your avatar — exactly where users expect it. A "Profile" nav tab would feel like an afterthought. |
| Notifications | **Top bar only** | Same as Messages — utility, not destination. |
| Search | **Top bar only** | Cross-cutting utility that works across all hubs; doesn't need its own nav tab. |
| Orders | **Dashboard sub-page** | Order tracking lives inside the Dashboard's "Active Work" section. Not a top-level destination. |
| Settings | **Layer 3 (Menu)** | Never a top-level tab anywhere. Users visit Settings infrequently and expect it in a hamburger/menu. |

### 3.3 Label and icon choices — rationale

**"Market" instead of "Shop" or "Store":** NeuralMart sells both products (one-time purchases) and services (ongoing engagements). "Shop" implies retail. "Store" implies a single seller's storefront. "Market" implies a many-seller platform with diverse goods — accurate to what the hub contains.

**"Contests" instead of "Competition" or "Briefs":** "Contests" is the user-facing language used throughout the platform (the `contests` table, the "Host a Contest" CTA, the contest feed). Consistency matters more than cleverness.

**"Explore" instead of "Discover" or "Search":** Explore is the standard term for human-curated, browse-first discovery (see Instagram, Twitter/X, TikTok). "Discover" implies algorithmic. "Search" implies query-first. NeuralMart's Explore hub is primarily browse/filter — "Explore" is correct.

**"Dash" (mobile label) not "Dashboard":** At 9px label size, "Dashboard" has too many characters and gets cramped at 390px with six items. "Dash" reads cleanly. Full "Dashboard" is used in the desktop sidebar where space allows.

### 3.4 Active state and interaction

```
Active item:  icon → primary color   label → primary color   no background pill
Inactive:     icon → muted           label → muted
Hover (desktop): icon + label → foreground color, subtle bg-primary/5
```

No background pill on the bottom bar at mobile — the items are too close together for pills to avoid looking cluttered. Color alone is sufficient for active state at this scale.

Tapping an already-active nav item **scrolls to top** of that hub (like tapping the status bar on iOS). This is especially useful on the Home feed after a long scroll session.

---

## 4. The Six Feature Hubs — Full Specification

### Hub 1: Home (`/`)
**Purpose:** Universal creative showcase. The platform's heartbeat.  
**Users:** All roles see this. Buyers discover talent. Creators broadcast work. Both do both.  
**Content:** Chronological + lightly boosted feed of creator posts, products, services, and open project briefs.  
**Primary action for Buyers:** Post a Project (composer CTA).  
**Primary action for Creators:** Share work (composer CTA).  
**Navigation placement:** Feature row position 1, always selected on first app open.  
**Hub pages reachable from here:** Every feed card deep-links to its source hub (product → Market, project → Projects, creator post → creator profile).

---

### Hub 2: Explore (`/explore`)
**Purpose:** Intentional discovery — find creators by category, browse featured work, search the talent pool.  
**Users:** Primarily Buyers finding talent. Also Creators scouting the landscape and finding collaborators.  
**Content:**
- Creator category grid (Branding, Motion, UI/UX, Photography, Writing, etc.)
- Featured creator spotlights (curated or ranked by platform activity)
- Trending products/services
- Search bar (replicated from top bar for discoverability)

**Primary action for Buyers:** Tap a creator → view storefront → book or buy.  
**Primary action for Creators:** Browse categories → understand the competitive landscape.  
**Navigation placement:** Feature row position 2.  
**Sub-pages:**
- `/explore` — category grid landing
- `/creators` — full creator directory with filters (category, rating, price range)
- `/creators/:id` — individual creator profile/storefront

---

### Hub 3: Projects (`/projects`)
**Purpose:** Freelance marketplace. Buyers post briefs. Creators submit proposals.  
**Users:**
- Buyers: post new projects, view incoming proposals, manage active engagements.
- Creators: browse open projects, filter by category/budget, submit proposals.
- Both: can do everything above.

**Content (Buyer view):** "My Projects" list (draft, open, in-progress, completed) + "Post a Project" CTA at top.  
**Content (Creator view):** Open project feed, filterable by category and budget, sorted by recency.  
**Content (unified):** A toggle or tabs at the top of the page: "Browse Open Projects" | "My Projects." Default changes by role (Creators see Browse first; Buyers see My Projects first).  
**Primary CTA for Buyers:** "Post a Project →" (navigates to `/projects/new`).  
**Primary CTA for Creators:** "Send Proposal" on individual project cards.  
**Navigation placement:** Feature row position 3.  
**Sub-pages:**
- `/projects` — hub landing (role-aware default tab)
- `/projects/new` — project creation wizard (Buyer + Both only)
- `/projects/:id` — project detail + proposal submission form

---

### Hub 4: Contests (`/contest-feed`)
**Purpose:** Competition hub. Buyers post contests with prizes. Creators submit entries. Winners are selected and paid.  
**Users:**
- Buyers: create contests, review submissions, select winners.
- Creators: browse live contests, submit entries, track their submissions.
- Both: full access to both sides.

**Content:** Active contest list sorted by prize size + deadline urgency. Each card shows: title, category, prize amount, deadline, submission count.  
**Above-the-fold:** Buyer composer card ("Host a Contest → ") at the top for Buyers/Both.  
**Visual identity:** Amber/gold accent throughout — Trophy icon, amber borders on contest cards, prize amounts in amber. This creates a distinct visual zone that feels different from the blue-primary main app — signals "this is high-stakes, time-limited."  
**Primary CTA for Buyers:** "Host a Contest →" (navigates to `/contests/new`).  
**Primary CTA for Creators:** "Submit Entry" on individual contest cards (redirects to `/contests/:id`).  
**Navigation placement:** Feature row position 4. Also accessible via Trophy icon in the top app bar on mobile (maintains the "header toggle" behavior from Feed v2 spec).  
**Sub-pages:**
- `/contest-feed` — hub landing, contest list
- `/contests/new` — contest creation wizard (Buyer + Both only)
- `/contests/:id` — contest detail + entry submission form

**Interaction note:** The Trophy icon in the top app bar navigates to `/contest-feed` (the same route as the feature row item). The two entry points are not separate modes — they go to the same page. The Trophy icon in the top bar exists because the top bar is visible at all times (including when the user is deep inside a hub page, far from the bottom nav). It's a redundant shortcut, not a separate concept.

---

### Hub 5: Market (`/products`)
**Purpose:** Digital product and service marketplace. Buy-now goods and bookable creator services in one place.  
**Users:** Buyers purchase. Creators sell. Both can browse and buy from each other.  
**Content:**
- Top section: Featured products (new releases + top sellers)
- Filter/category row: All · Digital Assets · Templates · Photography · Writing · UI Kits · Music
- Product grid (3-column on mobile when compact, 2-column when card-style)
- Services section below (or as a tab): bookable creator services

**Tabs at hub level:** "Products" | "Services" — clean tab switch, same page.  
**Primary CTA for Buyers:** Tap a product → product detail → Buy Now.  
**Primary CTA for Creators:** "List a Product" or "List a Service" button in their own hub view, or via the home composer chips.  
**Navigation placement:** Feature row position 5.  
**Sub-pages:**
- `/products` — product marketplace grid
- `/products/:id` — product detail + purchase
- `/products/new` — list a new product (Creator + Both only)
- `/services` — service marketplace list
- `/services/:id` — service detail + booking
- `/services/new` — list a new service (Creator + Both only)

**Why Products and Services share one nav slot ("Market"):**  
Both are purchase-intent surfaces. Splitting them into two nav slots (e.g., "Products" and "Services") would use 2 of 6 feature row slots for what is functionally one destination: "things you can buy." The tab switch within the Market hub handles the distinction cleanly.

---

### Hub 6: Dashboard (`/dashboard/creator` or `/dashboard/buyer`)
**Purpose:** Personal HQ. Analytics, earnings, active work, order tracking, and portfolio management in one place.  
**Users:** This hub's content changes significantly by role. It is the most role-differentiated hub in the app.

**Creator Dashboard (`/dashboard/creator`):**
- Earnings summary (this month, all time, pending payout)
- Active proposals (in-review, shortlisted, accepted)
- Active orders (in-progress, pending review)
- Your listings quick-view (top 3 products, top 3 services, with edit links)
- Contest submissions tracker
- Profile completion checklist (if < 100%)
- Followers + following counts with trend

**Buyer Dashboard (`/dashboard/buyer`):**
- Active projects (open for proposals, in-progress, review stage)
- Active orders (ordered services, delivered, pending approval)
- Hosted contests (open, judging, closed)
- Spend summary (this month, all time)
- Saved creators shortlist

**Both Dashboard:** Shows both panels, Creator first. A compact toggle ("Creator view / Buyer view") changes which panel is expanded by default — but both remain accessible without switching.

**Navigation placement:** Feature row position 6. Route is role-aware: `/dashboard/creator` for creator/both; `/dashboard/buyer` for buyer-only.

---

## 5. Layer 3 — Menu Hub (`/menu`)

The Menu is the catch-all for everything that doesn't belong in Layers 1 or 2. It is accessed via the Avatar in the mobile top bar or a "Menu" item in the sidebar on desktop.

Wait — **correction to current architecture:** In the existing build, `Menu` is position 5 of the bottom nav. With the updated six-item feature row (Home · Explore · Projects · Contests · Market · Dashboard), the `Menu` nav slot is **replaced by Dashboard**. Menu is then accessed via the **Avatar in the top bar** on mobile, and as a section at the bottom of the desktop sidebar.

### Menu page contents (`/menu`)

```
┌───────────────────────────────────────────┐
│  [Avatar]  Alex Carter                    │
│            Creator · Buyer · ⭐ Verified   │
│  [Edit Profile]                           │
├───────────────────────────────────────────┤
│  ACCOUNT                                  │
│  👤  Profile & Portfolio      →           │
│  🎨  Creator Settings         →           │
│  🔔  Notification Preferences →           │
├───────────────────────────────────────────┤
│  FINANCIAL                                │
│  💰  Wallet & Earnings        →           │
│  📦  My Orders                →           │
│  🧾  Transaction History      →           │
├───────────────────────────────────────────┤
│  PLATFORM                                 │
│  🛡  Trust & Safety           →           │
│  ❓  Help & Support           →           │
│  📣  Invite Friends           →           │
├───────────────────────────────────────────┤
│  [Log Out]                                │
└───────────────────────────────────────────┘
```

**Menu is never a hub.** It's a list of entry points. Nothing important happens on the Menu page itself — it's a directory. Real functionality lives one tap deeper (the Wallet page, the Orders page, etc.).

**Wallet summary widget:** The Menu page shows a compact wallet balance card at the top of the Financial section — balance + pending + quick "Add Funds" and "Withdraw" buttons. This is a summary, not the full Wallet hub. The full Wallet hub (`/wallet`) is a separate page, accessed by tapping the wallet card.

---

## 6. Where Everything Lives — Master Placement Table

| Feature | Layer 1 (Top Bar) | Layer 2 (Feature Row) | Layer 3 (Menu) | Hub sub-page |
|---|:---:|:---:|:---:|:---:|
| Home Feed | — | ✅ (pos 1) | — | — |
| Explore / Creators | — | ✅ (pos 2) | — | `/explore`, `/creators` |
| Search | ✅ (icon) | — | — | Search overlay |
| Notifications | ✅ (icon + badge) | — | — | Tray slide-in |
| Messages | ✅ (icon + badge) | — | — | `/messages` |
| Projects Hub | — | ✅ (pos 3) | — | `/projects`, `/projects/new`, `/projects/:id` |
| Contests Hub | ✅ (Trophy icon) | ✅ (pos 4) | — | `/contest-feed`, `/contests/new`, `/contests/:id` |
| Market (Products + Services) | — | ✅ (pos 5) | — | `/products`, `/services` |
| Dashboard | — | ✅ (pos 6) | — | `/dashboard/creator`, `/dashboard/buyer` |
| Profile / Storefront | ✅ (Avatar) | — | ✅ (link) | `/creators/:id` |
| Wallet | — | — | ✅ (summary widget + link) | `/wallet` |
| Orders | — | — | ✅ (link) | `/orders` |
| Transaction History | — | — | ✅ (link) | `/wallet/history` |
| Settings | — | — | ✅ (link) | `/settings` |
| Help & Support | — | — | ✅ (link) | `/help` |
| Become a Creator | — | — | ✅ (contextual) | `/settings/creator-upgrade` |
| Admin tools | — | — | ✅ (admin only) | `/admin` |
| Logout | — | — | ✅ (bottom) | — |

---

## 7. Search — Architecture

Search is accessed from the magnifier icon in the top bar. It opens a full-screen overlay (not a page navigation — overlay, so the back button dismisses it).

### Search overlay structure:
```
┌───────────────────────────────────────────┐
│  [← back]  [        Search NeuralMart   ] │  ← search input, auto-focused
├───────────────────────────────────────────┤
│  Recent searches                          │  ← shows on empty input
│  • Maya Johnson                           │
│  • "Figma UI kit"                         │
├───────────────────────────────────────────┤
│  RESULTS (after typing)                   │
│  Creators                                 │
│    [Av] Maya Johnson · UI/UX · ⭐4.9      │
│  Products                                 │
│    🛍 Mobile UI Kit — $49                 │
│  Services                                 │
│    ⚙ Brand Identity Package — from $300  │
│  Projects                                 │
│    💼 "Need a motion designer" · $1,200  │
│  Contests                                 │
│    🏆 Logo Design Challenge · $500 prize │
└───────────────────────────────────────────┘
```

**One search box, five result categories.** Categories appear as sections only when they have results. Empty categories are omitted entirely (no "No creators found" sections — only sections with hits).

**Search scope:** Global by default. Scoped search (search only within Products, or only within Creators) is accessible via a filter row that appears below the search input after the first keystroke.

---

## 8. Notifications — Architecture

Accessed from the Bell icon. Slides in as a sheet from the right on mobile; appears as a dropdown panel on desktop.

### Notification categories and priority:

| Category | Icon | Example | Visual priority |
|---|---|---|---|
| **Transaction** | 💰 | "Your order was paid — $250 arrived in your wallet" | High — green accent |
| **New Proposal** | 📨 | "Maya submitted a proposal on your project" | High — primary accent |
| **Contest Winner** | 🏆 | "You won the Logo Design contest! $500 awarded." | Highest — amber, bold |
| **New Order** | 📦 | "Alex purchased your Figma UI Kit" | High — primary |
| **New Follow** | 👤 | "Jordan Chen started following you" | Medium — neutral |
| **New Like / Comment** | ♡ | "3 people liked your post" | Low — muted, batched |
| **Platform** | ⬡ | "NeuralMart: New contest in your category" | Low — muted |

**Rules:**
- Transactional notifications (money movement, proposals, orders) are **never batched.** Each gets its own row.
- Social signals (likes, follows, comments) **are batched.** "5 people liked your post from yesterday" — one row, not five.
- Platform notifications are shown at most once per day, collapsed at the bottom of the tray.
- Notification tray shows the last 50 items. "View all notifications" link opens `/notifications` (full history page).

---

## 9. How to Avoid Overcrowding the First Screen

This is the most important constraint. Six feature row items + four top bar utility icons + a full-height page is the maximum surface area. Here are the rules enforced to prevent first-screen clutter:

### Rule 1: The 3-7-∞ depth model
- **3 taps or fewer:** Any primary feature. Home, Explore, Projects, Contests, Market, Dashboard all in 1 tap. Sub-pages in 2 taps. Composer actions in 2 taps.
- **7 taps or fewer:** Any secondary feature. Wallet (Menu → Wallet), Transaction History (Menu → Wallet → History), Profile editing.
- **∞ (as deep as needed):** Configuration, admin tools, legal pages — no depth limit because users visit these rarely and intentionally.

### Rule 2: The feature row has a hard cap of 6 items
If a new feature request ever needs its own nav slot, it must displace an existing item or absorb into an existing hub. The answer to "can we add a [new feature] to the nav?" is always: "yes, if it replaces something else, or no if it's a sub-feature of something that already has a hub."

### Rule 3: Composer chips are capped at 3
The composer card on the home feed is the only place where "create something" shortcuts live on the home screen. Maximum three chips (Post, Product, Service for Creators). If a new creation type is added (e.g., "Course"), one existing chip must become a "More →" overflow that opens a full creation menu.

### Rule 4: Badges only on real-time status
Notification badges (red/blue dots) appear only on the Bell and Messages icons. Never on feature row items (no "You have 3 open proposals" badge on the Projects tab). Badges create urgency; feature tabs are destinations, not inboxes.

### Rule 5: The Feature Gateway row is conditional
The horizontal pill shortcuts (Projects · Contests · Products · etc.) on the home screen are only shown to new users. Once a user has any activity, the row hides permanently. This prevents the home screen from having both a nav bar and a second row of shortcuts pointing to the same places.

### Rule 6: Dashboard is personal, not home
Dashboard is Tab 6 in the feature row — not the default landing page. Home (the feed) is always the default. If a user needs to check their earnings, they tap Dashboard. The app never defaults to a dashboard/metrics view on first open. Social feed first, always.

### Rule 7: No banners or announcements on the home screen
Platform announcements ("New feature: Courses!"), promotional banners ("Creator Pro is live!"), and onboarding checklists do not appear on the home screen. They appear as notification tray entries (high priority) or as a single dismissible card in the Dashboard. Never in the feed, never inline with the composer.

---

## 10. Interaction Notes — Behavior Spec

### Tapping the active nav item
If the user is already on Home and taps Home: scroll to the top of the feed AND refresh the feed (pull-to-refresh equivalent without the gesture). This is the same behavior as Instagram and TikTok's home icon.

Same behavior on all feature row items: tap active item → scroll to top + refresh.

### Tab persistence (scroll position)
When a user navigates away from Projects (mid-scroll) and then taps Projects again, they return to the **top of Projects**, not their previous scroll position. Reason: feature hubs are discovery surfaces, not documents. Returning to the top reorients the user. (Exception: Messages — return to previous scroll position because users may be mid-conversation list.)

### Bottom sheet for mobile creation flows
On mobile, tapping "Share your work…" in the composer does NOT navigate to a full new page. It opens a **bottom sheet** (slides up from the bottom, 90% height) containing the post composer form. The feed is still visible behind the dimmed overlay.

On desktop, the same action opens a **modal dialog** centered in the viewport.

Why: Navigation away from the home feed to create a post, then navigating back, causes a double full-page transition. A sheet/modal keeps the user contextually in the feed — they post and return to exactly where they were.

Exception: `/products/new` and `/services/new` are multi-step wizards too long for a sheet. They navigate to a full page.

### Feature hub entry animation
Every hub page enters with `fade-in + slide-in-from-bottom-4` at 500ms. This is already in the design system. No per-hub custom animations — consistency over novelty.

### Dashboard route resolution
The feature row "Dashboard" item routes to:
- `/dashboard/creator` if `user.role === 'creator' || user.role === 'both'`
- `/dashboard/buyer` if `user.role === 'buyer'`
- `/dashboard/admin` if `user.role === 'admin'`

For `both` users, the Dashboard defaults to the Creator view and has a tab/toggle to switch to Buyer view. The URL changes to `/dashboard/buyer` when they switch — deep-linkable.

### Contests: Two entry points, one destination
The Trophy icon in the top bar and the "Contests" item in the feature row both go to `/contest-feed`. No confusion — same route, same page. The Trophy icon is a redundant shortcut that's visible even when the bottom nav is obscured (e.g., when viewing a product detail with a full-screen image).

### Messages: Two entry points, one destination
The Messages icon in the top bar and a sidebar link on desktop both go to `/messages`. The top bar icon has a blue unread badge. The desktop sidebar link also shows an unread count badge inline.

---

## 11. Navigation Architecture — Final Summary Card

```
NEURALMART NAVIGATION SYSTEM
─────────────────────────────────────────────────────────
TOP BAR (mobile) / SIDEBAR HEADER (desktop):
  [Logo]  ·  [Search 🔍]  ·  [Notifications 🔔]  ·  [Messages 💬]  ·  [Avatar]

FEATURE ROW (mobile bottom) / SIDEBAR ITEMS (desktop):
  1. Home          → /                    Universal showcase feed
  2. Explore       → /explore             Creator & content discovery
  3. Projects      → /projects            Freelance marketplace
  4. Contests      → /contest-feed        Competition hub (also: top bar Trophy)
  5. Market        → /products            Products + Services marketplace
  6. Dashboard     → /dashboard/:role     Personal analytics & work HQ

MENU (Avatar tap → /menu):
  Wallet & Earnings  ·  Orders  ·  Transaction History
  Profile & Portfolio  ·  Creator Settings  ·  Notification Prefs
  Trust & Safety  ·  Help & Support  ·  Invite Friends  ·  Log Out

RULES:
  • 6 feature row items — hard cap, no exceptions
  • 4 top bar utility icons — hard cap
  • Badges only on Bell and Messages (real-time status, not nav items)
  • Feature Gateway pills (home screen) only for new users — hide after first activity
  • Dashboard is tab 6, never the default landing page
  • Every hub is 1 tap from anywhere
  • Every secondary tool is 2 taps (Menu → page)
  • Config / legal / admin is 3+ taps — no depth limit
─────────────────────────────────────────────────────────
```

---

*End of document. Companion docs: `neuralmart-home-page-architecture.md` · `neuralmart-ux-design-system.md` · `neuralmart-role-permissions-model.md` · `neuralmart-page-map.md`*
