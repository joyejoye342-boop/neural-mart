# NeuralMart — Order & Marketplace Lifecycle Architecture
## Part 4 of 5: User-Facing Order Management

**Document version:** 1.0  
**Depends on:** Parts 1, 2, and 3  
**Scope:** Buyer Order Center, Creator Order Center, universal order detail, timelines, notifications, reviews, and chat integration

---

## 0. Experience Principles

The Order experience should answer:

1. What did I buy or sell?
2. What is happening now?
3. What needs my action?
4. What happens next?
5. Where are the files, payment, conversation, and support options?

The system uses:

```text
One universal Order detail shell
→ Role-aware actions
→ Type-specific sections
→ Shared timeline, delivery, payment, review, and support components
```

The Order Center is not a second dashboard. It is the operational workspace for transactions.

### Important distinctions

- Buyer and creator see the same order state from different responsibility perspectives.
- Chat is linked to the order but does not replace it.
- Wallet/financial records remain the source of truth for money.
- Delivery/entitlement records remain the source of truth for file access.
- Ownership records remain the source of truth for exclusive ownership.
- Status filters are views over the universal order model, not new order systems.

---

## 1. Buyer Order Center

### 1.1 Purpose

The Buyer Order Center is where buyers manage purchases, creator work, deliveries, access, approvals, refunds, reviews, and disputes.

Primary route:

```text
/orders
```

Menu and Buyer Dashboard links:

- Orders
- Purchases
- Active work
- Downloads
- Refunds/disputes

### 1.2 Buyer sections

```text
All Orders
Active
Awaiting Delivery
Delivered
Completed
Cancelled
Refunded
Disputed
```

These are user-facing views that combine primary order status with delivery, refund, and dispute dimensions.

### 1.3 Section meanings

#### All Orders

Every order the buyer can access, sorted by recent activity by default.

#### Active

Orders requiring ongoing fulfillment or buyer participation:

- service work;
- project contracts;
- custom chat orders;
- active milestones;
- contest prize transactions;
- paid deliveries still in review.

#### Awaiting Delivery

Paid orders where the buyer is waiting for:

- creator acceptance;
- work to start;
- service delivery;
- project milestone;
- contest winner delivery;
- paid file unlock;
- replacement delivery.

#### Delivered

Orders with a submitted delivery that still require:

- review;
- approval;
- revision decision;
- download/access;
- completion confirmation.

#### Completed

Orders whose primary lifecycle is complete, including:

- instant digital product purchases;
- approved services;
- completed projects;
- completed file deliveries;
- completed contest prize orders.

#### Cancelled

Orders cancelled before completion. Refund state is shown separately.

#### Refunded

Orders with full or partial refund activity. The order remains visible for receipts, access history, and support.

#### Disputed

Orders with an open or recently resolved dispute. A dispute badge remains visible until the case is closed and any resulting refund/access changes are complete.

### 1.4 Buyer order cards

Every card uses the shared order shell:

```text
[type label] Brand Identity Package
[creator avatar] Maya Johnson · Creator
In Progress · Due Apr 18
$1,200 · Order NM-10482
Next: Send brand references
[Open order]
```

### 1.5 Card contents

Universal:

- Order type label
- Item/project/service title
- Creator identity
- Thumbnail or type icon
- Primary status
- Next action
- Price/total
- Order number
- Last activity
- Unread chat indicator
- Dispute/refund indicator, if relevant

Type-specific:

| Order type | Card-specific content |
|---|---|
| Digital product | Version, download state, license |
| Exclusive project | Sold/owned state, access status |
| Service | Package, due date, revisions left |
| Project contract | Milestone, due date, scope |
| Custom chat | Offer/order title, next delivery |
| Contest prize | Contest name, winner/delivery state |
| Paid file delivery | Preview/unlock/download state |

### 1.6 Buyer quick actions

Actions depend on order state:

- Open order
- Download/open files
- View license
- Send requirements
- Approve delivery
- Request revision
- Message creator
- View receipt
- Request refund
- Open dispute
- Cancel, when eligible
- Leave review
- Buy again/reorder

Do not show every action on every card. Use one primary action and a compact overflow menu.

### 1.7 Buyer filters

Filters:

- Order type
- Creator
- Date range
- Price range
- Payment status
- Delivery status
- Revision state
- Refund state
- Dispute state
- Ownership/access state
- Has unread activity
- Needs my action

Quick filter chips:

```text
Needs action · Due soon · Downloads · Reviews to write
```

### 1.8 Buyer search

Search matches:

- Order number
- Product/service/project title
- Creator name
- Contest name
- Delivery filename
- Conversation title
- License or purchase label

Search results remain scoped to the authenticated buyer's orders.

### 1.9 Buyer sorting

Default:

```text
Needs action
→ Recent activity
→ Nearest deadline
```

Optional:

- Newest purchase
- Oldest purchase
- Highest value
- Recently delivered
- Recently completed

Avoid sorting only by creation date when an active delivery or approval needs attention.

### 1.10 Buyer detail preview

Desktop can use a selected-order side panel for quick inspection. Full actions open the universal detail route.

Mobile opens the full order detail page rather than a narrow nested drawer.

### 1.11 Buyer empty states

#### No orders

```text
Your purchases and creator work will appear here.
[Explore products] [Browse services] [Find creators]
```

#### No active orders

```text
Nothing needs your attention right now.
```

#### No completed orders

```text
Completed purchases will stay here with their receipts and access history.
```

---

## 2. Creator/Freelancer Order Center

### 2.1 Purpose

The Creator Order Center is the operational workspace for accepting work, meeting deadlines, delivering files, responding to revisions, tracking payouts, and protecting scope.

Primary route:

```text
/dashboard/creator/orders
```

For Both users, the same order center supports the user's selling context without creating a second account.

### 2.2 Creator sections

```text
New Orders
Active Orders
Awaiting Buyer
Delivery Due
Revision Requests
Completed
Cancelled
Disputed
```

### 2.3 Section meanings

#### New Orders

Orders needing creator action before or at the start of fulfillment:

- new service order;
- accepted project contract;
- custom chat order;
- new paid file delivery;
- contest winner order;
- order awaiting creator acceptance.

#### Active Orders

Work currently in progress, including active milestones.

#### Awaiting Buyer

Orders blocked on:

- requirements;
- clarification;
- buyer approval;
- revision selection;
- milestone confirmation;
- payment/offer acceptance.

#### Delivery Due

Orders with:

- upcoming deadline;
- overdue delivery;
- milestone due;
- expiring delivery window.

Sort urgent delivery first.

#### Revision Requests

Orders where the buyer has requested an in-scope revision or reported an incomplete delivery.

#### Completed

Orders with closed fulfillment and available earnings/review state.

#### Cancelled

Orders cancelled before completion, with cancellation and refund outcomes visible.

#### Disputed

Orders with an open or recently resolved dispute, including required evidence or support action.

### 2.4 Creator order cards

```text
[Needs action] Brand Identity Package
[buyer avatar] Alex Rivera · Buyer
Revision requested · 1 round remaining
Due tomorrow · $1,200 pending
Next: Open revision request
[Open order]
```

### 2.5 Creator card contents

Universal:

- Order type
- Buyer identity
- Title
- Primary status
- Next action
- Deadline
- Earnings state
- Order value
- Last activity
- Unread chat count

Type-specific:

| Order type | Creator card-specific content |
|---|---|
| Digital product | Sales, version, access/download signal |
| Exclusive project | Sold timestamp, ownership delivery state |
| Service | Package, requirements, revisions, due date |
| Project contract | Milestone and remaining contract value |
| Custom chat | Offer/order state, next commitment |
| Contest prize | Winner confirmation, prize/payout state |
| Paid file delivery | Locked/unlocked, download/access state |

### 2.6 Creator quick actions

- Accept order
- Request requirements
- Open order
- Open chat
- Start work
- Update milestone
- Send preview
- Send delivery
- Request extension
- Respond to revision
- Send add-on/custom offer
- View payment/earnings
- Cancel/request support
- Respond to review

The primary action is always the next required operational step.

### 2.7 Useful business metrics

The Order Center may show a compact summary bar:

```text
Needs action: 3
Due this week: 2
Pending earnings: $640
On-time active orders: 94%
```

These are operational metrics, not a full analytics dashboard.

Rules:

- Maximum four summary values.
- Link each value to the filtered order list.
- Use meaningful periods and sample-size caveats.
- Do not show private buyer identities in aggregate charts.
- Keep revenue detail in Earnings.
- Keep proposal performance in Bid Insights.

### 2.8 Creator sorting

Default:

```text
Blocked/needs action
→ Overdue
→ Due soon
→ Awaiting buyer
→ Recent activity
```

Optional:

- Highest value
- Newest order
- Oldest order
- Buyer name
- Package/type

### 2.9 Creator capacity behavior

When active orders approach creator capacity:

- show workload count;
- show upcoming due dates;
- link to availability settings;
- allow pause/out-of-capacity action;
- preserve current active orders.

Pausing a listing does not cancel existing orders.

---

## 3. Universal Order Detail Page

### 3.1 Purpose

The universal Order Detail page is the authoritative user-facing workspace for one transaction.

Primary route:

```text
/orders/:orderId
```

The same route adapts to:

- buyer;
- seller/creator;
- Both role context;
- admin/support context.

### 3.2 Page structure

```text
Order header
→ Needs-action banner
→ Order summary
→ Parties and context
→ Scope/product/service details
→ Delivery and files
→ Revisions
→ Timeline
→ Chat
→ Financial information
→ Review
→ Help/refund/dispute
```

### 3.3 Order header

Show:

- Order type
- Human-readable order number
- Current primary status
- Secondary state chips
- Created date
- Last updated date
- Primary next action

Example:

```text
Service Order · NM-10482
Revision requested · Due tomorrow
[Review request]
```

Secondary chips may include:

- Payment confirmed
- Awaiting buyer
- 1 revision left
- Files unlocked
- Sold/Locked
- Refund under review
- Dispute open

### 3.4 Needs-action banner

The banner answers:

```text
What do I need to do next?
Why does it matter?
When is it due?
```

Examples:

```text
Buyer action needed: Submit brand references
Due before work can start
[Send requirements]
```

```text
Creator action needed: Respond to revision request
1 revision round remains
[Open request]
```

No banner appears when the order is complete and has no pending action.

### 3.5 Order summary

Universal:

- Item/title
- Order type
- Buyer/seller
- Price and currency
- Payment status
- Primary status
- Creation date
- Receipt

Type-specific:

- Product version/license
- Service package
- Project contract scope
- Contest prize/entry
- Chat offer
- Paid delivery items

### 3.6 Buyer and seller panel

Buyer sees:

- creator display name;
- profile link;
- trust signals;
- response/availability;
- open chat;
- report/support action.

Creator sees:

- buyer display name;
- buyer relationship/history signals that are allowed;
- open chat;
- project/order context;
- report/support action.

Private analytics, exact earnings, sensitive dispute rates, and unrelated buyer history remain hidden.

### 3.7 Commercial terms

Show the immutable purchased snapshot:

- Subtotal
- Discounts
- Taxes/fees
- Total
- Platform fee treatment where appropriate
- Payment status
- License/rights
- Scope/deliverables
- Deadline
- Revision terms
- Cancellation/refund terms

Creator sees:

- gross amount;
- platform fee;
- pending/eligible earnings;
- payout state.

Buyer sees:

- buyer total;
- payment method label;
- receipt;
- refund status.

### 3.8 Delivery and files

Universal delivery section:

- delivery status;
- delivery versions;
- previews;
- files/items;
- access state;
- download/open action;
- delivery note;
- timestamps.

Buyer actions:

- Preview
- Download/open
- Approve
- Request revision
- Report missing/corrupt file

Creator actions:

- Send delivery
- Replace file
- Add version
- Send preview
- View access history where permitted

For locked paywalled deliveries:

```text
Preview available
Original files locked
[Pay and unlock]
```

After payment:

```text
Files unlocked
[Download] [Open order]
```

### 3.9 Revisions

Show only when applicable:

- included rounds;
- used rounds;
- remaining rounds;
- active request;
- request reason;
- response;
- revision history;
- next deadline.

For digital products with no revision system, replace this section with:

```text
Product updates and corrections
```

### 3.10 Timeline

The timeline is always present, even when collapsed on mobile.

It shows the order's material state changes and next step.

### 3.11 Chat

Show:

- linked conversation preview;
- last relevant message;
- unread count;
- `Open chat`;
- contextual composer actions;
- delivery/offer messages;
- order system events.

Chat is embedded as a workspace section or opened as a dedicated route on mobile.

### 3.12 Financial information

Buyer:

- total paid;
- payment status;
- receipt;
- refund status;
- transaction date.

Creator:

- gross sale;
- platform fee;
- pending/eligible earnings;
- payout state;
- wallet/earnings link.

Neither party sees the other's confidential financial details beyond the necessary commercial terms.

### 3.13 Review section

Before eligibility:

```text
Review becomes available after this order is completed.
```

After eligibility:

```text
Share your experience
[Leave review]
```

After review:

- show submitted rating/review;
- allow edit within review window;
- show creator response, if available.

### 3.14 Help, refund, and dispute

Contextual actions:

- Get help with download
- Ask about license
- Request revision
- Request refund
- Cancel order
- Open dispute
- Report safety issue
- Contact support

Actions are gated by order state and policy. Do not show a refund CTA after the eligibility window without explaining the support route.

### 3.15 Type-specific page changes

| Type | Extra sections/actions |
|---|---|
| Digital product | License, version updates, download, verified purchase |
| Exclusive project | Ownership transfer, Sold/Locked, source-file access |
| Service | Requirements, package, revisions, delivery deadline |
| Project contract | Scope, milestones, proposal snapshot, change requests |
| Custom chat | Accepted offer, conversation context, custom scope |
| Contest prize | Winning entry, prize hold, rights, winner delivery |
| Paid file delivery | Preview lock, entitlement, download/access history |

---

## 4. Order Timeline

### 4.1 Timeline purpose

Every order has a transparent, chronological activity timeline.

The timeline should make it possible to answer:

- When was the order created?
- When was payment confirmed?
- Who needs to act?
- What was delivered?
- Which version was approved?
- What happened to the money?
- Was there a refund or dispute?

### 4.2 Core events

Supported events include:

- Order Created
- Payment Confirmed
- Seller Accepted
- Work Started
- Requirements Requested
- Requirements Received
- Milestone Funded
- File Delivered
- Preview Sent
- File Unlocked
- Revision Requested
- Revision Delivered
- Buyer Approved
- Order Completed
- Refund Requested
- Refund Approved/Declined
- Dispute Opened
- Dispute Resolved
- Order Cancelled
- Order Expired
- Payout Released
- Access Revoked
- Ownership Transferred

### 4.3 Event anatomy

Each visible event includes:

- event label;
- timestamp;
- actor or system;
- concise description;
- linked file/version/order action;
- current consequence;
- optional `View details`.

Example:

```text
Apr 18 · Maya Johnson
Delivered v1.1
Added corrected export and source file
[View delivery]
```

### 4.4 Buyer/seller visibility

Buyer and seller can see:

- order creation;
- payment confirmation;
- acceptance;
- work start;
- requirements;
- delivery;
- revisions;
- approval;
- completion;
- refund/dispute state;
- ownership/access events relevant to them.

### 4.5 Public visibility

Ordinary orders are not public.

Public surfaces may show only aggregate or opt-in evidence:

- completed order count;
- verified review;
- contest winner;
- Sold/Locked project;
- product sales count;
- service completion/reputation signal.

Public users cannot see:

- buyer identity;
- private scope;
- price unless intentionally public;
- payment method;
- private messages;
- revision arguments;
- dispute evidence;
- refund reasons.

### 4.6 Admin/platform visibility

Authorized internal users can see:

- full payment references;
- ledger entries;
- risk/fraud events;
- delivery access logs;
- file hashes/scan outcomes;
- private dispute evidence;
- internal notes;
- moderation actions;
- webhook/reconciliation events.

Internal notes are not automatically visible to buyer or seller.

### 4.7 Timeline integrity

Material events are append-only:

- ordinary participants cannot edit or delete them;
- retries do not create duplicate financial events;
- corrected display text does not change the underlying event;
- support can append a resolution event;
- timestamps use a consistent system time and show the user's timezone where useful.

---

## 5. Order Notifications

### 5.1 Notification principles

Notifications should be:

- contextual;
- actionable;
- tied to a specific order;
- deduplicated;
- urgency-aware;
- quiet when no action is required.

Every notification should answer:

```text
What happened?
Which order?
Do I need to act?
By when?
```

### 5.2 Buyer notifications

#### Payment and purchase

- Payment succeeded
- Payment failed
- Order created
- Product/file access ready
- Exclusive project ownership confirmed
- Receipt available

#### Fulfillment

- Seller accepted
- Work started
- Requirements requested
- Milestone ready
- Delivery received
- Replacement delivered
- Revision response received
- Order completed

#### Deadline and attention

- Creator deadline approaching
- Buyer approval due
- Revision window ending
- Offer/order expiring
- Missing requirements

#### Finance and resolution

- Refund requested
- Refund approved/declined
- Dispute opened
- Dispute response needed
- Dispute resolved
- Access revoked or restored

### 5.3 Creator notifications

#### Order intake

- New order
- Payment confirmed
- Service acceptance needed
- Project contract created
- Contest winner order created
- Paid delivery unlocked

#### Fulfillment

- Requirements received
- Buyer clarification
- Delivery viewed/accessed, where useful
- Revision requested
- Buyer approved
- Milestone approved
- Order completed

#### Deadline and risk

- Delivery due soon
- Delivery overdue
- Buyer inactivity is blocking work
- Revision deadline approaching
- Dispute opened

#### Finance and reputation

- Earnings pending
- Earnings released
- Refund request
- Refund decision
- Review received
- Dispute resolved

### 5.4 Delivery channels

Use:

- in-app notification;
- order-center badge;
- push;
- email;
- chat system event.

High-priority actions can use push/email. Low-priority activity stays in-app or in a digest.

### 5.5 Notification grouping

Group related events:

```text
3 new updates on Brand Identity Order
```

Do not send separate notifications for:

- every file in one delivery;
- every system event;
- every preview open;
- every timeline refresh;
- duplicate payment callbacks.

### 5.6 Notification controls

Users can configure:

- push;
- email;
- in-app;
- quiet hours;
- order thread mute;
- creator/buyer context mute;
- deadline reminders;
- marketing/recommendation separation.

Action-required order alerts may bypass a thread mute when needed for payment, safety, deadline, or dispute obligations.

---

## 6. Review and Reputation Integration

### 6.1 Review eligibility

A user can review when:

- the order is completed;
- payment was confirmed;
- the user is a legitimate participant;
- the order was not fully reversed for fraud/invalid purchase;
- the review window is open.

Eligible types:

- digital product;
- exclusive project purchase;
- service;
- project contract;
- custom chat order;
- paid file delivery;
- contest prize order where reviews are enabled.

### 6.2 Review window

The review window begins after:

- product/file access;
- buyer approval;
- auto-completion;
- contest completion;
- dispute resolution that closes as fulfilled.

The platform displays:

```text
Review available until [date]
```

After the window:

- editing closes;
- support may address policy violations;
- the review remains linked to the completed order.

### 6.3 Buyer review

Buyer can submit:

- overall rating;
- written review;
- optional category ratings;
- delivery/quality feedback;
- context tags.

The review records:

- order;
- type;
- purchased item/service;
- verified status;
- completion state;
- review date.

### 6.4 Seller review

Seller review of the buyer is available for interactive fulfillment orders:

- services;
- project contracts;
- custom chat orders;
- contest prize work;
- paid file delivery with custom fulfillment.

Seller review can cover:

- clarity of requirements;
- communication;
- responsiveness;
- approval timeliness;
- respect for scope;
- payment cooperation.

Seller review is not normally needed for an instant digital product purchase.

### 6.5 Mutual review behavior

To reduce retaliation:

- reviews are held until both submit or the review window closes;
- one party cannot edit its review based on seeing a new rating;
- review moderation handles harassment or private information;
- seller review does not expose sensitive buyer identity publicly by default.

### 6.6 Verified purchase indicator

Display:

```text
Verified purchase
```

only when the reviewer is linked to a valid completed order.

For services/projects:

```text
Verified client
```

For contest winners:

```text
Verified contest transaction
```

### 6.7 Effect on creator reputation

Completed order reviews can affect:

- public rating;
- review count;
- service/product-specific trust;
- completed-order count;
- reliability signals;
- repeat-buyer evidence;
- creator reputation dashboard.

Do not allow one transaction to dominate a creator's rating or badge calculation.

Ratings use:

- sample-size caveats;
- time-aware calculations;
- verified order weighting;
- fraud/refund exclusion rules;
- separation of product/service/project contexts where useful.

### 6.8 Effect on badges

Badges can use verified order evidence such as:

- completed orders;
- on-time delivery;
- verified ratings;
- repeat buyers;
- contest wins;
- response reliability.

Refunds, disputes, and cancellations may affect eligibility gradually, except for safety/fraud events that require immediate review.

Badges must not be purchasable or boosted solely by order volume.

### 6.9 Marketplace trust

Public trust signals remain compact:

- verified creator;
- rating/reviews;
- completed orders;
- on-time/reliability label;
- relevant badge.

Private metrics remain private:

- exact earnings;
- dispute rate;
- proposal win rate;
- buyer identity;
- client list;
- refund details.

---

## 7. Chat Integration

### 7.1 Pre-order conversation

Before an order exists, Chat supports:

- questions;
- references;
- product/service sharing;
- project brief discussion;
- proposal clarification;
- custom offer creation.

The conversation may link to a product, service, project, proposal, or contest context without implying a paid order.

### 7.2 Offer

The offer card links:

- scope;
- price;
- deadline;
- revisions;
- usage rights;
- files/previews;
- expiration;
- buyer acceptance;
- payment CTA.

Accepting an offer does not change the order state until payment is confirmed.

### 7.3 Active order

After order creation, the conversation shows a pinned order strip:

```text
Brand Identity · Project Contract
In Progress · Due Apr 18
$1,200 · 1 revision remaining
[Open order]
```

Chat system events mirror material order changes:

- Order created
- Payment confirmed
- Work started
- Requirements received
- Delivery submitted
- Revision requested
- Buyer approved
- Order completed

The order record remains authoritative.

### 7.4 Delivery in chat

Chat can carry:

- preview;
- locked file delivery;
- unlocked files;
- delivery note;
- version link;
- replacement message;
- buyer approval CTA.

The actual access check is performed against the order, delivery, entitlement, and license records.

### 7.5 Revisions in chat

Buyer can initiate a structured revision from the delivery card:

```text
Request revision
→ Choose reason
→ Add grouped changes
→ Submit to order
```

The chat message references the revision record. A plain message saying “please change this” may be conversational context but does not consume or alter revision allowance until structured into the order.

### 7.6 Completion

When the buyer approves:

- order timeline records Buyer Approved;
- chat shows a system event;
- review becomes scheduled/available after completion;
- creator payout moves toward eligibility.

When auto-completion occurs:

- system event appears in Chat;
- the order timeline remains authoritative;
- both users receive the appropriate notification.

### 7.7 Post-order communication

The linked order chat remains available for:

- support;
- license questions;
- replacement files;
- approved follow-on offers;
- repeat orders;
- review reminders;
- dispute communication.

New unrelated work should create a new context-linked offer/order rather than modifying a completed order.

### 7.8 Chat is not transaction truth

Chat cannot independently:

- mark payment as confirmed;
- transfer ownership;
- unlock files;
- complete an order;
- release earnings;
- approve a refund;
- change project scope.

It can request or present those actions through structured controls that call the appropriate order, payment, delivery, wallet, or support workflow.

---

## 8. Mobile-First Behavior

### Buyer mobile

- Full-width order cards
- Horizontal status filters
- Sticky `Needs action` section
- Bottom-sheet filters
- Single-column detail page
- Sticky primary action at the bottom
- Collapsible timeline
- Full-screen delivery preview
- Order/chat switcher

### Creator mobile

- New/urgent work above history
- Due date and next action prominent
- Compact earnings state
- One-tap delivery/revision actions
- Requirements checklist in a bottom sheet
- Timeline and chat accessible without losing order context

### Mobile detail priority

```text
Status
→ Next action
→ Deadline
→ Price/payment
→ Delivery
→ Chat
→ Timeline
→ Full details
```

Do not bury the next action below long descriptions or a full event history.

---

## 9. Order Center Metrics and Performance Boundaries

The Order Center may summarize:

- active order count;
- needs-action count;
- due-soon count;
- pending earnings for creators;
- reviews awaiting completion;
- unresolved disputes.

The Order Center should not become:

- a full revenue analytics dashboard;
- a proposal analytics page;
- a content performance report;
- an accounting ledger;
- an admin support console.

Those remain linked destinations.

## Final rule

The Order Center should make every transaction operationally clear without making the user reconstruct the truth from chat, notifications, wallet history, or marketplace pages: one order page, one timeline, one next action, one protected delivery path, and one auditable financial state.
