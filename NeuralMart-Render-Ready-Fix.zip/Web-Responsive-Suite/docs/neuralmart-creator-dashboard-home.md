# NeuralMart — Creator Dashboard Home

**Document version:** 1.0  
**Route:** `/dashboard/creator`  
**Audience:** Creator and Both accounts

---

## 0. Job of the Dashboard Home

The Creator Dashboard home is the daily starting point for running a creative business. It should answer:

1. What needs my attention today?
2. How is my business performing?
3. What is the most useful next action?

It is not the place for every report, setting, or management table. The home page is a prioritized briefing; deeper pages hold the detail.

> **Attention first. Snapshot second. Improvement third.**

---

## 1. Above-the-Fold Layout

### Desktop

```text
┌────────────────────────────────────────────────────────────────┐
│ Creator Dashboard                         [View profile] [•••] │
│ Good morning, Maya · Selling view                              │
│ [Create post] [New service] [New product]                      │
├────────────────────────────────────────────────────────────────┤
│ NEEDS ATTENTION                                                │
│ 2 orders due soon · 1 proposal viewed · Payout method ready    │
│ [Review tasks →]                                               │
├────────────────────────────────────────────────────────────────┤
│ BUSINESS SNAPSHOT                                              │
│ Earnings       Active work       Profile views       Rating     │
│ $1,240         4                 1,840               4.9 ★      │
└────────────────────────────────────────────────────────────────┘
```

### Mobile

```text
┌───────────────────────────────┐
│ Creator Dashboard       [•••] │
│ Good morning, Maya            │
│ [Create] [Service] [Product]  │
├───────────────────────────────┤
│ NEEDS ATTENTION               │
│ 2 orders due · 1 reply needed │
│ [Review tasks →]              │
├───────────────────────────────┤
│ BUSINESS SNAPSHOT             │
│ [Earnings] [Orders]           │
│ [Views]    [Rating]           │
└───────────────────────────────┘
```

The above-fold area contains only three components:

1. Header and three primary shortcuts
2. Needs Attention
3. Four business KPIs

Everything below is supporting context.

---

## 2. Top KPIs

Show four KPI cards above the fold:

| KPI | Meaning | Detail destination |
|---|---|---|
| **Available earnings** | Amount currently eligible to withdraw | Earnings |
| **Active work** | Orders/projects currently requiring creator action | Orders |
| **Profile views** | Profile discovery in selected period | Audience |
| **Rating** | Verified marketplace rating and review count | Reputation |

### KPI rules

- Default comparison period: last 30 days.
- Show a trend only when there is a valid comparison period.
- Use `—` or `Not enough data` instead of an invented zero.
- KPI cards show one value, one comparison, and one destination.
- Do not show more than four above the fold.
- Earnings uses the creator's display currency but links to the original-currency ledger.
- Rating shows review count beside the value: `4.9 ★ · 42 reviews`.

### Secondary KPIs deeper on page

- Followers
- Pending earnings
- On-time delivery
- Proposal win rate
- Content saves
- Completed orders

These belong in the relevant modules, not the first KPI row.

---

## 3. Needs Attention Module

This is the highest-priority module after the header. It contains only actionable items:

- Order due soon
- Revision requested
- Buyer message awaiting reply
- Proposal viewed or accepted
- Contest deadline approaching
- Product/service draft incomplete
- Payout setup incomplete
- Profile missing information
- Review received and awaiting response
- Badge at risk or quality review needed

### Item format

```text
[status icon] Brand identity package
              Delivery due tomorrow
              [Open order →]
```

### Rules

- Maximum three visible items; `View all tasks` opens the full queue.
- Sort by urgency, then financial/work impact.
- Remove items immediately after resolution.
- Informational notifications stay in Notifications.
- Do not use a red badge for every item. Red is reserved for blocked or urgent states.
- If there are no tasks:

```text
You’re all caught up.
Here’s one useful next step: feature your best work.
[View public profile →]
```

---

## 4. Earnings Snapshot

### Home module

```text
EARNINGS
Available to withdraw       $1,240
Pending                     $180
This month                  $2,840  ↑ 18%

[Withdraw earnings] [View financial dashboard →]
```

### What belongs on home

- Available balance
- Pending balance
- Current-period earnings
- One simple trend line or comparison
- Payout status
- Withdraw CTA when eligible

### What belongs deeper

- Gross versus net
- Platform fees
- Per-product/service revenue
- Full transaction history
- Payout method management
- Tax/report exports
- Currency breakdown
- Forecasting

The home page does not show buyer identities or detailed transaction rows.

---

## 5. Order and Project Status Snapshot

Use one unified **Active Work** module for services, products requiring delivery, projects, and contest activity.

```text
ACTIVE WORK                                      [View all →]
In progress     3
Due soon        2
Awaiting buyer  1
Proposal viewed 1

[avatar] Alex Rivera · Brand identity
         Due tomorrow · In progress       [Open]
```

### Status groups

- Needs response
- In progress
- Due soon
- Awaiting buyer
- Completed recently
- Disputed or blocked

### Rules

- Show the next action, not only the status.
- Separate active work from historical work.
- Give orders and accepted projects more prominence than open proposals.
- Keep contest submissions as a smaller opportunity row unless they need action.
- Never expose private buyer information outside the creator's authenticated dashboard.

---

## 6. Content Performance Summary

```text
CONTENT PERFORMANCE                         [View content →]
Top post: “Fintech onboarding”
1,240 views · 86 saves · 12 profile visits

Best format: Case studies
↑ 32% more saves than graphics this month
```

### MVP summary

- Top-performing content item
- Views/impressions
- Saves
- Profile visits or link clicks
- Best-performing format
- One recommendation

### Deeper content analytics

- Format comparison
- Reach trend
- Engagement rate
- Follows from content
- Chat leads
- Purchases/orders attributed to content
- Content lifecycle and publish history

Do not rank content only by views. A lower-view post that creates qualified chats or orders may be more valuable.

---

## 7. Badge and Level Summary

```text
REPUTATION
Top Rated Creator
4.9 ★ · 42 verified reviews

BADGES
[Top Rated] [Fast Responder] [3× Contest Winner]
Next: Elite Creator · 72% complete
[View reputation →]
```

### Home behavior

- Show current tier.
- Show up to three earned badges.
- Show one next milestone.
- Link to the full Reputation page.
- Never show a full badge wall or unfinished checklist on the first screen.

The detailed criteria, demotion rules, and perks are defined in `neuralmart-creator-badge-system.md`.

---

## 8. Alerts and Notifications

Alerts are different from Needs Attention:

- **Needs Attention:** creator action is required.
- **Notifications:** something happened; action may be optional.

The home page may show a compact notification preview:

```text
RECENT ACTIVITY
New review from Alex
Proposal viewed by Greenline
3 new followers
[Open notifications →]
```

Maximum three items. Do not duplicate the full notification center.

---

## 9. Suggested Next Actions

The dashboard can show one recommendation after the operational modules:

```text
NEXT BEST STEP
Your service page gets views but few bookings.
Add delivery examples to improve buyer confidence.
[Improve service →]
```

Recommendations must be:

- based on measurable behavior;
- specific and actionable;
- dismissible;
- non-judgmental;
- linked to a real edit or detail page.

Examples:

- Complete profile information.
- Pin stronger work.
- Respond to a proposal.
- Add a service gallery.
- Set up payout method.
- Ask a completed buyer for a review.

Do not recommend creating more content when an overdue order needs attention.

---

## 10. Below-the-Fold Layout

Recommended order:

```text
Above fold:
  Header + shortcuts
  Needs Attention
  Four KPIs

Below fold:
  Earnings trend + reputation
  Active Work
  Content Performance
  Badge progress
  Audience summary
  Recent activity
  Suggested next action
```

### Layout rules

- Desktop may use a two-column lower grid.
- Mobile remains a single vertical stream.
- Every card has one clear destination.
- Use no more than two charts on home.
- Dense tables belong in Orders, Earnings, Content, or Insights.

---

## 11. Empty and New-Creator States

### New creator

```text
Your creator workspace is ready.
Start by completing your profile and publishing one piece of work.
[Complete profile] [Create first post]
```

### No orders

Show profile readiness and service setup, not an empty chart:

```text
No active orders yet.
Make your profile easier to hire from.
[Review profile] [Create a service]
```

### No earnings

Show `No earnings yet`, not `$0.00` as a negative signal, with a link to create a service/product.

---

## 12. Mobile and Accessibility

- KPI cards use a 2×2 grid or horizontal scroll.
- Shortcuts are 44px minimum targets.
- Needs Attention stays near the top after the header.
- Charts have text summaries and do not rely on color.
- Screen readers encounter action, status, and destination in that order.
- Do not require hover to understand a metric.
- Skeletons match the final card shapes.

## Final home rule

The Creator Dashboard home should feel like a morning briefing for a working creator: resolve the urgent item, see the business pulse, understand what is performing, and receive one useful next move.
