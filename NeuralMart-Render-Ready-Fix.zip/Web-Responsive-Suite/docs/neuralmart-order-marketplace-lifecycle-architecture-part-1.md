# NeuralMart — Order & Marketplace Lifecycle Architecture
## Part 1 of 5: Universal Order Foundation

**Document version:** 1.0  
**Scope:** Universal order object, order types, lifecycle, status model, and payment-to-order creation  
**Audience:** Product, engineering, payments, marketplace, trust, and support teams

---

## 0. Architecture Decision

NeuralMart should use:

```text
One universal Order aggregate
→ Type-specific extension records
→ Shared payment, fulfillment, ownership, revision, refund, dispute, and payout records
```

It should not use completely separate order systems for products, services, projects, contests, and chat.

### Why

Every commercial transaction needs the same core capabilities:

- buyer and seller identity;
- amount and fee accounting;
- payment state;
- order history;
- notifications;
- receipts;
- refunds;
- disputes;
- reviews;
- wallet/ledger references;
- audit events.

Separate order systems would duplicate these rules and make a buyer's Orders page, creator earnings, support cases, and analytics inconsistent.

### Important refinement

The universal order is an aggregate, not one enormous table containing every possible field.

```text
Order core
├── Product order details
├── Exclusive project purchase details
├── Service order details
├── Custom chat order details
├── Project contract details
├── Contest prize details
├── Paid file delivery details
├── Order items/deliveries
├── Payment transactions
├── Ledger entries
├── Ownership/entitlements
├── Revisions
├── Refunds
├── Disputes
├── Reviews
└── Audit events
```

The core order owns the lifecycle. Type-specific records add rules and detail.

---

## 1. Universal Order Object

### 1.1 Order identity

Every order has:

- Internal `Order ID`
- Human-readable order number
- Order type
- Order origin/channel
- Creation source
- Buyer
- Seller/creator/freelancer
- Related marketplace object references
- Current primary lifecycle status
- Timestamps

### Internal and public identifiers

Use two identifiers:

```text
Internal ID: database identifier
Public order number: human-readable support/receipt identifier
```

The public order number is safe to show in receipts, chat, support, and email. Internal IDs should not be treated as authorization secrets.

### 1.2 Participants

Universal:

- `buyerId`
- `sellerId`
- Optional `buyerOrganizationId` or buyer team reference
- Optional seller team/agency reference
- Participant role snapshot at order creation

The seller is the person or creator account receiving the commercial obligation. For a contest prize order, the buyer is the contest host and the seller is the winning creator.

For platform-managed orders, NeuralMart may be a fee recipient or settlement party, but it should not be represented as the creator/seller in the user-facing relationship.

### 1.3 Order type

Universal:

- `orderType`
- `orderOrigin`
- `fulfillmentMode`

`orderType` identifies the business transaction. `orderOrigin` explains how it started. `fulfillmentMode` explains how value is delivered.

Example:

```text
orderType: paid_file_delivery
orderOrigin: chat
fulfillmentMode: secure_download
```

### 1.4 Related objects

The order may reference:

- Product
- Product version
- Service
- Service package
- Project
- Proposal
- Project contract
- Contest
- Contest entry
- Conversation
- Offer
- Delivery
- Milestone

Not every order type uses every reference.

### 1.5 Commercial amounts

Universal monetary fields:

- Subtotal/list price
- Discount amount
- Tax amount, when applicable
- Buyer total
- Currency
- Platform fee
- Payment processing fee
- Seller gross amount
- Seller net/pending earnings
- Refund amount
- Amount already paid
- Amount remaining

Recommended formula:

```text
Buyer total
  = subtotal
  - discount
  + tax
  + buyer-visible fees

Seller net
  = seller gross
  - platform fee
  - seller-charged processing/adjustment fees
  - refunds/chargebacks
```

The exact fee policy can vary by order type, but the order must store the applied fee snapshot. Future fee-policy changes must not rewrite historical orders.

### 1.6 Payment fields

Universal:

- Payment status
- Payment method reference
- Payment intent/authorization reference
- Capture/settlement reference
- Payment attempt count
- Idempotency key
- Paid timestamp
- Payment failure reason, safe for user display
- Receipt reference

Payment credentials, full card numbers, passwords, and secret tokens never belong in the order record.

### 1.7 Lifecycle fields

Universal:

- Primary order status
- Payment status
- Fulfillment/delivery status
- Payout status
- Created timestamp
- Updated timestamp
- Accepted timestamp, when applicable
- Started timestamp, when applicable
- Delivered timestamp, when applicable
- Completed timestamp, when applicable
- Cancelled timestamp, when applicable
- Expired timestamp, when applicable

### 1.8 Ownership fields

Universal field:

- Ownership status

The field is `not_applicable` for many services and ordinary products.

Used for:

- Exclusive projects
- Exclusive products
- Digital product entitlements
- Source-file or license ownership
- Contest rights transfer, if rules require it

Ownership must be represented by a durable ownership/entitlement record as well as an order snapshot. The order field is a current summary, not the entire ownership history.

### 1.9 Revision fields

Universal summary:

- Revision status
- Included revision count
- Used revision count
- Remaining revision count
- Revision deadline

Applies primarily to:

- Service orders
- Custom chat orders
- Project contracts
- Project milestones
- Contest finalist revisions

For instant digital products, revision status is `not_applicable`.

### 1.10 Refund and dispute fields

Universal:

- Refund status
- Refunded amount
- Refund reason
- Refund timestamp
- Dispute status
- Dispute ID/reference
- Dispute opened timestamp
- Resolution timestamp
- Resolution outcome

Refund and dispute are not simply replacements for the main order status. A completed order can later have a partial refund or dispute overlay.

### 1.11 Transaction and ledger references

Universal:

- Buyer payment transaction reference
- Seller ledger/payout reference
- Platform fee ledger reference
- Refund transaction references
- Chargeback reference, when applicable
- Wallet transaction references
- Receipt reference
- Audit event references

An order is not considered paid because a wallet transaction row exists alone. Payment confirmation must be tied to a valid payment transaction and order state transition.

### 1.12 Immutable snapshots

At order creation, preserve:

- Buyer identity/display name
- Seller identity/display name
- Product/service/project/contest title
- Package or version
- Scope and deliverables
- Price and currency
- Fees
- License/usage terms
- Delivery expectations
- Revision terms
- Refund policy
- Ownership terms
- Source conversation/offer text, where relevant

Historical order records must remain understandable even after a creator edits or archives the listing.

---

## 2. Universal Order Entity vs Separate Systems

### Recommendation

Use one universal Order aggregate with type-specific extensions.

### Shared order core

The shared core owns:

- identities;
- type and context;
- amounts;
- payment;
- primary lifecycle;
- timestamps;
- receipt;
- wallet/ledger links;
- refund/dispute references;
- audit history.

### Type-specific extensions

Each order type owns:

- its unique source object;
- availability rules;
- delivery rules;
- ownership rules;
- review behavior;
- cancellation policy;
- payout timing;
- type-specific metadata.

### What not to do

Do not create:

```text
ProductOrders
ServiceOrders
ProjectPayments
ContestPayouts
ChatPayments
```

as entirely independent lifecycles with their own payment and refund logic.

Do not put dozens of nullable columns such as `productId`, `serviceId`, `contestId`, `milestoneId`, and `fileDeliveryId` into one unstructured row without validation.

Use a typed relation or extension record with one clear source of truth per type.

---

## 3. Order Types

### 3.1 Digital Product Order

Used for a standard, non-exclusive digital product purchase.

Related objects:

- Product
- Product version
- Product license
- Delivery asset/bundle

Characteristics:

- Usually no seller acceptance step
- Usually immediate delivery
- Ownership is a digital entitlement/license
- Revision status is not applicable
- Completion may occur shortly after payment and access grant
- Refund/dispute policy still applies

Typical lifecycle:

```text
Pending Payment
→ Paid
→ Delivered
→ Completed
```

### 3.2 Exclusive Project Purchase

Used for a pre-made creator project sold once under the Exclusive Ownership/Sell Once model.

Related objects:

- Project
- Project version
- Ownership transfer
- Source/delivery assets

Characteristics:

- Availability must be enforced server-side
- Successful purchase locks the project
- Duplicate purchases are prevented
- Ownership is permanently recorded
- Sold project remains visible as Sold/Locked
- Buy Now is disabled after successful purchase

Typical lifecycle:

```text
Pending Payment
→ Paid
→ Delivered or Awaiting Buyer
→ Completed
```

The project is marked sold at the atomic purchase/ownership step, not after the buyer downloads the file.

### 3.3 Service Order

Used for a listed Basic, Standard, or Premium service package.

Related objects:

- Service
- Service package
- Buyer requirements
- Delivery
- Revisions

Characteristics:

- May require creator acceptance
- Buyer requirements can block the start date
- Has delivery and revision states
- Completion typically follows buyer approval or review-window expiry
- Seller payout may remain pending until completion

Typical lifecycle:

```text
Pending Payment
→ Paid
→ Accepted
→ In Progress
→ Awaiting Buyer
→ Delivered
→ Revision Requested, if needed
→ Completed
```

### 3.4 Custom Chat Order

Used when a buyer and creator negotiate a paid scope inside chat that is not a normal listed service package or project contract.

Related objects:

- Conversation
- Offer
- Message/offer version
- Delivery
- Optional product/service/project reference

Characteristics:

- Requires an explicit accepted offer
- Price, scope, timeline, license, and revisions are snapshotted
- May be instant delivery or fulfillment work
- Cannot rely on ordinary message text as a contract

The accepted structured offer is the commercial source of truth.

### 3.5 Project Contract Order

Used after a buyer accepts a proposal for a direct project.

Related objects:

- Project
- Accepted proposal version
- Milestones
- Conversation
- Deliverables

Characteristics:

- Custom scope
- Creator-defined proposal
- May have milestones
- Has delivery, revision, approval, and dispute behavior
- Does not use contest-entry logic

Typical lifecycle:

```text
Pending Payment
→ Paid
→ Accepted
→ In Progress
→ Awaiting Buyer
→ Delivered
→ Completed
```

### 3.6 Contest Prize Order

Used to release a funded contest prize to a selected winner.

Related objects:

- Contest
- Winning submission
- Winner selection
- Prize/funding hold
- Rights-transfer terms

Characteristics:

- Buyer is the contest host
- Seller is the winning creator
- Prize funding exists before the contest opens
- Winner selection and payout are separate audited events
- Non-winning entrants do not become sellers
- Rights depend on published contest rules

Typical lifecycle:

```text
Paid or Funded
→ Winner Selected
→ Awaiting Required Delivery
→ Delivered
→ Completed
```

### 3.7 Paid File Delivery Order

Used for a paywalled custom asset or final file delivered through chat.

Related objects:

- Conversation
- Delivery
- Delivery items
- Preview assets
- Entitlement/access grant

Characteristics:

- Original file is locked before payment
- Preview may be available
- Payment unlocks access immediately
- May attach to an existing service/project order
- If standalone, it creates a new order

Typical lifecycle:

```text
Pending Payment
→ Paid
→ Delivered
→ Completed
```

### 3.8 Order type, origin, and fulfillment

Some categories overlap by design. Keep the distinctions explicit:

| Field | Example | Purpose |
|---|---|---|
| Order type | Paid file delivery | Commercial classification |
| Origin | Chat | Where the transaction began |
| Fulfillment mode | Secure download | How the buyer receives value |
| Related object | Project 481 | What the order is connected to |

This allows a service order to have a chat origin and file delivery without creating a second hidden order.

---

## 4. Universal Marketplace Lifecycle

### 4.1 Canonical path

```text
Discovery
→ Selection
→ Checkout / Offer
→ Payment authorization
→ Order creation
→ Acceptance, when required
→ Processing
→ Delivery
→ Buyer review
→ Revision, if needed
→ Completion
→ Payout/settlement
```

### 4.2 Discovery

The buyer discovers an offer through:

- Showcase Feed
- Product marketplace
- Service marketplace
- Creator profile
- Project proposal
- Contest
- Chat
- Related recommendations

The listing or offer must show enough information to understand:

- price;
- seller;
- scope or contents;
- delivery expectations;
- license/ownership;
- availability;
- review/trust signals.

### 4.3 Selection

The buyer:

- chooses a product;
- chooses a service package;
- selects an exclusive project;
- accepts a proposal;
- accepts a custom chat offer;
- enters a contest prize flow as the host;
- selects a paid file delivery.

Selection does not grant ownership or access.

### 4.4 Checkout or offer

#### Fixed purchase

Used for:

- digital products;
- exclusive projects;
- listed service packages;
- paid file deliveries with fixed price.

#### Structured offer

Used for:

- custom chat orders;
- project contracts;
- custom service scope;
- add-ons and milestones.

The offer must be accepted before payment unless the buyer is purchasing a fixed, already-defined package.

### 4.5 Payment

Payment moves through:

```text
Payment pending
→ Authorized
→ Captured/confirmed
→ Settled or held
```

The order is not active merely because checkout opened.

### 4.6 Order creation

The order is created with:

- buyer/seller;
- type;
- source references;
- immutable commercial snapshot;
- payment reference;
- initial status;
- fulfillment rules;
- availability reservation;
- notification events.

### 4.7 Processing

Processing means the seller is preparing or performing the promised work.

Applicable actions:

- accept order;
- request buyer requirements;
- start work;
- update milestone;
- prepare locked delivery;
- ask for clarification.

### 4.8 Delivery

Delivery may be:

- instant download;
- secure file unlock;
- service file delivery;
- project milestone;
- contest prize asset;
- external-but-recorded handoff.

Delivery must be linked to the order and versioned.

### 4.9 Review and revision

The buyer can:

- approve;
- request an included revision;
- report a mismatch;
- open a dispute;
- ask a question.

A revision request does not automatically change price, scope, or deadline.

### 4.10 Completion

An order completes when:

- buyer approves;
- required review window expires;
- instant delivery completes under its policy;
- contest payout requirements are satisfied;
- dispute resolution closes it as complete.

Completion triggers:

- review eligibility;
- final seller earnings release;
- analytics conversion;
- repeat-purchase prompts;
- ownership/entitlement finalization where applicable.

---

## 5. Alternative Lifecycle Paths

### 5.1 Cancellation

```text
Pending Payment or Paid
→ Cancelled
```

Cancellation must specify:

- who cancelled;
- reason;
- whether payment was captured;
- whether refund is required;
- whether availability is restored;
- whether ownership was already transferred.

An exclusive project that has been successfully sold is not automatically relisted after ordinary cancellation.

### 5.2 Refund

```text
Paid / Delivered / Completed
→ Refund requested
→ Refund approved or declined
→ Refunded or partially refunded
```

Refund is a financial overlay and may occur after completion.

### 5.3 Dispute

```text
Any paid fulfillment state
→ Disputed
→ Evidence/review
→ Resolved
```

Possible outcomes:

- release payment;
- full refund;
- partial refund;
- replacement delivery;
- revised delivery;
- access revocation;
- account or safety action.

### 5.4 Failed payment

```text
Checkout
→ Payment failed
→ Pending Payment retained briefly
or
→ Expired
```

No seller earnings, ownership transfer, file unlock, or completed order occurs on a failed payment.

### 5.5 Seller rejection

Applies to services, custom orders, and project contracts when creator acceptance is required:

```text
Paid / Awaiting Acceptance
→ Seller rejected
→ Cancelled
→ Refund or payment release
```

Listed instant products and already-defined digital downloads do not normally have a seller rejection step.

### 5.6 Buyer inactivity

Use policy-specific timers:

- Missing requirements: order remains `Awaiting Buyer`
- Delivery review: auto-completion after the stated review window
- Revision request: revision expires only under clearly disclosed policy
- Payment checkout: payment attempt expires

Do not silently close a paid order without a visible deadline and reminders.

### 5.7 Incomplete delivery

```text
Delivered
→ Buyer reports incomplete
→ Revision Requested or Disputed
```

The seller cannot mark an incomplete delivery as complete merely by resending a message.

### 5.8 Revision request

```text
Delivered
→ Revision Requested
→ In Progress
→ Delivered
```

The order preserves:

- original delivery;
- revision request;
- revised delivery;
- remaining revision allowance.

### 5.9 Expired order

Expiry applies to:

- unpaid checkout;
- unaccepted offer;
- unfulfilled custom offer;
- expired service availability;
- contest deadline/funding window;
- delivery access window, if explicitly defined.

Expiry is not the same as cancellation or refund.

---

## 6. Universal Status System

NeuralMart should avoid one giant enum that tries to describe payment, delivery, ownership, refunds, disputes, revisions, and payout at once.

Use:

```text
One primary order lifecycle status
+
Orthogonal status dimensions
```

### 6.1 Primary order status

Recommended primary values:

```text
Pending Payment
Paid
Accepted
In Progress
Awaiting Buyer
Delivered
Revision Requested
Completed
Cancelled
Expired
```

### 6.2 Universal primary statuses

These can be understood across all order types:

- Pending Payment
- Paid
- Completed
- Cancelled
- Expired

`Paid` means the payment was confirmed, not merely attempted.

`Completed` means the order's commercial obligations are closed under its type policy.

### 6.3 Conditional primary statuses

These apply only when the order has an interactive fulfillment obligation:

- Accepted
- In Progress
- Awaiting Buyer
- Delivered
- Revision Requested

For a digital product:

```text
Paid → Delivered → Completed
```

For a service:

```text
Paid → Accepted → In Progress → Awaiting Buyer → Delivered → Completed
```

For a custom order:

```text
Paid → Accepted → In Progress → Delivered
```

### 6.4 Refund and dispute are overlays

Do not make `Refunded` and `Disputed` mutually exclusive replacements for the main lifecycle.

Use:

```text
primaryStatus: Completed
refundStatus: Partially Refunded
disputeStatus: Closed
```

or:

```text
primaryStatus: Delivered
refundStatus: None
disputeStatus: Open
```

This preserves the order's operational history.

### 6.5 Status dimensions

#### Payment status

```text
Not Required
Pending
Authorized
Paid
Failed
Partially Refunded
Refunded
Charged Back
```

#### Delivery status

```text
Not Applicable
Not Started
Preparing
Locked
Available
Delivered
Access Revoked
```

#### Ownership status

```text
Not Applicable
Pending
Licensed
Transferred
Sold / Locked
Revoked
```

#### Revision status

```text
Not Applicable
Not Started
Available
Requested
In Progress
Exhausted
Closed
```

#### Refund status

```text
None
Requested
Under Review
Approved
Partially Refunded
Refunded
Declined
```

#### Dispute status

```text
None
Open
Evidence Requested
Under Review
Resolved for Buyer
Resolved for Seller
Resolved Partially
Closed
```

#### Payout status

```text
Not Due
Pending
Held
Eligible
Released
Reversed
```

### 6.6 Invalid status combinations

The lifecycle must reject combinations such as:

- `Completed` with no confirmed payment for a paid order
- `Unlocked` without an active entitlement
- `Sold/Locked` without an ownership record
- `Released` payout while a mandatory hold/dispute is open
- `Revision Requested` on a non-revisable instant product
- `Seller earnings` credited before payment confirmation

---

## 7. Payment and Order Creation

### 7.1 Buyer initiates checkout

The buyer starts from:

- Buy Now
- Book service
- Accept offer
- Pay milestone
- Unlock file
- Purchase exclusive project
- Fund contest prize

The server creates or retrieves an idempotent payment attempt.

### 7.2 Payment validation

Before authorization, validate:

1. Buyer is authenticated.
2. Buyer is allowed to purchase this object.
3. Buyer is not the seller where self-purchase is prohibited.
4. Listing/offer is active.
5. Price and currency are current.
6. Required license is selected.
7. Product/project/service is available.
8. Service capacity permits the order.
9. Project has not already been sold.
10. Contest is in a fundable state.
11. Conversation offer has not expired.
12. Buyer has sufficient funds or a valid payment method.
13. The idempotency key has not already completed.

The server recalculates all amounts. It never trusts the client-submitted total.

### 7.3 Payment authorization

Prefer:

```text
Authorize funds
→ Reserve scarce availability
→ Create order and related records
→ Capture/confirm payment
→ Activate fulfillment
```

For internal wallet payments, the debit and reservation can occur in one database transaction.

For an external processor, use a payment intent/authorization plus an idempotent confirmation handler and compensating void/refund if the order transaction fails.

### 7.4 Order creation

On confirmed payment, create:

- Universal order
- Type-specific order detail
- Order item/delivery record
- Payment transaction
- Buyer ledger entry
- Seller pending-earnings entry
- Platform fee entry
- Receipt
- Conversation system event, if chat-linked
- Notification event
- Ownership/entitlement record, if applicable

The order and payment transition must be safe to retry.

### 7.5 Seller notification

After the order is committed, notify the seller:

- New order received
- Amount and currency
- Order type
- Required action
- Due date
- Buyer requirements
- Linked conversation/order

Do not notify the seller of a confirmed order before the transaction is durable.

### 7.6 Buyer confirmation

After commit, the buyer receives:

- Order number
- Receipt
- Payment confirmation
- Expected delivery/access
- Seller identity
- Support/dispute path
- Chat update, if applicable

### 7.7 Availability update

Availability updates depend on type:

| Order type | Availability effect |
|---|---|
| Digital product | Usually no reduction; listing remains available |
| Exclusive project | Immediately Sold/Locked |
| Service | Active capacity/queue increases |
| Custom chat | Offer/order capacity reserved |
| Project contract | Proposal becomes accepted/closed to competing selection |
| Contest prize | Prize reserve is allocated to winner |
| Paid file delivery | Asset/order access reserved; duplicate charge prevented |

### 7.8 Wallet effects

A confirmed paid order creates balanced ledger entries:

```text
Buyer: debit / purchase
Platform: fee receivable or fee revenue
Seller: pending earnings
```

Seller pending earnings become released according to:

- instant product policy;
- buyer review window;
- service/project completion;
- dispute state;
- contest payout gate.

Wallet balances should be derived from ledger entries or maintained with transactional balance updates. A UI counter is never the source of truth.

### 7.9 Receipt generation

Generate a receipt containing:

- Order number
- Buyer and seller
- Order type
- Item/scope
- Price
- Discounts
- Taxes/fees
- Total
- Payment status
- License/ownership summary
- Delivery expectation
- Support/refund link

---

## 8. Exclusive Project Purchase: Race-Safe Ownership

Exclusive projects are the highest-risk availability case because two buyers may attempt to buy the same project simultaneously.

### 8.1 Required backend invariants

The backend must enforce:

1. A project can have at most one active exclusive ownership record.
2. A sold project cannot create a second successful order.
3. Availability is checked inside the transaction that reserves ownership.
4. Client buttons, disabled states, and feed labels are not security controls.
5. Retries use an idempotency key.
6. Failed payment does not transfer ownership.
7. Successful ownership transfer is durable before the buyer sees success.

### 8.2 Recommended purchase sequence

```text
Buyer starts checkout
→ Create idempotent payment authorization
→ Begin database transaction
→ Lock project availability row
→ Verify project is available and eligible
→ Verify no active ownership exists
→ Create order snapshot
→ Insert unique ownership record
→ Mark project Sold/Locked
→ Record buyer/seller/platform ledger entries
→ Commit transaction
→ Capture/confirm payment if required
→ Grant delivery/access
→ Notify buyer and seller
```

For payment systems that require capture before the database commit, use an authorization hold first and capture only after the ownership transaction succeeds. If the ownership transaction loses the race, void the authorization and show the buyer that the project was just purchased by someone else.

### 8.3 Unique ownership constraint

The data model must enforce a unique active ownership record for the exclusive project.

Conceptually:

```text
one project
→ one successful exclusive ownership transfer
```

Do not rely on:

- checking `isActive` in application code without a row lock;
- hiding the Buy Now button;
- feed refresh timing;
- client-side project state;
- incrementing a sales counter.

### 8.4 Race outcomes

#### Buyer A wins

- Ownership record inserted
- Project becomes Sold/Locked
- Buyer A receives success
- Buyer B's authorization is voided/refunded
- Buyer B sees `This project was just purchased`

#### Buyer B retries after sale

- Server rejects purchase
- No order is marked paid
- No ownership is created
- No seller earnings are created

#### Payment succeeds but post-payment processing fails

- Payment callback is retried idempotently
- Order remains in a recoverable payment-processing state
- Ownership is either committed once or authorization is reversed
- Buyer is never charged twice

### 8.5 Permanent ownership rule

For Sell Once:

```text
Successful purchase
→ Project Sold
→ Ownership permanently recorded
→ Buy Now disabled
→ Sold/Locked profile visibility retained
```

A later refund does not silently relist the project. The transaction may be refunded and the buyer's access/license may be revoked according to policy, but the project's historical sold state remains unless an authorized platform process explicitly reverses the ownership event.

This protects the promise that a creator will not sell the same exclusive project to a second buyer after the first transaction.

---

## 9. Type-Specific Lifecycle Summary

| Type | Acceptance | Delivery | Revisions | Ownership | Payout gate |
|---|---:|---:|---:|---:|---:|
| Digital product | Usually no | Instant/download | No | License/entitlement | Payment or short hold |
| Exclusive project | No seller acceptance after listing | File/access delivery | Optional | Permanent sold/locked | Payment/rights policy |
| Service order | Often | Creator fulfillment | Yes | Usually license | Completion/review |
| Custom chat order | Offer acceptance | Custom delivery | Per offer | Per offer | Completion/approval |
| Project contract | Proposal acceptance | Milestones/delivery | Yes | Per contract | Milestone approval |
| Contest prize | Winner selection | Prize/rights delivery | Bounded finalist work | Contest rules | Winner/payout gates |
| Paid file delivery | No separate acceptance after offer | Secure unlock | Usually no or per linked order | Entitlement/license | Payment/access policy |

---

## 10. Universal Notifications and Audit Events

Every material order transition emits an auditable event:

- Checkout started
- Payment authorized
- Payment confirmed
- Order created
- Seller notified
- Ownership reserved
- Project sold/locked
- Service accepted
- Order started
- Requirements received
- Delivery sent
- File unlocked
- Revision requested
- Buyer approved
- Order completed
- Payout released
- Cancellation requested
- Refund approved
- Dispute opened
- Dispute resolved

Notifications are derived from these events, not from ad hoc UI actions.

---

## 11. Product Principles for Parts 2–5

Later lifecycle specifications should preserve these foundation rules:

1. One universal order aggregate; specialized details by type.
2. Payment, delivery, ownership, revisions, refunds, disputes, and payouts are separate status dimensions.
3. The server is the source of truth for price, availability, access, ownership, and payment.
4. A completed order remains historically understandable after listings change.
5. Chat is a context surface, not the financial system of record.
6. Exclusive ownership is reserved atomically and never protected only by UI.
7. Status transitions are auditable and idempotent.
8. Buyer and seller experiences may differ, but they reference the same order state.

## Final rule

NeuralMart should make every transaction look different at the surface while behaving consistently underneath: one order identity, one auditable payment path, one source of truth for ownership and availability, and type-specific fulfillment rules layered on top.
