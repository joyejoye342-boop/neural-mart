# NeuralMart — Buyer Project Posting Flow

**Document version:** 1.0  
**Entry points:** Buyer home composer · Menu · Creator profile · Buyer Dashboard

---

## 0. Flow Principle

Project creation should be **quick to start and guided enough to produce useful briefs**.

The user should not face a giant form immediately. Use:

```text
Choose project type
→ State the outcome
→ Add scope and skills
→ Set budget and timing
→ Add references
→ Preview and publish
```

The form autosaves as a Draft and progressively reveals optional detail.

---

## 1. Step 0 — Choose Opportunity Type

```text
What are you looking for?

[Direct project]
Hire one creator through proposals and conversation.

[Contest]
Invite multiple entries and award a funded prize.
```

### Difference shown immediately

| Direct project | Contest |
|---|---|
| One creator is selected | One or more winners are selected |
| Creators send proposals | Creators submit entries |
| Budget pays selected creator | Prize amount must be defined/funded |
| Scope and delivery are central | Rules, judging, and rights are central |

Use a short explanation; do not use legal or marketplace jargon.

---

## 2. Direct Project Flow

### Step 1 — Outcome

Required:

- Project title
- Category
- One-sentence goal

Prompts:

```text
What do you want made?
Example: “Brand identity for a climate-tech startup”

What will success look like?
Example: “We need a flexible identity for web, pitch deck, and launch assets.”
```

The title should be at least 10 characters and describe an outcome, not an internal task code.

### Step 2 — Scope and deliverables

Required:

- Description
- Expected deliverables
- Preferred communication language

Recommended prompts:

- What needs to be delivered?
- How many versions or pages?
- What should the creator know before applying?
- What is already available?

Optional:

- Number of revisions
- Existing brand/system constraints
- Example references
- Screening questions

The form can show a structured deliverables list without requiring technical vocabulary:

```text
[+ Add deliverable]
Logo files
Pitch deck template
Social launch graphics
```

### Step 3 — Category and skills

Required:

- Primary category
- At least one skill/tag

Optional:

- Additional skills
- Tools/software preference
- Experience level
- Language
- Location/timezone preference

Use suggestions rather than a blank taxonomy field:

```text
Branding · UI/UX · Motion · Illustration · Writing · Video
```

Tags are used to match creators and rank opportunity-feed results.

### Step 4 — Budget

Offer three simple choices:

```text
How would you like to budget this project?

[Fixed budget]   [Budget range]   [Help me estimate]
```

#### Fixed budget

- Amount
- Currency
- Whether the amount includes platform fees

#### Budget range

- Minimum
- Maximum
- Currency

#### Help me estimate

Ask:

- deliverable complexity;
- experience level;
- number of deliverables;
- timeline;
- expected revisions.

Show a suggested range with an explanation. The buyer can edit or skip it.

### Budget rules

- Minimum platform-defined amount.
- Maximum must be equal to or greater than minimum.
- Show the creator-facing amount clearly.
- Explain platform fees separately.
- Do not force a buyer to fund the full project before selecting a creator unless the payment flow requires escrow.
- Allow budget to remain negotiable when clearly labeled `Open to proposals`.

### Step 5 — Deadline

Separate two dates:

1. **Proposal deadline:** when creators should apply.
2. **Target delivery date:** when the buyer wants the work completed.

For MVP, proposal deadline can be optional and delivery date required for projects with time-sensitive scope.

Offer:

```text
[I have a date] [Flexible timing]
```

Required deadline rules:

- Date and timezone
- Cannot be in the past
- Must allow a reasonable minimum lead time
- Shows human-readable summary: `Due Apr 28 · Dhaka time`
- Warns when the budget and timeline appear unrealistic without blocking publication

### Step 6 — Attachments and references

Optional:

- Reference images
- Brief PDF/document
- Brand assets
- Example links
- Existing files

Each attachment shows:

- filename;
- type;
- size;
- upload state;
- remove control.

References are labeled separately from required deliverables:

```text
Reference inspiration
These examples help creators understand the direction.
```

Private client information should not be required in the public brief.

### Step 7 — Visibility and collaboration preferences

Optional:

- Public or limited brief
- Invite specific creators
- Allow creators to share work samples
- Preferred communication channel
- Whether the project may be featured as a public case study later

Default: public to eligible creators, with private contact/payment information protected.

### Step 8 — Preview and publish

Preview shows the creator-facing card:

```text
Open project
Title
Brief excerpt
Budget · Category · Skills
Deadline
Attachments
```

Validation summary:

- missing required fields;
- unclear title;
- no budget;
- invalid date;
- attachment issue;
- policy-sensitive content.

Final actions:

```text
[Save draft] [Publish project]
```

After publishing:

- show success confirmation;
- show expected next step;
- route back to the originating feed when `returnTo` exists;
- otherwise open project detail;
- offer `Invite creators` and `View project`.

---

## 3. Contest Flow

Contest creation shares the first two steps but adds contest-specific requirements.

Required:

- Contest title
- Category
- Creative brief
- Prize amount
- Submission deadline
- Submission format
- Judging criteria
- Winner count
- Rights/ownership terms
- Host identity

Recommended:

- Reference assets
- Allowed tools
- Entry limits
- Public/private submissions
- Feedback policy
- Runner-up prizes

### Contest budget/prize rules

- Prize amount must be explicit.
- Prize funding/escrow state is shown before publication.
- Platform fees are separate from prize.
- Multiple-winner contests define the split.
- Deadline and judging period are distinct.
- Ownership transfer is explicit in the contest terms.

Contest creation is guided, not quick-posted, because unclear rules create disputes.

---

## 4. Quick vs Guided Creation

### Quick start

From home, the buyer sees only:

```text
What are you looking to create?
[Post a project]
```

The first screen asks for title, category, and goal. Everything else follows in the guided flow.

### Guided form

Use a five-step progress indicator:

```text
Goal → Scope → Budget → Timing → Publish
```

Optional details appear under `Add more detail`. The buyer can publish a valid simple project without completing every advanced field.

### Non-technical UX

- Use examples in every complex field.
- Ask outcome questions instead of technical specifications.
- Explain why a field improves proposals.
- Provide templates by category.
- Use plain language: `What should be delivered?` rather than `Define acceptance criteria`.
- Autosave drafts.
- Let buyers preview the creator-facing result.

---

## 5. Draft, Edit, and Publish States

```text
Draft
→ Ready to publish
→ Open
→ Reviewing proposals
→ In progress
→ Completed / Closed
```

### Draft behavior

- Autosave after meaningful field changes.
- Show completion percentage and missing fields.
- Preserve uploaded references.
- Allow discard with confirmation.

### Edit after publishing

- Title/category edits can be immediate if no proposals exist.
- Material budget, scope, or deadline edits notify shortlisted/proposing creators.
- After selection, material changes require buyer/creator agreement or a new project.
- Closed projects become read-only except for permitted history updates.

## Final rule

A buyer should be able to publish a clear, useful project in a few minutes, while the guided flow quietly collects enough structure for creators to make accurate proposals.
