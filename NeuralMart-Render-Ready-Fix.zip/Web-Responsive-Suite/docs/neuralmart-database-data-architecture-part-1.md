# NeuralMart — Database & Data Architecture
## Part 1 of 3: Operational Data Foundation, Identity, Content, Marketplace Objects, and Digital Products

**Document version:** 1.0  
**Depends on:** NeuralMart architecture from Prompts #1–#35  
**Continues in:** Part 2 — Orders, Chat, Wallet, Payments, Delivery, Ownership, Reviews, Notifications, and Trust data  
**Continues in:** Part 3 — Analytics storage, indexing, security, retention, migrations, reliability, and backend data access  
**Scope:** Primary database strategy, core entity map, identity and roles, profiles, creators, social content, media, projects, proposals, contests, services, and digital products

---

## 0. Foundation Rules

This document extends the previously approved architecture without creating parallel systems.

NeuralMart remains:

- one identity per person;
- one flexible capability model;
- one public identity/profile foundation;
- one universal Order aggregate;
- one Wallet/financial system;
- one contextual Chat system;
- one protected file-access model;
- separate Showcase and Opportunities feed surfaces;
- separate Products, Services, Projects, and Contests as marketplace concepts;
- backend-enforced for authorization, availability, ownership, payment, and access.

Part 1 focuses on the durable operational records that the rest of the platform depends on.

The following concerns are intentionally defined only at the relationship level here and will be detailed in Part 2:

- Payment authorization and capture
- Wallet and financial ledger
- Withdrawals and payout settlement
- Universal Order internals
- Delivery and revision execution
- Chat/message storage details
- Refund and dispute workflows
- Review/rating calculation
- Notification delivery

---

# 1. Database Architecture Strategy

## 1.1 Requirements

NeuralMart needs to store and query:

- strongly consistent identities and permissions;
- creator and buyer relationships;
- content and engagement;
- project and contest state;
- proposals and selection history;
- products, services, licenses, and availability;
- financial and ownership references;
- protected file metadata;
- order relationships;
- review and reputation evidence;
- operational analytics events.

Some records are highly relational and transactional. Others are large binary objects, fast-changing counters, searchable text, or analytical events.

One storage technology should not be forced to perform every job.

## 1.2 Relational database evaluation

A relational database is the best fit for the operational core.

Strengths:

- ACID transactions for payment/order/ownership workflows;
- foreign keys and uniqueness constraints;
- reliable many-to-many relationships;
- consistent role and permission checks;
- project/proposal/shortlist integrity;
- product/version/license relationships;
- order and ownership history;
- predictable filtering and pagination;
- mature backup and migration tooling;
- row-level and column-level access patterns;
- strong support for structured JSON fields where needed.

Weaknesses:

- very large media binaries should not be stored in database rows;
- high-volume analytics events may need an append-only or warehouse destination;
- full-text and semantic discovery may eventually need a dedicated search index;
- rapidly changing counters need careful write and aggregation strategies.

These are reasons to add supporting systems, not reasons to abandon relational integrity.

## 1.3 Document database evaluation

A document database could be useful for:

- flexible drafts;
- irregular content blocks;
- denormalized feed cards;
- search documents;
- rapidly changing analytics payloads.

It is not the right primary database for NeuralMart because:

- payment and ownership relationships require strong transactional constraints;
- proposals, projects, users, roles, and orders cross-reference many entities;
- duplicate exclusive purchases must be prevented by a durable uniqueness rule;
- financial records cannot depend on application-only joins;
- document-level flexibility can hide invalid relationships;
- reporting across buyers, creators, orders, products, and payouts becomes inconsistent.

Document storage may be used later for derived search/index documents or bounded content payloads, but not as the operational source of truth.

## 1.4 Hybrid architecture evaluation

A hybrid system is appropriate at the platform level:

```text
PostgreSQL
→ Primary operational records

Object storage
→ Images, videos, documents, source files, delivery files

Cache/queue layer
→ Sessions, rate limits, jobs, hot reads, idempotency coordination

Search index
→ Full-text, facets, discovery ranking, autocomplete

Analytics store/warehouse
→ High-volume event analysis and long-range reporting
```

The hybrid model must not become several competing sources of truth.

## 1.5 Recommendation

Use:

```text
PostgreSQL as the primary operational database
+
Private/public object storage for binary files
+
Optional Redis-compatible cache and job infrastructure
+
Optional search index for discovery
+
Separate analytics store when event volume justifies it
```

### Primary architecture decision

**NeuralMart should use a relational-first hybrid architecture.**

PostgreSQL is authoritative for:

- users and roles;
- profiles;
- products and services;
- projects and contests;
- proposals and entries;
- posts and content relationships;
- order references;
- ownership references;
- permissions;
- transactional state;
- audit and timeline references.

Object storage is authoritative for binary bytes. PostgreSQL remains authoritative for the metadata, ownership, access policy, checksum, lifecycle, and relationship of every stored file.

Search, cache, queues, and analytics are derived or supporting systems. If they are unavailable, the platform must not lose or redefine financial, ownership, permission, or marketplace truth.

## 1.6 PostgreSQL design style

Use:

- UUID or equivalent non-guessable internal IDs;
- public human-readable IDs where user-facing support needs them;
- foreign keys for operational relationships;
- unique constraints for identity and ownership invariants;
- check constraints for bounded values;
- enum or reference-table strategy for stable statuses;
- timestamps in UTC;
- explicit timezone fields where deadlines are user-facing;
- integer minor units for money, never floating-point amounts;
- JSONB only for bounded, versioned, non-relational payloads;
- append-only records for financial, ownership, audit, and material lifecycle events.

Avoid:

- storing authorization rules only in JSON;
- generic `entityType/entityId` links when a real foreign key is possible;
- duplicate buyer/creator identity fields on every record;
- storing binary files in PostgreSQL;
- using feed cards as the source of content truth;
- using counters as the only record of engagement;
- deleting historical marketplace records to represent a current state.

## 1.7 Read models and projections

The normalized PostgreSQL model is the source of truth. Performance-oriented read models may be added for:

- feed pages;
- creator storefronts;
- marketplace search;
- dashboard summaries;
- notification counts;
- order-center filters.

Read models must contain:

- a source record reference;
- a refresh/update strategy;
- a way to rebuild from authoritative records;
- a clear stale-data tolerance.

An unavailable projection must not make a valid product, order, ownership, or permission disappear permanently.

---

# 2. Core Entity Map

## 2.1 Classification legend

| Classification | Meaning |
|---|---|
| Core | Identity or primary marketplace object |
| Supporting | Relationship, configuration, or extension of a core object |
| Transactional | A user action or lifecycle record that changes state |
| Content | User-created media, posts, comments, and discovery objects |
| Financial | Money, payment, wallet, payout, refund, or ownership value records |
| System | Platform operations, moderation, support, preferences, and policy |
| Analytics | Events and derived performance facts |

An entity can have one primary classification while participating in other domains.

## 2.2 Identity and access entities

| Entity | Class | Purpose |
|---|---|---|
| `User` | Core | One authenticated NeuralMart identity |
| `UserRole` | Supporting | Enabled account capability or staff role |
| `UserCapability` | Supporting | Fine-grained capability state when needed |
| `Profile` | Core | Shared public identity and presentation |
| `CreatorProfile` | Core | Creator capability and storefront-specific data |
| `FreelancerProfile` | Supporting | Optional creator specialization for proposal/project work; not a separate account |
| `BuyerProfile` | Supporting | Buyer preferences, organization, and hiring context |
| `Verification` | System | Identity, payout, or capability verification evidence/state |
| `AccountRestriction` | System | Suspensions, limits, holds, or trust restrictions |
| `Session` | System | Authenticated session reference |

## 2.3 Trust and relationship entities

| Entity | Class | Purpose |
|---|---|---|
| `Badge` | Core | Definition of an earned trust/achievement badge |
| `UserBadge` | Supporting | Assignment and evidence reference for a badge |
| `Reputation` | Supporting | Derived creator trust and performance summary |
| `Follow` | Supporting | User-to-user following relationship |
| `Block` | System | Safety and visibility exclusion relationship |
| `Report` | System | Content, user, or marketplace report |
| `PolicyAcceptance` | System | Versioned acceptance of platform/license/policy terms |

## 2.4 Social and content entities

| Entity | Class | Purpose |
|---|---|---|
| `Feed` | Core/System | Logical discovery surface such as Showcase or Opportunities |
| `FeedEligibility` | Supporting | Rules or current eligibility for an object to appear in a feed |
| `FeedEntry` | Supporting | Optional derived feed projection referencing source content |
| `Post` | Content/Core | Universal social/showcase content record |
| `PostType` | Supporting | Stable taxonomy for post/content format |
| `Media` | Content/Supporting | Metadata for an image, video, document, or other asset |
| `PostMedia` | Supporting | Ordered media relationship for a post |
| `Comment` | Content/Transactional | User comment and thread relationship |
| `Reaction` | Content/Transactional | User reaction to a post/comment/content object |
| `Save` | Supporting/Transactional | User-saved content or marketplace object |
| `Share` | Analytics/Transactional | Share action and attribution reference |
| `ContentLink` | Supporting | Typed link from a post to product/service/project/contest |
| `ContentModeration` | System | Moderation status, decision, and review reference |

## 2.5 Project and proposal entities

| Entity | Class | Purpose |
|---|---|---|
| `Project` | Core | Buyer-created brief or hiring opportunity |
| `ProjectAttachment` | Supporting | Typed relationship between a project and media |
| `ProjectSkill` | Supporting | Project skill/category facet |
| `ProjectProposal` | Transactional/Core | Creator's structured offer to a project |
| `ProposalVersion` | Supporting | Immutable proposal revisions |
| `ProposalAttachment` | Supporting | Media or portfolio reference attached to a proposal |
| `ProjectShortlist` | Transactional | Buyer-private shortlist state |
| `ProjectSelection` | Transactional | Selected proposal/creator decision |
| `ProjectContract` | Supporting/Transactional | Accepted proposal terms that become an Order source |

## 2.6 Contest entities

| Entity | Class | Purpose |
|---|---|---|
| `Contest` | Core | Buyer-hosted competition brief |
| `ContestPrize` | Financial/Supporting | Prize definition and funding reference |
| `ContestEntry` | Transactional/Core | Creator submission to a contest |
| `ContestEntryFile` | Supporting | Media/file relationship for an entry |
| `ContestShortlist` | Transactional | Host/judge shortlist state |
| `ContestWinner` | Transactional | Winner selection and confirmation |
| `ContestOwnership` | Financial/Supporting | Rights/ownership transfer terms and outcome |

## 2.7 Service entities

| Entity | Class | Purpose |
|---|---|---|
| `Service` | Core | Creator's fixed/scoped service offer |
| `ServicePackage` | Supporting | Basic, Standard, Premium, or custom package |
| `ServiceMedia` | Supporting | Service preview and portfolio proof relationship |
| `ServiceRequirement` | Supporting | Buyer information required before work begins |
| `ServiceAvailability` | Supporting | Listing visibility, capacity, and pause state |
| `ServiceOrder` | Supporting/Transactional | Type-specific extension pointing to the universal Order |

## 2.8 Digital product entities

| Entity | Class | Purpose |
|---|---|---|
| `Product` | Core | Creator-owned digital product listing |
| `ProductVersion` | Supporting | Immutable product release/version |
| `ProductFile` | Supporting | File included in a product version |
| `ProductPreview` | Supporting | Preview asset shown before purchase |
| `ProductLicense` | Core/Supporting | License definition and terms |
| `ProductCategory` | Supporting | Product taxonomy |
| `ProductPurchase` | Transactional/Supporting | Order-to-product purchase/entitlement bridge |
| `Ownership` | Financial/Core | Durable exclusive ownership or rights record |

## 2.9 Commerce and fulfillment entities

These are listed here as cross-domain references and will be detailed in Part 2:

| Entity | Class | Purpose |
|---|---|---|
| `Order` | Transactional/Core | Universal commercial lifecycle |
| `OrderItem` | Transactional | Item or scope component in an Order |
| `Delivery` | Transactional | Versioned fulfillment delivery |
| `Revision` | Transactional | Structured revision request and outcome |
| `Review` | Transactional/Trust | Order-linked written review |
| `Rating` | Transactional/Trust | Order-linked numeric/category rating |
| `Chat` | Supporting | Commerce context abstraction |
| `Conversation` | Core/Supporting | Participant and context-linked thread |
| `Message` | Transactional | Conversation message/system event |
| `ChatAttachment` | Supporting | Media attached to a message |
| `Offer` | Transactional | Structured pre-order or add-on offer |

## 2.10 Financial and support entities

These will be detailed in Part 2:

| Entity | Class | Purpose |
|---|---|---|
| `Wallet` | Financial | One user wallet/account summary |
| `Transaction` | Financial | Ledger movement |
| `Payment` | Financial/Transactional | Payment attempt, authorization, capture, or refund reference |
| `Withdrawal` | Financial/Transactional | Creator payout request |
| `Refund` | Financial/Transactional | Payment and wallet reversal |
| `Dispute` | System/Transactional | Order-linked case reference and state |
| `Notification` | System | User-facing event delivery |
| `SupportTicket` | System | Support context and case |
| `Settings` | System | User preference and configuration records |

## 2.11 Analytics entities

| Entity | Class | Purpose |
|---|---|---|
| `AnalyticsEvent` | Analytics | Canonical event emitted from an authoritative action |
| `AnalyticsAttribution` | Analytics | Source/context relationship for a conversion |
| `MetricSnapshot` | Analytics | Precomputed period summary |

Analytics entities never replace operational records.

---

# 3. User Data Model

## 3.1 User identity

`User` is the single account and security boundary.

Core attributes:

- `id`
- authentication provider reference
- normalized email/phone reference where applicable
- account-level status
- account creation timestamp
- last authenticated activity
- last meaningful activity
- current role/capability summary
- deletion/deactivation state
- security and restriction summary

The User record should not contain every public profile field or marketplace preference.

## 3.2 Account status

Recommended account status dimensions:

```text
Active
Pending Verification
Restricted
Suspended
Deactivated
Deletion Requested
Deleted/Anonymized
```

Do not overload one status with every operational restriction.

Use separate records or fields for:

- login blocked;
- selling blocked;
- buying blocked;
- messaging blocked;
- payout held;
- content publishing blocked;
- moderation review required.

## 3.3 Authentication reference

The application stores an opaque authentication reference, not credentials.

User may reference:

- managed authentication subject ID;
- authentication provider;
- verification state;
- last sign-in timestamp.

Passwords, access tokens, provider secrets, and full authentication credentials do not belong in the application database.

## 3.4 Profile reference

Each active User has one shared `Profile` record.

```text
User
└── Profile
    ├── CreatorProfile, optional
    ├── FreelancerProfile, optional specialization
    └── BuyerProfile, optional
```

The Profile is the common public identity anchor. Role-specific extensions do not create separate identities.

## 3.5 Role information

The User may retain a compatibility summary:

```text
buyer | creator | both | admin
```

For scalable storage, the authoritative enabled-capability records should be normalized through `UserRole`/`UserCapability`.

The summary field exists for:

- compatibility with current routes and APIs;
- fast common authorization checks;
- simple UI bootstrapping.

It must not become the only place where role history, activation, pause, or fine-grained permissions are stored.

## 3.6 Activity timestamps

Store separately:

- account created;
- profile updated;
- last sign-in;
- last active session;
- last content publication;
- last marketplace activity;
- last financial activity.

This prevents one vague `updatedAt` field from becoming an unreliable activity metric.

## 3.7 Deletion and deactivation

Account deactivation:

- prevents normal login or public activity according to state;
- preserves active orders, financial records, ownership, reviews, and legal/audit history;
- hides or anonymizes public profile presentation as policy requires;
- does not delete seller/buyer references from historical orders.

Deletion must use a controlled workflow:

```text
Deletion requested
→ Eligibility check
→ Active obligations reviewed
→ Public data anonymized or removed
→ Financial/legal records retained as required
→ Access revoked
→ Account marked deleted
```

Never use cascading deletion from User to erase order, ownership, payment, or dispute history.

---

# 4. Flexible Role Architecture

## 4.1 One account, multiple capabilities

A single User can act as:

- Creator;
- Freelancer;
- Buyer/Client;
- Contest Participant;
- Digital Seller.

These are not separate accounts.

The approved account-level role model remains:

| Stored summary | Meaning |
|---|---|
| `buyer` | Buyer capabilities enabled |
| `creator` | Creator capabilities enabled |
| `both` | Buyer and Creator capabilities enabled |
| `admin` | Staff-only administrative account |

`Freelancer`, `Contest Participant`, and `Digital Seller` are activity/capability expressions within Creator capability, not new account-level roles.

## 4.2 UserRole

`UserRole` records:

- user;
- role/capability key;
- enabled/paused state;
- activated timestamp;
- deactivated timestamp, if applicable;
- activation source;
- eligibility or verification reference;
- current/default context where relevant.

Recommended capability keys:

```text
buyer
creator
admin
```

Derived activity capabilities:

```text
freelancer
contest_participant
digital_seller
service_seller
product_seller
```

Derived activity keys should generally come from actual records:

- a proposal makes the user active as a freelancer for that project;
- a contest entry makes the user a contest participant;
- an active product listing makes the user a digital seller.

Do not grant permanent permissions from a decorative activity label.

## 4.3 UserCapability

When authorization becomes more detailed than broad roles, use explicit capabilities such as:

```text
project.create
proposal.submit
contest.host
contest.enter
product.publish
service.publish
order.buy
order.sell
wallet.withdraw
content.publish
```

Capabilities can be resolved from:

- enabled role;
- account status;
- verification;
- trust/risk restriction;
- ownership of the resource;
- participant relationship;
- system/admin policy.

The database stores durable capability state and restrictions. The backend remains responsible for evaluating the final permission.

## 4.4 Active role/context

The active role is a user experience preference, not a permission mutation.

For a `both` user:

```text
activeContext = buying | selling
```

It controls:

- default dashboard;
- default feed tab;
- composer emphasis;
- ordering of shortcuts;
- notification grouping.

It does not:

- create another account;
- revoke buyer access;
- revoke creator access;
- create another wallet;
- create another inbox;
- change order ownership.

Store it as a user preference or session preference, not as the authoritative role.

## 4.5 Role switching

Role/context switching:

1. Loads the same User and Profile.
2. Changes the preferred surface.
3. Recomputes available actions from current capabilities.
4. Preserves one wallet, inbox, public identity, and order history.

If a buyer activates Creator capability:

```text
Buyer
→ Creator capability enabled
→ Summary becomes Both
→ CreatorProfile provisioned
→ Onboarding state created
```

If a creator pauses selling:

```text
Creator capability paused
→ Existing orders/history preserved
→ Listings hidden or paused
→ CreatorProfile retained
```

Pausing is not deletion.

## 4.6 Admin separation

Admin remains structurally separate from marketplace capabilities.

An admin account should not simultaneously represent ordinary marketplace buying/selling in the same staff identity. If staff need personal marketplace activity, use a separate ordinary account so moderation and financial audit trails remain clear.

---

# 5. Profile Architecture

## 5.1 Relationship

```text
User
↓ 1:1
Profile
├── CreatorProfile, 0:1
│   └── FreelancerProfile, 0:1 specialization
└── BuyerProfile, 0:1
```

The same User can have both CreatorProfile and BuyerProfile.

## 5.2 User fields

User contains:

- internal identity ID;
- authentication subject;
- account status;
- role/capability summary;
- security timestamps;
- verification summary;
- restriction/deactivation summary;
- created/updated timestamps.

User does not contain:

- public bio;
- creator category;
- portfolio;
- buyer hiring preferences;
- product/service listing fields;
- wallet balance;
- follower counts;
- raw analytics counters.

## 5.3 Profile fields

Profile contains shared identity/presentation:

- profile ID;
- user ID;
- display name;
- username/handle;
- avatar media reference;
- cover media reference;
- short bio;
- public links;
- locale;
- timezone;
- language preferences;
- public profile visibility;
- profile completion state;
- public creation/member-since timestamp.

Profile may also contain derived presentation settings:

- featured content selection;
- profile layout preference;
- pronoun/display preference where supported;
- public contact preference.

Profile does not contain private authentication or financial data.

## 5.4 CreatorProfile fields

CreatorProfile contains creator-specific storefront and trust data:

- creator profile ID;
- profile ID or user ID;
- primary category;
- skills/tags;
- creator headline;
- public availability state;
- response-time presentation;
- service/product publishing state;
- creator onboarding state;
- creator pause state;
- portfolio configuration;
- public storefront visibility;
- creator verification summary;
- derived sales/completion/review counters;
- public creator level/badge summary.

It references, but does not duplicate:

- Posts for showcase work;
- Products for digital listings;
- Services for service listings;
- Reviews/Ratings for verified trust;
- Orders for completed work;
- Wallet/Ledger for earnings;
- Analytics for performance.

## 5.5 FreelancerProfile fields

FreelancerProfile is an optional specialization underneath CreatorProfile, not a separate identity or account-level role.

It contains project-work preferences such as:

- proposal headline;
- project categories;
- availability/capacity;
- preferred project sizes;
- typical delivery range;
- working hours/timezone;
- proposal defaults;
- portfolio proof preferences;
- project-specific profile visibility.

It should not duplicate:

- display name;
- avatar;
- bio;
- creator rating;
- wallet;
- earnings;
- identity verification.

If the platform later decides the specialization is unnecessary, these fields can remain as CreatorProfile project preferences without changing the User model.

## 5.6 BuyerProfile fields

BuyerProfile contains buyer/hiring context:

- buyer profile ID;
- profile ID or user ID;
- hiring preferences;
- preferred categories;
- typical budget ranges;
- organization/team reference, if applicable;
- default project visibility;
- project posting defaults;
- contest hosting defaults;
- buyer onboarding state;
- saved payment preference reference, never raw payment credentials;
- buyer-side notification preferences.

BuyerProfile does not duplicate:

- display name;
- avatar;
- public bio;
- wallet;
- order history;
- chat identity.

## 5.7 Derived counters

Counts such as:

- followers;
- following;
- posts;
- product sales;
- completed orders;
- reviews;
- contest wins;

may be maintained as cached summaries for performance.

The underlying relationship tables remain authoritative. Counter updates must be repairable from source records.

---

# 6. Creator Data Model

## 6.1 Creator as a connected graph

The CreatorProfile is a capability anchor, not a container for every creator record.

```text
CreatorProfile
├── Posts / Showcase content
├── Products / Product versions
├── Services / Service packages
├── Project proposals
├── Contest entries and wins
├── Completed seller Orders
├── Deliveries and revisions
├── Reviews and ratings
├── Badges and reputation
├── Wallet/earnings references
└── Analytics events and aggregates
```

## 6.2 Portfolio

Portfolio content should use existing Post and Media records:

- Post identifies the public presentation;
- Media identifies the assets;
- ContentLink connects a post to a Product, Service, Project, or Contest where relevant;
- PortfolioPlacement or creator-curated selection records ordering/featured state;
- visibility and moderation remain on the source content.

Do not copy a portfolio image into a separate portfolio file table only because it appears on a creator profile.

## 6.3 Services and products

CreatorProfile owns the capability to publish. The Service and Product records own the listing data.

```text
CreatorProfile 1 → many Service
CreatorProfile 1 → many Product
```

The creator identity is referenced by ID. Display name/avatar are read from Profile or cached as a historical snapshot only when a transaction requires it.

## 6.4 Creator posts

Posts reference the author User/Profile and may be eligible for the Showcase Feed.

Posts can link to:

- a product;
- a service;
- a completed project;
- a contest entry/win;
- a general showcase item.

The same Post remains one record even when shown:

- on the creator profile;
- in the Showcase Feed;
- in search;
- on a linked product/service page.

## 6.5 Reviews and ratings

Creator reputation is derived from eligible verified orders and reviews.

The creator record should store summaries such as:

- average rating;
- rating count;
- completed order count;
- on-time delivery signal;
- review count.

It should not replace:

- the individual Review;
- the individual Rating;
- the Order relationship;
- the delivery/payment evidence.

## 6.6 Badges

Badge definitions are shared platform records.

UserBadge records:

- user;
- badge;
- earned state;
- earned timestamp;
- evidence period;
- calculation/reference snapshot;
- visibility state;
- revocation/demotion state where applicable.

Badges should reference verified outcomes, not copy all underlying order data.

## 6.7 Contest wins and completed projects

ContestWinner, ProjectSelection, ProjectContract, and Order records preserve specific history.

CreatorProfile may expose derived summaries:

- contest wins;
- finalists;
- completed projects;
- completed orders;
- sales.

These are not manually editable creator fields.

## 6.8 Earnings and analytics

Creator earnings belong to Wallet/Transaction/Payment records and will be detailed in Part 2.

Creator analytics belong to AnalyticsEvent and derived metric records and will be detailed in Part 3.

CreatorProfile may cache:

- public completed-order count;
- public sales count;
- public rating summary;
- public availability;

Private earnings and sensitive client metrics must not be stored in public profile records.

---

# 7. Feed & Social Data Model

## 7.1 Separate feed purposes

NeuralMart keeps:

```text
Showcase Feed
→ Creator work, products, services, and selected open project discovery

Opportunities Feed
→ Contests and open project opportunities

Marketplace discovery
→ Product/service grids and search, not a social feed
```

Feed identity is a product concern. The database should support these surfaces without copying source content.

## 7.2 Feed entity

`Feed` represents a logical discovery surface:

- feed ID;
- stable key (`showcase`, `opportunities`);
- display name;
- purpose;
- ranking mode;
- visibility rules;
- active state;
- configuration version.

The Feed record does not own the Post, Project, Contest, Product, or Service.

## 7.3 Feed eligibility

`FeedEligibility` or equivalent source-specific eligibility records define whether an object may appear:

- source type;
- source ID;
- feed type;
- eligibility status;
- eligibility reason;
- visible-from timestamp;
- visible-until timestamp;
- moderation state;
- ranking hints;
- last evaluated timestamp.

Examples:

```text
Post → Showcase → eligible
Product → Showcase/Marketplace → eligible
Service → Showcase/Marketplace → eligible
Project(status=open) → Showcase/Opportunities → eligible
Contest(status=open) → Opportunities → eligible
```

## 7.4 Feed entry projection

For simple scale, feed results can be queried from normalized tables with indexed eligibility conditions.

At larger scale, `FeedEntry` may be a rebuildable read model:

- feed ID;
- source type;
- source ID;
- author/owner ID;
- ranking score;
- eligibility snapshot;
- created/updated timestamps;
- cursor fields.

`FeedEntry` must never become the only copy of the source content.

## 7.5 Feed interaction

Feed interactions reference the source object:

- FeedInteraction ID;
- user;
- feed;
- source type/source ID or typed source reference;
- interaction type;
- session/source context;
- created timestamp.

Interaction types:

- impression;
- open/click;
- save;
- share;
- follow;
- proposal start;
- product/service detail open;
- contest entry start.

Engagement actions with durable user meaning use dedicated tables when appropriate:

- Reaction;
- Comment;
- Save;
- Follow.

AnalyticsEvent can capture high-volume impressions and attribution.

## 7.6 No content duplication

The same Post, Product, Service, Project, or Contest is referenced from multiple feeds or surfaces.

Do not create:

```text
ShowcasePostCopy
OpportunityPostCopy
ProfilePostCopy
```

Instead:

```text
One source record
→ Multiple eligibility/projection references
→ Surface-specific card presentation
```

## 7.7 Feed visibility

Visibility is evaluated from:

- source status;
- author capability;
- moderation state;
- privacy setting;
- feed rules;
- relationship/block rules;
- scheduled publication window;
- deletion/archive state.

The feed response may be role-aware in CTA and ranking, but the underlying source record remains one record.

---

# 8. Post & Content Architecture

## 8.1 Universal Post

`Post` is the universal social/showcase content record.

Core attributes:

- Post ID;
- author User/Profile reference;
- PostType;
- text/body;
- title or caption;
- primary media reference;
- visibility;
- lifecycle status;
- scheduled publish timestamp;
- published timestamp;
- archived/deleted timestamp;
- moderation state;
- created/updated timestamps.

## 8.2 PostType

Stable PostType values may include:

```text
showcase
case_study
portfolio_update
behind_the_scenes
product_promotion
service_promotion
project_result
contest_result
announcement
```

PostType controls presentation and eligibility hints. It does not create a separate post table.

## 8.3 Linked marketplace objects

A Post may link to:

- Product;
- Service;
- Project;
- Contest;
- ContestEntry;
- completed Order or Project Contract when public sharing is allowed.

Use typed relationship tables or explicit nullable foreign keys for supported link types.

Recommended model:

```text
Post
├── PostProductLink
├── PostServiceLink
├── PostProjectLink
├── PostContestLink
└── PostOrderProofLink
```

Each typed link can preserve:

- display order;
- relationship label;
- creator-provided relevance note;
- visibility;
- created timestamp.

Avoid an unconstrained generic `linkedEntityId` for core marketplace links because it cannot enforce referential integrity.

## 8.4 Content lifecycle

```text
Draft
→ Scheduled
→ Published
→ Archived
→ Deleted
```

Moderation is a separate overlay:

```text
Pending Review
Approved
Limited
Removed
Appealed
```

A post may be `Published` while a later moderation action changes its visibility or feed eligibility. Deletion should preserve a tombstone/audit reference where required.

## 8.5 Visibility

Recommended visibility:

```text
Public
Followers
Unlisted
Private Draft
Restricted
```

Visibility must be checked with:

- author account status;
- block relationships;
- moderation;
- linked object permissions;
- scheduled time.

## 8.6 Content interactions

### Comment

Comment contains:

- comment ID;
- post/source reference;
- author;
- parent comment reference;
- body;
- status/moderation state;
- timestamps.

### Reaction

Reaction contains:

- user;
- source content;
- reaction type;
- created/updated timestamp.

Use a uniqueness constraint for one active reaction per user/source/type where product rules require it.

### Save

Save contains:

- user;
- saved object type/reference;
- collection or folder reference if later supported;
- created timestamp.

The saved object may be a Post, Product, Service, Project, or Contest. Typed save relationships are preferable for core entities.

### Share

Share records the action and attribution:

- user if authenticated;
- source object;
- destination/context if available;
- created timestamp;
- privacy-safe campaign/source data.

Shares should not expose private content or private order context.

## 8.7 Specialized content decision

Use one universal Post for social presentation, and separate specialized entities for marketplace truth:

```text
Post
→ optional Product
→ optional Service
→ optional Project
→ optional Contest
```

Do not model a product listing, service listing, project brief, or contest solely as a Post. Their pricing, availability, proposals, entries, delivery, and ownership rules require dedicated entities.

---

# 9. Media & File Data Model

## 9.1 Storage rule

Large binary files must not be stored directly in PostgreSQL.

Use external object storage:

```text
Application
→ Media metadata in PostgreSQL
→ Private/public object-storage key
→ Authorized upload/download URL
```

The database stores references and policy, not binary content.

## 9.2 Media entity

`Media` is the common metadata record for:

- images;
- videos;
- thumbnails;
- documents;
- source files;
- project attachments;
- product files;
- contest entries;
- chat files;
- delivery files.

Core attributes:

- Media ID;
- owner User;
- uploader User;
- storage provider;
- bucket/container reference;
- object key/path reference;
- MIME type;
- original filename;
- sanitized display filename;
- file size in bytes;
- checksum/hash;
- media kind;
- dimensions/duration where applicable;
- upload status;
- scan status;
- visibility;
- access level;
- created timestamp;
- deleted/retention state.

Storage credentials and signed URLs are never persisted as permanent file permissions.

## 9.3 Media lifecycle

```text
Upload Initiated
→ Uploading
→ Uploaded
→ Scanning
→ Available
→ Restricted/Quarantined
→ Archived
→ Deleted/Expired
```

The application should not expose a file as available until:

- upload completion is verified;
- checksum/size is recorded;
- malware/policy scan rules pass;
- ownership/access policy is attached;
- the referencing object is allowed to publish.

## 9.4 Access levels

Access level describes the broad file policy:

```text
Public Preview
Authenticated Public
Owner Only
Private Participant
Order Entitled
Exclusive Owner
Admin Audited
Quarantined
```

Actual access still requires:

- authenticated user;
- relation to the object/order;
- active entitlement or ownership;
- no refund/dispute/policy block;
- file included in the relevant version.

## 9.5 Media relationships

Use typed bridge records:

```text
PostMedia
ProjectAttachment
ProposalAttachment
ContestEntryFile
ServiceMedia
ProductFile
ProductPreview
ChatAttachment
DeliveryItem
```

These bridges preserve:

- role/purpose;
- display order;
- preview state;
- file label;
- created timestamp;
- source/reference context.

One Media record may be referenced in more than one context only when product policy allows it. A private delivery copy may require a distinct access-controlled relationship even when the underlying asset originated elsewhere.

## 9.6 File ownership

`Media.ownerUserId` identifies the user or creator account responsible for the asset at upload/creation time.

Ownership of a file is not the same as access:

- a creator can own a private source file;
- a buyer can receive a license/access grant;
- an exclusive buyer can receive ownership rights;
- a contest entry can remain creator-owned until rights transfer;
- a platform-generated preview can be platform-managed but derived from creator media.

## 9.7 Object storage relationship

Object storage contains:

- bucket/container;
- object key;
- binary bytes;
- optional generated derivatives.

PostgreSQL contains:

- Media identity;
- owner/uploader;
- object reference;
- checksum;
- file metadata;
- lifecycle;
- scan state;
- visibility/access policy;
- relationships to Products, Posts, Projects, Orders, Conversations, and Deliveries.

The client must never construct unrestricted object-storage URLs from a database path.

## 9.8 Derivatives

Images and videos may have derived Media records:

- thumbnail;
- poster frame;
- compressed preview;
- watermarked preview;
- transcoded format;
- waveform or metadata derivative.

Each derivative references:

- source Media;
- derivative purpose;
- generation status;
- transformation version.

The original remains the source asset unless a product explicitly replaces it with a new version.

---

# 10. Project Data Model

## 10.1 Project definition

`Project` is a buyer-created hiring brief or opportunity. It is distinct from:

- a Service, which is a creator-defined offer;
- a Product, which is a pre-made asset;
- a Contest, which uses entry-based selection;
- a Project Contract, which is created after a proposal is accepted.

## 10.2 Project attributes

Core:

- Project ID;
- owner/buyer User;
- BuyerProfile reference;
- title;
- short description;
- full brief;
- category;
- skills;
- project type;
- budget mode;
- budget minimum/maximum or fixed budget;
- currency;
- target deadline;
- timezone;
- buyer dependency assumptions;
- visibility;
- proposal settings;
- status;
- selected creator reference;
- selected proposal reference;
- related contest reference if converted;
- related Order/ProjectContract reference after selection;
- related Conversation reference;
- created/updated/published/closed timestamps.

## 10.3 Project types

Examples:

```text
fixed_scope
open_budget
hiring_request
invite_only
milestone
ongoing
```

Recurring/retainer behavior may be supported later but should not force recurring payment fields into the base Project now.

## 10.4 Project status

```text
Draft
→ Open
→ Reviewing Proposals
→ Shortlisted
→ Creator Selected
→ In Progress
→ Awaiting Delivery
→ Revision Requested
→ Completed
→ Closed
```

Alternative or overlay states:

```text
Paused
Cancelled
Expired
Disputed
```

The selected creator and selected proposal are references to historical records, not free-text fields.

## 10.5 ProjectAttachment

`ProjectAttachment` connects a Project to Media.

Attributes:

- ProjectAttachment ID;
- project;
- media;
- attachment kind;
- display order;
- buyer-provided/creator-added indicator;
- visibility;
- created timestamp.

Attachment kinds:

```text
brief_reference
brand_asset
requirements
inspiration
technical_document
private_buyer_attachment
```

The ProjectAttachment controls context access. A public project can have private buyer attachments.

## 10.6 Project relationships

```text
Project
├── ProjectAttachment
├── ProjectSkill
├── ProjectProposal
├── ProjectShortlist
├── ProjectSelection
├── ProjectContract
├── Order
├── Conversation
└── optional Contest conversion
```

### Proposal

A Project has many proposals. A Creator can submit proposals to many Projects.

### Shortlist

Shortlist is buyer-private and references a Proposal, not merely a User, so proposal versions and historical context remain clear.

### Selected creator

Store selected Proposal and selected Creator references. The selected Creator can be derived from the Proposal, but an explicit selection record preserves the decision event and actor.

### Order

The accepted proposal creates a ProjectContract and then a universal Order. The Project remains the hiring context; the Order becomes the fulfillment source of truth.

### Conversation

Project conversations may exist before selection. After selection, the active fulfillment Conversation references the ProjectContract/Order context rather than changing the original proposal history.

### Contest conversion

If a buyer converts a Project into a Contest:

- preserve the original Project;
- create a Contest with an explicit source project reference;
- record the conversion actor/time;
- do not silently transform existing proposals into contest entries;
- define whether proposals are closed, archived, or retained as history.

---

# 11. Proposal / Bidding Data Model

## 11.1 Proposal definition

`ProjectProposal` is a creator's structured offer to complete a Project.

It is not:

- a contest entry;
- a Service booking;
- a Chat message;
- an Order;
- an ownership record.

## 11.2 ProjectProposal attributes

- Proposal ID;
- project;
- creator User;
- CreatorProfile;
- current ProposalVersion reference;
- status;
- submitted timestamp;
- withdrawn timestamp;
- selected/rejected/expired timestamp;
- buyer-visible response state;
- private creator notes where permitted;
- source Conversation reference.

## 11.3 ProposalVersion

Every material proposal change creates a new immutable ProposalVersion.

Attributes:

- version ID;
- proposal;
- version number;
- price;
- currency;
- delivery estimate;
- earliest start date;
- milestone summary;
- revision count;
- deliverables;
- scope assumptions;
- exclusions;
- usage/license assumptions;
- pitch;
- buyer questions;
- expiration;
- created by;
- created timestamp.

The current version is a pointer. Historical versions remain available to authorized participants.

## 11.4 ProposalStatus

Recommended states:

```text
Draft
Submitted
Viewed
Shortlisted
Clarification Requested
Negotiating
Selected
Declined
Withdrawn
Expired
Superseded
```

The status does not replace Project status. A project can have many proposals in different states.

## 11.5 ProposalAttachment

ProposalAttachment may reference:

- Media;
- Showcase Post;
- Product;
- Service;
- Case study;
- external portfolio reference where allowed.

Prefer typed references for internal entities. Preserve:

- relevance note;
- display order;
- creator-selected proof context;
- visibility.

## 11.6 Bid terminology

The product may use “bid” in UI or analytics, but the durable model should use `ProjectProposal`/`ProposalVersion`.

If a separate `Bid` entity is retained for compatibility:

- it should reference a Proposal;
- it should not duplicate price, creator, or project;
- it may represent a submitted proposal action or marketplace index;
- it must not become a second negotiation source of truth.

## 11.7 Shortlist

`ProjectShortlist` records buyer-private decisions:

- shortlist ID;
- project;
- proposal;
- buyer;
- status (`shortlisted`, `removed`, `archived`);
- private note;
- created/updated timestamps.

Do not notify creators about every private shortlist removal unless a product policy explicitly requires it.

## 11.8 Historical integrity

A creator can submit proposals across many projects. Each proposal keeps:

- original project;
- creator;
- all material versions;
- samples;
- status history;
- buyer interactions;
- selection outcome.

A selected Proposal is not overwritten by the resulting Order. It remains negotiation history; the ProjectContract/Order is the fulfillment source of truth.

---

# 12. Contest Data Model

## 12.1 Contest definition

`Contest` is a buyer-hosted competition with published rules, entry criteria, judging period, and a funded or otherwise authorized prize.

It is separate from a Project proposal flow.

## 12.2 Contest attributes

- Contest ID;
- host/buyer User;
- BuyerProfile;
- title;
- brief;
- category;
- required skills/formats;
- public/private visibility;
- invitation rules;
- entry start/deadline;
- judging start/end;
- winner announcement date;
- entry limits;
- judging criteria;
- prize reference;
- rights/ownership terms;
- status;
- selected winner reference;
- related Order after winner selection;
- related Conversation where allowed;
- created/updated timestamps.

## 12.3 Contest status

```text
Draft
→ Funded/Ready
→ Open for Entries
→ Closed for Entries
→ Judging
→ Winner Selected
→ Winner Confirming
→ Prize Fulfillment
→ Completed
```

Alternative states:

```text
Paused
Cancelled
Prize Issue
Disputed
Expired
```

Prize funding state is separate from Contest status and will connect to financial records in Part 2.

## 12.4 ContestEntry

`ContestEntry` records one creator submission.

Attributes:

- Entry ID;
- contest;
- creator User;
- CreatorProfile;
- title/label;
- description/concept note;
- submission version;
- entry status;
- submitted timestamp;
- withdrawn timestamp;
- moderation state;
- creator ownership state;
- finalist/winner references;
- related Conversation if contest rules allow.

Entry status:

```text
Draft
Submitted
Under Review
Shortlisted
Finalist
Winner
Runner-up
Not Selected
Withdrawn
Disqualified
```

## 12.5 EntryFile

`ContestEntryFile` connects ContestEntry to Media.

It preserves:

- file role;
- version;
- display order;
- preview/full submission state;
- source-file state;
- access policy;
- created timestamp.

Entry files remain creator-controlled until the published contest rights and ownership terms take effect.

## 12.6 ContestShortlist

ContestShortlist records:

- contest;
- entry;
- judge/host;
- stage;
- private/public note where supported;
- decision timestamp.

Shortlisting is distinct from winning. A finalist can be shortlisted without receiving rights or prize funds.

## 12.7 ContestWinner

ContestWinner records:

- contest;
- winning entry;
- winning creator;
- rank/result;
- selection actor;
- selected timestamp;
- confirmation status;
- fallback/runner-up reference;
- winner order reference;
- rights transfer status.

Winner selection must not itself be treated as final ownership transfer. Prize fulfillment and rights confirmation remain separate steps.

## 12.8 ContestPrize

`ContestPrize` contains:

- prize ID;
- contest;
- amount/value;
- currency;
- prize type;
- funding status;
- funding/payment reference;
- payout/fulfillment status;
- rights included;
- delivery requirements.

The prize may be:

- cash;
- fixed product/service;
- contract opportunity;
- licensing/ownership award;
- mixed prize.

## 12.9 ContestOwnership

`ContestOwnership` records rights transfer when contest rules require it:

- contest;
- entry;
- winner;
- host/buyer;
- ownership type;
- rights scope;
- effective date;
- source-file status;
- transfer condition;
- related Order;
- reversal/dispute reference.

Non-winning entries do not receive a ContestOwnership record unless separately purchased or licensed.

---

# 13. Service Data Model

## 13.1 Service definition

`Service` is a creator-defined offer to perform bounded work for a buyer.

It is separate from:

- Product, which is a pre-made asset;
- Project, which is a buyer broadcast brief;
- Proposal, which is a creator response to a Project.

## 13.2 Service attributes

- Service ID;
- creator User;
- CreatorProfile;
- title;
- outcome statement;
- description;
- category;
- skills/tags;
- status;
- visibility;
- availability state;
- package mode;
- requirements;
- FAQ;
- portfolio proof;
- rating/review summary;
- created/updated/published timestamps.

## 13.3 Service status

```text
Draft
→ Pending Review
→ Published
→ Paused
→ Archived
→ Moderated/Restricted
```

Existing Orders remain valid when a Service listing is paused or archived.

## 13.4 ServicePackage

Each Service has one or more packages:

- package ID;
- service;
- package name;
- tier (`basic`, `standard`, `premium`, `custom`);
- description;
- price;
- currency;
- delivery time;
- delivery unit;
- revisions included;
- deliverables;
- source-file status;
- license/usage status;
- requirements;
- add-on eligibility;
- active state;
- display order.

Basic is required for the MVP package model. Standard and Premium are optional.

Package data is snapshotted into a Service Order/Order at purchase time. Later listing edits do not rewrite active orders.

## 13.5 ServiceMedia

ServiceMedia connects a Service to:

- cover image;
- preview gallery;
- portfolio sample;
- case study;
- related Showcase Post;
- product proof.

It stores purpose, order, caption/relevance note, and visibility.

## 13.6 ServiceRequirement

Requirements describe buyer inputs needed to begin:

- requirement ID;
- service/package;
- prompt/label;
- response type;
- required/optional;
- validation rules;
- display order;
- private/access policy.

Submitted responses belong to the resulting Order/fulfillment context, not only to the reusable Service definition.

## 13.7 Service availability

ServiceAvailability or equivalent fields control:

- published/paused state;
- capacity;
- queue estimate;
- accepting new orders;
- vacation mode;
- category availability;
- creator restriction.

Availability must not cancel existing orders.

## 13.8 ServiceOrder relationship

The service does not create a parallel order system.

```text
Service
→ ServicePackage
→ Universal Order
→ ServiceOrder extension
```

The extension references:

- service;
- package;
- purchased requirements;
- package snapshot;
- revision allowance;
- delivery terms.

Universal payment, delivery, refund, dispute, review, and payout records remain shared.

---

# 14. Digital Product Data Model

## 14.1 Product definition

`Product` is a creator-owned digital asset or bundle sold under a defined license and delivery policy.

Supported examples:

- AI reels;
- thumbnail packs;
- graphics;
- video assets;
- templates;
- prompt packs;
- source files;
- creative bundles.

## 14.2 Product attributes

- Product ID;
- creator User;
- CreatorProfile;
- title;
- value statement;
- full description;
- product type;
- category;
- tags;
- cover/thumbnail Media;
- current ProductVersion;
- default ProductLicense;
- pricing summary;
- availability/sales state;
- exclusive state;
- update policy;
- support policy;
- refund eligibility;
- moderation state;
- created/updated/published timestamps.

## 14.3 Product lifecycle

```text
Draft
→ Pending Review
→ Published
→ Paused
→ Archived
→ Sold/Locked for exclusive product
```

Product listing state and version state are separate:

- a listing can be active while a new version is processing;
- a product can be archived while historical buyers retain access;
- an exclusive product becomes Sold/Locked after ownership commits.

## 14.4 ProductVersion

`ProductVersion` is an immutable or append-only release snapshot.

Attributes:

- version ID;
- product;
- version label/number;
- changelog;
- compatibility;
- release status;
- published timestamp;
- update eligibility;
- malware/scan state;
- created by.

A later version must not rewrite the files or license terms of a completed historical purchase.

## 14.5 ProductFile

ProductFile connects a ProductVersion to Media.

Attributes:

- ProductFile ID;
- product version;
- media;
- file role;
- relative label/path;
- included/excluded state;
- buyer access policy;
- license restriction;
- display order.

File roles:

```text
delivery
documentation
source
license_restricted
preview_reference
```

ProductFile metadata does not make the underlying Media public. Access is controlled by entitlement/license/ownership rules.

## 14.6 ProductPreview

ProductPreview connects a Product or ProductVersion to preview Media:

- cover;
- gallery image;
- preview video;
- sample page;
- watermarked sample;
- file-tree screenshot;
- before/after example.

Preview records explicitly identify whether a file is safe for public display.

## 14.7 ProductLicense

`ProductLicense` defines buyer rights:

- license ID;
- product/version reference;
- license type;
- title and summary;
- personal/commercial/team scope;
- seat/user limits;
- client-work permission;
- modification permission;
- source-file rights;
- attribution requirements;
- resale/redistribution restrictions;
- AI/model-input restrictions;
- exclusive status;
- effective dates;
- version.

The purchased license is snapshotted into the Order/entitlement. Future license changes apply to future purchases unless an explicit update policy says otherwise.

License types:

```text
standard
commercial
team
exclusive
custom
```

## 14.8 ProductCategory

ProductCategory is a shared taxonomy/facet record:

- category ID;
- parent category;
- display name;
- slug;
- active state;
- marketplace/feed visibility;
- sort order.

Products may also have normalized ProductTag/Skill relationships rather than a single comma-separated string.

## 14.9 ProductPurchase

`ProductPurchase` is a bridge between:

- buyer;
- Product;
- ProductVersion;
- ProductLicense;
- universal Order;
- entitlement/access grant;
- refund/revocation state.

It is not a second order.

Attributes:

- ProductPurchase ID;
- order;
- buyer;
- product;
- purchased version;
- license snapshot/reference;
- entitlement state;
- access granted timestamp;
- access revoked timestamp;
- purchase/refund state;
- created timestamp.

## 14.10 Exclusive products

For exclusive products:

```text
Product
→ universal Order
→ ProductPurchase
→ Ownership
→ Sold/Locked listing state
```

The Ownership record is authoritative for exclusive rights. Product availability is updated atomically with the successful ownership assignment as defined in the final Order architecture.

## 14.11 Product creator ownership

The creator remains the listing owner until a successful exclusive transfer or rights agreement. Product listing ownership, file ownership, buyer entitlement, and exclusive buyer ownership are distinct concepts and must not be collapsed into one `ownerId` field.

---

# Database Foundation Decisions

These decisions must remain consistent in Parts 2 and 3:

1. PostgreSQL is the primary operational source of truth.
2. The overall platform uses a relational-first hybrid architecture.
3. Object storage holds binary files; PostgreSQL stores metadata, references, lifecycle, and access policy.
4. Search, cache, queues, and analytics stores are derived/supporting systems, not competing sources of truth.
5. NeuralMart has one User identity, one Profile, one wallet, one inbox, and one order history per account.
6. Buyer and Creator capabilities are additive; `Both` is not a second account.
7. Freelancer, Contest Participant, and Digital Seller are creator activities/capabilities, not separate account silos.
8. Admin remains a separate staff capability and should not be mixed with ordinary marketplace participation in one staff account.
9. Active role/context changes the default surface, not permissions or identity.
10. User contains authentication/account state; Profile contains shared public identity; role-specific profiles contain only role-specific data.
11. FreelancerProfile is an optional specialization under CreatorProfile, not a separate user or role.
12. Creator, Buyer, Product, Service, Project, Contest, and Post remain separate domain concepts.
13. Products, Services, Projects, and Contests are not modeled only as Posts.
14. One Post can appear in multiple surfaces through eligibility/projection references; content is never copied per feed.
15. Core marketplace links use typed foreign-key relationships where possible; unconstrained polymorphic IDs are avoided for authoritative relationships.
16. Feed records and feed projections reference source objects; they do not own content truth.
17. Media metadata is relational, but large binaries remain outside the primary database.
18. File access is separate from file ownership and depends on entitlement, ownership, order, and policy.
19. Product versions, proposal versions, delivery versions, licenses, and commercial terms preserve history rather than being overwritten.
20. A selected proposal becomes Project Contract/Order history; the proposal remains negotiation history and the Order becomes fulfillment truth.
21. Contest entries are not proposals, and contest winners do not automatically equal ownership transfer.
22. Service packages and ProductPurchase records extend shared commerce; they do not create parallel order systems.
23. Derived counters are rebuildable summaries; underlying relationship and transaction records remain authoritative.
24. Deactivation or deletion must not cascade-delete financial, ownership, order, dispute, or audit history.
25. Part 2 must connect these entities to the universal Order, Payment, Wallet, Delivery, Access, Ownership, Chat, Review, Refund, Dispute, and Notification records without duplicating them.
26. Part 3 must define indexing, search/read models, analytics storage, security boundaries, retention, migrations, backups, and operational reliability on top of this foundation.
