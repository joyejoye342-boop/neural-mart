# NeuralMart — Creator Contest Participation Experience

**Document version:** 1.0  
**Audience:** Creator and Both users operating as creators  
**Primary entry:** `/contest-feed` → `/contests/:id`

---

## 0. Participation Goal

Creator contest participation should help a creator answer:

1. Is this contest legitimate and worth my time?
2. Can I make a strong entry within the rules and deadline?
3. What exactly do I need to submit?
4. What is happening to my entry after submission?

The experience must never make creators guess whether the prize is funded, what rights they are giving up, or whether the buyer can use non-winning work.

---

## 1. Discovering Contests

Creators discover contests through:

- Opportunities Feed;
- saved searches;
- creator dashboard opportunity module;
- category pages;
- notifications for followed categories/hosts;
- contest links from creator profiles or messages.

The contest card shows:

```text
[Contest] Logo Design Challenge
$500 funded · Ends in 4 days
Branding · Vector · 23 entries
Hosted by Greenline · ✓ Verified
[Submit entry]
```

### Feed filters

- Category
- Skills
- Prize range
- Deadline
- Entry count
- Blind/open judging
- Public/invite-only eligibility
- Rights/ownership
- Host verification
- Saved/not saved

### Ranking

Recommended contest ranking uses:

```text
Skill/category fit
→ Prize and effort fit
→ Deadline urgency
→ Host trust
→ Competition level
→ Freshness
```

High prize alone must not dominate if the contest is a poor fit or has unclear rights.

---

## 2. Contest Evaluation Experience

Before showing `Submit entry`, the contest page should expose a decision summary:

```text
SHOULD I ENTER?
Prize                 $500 funded
Time left             4 days
Expected deliverables 3 files
Judging               Host-selected · 4 criteria
Rights                Winner receives stated usage rights
Competition           23 entries
Host                  Verified · 1 completed contest
```

### Creator evaluation checklist

- Is the prize funded?
- Is the brief specific enough?
- Can I produce the required deliverables?
- Is the deadline realistic?
- What is the expected effort?
- What does the winner receive?
- What happens to non-winning work?
- Are source files required?
- Is judging blind or identified?
- Is feedback provided?
- Does the host have a reliable history?

### Save without committing

Creators can:

- Save contest;
- add a private note;
- set a reminder;
- hide contest;
- compare with other saved contests.

The interface should not pressure a creator into starting an entry before the rules are understood.

---

## 3. Entry Submission Flow

```text
Start entry
→ Review rules
→ Add primary preview
→ Add concept and metadata
→ Add supporting files
→ Confirm rights/originality
→ Preview
→ Submit
```

### Step 1 — Rules confirmation

Show a concise checklist:

```text
Required:
✓ 1 logo concept
✓ Black-and-white version
✓ Short rationale
✓ PNG or JPG preview
```

Also show:

- entry limit;
- edit deadline;
- source-file policy;
- winner rights;
- feedback policy.

### Step 2 — Primary entry

Support:

- image;
- video;
- audio;
- design preview;
- document/PDF;
- link, where appropriate.

Generate a preview automatically and retain the original file privately.

### Step 3 — Entry metadata

Required:

- entry title;
- short concept summary;
- originality/rights declaration.

Optional:

- design/process rationale;
- tools used;
- deliverables included;
- accessibility description;
- portfolio link;
- alternate concept;
- implementation notes.

### Step 4 — Supporting files

Possible attachments:

- preview variations;
- mockups;
- PDF rationale;
- compressed demo;
- style frames;
- usage examples;
- source files if the contest requires them.

Rules:

- show type, size, and upload progress;
- scan uploads;
- warn before adding private client material;
- label source files as private or winner-delivery;
- do not expose source files to the host before the rules allow it.

### Step 5 — Submission preview

```text
YOUR ENTRY
Logo Concept A
2 previews · 1 rationale PDF

This entry will be visible to:
Greenline Studio
Entry status: Submitted

By submitting, you confirm the work is original and accept
the published contest rules.
[Submit entry]
```

After submission:

- show confirmation;
- show exact submitted version;
- show edit deadline;
- route to `My contests`;
- allow sharing the contest link, not hidden entry files.

---

## 4. Entry Metadata and Versioning

Every submission has:

- entry ID;
- contest ID;
- creator ID;
- version number;
- submitted timestamp;
- files;
- metadata;
- status;
- feedback;
- rights state.

### Version behavior

- Before deadline: creator can replace or update the entry if allowed.
- Each update creates a version record.
- The host sees the current eligible version by default.
- The creator can view prior versions privately.
- After entry close: entry is locked.
- During finalist revisions: a separate revision version is created.

Avoid silent overwrites. Creators should always know which version is being judged.

---

## 5. Revisions

### Before deadline

Creators may edit their entry according to the contest rules:

```text
Edit entry
→ Update files/metadata
→ Add version note
→ Confirm replacement
```

### After deadline

No ordinary edits. This protects fairness.

### Finalist revision

If the contest supports finalist revisions, the creator sees:

```text
REVISION REQUEST
Clarify the mobile icon version.
Due Apr 30 · 1 revision round remaining
[Accept] [Decline]
```

The request must be within the published contest scope. A creator can decline without losing the original submitted entry.

### Winner revision

Winner revisions are limited to the published terms. Additional changes become a new paid project or order:

```text
This request is outside the contest terms.
[Offer paid follow-on] [Decline politely]
```

Creators never owe unlimited unpaid revisions because they won.

---

## 6. Feedback and Status

### Creator-facing status timeline

```text
Submitted
→ Entry deadline passed
→ Judging
→ Shortlisted
→ Finalist / Revision requested
→ Winner or Not selected
→ Payout pending
→ Paid
```

### Feedback visibility

Feedback can be:

- private to the creator;
- visible to finalists;
- public summary after completion.

The creator sees the policy before entering.

### Feedback format

Prefer structured criteria:

```text
Brand fit       Strong
Originality     Needs clarification
Usability       Strong
Presentation    Strong

Host note:
The concept fits the audience well. Please clarify the small-size mark.
```

Do not expose private notes, internal host comparisons, or other creators' submissions.

### Not selected state

Use a respectful, informative state:

```text
Not selected
The host selected another entry.
Your work remains yours under the contest rules.
[View feedback] [Offer as portfolio work]
```

Do not show a public failure label.

---

## 7. Creator Contest Tracking Hub

Add a `My Contests` section to the Creator Dashboard or Opportunities area.

### Tabs

```text
Saved
In progress
Submitted
Shortlisted
Finalists
Won
Completed
Not selected
```

### Active contest card

```text
Logo Design Challenge
Your entry: Submitted · v2
Judging starts in 1 day
$500 funded
[View contest] [View entry]
```

### Needs Attention

- Draft entry incomplete
- Required file missing
- Contest deadline approaching
- Revision request received
- Finalist response due
- Winner confirmation required
- Payout setup incomplete

### Notifications

Notify creators for:

- contest closing soon;
- entry accepted;
- shortlist/finalist selection;
- feedback received;
- revision request;
- winner selection;
- payout state;
- contest cancellation or dispute.

Notification text must include the contest name and the next action.

---

## 8. Creator Safety and Decision Support

Before entry, display:

- funded state;
- host verification;
- host contest history;
- rights terms;
- source-file expectations;
- cancellation policy;
- feedback policy;
- report action.

Creators can report:

- copied brief or work request;
- misleading prize;
- hidden ownership terms;
- off-platform payment pressure;
- abusive feedback;
- suspicious voting or selection.

The creator should never have to submit a private password, token, or payment credential to enter or receive a prize.

---

## 9. MVP vs Advanced Participation

### MVP

- Discover contests in Opportunities Feed
- Contest detail with clear prize/deadline/rights
- Save contest
- One entry per creator by default
- Upload preview and supporting files
- Concept title and description
- Originality confirmation
- Edit until deadline
- Status tracking
- Shortlist/finalist/winner notifications
- Basic private feedback
- Winner payout status
- Linked post-contest chat

### Advanced

- Blind judging
- Multiple entry variants
- Team entries
- Multi-stage rounds
- Paid finalist revisions
- Entry analytics
- Creator contest portfolio
- Saved-search alerts
- Contest comparison
- Public result galleries
- Advanced rights/licensing options
- Automated originality and duplicate detection

## Final rule

The creator contest experience should make participation feel deliberate and professional: creators understand the opportunity before spending time, submit a protected and well-presented entry, receive clear status changes, and can turn a strong contest relationship into paid work without unpaid scope creep.
