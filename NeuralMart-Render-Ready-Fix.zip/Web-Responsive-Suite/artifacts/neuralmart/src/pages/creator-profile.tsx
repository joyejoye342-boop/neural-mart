import React from 'react';
import { useGetCreator, useListPosts, useListProducts, useGetMe } from '@workspace/api-client-react';
import { useParams, Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MapPin, Link as LinkIcon, Calendar, MessageSquare, UserPlus, Star, BadgeCheck } from 'lucide-react';
import { format } from 'date-fns';

export default function CreatorProfile() {
  const { id } = useParams();
  const creatorId = parseInt(id || '0');
  
  const { data: currentUser } = useGetMe();
  const { data: creator, isLoading } = useGetCreator(creatorId);
  const { data: postsData } = useListPosts({ creatorId, limit: 10 }, { query: { enabled: !!creatorId } as any });
  const { data: productsData } = useListProducts({ creatorId, limit: 10 }, { query: { enabled: !!creatorId } as any });

  const isOwnProfile = currentUser?.id === creatorId;

  if (isLoading) return <ProfileSkeleton />;
  if (!creator) return <div className="text-center py-20">Creator not found.</div>;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-16">
      {/* Cover Image */}
      <div className="h-48 md:h-64 lg:h-80 w-full rounded-b-3xl md:rounded-3xl overflow-hidden bg-muted relative -mt-4 md:mt-0 shadow-lg">
        {creator.coverUrl ? (
          <img src={creator.coverUrl} className="w-full h-full object-cover" alt="cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-tr from-primary/40 to-accent/40" />
        )}
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="flex flex-col md:flex-row gap-6 relative -mt-16 md:-mt-24">
          
          {/* Avatar & Left Sidebar */}
          <div className="w-full md:w-1/3 lg:w-1/4 flex flex-col gap-6">
            <Avatar className="w-32 h-32 md:w-48 md:h-48 border-4 border-background shadow-xl bg-muted">
              <AvatarImage src={creator.avatarUrl || ''} />
              <AvatarFallback className="text-4xl bg-primary/10 text-primary">{creator.displayName?.charAt(0)}</AvatarFallback>
            </Avatar>

            <div className="space-y-4">
              <div>
                <h1 className="text-3xl font-serif font-bold tracking-tight">{creator.displayName}</h1>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-muted-foreground font-medium">{creator.category || 'Creator'}</span>
                  {creator.rating > 0 && (
                    <div className="flex items-center text-accent text-sm font-bold bg-accent/10 px-2 py-0.5 rounded">
                      <Star className="w-3 h-3 fill-accent mr-1" />
                      {creator.rating.toFixed(1)}
                    </div>
                  )}
                </div>
              </div>

              {!isOwnProfile && (
                <div className="flex gap-3">
                  <Button className="flex-1 font-bold shadow-md">
                    <UserPlus className="w-4 h-4 mr-2" /> Follow
                  </Button>
                  <Button variant="secondary" size="icon" className="shrink-0">
                    <MessageSquare className="w-4 h-4" />
                  </Button>
                </div>
              )}

              {isOwnProfile && (
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/profile/edit">Edit Profile</Link>
                </Button>
              )}

              <div className="text-sm text-muted-foreground whitespace-pre-wrap">
                {creator.bio || 'No bio provided.'}
              </div>

              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" /> Joined {format(new Date(creator.createdAt), 'MMMM yyyy')}
                </div>
                <div className="flex items-center gap-2">
                  <LinkIcon className="w-4 h-4" /> {creator.followersCount} followers
                </div>
              </div>

              {creator.badges && creator.badges.length > 0 && (
                <div className="pt-4 border-t border-border">
                  <h3 className="font-semibold text-sm mb-3">Badges</h3>
                  <div className="flex flex-wrap gap-2">
                    {creator.badges.map((b: any) => (
                      <div key={b.id} title={b.badge.name} className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-xl border border-border shadow-sm">
                        {b.badge.icon}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {creator.skills && creator.skills.length > 0 && (
                <div className="pt-4 border-t border-border">
                  <h3 className="font-semibold text-sm mb-3">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {creator.skills.map((skill: string) => (
                      <span key={skill} className="text-xs px-2 py-1 bg-muted rounded-md border border-border font-medium">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Main Content */}
          <div className="w-full md:w-2/3 lg:w-3/4 md:mt-28">
            <Tabs defaultValue="posts" className="w-full">
              <TabsList className="w-full bg-transparent border-b border-border rounded-none h-12 justify-start gap-6 p-0 mb-6">
                <TabsTrigger value="posts" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-full">
                  Showcase
                </TabsTrigger>
                <TabsTrigger value="products" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-full">
                  Products
                </TabsTrigger>
              </TabsList>

              <TabsContent value="posts" className="space-y-6">
                {!postsData?.posts.length ? (
                  <div className="text-center py-12 text-muted-foreground bg-card border border-border rounded-xl">
                    No posts yet.
                  </div>
                ) : (
                  postsData.posts.map((post: any) => (
                    <Card key={post.id} className="bg-card border-border shadow-sm">
                      <CardContent className="p-5">
                        <p className="whitespace-pre-wrap text-sm mb-4">{post.content}</p>
                        {post.mediaUrl && (
                          <div className="rounded-xl overflow-hidden bg-muted">
                            <img src={post.mediaUrl} className="w-full h-auto max-h-[500px] object-cover" alt="Post media" />
                          </div>
                        )}
                        <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground font-medium">
                          <span>{post.likesCount} likes</span>
                          <span>{post.commentsCount} comments</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="products">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {!productsData?.products.length ? (
                    <div className="col-span-full text-center py-12 text-muted-foreground bg-card border border-border rounded-xl">
                      No products available.
                    </div>
                  ) : (
                    productsData.products.map((product: any) => (
                      <Link key={product.id} href={`/products/${product.id}`}>
                        <Card className="hover:border-primary/50 transition-colors cursor-pointer group bg-card overflow-hidden h-full">
                          <div className="aspect-[4/3] bg-muted relative">
                            {product.previewImageUrl && (
                              <img src={product.previewImageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={product.title} />
                            )}
                            <div className="absolute top-3 right-3 bg-background/90 backdrop-blur-md px-3 py-1 rounded-full text-sm font-bold shadow-sm">
                              ${product.price}
                            </div>
                          </div>
                          <CardContent className="p-4">
                            <h3 className="font-bold text-lg line-clamp-1 mb-1 group-hover:text-primary transition-colors">{product.title}</h3>
                            <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                          </CardContent>
                        </Card>
                      </Link>
                    ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
        </div>
      </div>
    </div>
  );
}

function ProfileSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-64 w-full rounded-3xl" />
      <div className="max-w-5xl mx-auto px-4 flex gap-6 -mt-16 relative">
        <div className="w-1/4 space-y-4">
          <Skeleton className="w-48 h-48 rounded-full border-4 border-background" />
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-10 w-full" />
        </div>
        <div className="w-3/4 mt-24 space-y-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      </div>
    </div>
  );
}