import React, { useState } from 'react';
import { useListOrders, useGetMe } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Link } from 'wouter';
import { formatDistanceToNow, format } from 'date-fns';
import { Package, Filter, Download, MessageSquare, ExternalLink } from 'lucide-react';

export default function Orders() {
  const { data: user } = useGetMe();
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  
  const { data: ordersData, isLoading } = useListOrders(undefined, { query: { enabled: !!user } as any });

  if (!user) return null;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12 pt-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-2">
        <div>
          <h1 className="text-4xl font-serif font-bold tracking-tight mb-2">Order History</h1>
          <p className="text-lg text-muted-foreground">Track your purchases and sales.</p>
        </div>
        <Button variant="outline" size="sm" className="gap-2 self-start md:self-auto">
          <Filter className="w-4 h-4" /> Filter
        </Button>
      </div>

      <Tabs defaultValue="buyer" onValueChange={(v: any) => setRole(v)} className="w-full">
        <TabsList className="h-12 p-1 bg-muted rounded-xl mb-6 inline-flex">
          <TabsTrigger value="buyer" className="rounded-lg data-[state=active]:bg-card data-[state=active]:shadow-sm px-8">
            Buying
          </TabsTrigger>
          {(user.role === 'creator' || user.role === 'both') && (
            <TabsTrigger value="seller" className="rounded-lg data-[state=active]:bg-card data-[state=active]:shadow-sm px-8">
              Selling
            </TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value={role} className="mt-0 space-y-4">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full rounded-xl" />
            ))
          ) : !ordersData?.orders.length ? (
            <div className="text-center py-20 bg-card rounded-2xl border border-border">
              <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">No orders found</h3>
              <p className="text-muted-foreground mb-6">
                {role === 'buyer' 
                  ? "You haven't purchased anything yet." 
                  : "You don't have any sales yet."}
              </p>
              <Link href={role === 'buyer' ? '/products' : '/dashboard/creator'}>
                <Button>{role === 'buyer' ? 'Explore Products' : 'Go to Dashboard'}</Button>
              </Link>
            </div>
          ) : (
            ordersData.orders.map((order: any) => {
              const otherUser = role === 'buyer' ? order.seller : order.buyer;
              const isProduct = order.type === 'product';
              
              return (
                <Card key={order.id} className="bg-card border-border shadow-sm overflow-hidden hover:border-primary/30 transition-colors">
                  <div className="bg-muted/30 px-6 py-3 border-b border-border flex flex-wrap gap-4 items-center justify-between text-sm">
                    <div className="flex gap-6">
                      <div>
                        <span className="text-muted-foreground uppercase tracking-wider text-xs font-semibold block mb-0.5">Order Placed</span>
                        <span className="font-medium text-foreground">{format(new Date(order.createdAt), 'MMM d, yyyy')}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground uppercase tracking-wider text-xs font-semibold block mb-0.5">Total</span>
                        <span className="font-medium text-foreground">${order.amount.toFixed(2)}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground uppercase tracking-wider text-xs font-semibold block mb-0.5">Order #</span>
                        <span className="font-mono text-muted-foreground">{order.id.toString().padStart(6, '0')}</span>
                      </div>
                    </div>
                    <Badge variant={order.status === 'completed' || order.status === 'delivered' ? 'default' : 'secondary'} className="capitalize">
                      {order.status}
                    </Badge>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
                      
                      <div className="flex-1 flex gap-4 items-center">
                        <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                          <Package className="w-8 h-8 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-bold text-lg leading-tight mb-1">
                            {isProduct ? 'Digital Product Purchase' : order.type === 'service' ? 'Freelance Service' : 'Contest Prize'}
                          </h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <span>{role === 'buyer' ? 'Seller:' : 'Buyer:'}</span>
                            <Link href={`/creators/${otherUser?.id}`} className="flex items-center gap-1.5 hover:text-primary transition-colors font-medium text-foreground">
                              <Avatar className="w-5 h-5 border border-border">
                                <AvatarImage src={otherUser?.avatarUrl} />
                                <AvatarFallback className="text-[10px]">{otherUser?.displayName?.charAt(0)}</AvatarFallback>
                              </Avatar>
                              {otherUser?.displayName}
                            </Link>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-3 sm:justify-end w-full sm:w-auto">
                        <Button variant="outline" size="sm" className="gap-2" asChild>
                          <Link href={`/messages?user=${otherUser?.id}`}>
                            <MessageSquare className="w-4 h-4" /> Message
                          </Link>
                        </Button>
                        
                        {isProduct && order.status === 'completed' && order.downloadUrl && role === 'buyer' && (
                          <Button size="sm" className="gap-2">
                            <Download className="w-4 h-4" /> Download
                          </Button>
                        )}
                        
                        {!isProduct && order.status === 'active' && role === 'buyer' && (
                          <Button size="sm" className="gap-2">
                            Review Delivery
                          </Button>
                        )}

                        <Button variant="ghost" size="icon" className="shrink-0 text-muted-foreground">
                          <ExternalLink className="w-5 h-5" />
                        </Button>
                      </div>

                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}