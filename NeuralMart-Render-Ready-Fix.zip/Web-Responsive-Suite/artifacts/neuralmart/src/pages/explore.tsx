import React, { useState } from 'react';
import { useSearch, useGetTrending } from '@workspace/api-client-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search as SearchIcon, ArrowRight, TrendingUp, Filter } from 'lucide-react';
import { Link } from 'wouter';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

export default function Explore() {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  // Simple debounce
  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 500);
    return () => clearTimeout(timer);
  }, [query]);

  const { data: trending, isLoading: isLoadingTrending } = useGetTrending({
    query: { queryKey: ['trending'] }
  });

  const { data: searchResults, isLoading: isLoadingSearch } = useSearch(
    { q: debouncedQuery, limit: 10 },
    { query: { enabled: debouncedQuery.length > 2, queryKey: ['search', debouncedQuery] } }
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center max-w-2xl mx-auto pt-8">
        <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">Discover the best</h1>
        <p className="text-lg text-muted-foreground mb-8">Search for creators, digital products, freelance services, or open projects.</p>
        
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-muted-foreground group-focus-within:text-primary transition-colors">
            <SearchIcon className="h-6 w-6" />
          </div>
          <Input 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search anything..." 
            className="pl-12 h-14 text-lg bg-card border-2 border-border focus-visible:border-primary focus-visible:ring-4 focus-visible:ring-primary/20 rounded-2xl shadow-lg transition-all" 
          />
          <Button size="icon" variant="ghost" className="absolute right-2 top-2 h-10 w-10">
            <Filter className="w-5 h-5 text-muted-foreground" />
          </Button>
        </div>
      </div>

      {debouncedQuery.length > 2 ? (
        <SearchResults results={searchResults} isLoading={isLoadingSearch} />
      ) : (
        <TrendingSection trending={trending} isLoading={isLoadingTrending} />
      )}
    </div>
  );
}

function TrendingSection({ trending, isLoading }: { trending: any, isLoading: boolean }) {
  if (isLoading) {
    return (
      <div className="space-y-8">
        <div>
          <Skeleton className="h-8 w-48 mb-6" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1,2,3,4].map(i => <Skeleton key={i} className="h-48 rounded-xl" />)}
          </div>
        </div>
      </div>
    );
  }

  if (!trending) return null;

  return (
    <div className="space-y-12 pb-12">
      {/* Categories */}
      <div className="flex flex-wrap gap-2 justify-center">
        {trending.categories?.map((cat: string) => (
          <Badge key={cat} variant="secondary" className="px-4 py-2 text-sm font-medium hover:bg-primary hover:text-primary-foreground cursor-pointer transition-colors rounded-full">
            {cat}
          </Badge>
        ))}
      </div>

      {/* Trending Creators */}
      <div>
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="w-6 h-6 text-primary" />
          <h2 className="text-2xl font-serif font-bold">Trending Creators</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {trending.creators?.slice(0, 4).map((tc: any) => (
            <Link key={tc.creator.id} href={`/creators/${tc.creator.id}`}>
              <Card className="hover:border-primary/50 transition-colors cursor-pointer group bg-card border-border overflow-hidden h-full">
                <div className="h-20 bg-muted relative">
                  {tc.creator.coverUrl && <img src={tc.creator.coverUrl} className="w-full h-full object-cover" alt="cover" />}
                </div>
                <CardContent className="pt-0 relative px-4 pb-4">
                  <Avatar className="w-16 h-16 border-4 border-card -mt-8 mb-3 bg-muted">
                    <AvatarImage src={tc.creator.avatarUrl} />
                    <AvatarFallback className="text-lg">{tc.creator.displayName?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <h3 className="font-bold text-lg truncate group-hover:text-primary transition-colors">{tc.creator.displayName}</h3>
                  <p className="text-sm text-muted-foreground truncate mb-2">{tc.creator.category || 'Creator'}</p>
                  <div className="flex items-center gap-2 text-xs font-medium text-emerald-500 bg-emerald-500/10 w-fit px-2 py-1 rounded-md mt-auto">
                    <TrendingUp className="w-3 h-3" />
                    +{tc.growthRate}% this week
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Trending Products */}
      <div>
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="w-6 h-6 text-accent" />
          <h2 className="text-2xl font-serif font-bold">Hot Products</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {trending.products?.slice(0, 3).map((product: any) => (
            <Link key={product.id} href={`/products/${product.id}`}>
              <Card className="hover:border-accent/50 transition-colors cursor-pointer group overflow-hidden bg-card">
                <div className="aspect-[4/3] bg-muted relative overflow-hidden">
                  {product.previewImageUrl && (
                    <img src={product.previewImageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={product.title} />
                  )}
                  <div className="absolute top-3 right-3 bg-background/90 backdrop-blur-md px-3 py-1 rounded-full text-sm font-bold shadow-sm">
                    ${product.price}
                  </div>
                </div>
                <CardContent className="p-5">
                  <h3 className="font-bold text-lg line-clamp-1 mb-1 group-hover:text-accent transition-colors">{product.title}</h3>
                  <div className="flex items-center gap-2 mt-3">
                    <Avatar className="w-5 h-5">
                      <AvatarImage src={product.creator?.avatarUrl} />
                      <AvatarFallback className="text-[10px]">{product.creator?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-muted-foreground truncate">{product.creator?.displayName}</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function SearchResults({ results, isLoading }: { results: any, isLoading: boolean }) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1,2,3].map(i => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}
      </div>
    );
  }

  if (!results?.results?.length) {
    return (
      <div className="text-center py-20">
        <SearchIcon className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
        <h3 className="text-xl font-bold mb-2">No results found</h3>
        <p className="text-muted-foreground">Try adjusting your search terms.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-12">
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">Search Results</h3>
      {results.results.map((res: any) => {
        if (res.type === 'creator' && res.creator) {
          return (
            <Link key={`creator-${res.id}`} href={`/creators/${res.creator.id}`}>
              <div className="flex items-center gap-4 p-4 bg-card border border-border rounded-xl hover:border-primary/40 transition-colors cursor-pointer group">
                <Avatar className="w-12 h-12 border border-border">
                  <AvatarImage src={res.creator.avatarUrl} />
                  <AvatarFallback>{res.creator.displayName?.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-foreground group-hover:text-primary transition-colors">{res.creator.displayName}</h4>
                  <p className="text-sm text-muted-foreground truncate">{res.creator.category || 'Creator'}</p>
                </div>
                <Badge variant="outline">Creator</Badge>
              </div>
            </Link>
          );
        }
        if (res.type === 'product' && res.product) {
          return (
            <Link key={`product-${res.id}`} href={`/products/${res.product.id}`}>
              <div className="flex items-center gap-4 p-4 bg-card border border-border rounded-xl hover:border-primary/40 transition-colors cursor-pointer group">
                <div className="w-16 h-16 rounded-lg bg-muted flex-shrink-0 overflow-hidden">
                  {res.product.previewImageUrl && <img src={res.product.previewImageUrl} className="w-full h-full object-cover" alt="product" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-foreground group-hover:text-primary transition-colors truncate">{res.product.title}</h4>
                  <p className="text-sm text-muted-foreground">${res.product.price}</p>
                </div>
                <Badge variant="outline">Product</Badge>
              </div>
            </Link>
          );
        }
        // Add renders for project/service/contest as needed
        return null;
      })}
    </div>
  );
}