import React from 'react';
import { useListProducts } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Filter, ShoppingBag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function Products() {
  const { data: productsData, isLoading } = useListProducts({
    
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-8 mb-8">
        <div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">Digital Products</h1>
          <p className="text-lg text-muted-foreground">Discover and buy digital assets, courses, and tools from top creators.</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="w-4 h-4" /> Filter
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-72 rounded-xl" />)}
        </div>
      ) : !productsData?.products.length ? (
        <div className="text-center py-20 bg-card rounded-2xl border border-border">
          <ShoppingBag className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">No products found</h3>
          <p className="text-muted-foreground">Check back later or adjust your filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {productsData.products.map((product: any) => (
            <Link key={product.id} href={`/products/${product.id}`}>
              <Card className="hover:border-primary/50 transition-colors cursor-pointer group bg-card overflow-hidden h-full flex flex-col shadow-sm hover:shadow-md">
                <div className="aspect-[4/3] bg-muted relative overflow-hidden">
                  {product.previewImageUrl ? (
                    <img src={product.previewImageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={product.title} />
                  ) : (
                    <div className="w-full h-full bg-primary/5 flex items-center justify-center">
                      <ShoppingBag className="w-12 h-12 text-primary/20" />
                    </div>
                  )}
                  <div className="absolute top-3 right-3 bg-background/90 backdrop-blur-md px-3 py-1 rounded-full text-sm font-bold shadow-sm">
                    ${product.price}
                  </div>
                  {product.category && (
                    <Badge variant="secondary" className="absolute top-3 left-3 shadow-sm bg-background/90 backdrop-blur-md hover:bg-background/90">
                      {product.category}
                    </Badge>
                  )}
                </div>
                <CardContent className="p-5 flex-1 flex flex-col">
                  <h3 className="font-bold text-lg line-clamp-2 mb-2 group-hover:text-primary transition-colors">{product.title}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-1">{product.description}</p>
                  
                  <div className="flex items-center gap-3 pt-4 border-t border-border mt-auto">
                    <Avatar className="w-8 h-8 border border-border">
                      <AvatarImage src={product.creator?.avatarUrl} />
                      <AvatarFallback className="bg-primary/10 text-primary text-xs">{product.creator?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate group-hover:underline">{product.creator?.displayName}</p>
                    </div>
                    {product.salesCount > 0 && (
                      <span className="text-xs text-muted-foreground font-medium">{product.salesCount} sales</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}