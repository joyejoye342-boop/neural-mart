import React from 'react';
import { useListProjects } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Filter, Briefcase, Clock, DollarSign } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

export default function Projects() {
  const { data: projectsData, isLoading } = useListProjects({
    
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-8 mb-8">
        <div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">Project Board</h1>
          <p className="text-lg text-muted-foreground">Find clients looking for your skills and submit proposals.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" /> Filter
          </Button>
          <Button asChild>
            <Link href="/projects/new">Post a Project</Link>
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-48 rounded-xl w-full" />)}
        </div>
      ) : !projectsData?.projects.length ? (
        <div className="text-center py-20 bg-card rounded-2xl border border-border">
          <Briefcase className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">No projects found</h3>
          <p className="text-muted-foreground">Check back later or adjust your filters.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {projectsData.projects.map((project: any) => (
            <Link key={project.id} href={`/projects/${project.id}`}>
              <Card className="hover:border-primary/50 transition-all cursor-pointer group bg-card border-border shadow-sm hover:shadow-md">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar className="w-8 h-8 border border-border">
                          <AvatarImage src={project.buyer?.avatarUrl} />
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">{project.buyer?.displayName?.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-muted-foreground">{project.buyer?.displayName}</span>
                        <span className="text-muted-foreground text-sm">•</span>
                        <span className="text-sm text-muted-foreground">{formatDistanceToNow(new Date(project.createdAt), { addSuffix: true })}</span>
                      </div>
                      
                      <h3 className="font-serif font-bold text-2xl mb-2 group-hover:text-primary transition-colors">{project.title}</h3>
                      <p className="text-muted-foreground line-clamp-2 mb-4">{project.description}</p>
                      
                      <div className="flex flex-wrap gap-2">
                        {project.category && (
                          <Badge variant="secondary" className="bg-muted text-muted-foreground hover:bg-muted">
                            {project.category}
                          </Badge>
                        )}
                        <Badge variant={project.status === 'open' ? 'default' : 'secondary'} className="capitalize">
                          {project.status.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="md:w-48 flex flex-col md:items-end justify-between border-t md:border-t-0 md:border-l border-border pt-4 md:pt-0 md:pl-6">
                      <div className="space-y-4 w-full">
                        <div className="flex items-center justify-between md:flex-col md:items-end md:gap-1">
                          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Budget</span>
                          <span className="font-bold text-xl text-foreground">
                            ${project.budgetMin} - ${project.budgetMax}
                          </span>
                        </div>
                        <div className="flex items-center justify-between md:flex-col md:items-end md:gap-1">
                          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Proposals</span>
                          <span className="font-medium text-muted-foreground">
                            {project.proposalCount} received
                          </span>
                        </div>
                      </div>
                      <Button variant="secondary" className="w-full mt-6 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                        View Project
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}