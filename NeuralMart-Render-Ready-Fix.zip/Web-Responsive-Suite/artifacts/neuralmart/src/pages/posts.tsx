import React, { useMemo, useRef, useState } from 'react';
import { useListPosts, useGetMe, getListPostsQueryKey, getGetShowcaseFeedQueryKey, getGetHomeFeedQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { MoreHorizontal, Image as ImageIcon, X, Loader2, Send, FileImage } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'wouter';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { PostInteractions } from '@/components/posts/PostInteractions';

type PickedMedia = { file: File; preview: string };

export default function Posts() {
  const { data: postsData, isLoading } = useListPosts({});
  const { data: user } = useGetMe({ query: { retry: false } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [content, setContent] = useState('');
  const [media, setMedia] = useState<PickedMedia[]>([]);
  const [publishing, setPublishing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');

  const canPublish = useMemo(() => Boolean(user) && !publishing && (content.trim().length > 0 || media.length > 0), [user, publishing, content, media]);

  function chooseFiles(files: FileList | null) {
    if (!files) return;
    const incoming = Array.from(files);
    const allowed = incoming.filter(file => /^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime))$/.test(file.type));
    const tooLarge = allowed.filter(file => file.size > 200 * 1024 * 1024);
    if (tooLarge.length) toast({ title: 'File too large', description: 'Each image/video must be 200 MB or smaller.', variant: 'destructive' });
    const ready = allowed.filter(file => file.size <= 200 * 1024 * 1024);
    if (ready.length !== incoming.length) toast({ title: 'Some files were skipped', description: 'Supported formats: JPG, PNG, WEBP, GIF, MP4, WEBM and MOV.' });
    const room = Math.max(0, 10 - media.length);
    const next = ready.slice(0, room).map(file => ({ file, preview: URL.createObjectURL(file) }));
    setMedia(old => [...old, ...next]);
    if (ready.length > room) toast({ title: '10-file limit', description: 'A post can contain up to 10 images/videos.' });
    if (inputRef.current) inputRef.current.value = '';
  }

  function removeMedia(index: number) {
    setMedia(old => { URL.revokeObjectURL(old[index]?.preview); return old.filter((_, i) => i !== index); });
  }

  async function publish() {
    if (!canPublish) return;
    setPublishing(true);
    try {
      let mediaUrls: string[] = [];
      if (media.length) {
        setUploadProgress(`Uploading ${media.length} file${media.length > 1 ? 's' : ''}…`);
        const form = new FormData();
        media.forEach(item => form.append('files', item.file));
        const upload = await fetch('/api/uploads', { method: 'POST', body: form, credentials: 'include' });
        const uploadData = await upload.json().catch(() => ({}));
        if (!upload.ok) throw new Error(uploadData.error || 'Could not upload media. Please try again.');
        mediaUrls = (uploadData.files || []).map((file: { url: string }) => file.url);
      }
      setUploadProgress('Publishing post…');
      const type = media.some(item => item.file.type.startsWith('video/')) ? 'video' : media.length ? 'image' : 'text';
      const response = await fetch('/api/posts', {
        method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, content: content.trim(), mediaUrls, mediaUrl: mediaUrls[0] || null }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Could not publish your post.');
      setContent('');
      media.forEach(item => URL.revokeObjectURL(item.preview));
      setMedia([]);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetShowcaseFeedQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetHomeFeedQueryKey() }),
      ]);
      toast({ title: 'Post published', description: 'Your update is now in the showcase feed.' });
    } catch (error) {
      toast({ title: 'Could not publish', description: error instanceof Error ? error.message : 'Please try again.', variant: 'destructive' });
    } finally { setPublishing(false); setUploadProgress(''); }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6 pb-12 pt-6 px-1 sm:px-0">
      <header className="rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-card to-card p-6 sm:p-8">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Neural Mart · Creator Studio</p>
        <h1 className="mt-2 text-3xl sm:text-4xl font-bold tracking-tight">Showcase Feed</h1>
        <p className="mt-2 max-w-xl text-sm sm:text-base text-muted-foreground">Share your work, publish photos and videos, and build your community.</p>
      </header>

      <Card className="overflow-hidden border-border shadow-sm">
        <CardHeader className="pb-3"><div className="flex items-center gap-3">
          <Avatar className="h-11 w-11"><AvatarImage src={user?.avatarUrl || ''}/><AvatarFallback>{user?.displayName?.charAt(0)?.toUpperCase() || 'N'}</AvatarFallback></Avatar>
          <div><h2 className="font-semibold">Create a post</h2><p className="text-xs text-muted-foreground">Share an update with the Neural Mart community</p></div>
        </div></CardHeader>
        <CardContent className="space-y-4">
          <Textarea value={content} onChange={e => setContent(e.target.value)} placeholder="What would you like to share?" maxLength={5000} className="min-h-28 resize-y border-0 bg-muted/40 text-base focus-visible:ring-1" aria-label="Post text" />
          {media.length > 0 && <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">{media.map((item, i) => <div key={`${item.file.name}-${i}`} className="group relative overflow-hidden rounded-xl border bg-muted">
            {item.file.type.startsWith('video/') ? <video src={item.preview} controls className="aspect-square w-full object-cover" /> : <img src={item.preview} alt={item.file.name} className="aspect-square w-full object-cover" />}
            <button type="button" onClick={() => removeMedia(i)} aria-label="Remove attachment" className="absolute right-2 top-2 rounded-full bg-black/75 p-1.5 text-white hover:bg-black"><X className="h-4 w-4"/></button>
            <span className="block truncate px-2 py-1 text-xs text-muted-foreground">{item.file.name}</span>
          </div>)}</div>}
          <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime" multiple hidden onChange={e => chooseFiles(e.target.files)} />
          <div className="flex flex-col gap-3 border-t pt-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => inputRef.current?.click()} disabled={publishing || media.length >= 10}><ImageIcon className="mr-2 h-4 w-4 text-emerald-600"/> Photo / Video</Button>
              <span className="self-center text-xs text-muted-foreground">Up to 10 files · 200 MB each</span>
            </div>
            <Button type="button" onClick={publish} disabled={!canPublish} className="min-w-32">{publishing ? <><Loader2 className="mr-2 h-4 w-4 animate-spin"/>{uploadProgress || 'Publishing…'}</> : <><Send className="mr-2 h-4 w-4"/>Publish post</>}</Button>
          </div>
          {!user && <p className="text-sm text-muted-foreground">Please <Link href="/login" className="text-primary underline">sign in</Link> to publish a post.</p>}
        </CardContent>
      </Card>

      <div className="flex items-end justify-between gap-4"><div><h2 className="text-xl font-bold">Latest posts</h2><p className="text-sm text-muted-foreground">Community updates and creator work</p></div><div className="text-xs text-muted-foreground">{postsData?.total ?? postsData?.posts?.length ?? 0} posts loaded</div></div>
      {isLoading ? <div className="space-y-5">{[1,2,3].map(i => <PostSkeleton key={i}/>)}</div> : !postsData?.posts?.length ? (
        <div className="rounded-2xl border border-dashed border-border bg-card py-16 text-center"><FileImage className="mx-auto mb-4 h-12 w-12 text-muted-foreground/40"/><h3 className="text-lg font-semibold">Your feed starts here</h3><p className="mt-1 text-sm text-muted-foreground">Publish the first photo, video or update above.</p></div>
      ) : <div className="space-y-5">{postsData.posts.map((post: any) => <Card key={post.id} className="overflow-hidden border-border shadow-sm">
        <CardHeader className="flex flex-row items-center gap-3 p-4 pb-2"><Link href={`/creators/${post.creatorId}`}><Avatar className="h-10 w-10 border"><AvatarImage src={post.creator?.avatarUrl || ''}/><AvatarFallback>{post.creator?.displayName?.charAt(0)?.toUpperCase() || 'N'}</AvatarFallback></Avatar></Link><div className="min-w-0 flex-1"><Link href={`/creators/${post.creatorId}`}><h4 className="truncate text-sm font-semibold hover:underline">{post.creator?.displayName || 'Neural Mart creator'}</h4></Link><p className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })} · <span className="capitalize">{post.type}</span></p></div><Button variant="ghost" size="icon" aria-label="More post options"><MoreHorizontal className="h-5 w-5"/></Button></CardHeader>
        <CardContent className="p-4 pt-2"><p className="mb-3 whitespace-pre-wrap break-words text-sm">{post.content}</p>{(post.mediaUrls?.length ? post.mediaUrls : post.mediaUrl ? [post.mediaUrl] : []).map((url: string, i: number) => <div key={`${url}-${i}`} className="mb-2 overflow-hidden rounded-xl bg-muted">{/\.(mp4|webm|mov)(\?|$)/i.test(url) || post.type === 'video' || post.type === 'reel' ? <video src={url} controls playsInline preload="metadata" className="max-h-[620px] w-full bg-black" /> : <img src={url} alt="Post attachment" loading="lazy" className="max-h-[620px] w-full object-contain"/>}</div>)}</CardContent>
        <PostInteractions post={post}/>
      </Card>)}</div>}
    </div>
  );
}

function PostSkeleton() { return <Card><CardHeader className="flex flex-row items-center gap-3 p-4"><Skeleton className="h-10 w-10 rounded-full"/><div className="flex-1 space-y-2"><Skeleton className="h-4 w-32"/><Skeleton className="h-3 w-24"/></div></CardHeader><CardContent className="space-y-3 p-4 pt-0"><Skeleton className="h-4 w-full"/><Skeleton className="h-72 w-full rounded-xl"/></CardContent></Card>; }
