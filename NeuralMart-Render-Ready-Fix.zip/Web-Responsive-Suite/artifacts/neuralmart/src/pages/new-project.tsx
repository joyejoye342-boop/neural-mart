import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useCreateProject } from '@workspace/api-client-react';
import { Link, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ArrowLeft, Briefcase } from 'lucide-react';

const projectSchema = z.object({
  title: z.string().min(10, 'Title must be at least 10 characters'),
  category: z.string().min(2, 'Category is required'),
  description: z.string().min(50, 'Description must be detailed enough (min 50 characters)'),
  budgetMin: z.coerce.number().min(5, 'Minimum budget is $5'),
  budgetMax: z.coerce.number().min(5, 'Maximum budget is $5'),
  deadline: z.string().min(1, 'Deadline is required'),
}).refine((data) => data.budgetMax >= data.budgetMin, {
  message: "Maximum budget must be greater than or equal to minimum budget",
  path: ["budgetMax"],
});

type ProjectFormValues = z.infer<typeof projectSchema>;

export default function NewProject() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const createProjectMutation = useCreateProject();

  // Support ?returnTo=/ so the home-feed composer can send users back to
  // the Showcase Feed (or Contest Feed) instead of the new project's detail page.
  const returnTo = new URLSearchParams(window.location.search).get('returnTo');

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      title: '',
      category: '',
      description: '',
      budgetMin: 50,
      budgetMax: 200,
      deadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 14 days from now
    },
  });

  const onSubmit = (data: ProjectFormValues) => {
    // Add time to deadline to make it a valid ISO datetime for the backend
    const payload = {
      ...data,
      deadline: new Date(data.deadline).toISOString()
    };

    createProjectMutation.mutate({ data: payload }, {
      onSuccess: (res) => {
        toast({
          title: "Project posted!",
          description: "Your project is now live for creators to bid on.",
        });
        setLocation(returnTo || `/projects/${res.id}`);
      },
      onError: (err) => {
        toast({
          title: "Error posting project",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="max-w-3xl mx-auto py-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <Button variant="ghost" className="mb-6 -ml-4 text-muted-foreground hover:text-foreground" onClick={() => window.history.back()}>
        <ArrowLeft className="w-4 h-4 mr-2" /> Back
      </Button>

      <div className="mb-8">
        <h1 className="text-4xl font-serif font-bold tracking-tight mb-2">Post a Project</h1>
        <p className="text-lg text-muted-foreground">Describe what you need, set a budget, and receive proposals from talented creators.</p>
      </div>

      <Card className="bg-card border-border shadow-lg">
        <CardHeader className="bg-muted/30 border-b border-border p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary/10 text-primary rounded-xl">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Project Details</CardTitle>
              <CardDescription>Be as specific as possible to get the best proposals.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">Project Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Build a custom e-commerce website" className="h-12 text-lg bg-background" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Web Development" className="h-12 bg-background" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deadline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Deadline</FormLabel>
                      <FormControl>
                        <Input type="date" className="h-12 bg-background" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 bg-muted/50 rounded-xl border border-border">
                <div className="col-span-full">
                  <h4 className="font-semibold mb-1">Budget Range (USD)</h4>
                  <p className="text-sm text-muted-foreground mb-4">Set realistic expectations to attract quality creators.</p>
                </div>
                <FormField
                  control={form.control}
                  name="budgetMin"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Minimum Budget</FormLabel>
                      <FormControl>
                        <Input type="number" className="h-12 bg-background" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="budgetMax"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Budget</FormLabel>
                      <FormControl>
                        <Input type="number" className="h-12 bg-background" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">Project Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe the deliverables, timeline, required skills, and any other relevant details..." 
                        className="min-h-[200px] text-base resize-y bg-background" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end pt-6 border-t border-border">
                <Button 
                  type="submit" 
                  size="lg" 
                  className="font-bold px-8 h-14"
                  disabled={createProjectMutation.isPending}
                >
                  {createProjectMutation.isPending ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : null}
                  Post Project
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}