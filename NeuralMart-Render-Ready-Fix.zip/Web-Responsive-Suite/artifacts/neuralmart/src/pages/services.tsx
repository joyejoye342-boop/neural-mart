import React from 'react';
import { useListServices } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Filter, Briefcase, Star, Clock } from 'lucide-react';

export default function Services() {
  const { data: servicesData, isLoading } = useListServices({
    
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-8 mb-8">
        <div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">Freelance Services</h1>
          <p className="text-lg text-muted-foreground">Hire experts for design, development, marketing, and more.</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="w-4 h-4" /> Filter
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-80 rounded-xl" />)}
        </div>
      ) : !servicesData?.services.length ? (
        <div className="text-center py-20 bg-card rounded-2xl border border-border">
          <Briefcase className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">No services found</h3>
          <p className="text-muted-foreground">Check back later or adjust your filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesData.services.map((service: any) => (
            <Link key={service.id} href={`/services/${service.id}`}>
              <Card className="hover:border-primary/50 transition-colors cursor-pointer group bg-card overflow-hidden h-full flex flex-col shadow-sm hover:shadow-md">
                <div className="aspect-video bg-muted relative overflow-hidden">
                  {service.previewImageUrl ? (
                    <img src={service.previewImageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={service.title} />
                  ) : (
                    <div className="w-full h-full bg-primary/5 flex items-center justify-center">
                      <Briefcase className="w-12 h-12 text-primary/20" />
                    </div>
                  )}
                </div>
                <CardContent className="p-5 flex-1 flex flex-col">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar className="w-6 h-6 border border-border">
                      <AvatarImage src={service.creator?.avatarUrl} />
                      <AvatarFallback className="bg-primary/10 text-primary text-[10px]">{service.creator?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <p className="text-sm font-medium text-muted-foreground group-hover:underline truncate">{service.creator?.displayName}</p>
                  </div>

                  <h3 className="font-bold text-lg line-clamp-2 mb-2 group-hover:text-primary transition-colors">{service.title}</h3>
                  
                  <div className="flex items-center gap-4 mt-auto pt-4">
                    {service.rating > 0 ? (
                      <div className="flex items-center gap-1 text-sm font-bold text-accent">
                        <Star className="w-4 h-4 fill-accent" />
                        {service.rating.toFixed(1)} <span className="text-muted-foreground font-normal">({service.reviewCount})</span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">New Service</span>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {service.basic.deliveryDays}d delivery
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-muted-foreground uppercase font-semibold">Starts at</span>
                      <div className="font-bold text-lg text-foreground">${service.basic.price}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}