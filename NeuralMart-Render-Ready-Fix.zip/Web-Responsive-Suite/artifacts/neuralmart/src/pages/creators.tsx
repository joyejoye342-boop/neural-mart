import React from 'react';
import { useListCreators } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Star, TrendingUp } from 'lucide-react';

export default function Creators() {
  const { data: creatorsData, isLoading } = useListCreators();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="text-center max-w-2xl mx-auto pt-8 mb-12">
        <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">Discover Creators</h1>
        <p className="text-lg text-muted-foreground">Find top talent, buy exclusive digital products, and hire freelancers for your next project.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {creatorsData?.creators.map((creator: any) => (
            <Link key={creator.id} href={`/creators/${creator.id}`}>
              <Card className="hover:border-primary/50 transition-colors cursor-pointer group bg-card border-border overflow-hidden h-full flex flex-col shadow-sm hover:shadow-md">
                <div className="h-24 bg-muted relative">
                  {creator.coverUrl ? (
                    <img src={creator.coverUrl} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt="cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-r from-primary/20 to-accent/20" />
                  )}
                </div>
                <CardContent className="pt-0 relative px-6 pb-6 flex-1 flex flex-col">
                  <div className="flex justify-between items-start">
                    <Avatar className="w-20 h-20 border-4 border-card -mt-10 mb-4 bg-muted shadow-sm">
                      <AvatarImage src={creator.avatarUrl} />
                      <AvatarFallback className="text-xl font-bold bg-primary/10 text-primary">{creator.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    {creator.rating > 0 && (
                      <div className="mt-3 flex items-center gap-1 text-sm font-bold bg-accent/10 text-accent px-2 py-1 rounded-md">
                        <Star className="w-3 h-3 fill-accent" />
                        {creator.rating.toFixed(1)}
                      </div>
                    )}
                  </div>
                  
                  <h3 className="font-bold text-xl line-clamp-1 group-hover:text-primary transition-colors">{creator.displayName}</h3>
                  <p className="text-sm text-muted-foreground font-medium mb-3">{creator.category || 'Creator'}</p>
                  
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-1">
                    {creator.bio || 'No bio provided.'}
                  </p>

                  <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground border-t border-border pt-4 mt-auto">
                    <div className="flex flex-col">
                      <span className="text-foreground font-bold text-sm">{creator.followersCount}</span>
                      <span>Followers</span>
                    </div>
                    <div className="w-px h-8 bg-border"></div>
                    <div className="flex flex-col">
                      <span className="text-foreground font-bold text-sm">{creator.totalSales}</span>
                      <span>Sales</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}