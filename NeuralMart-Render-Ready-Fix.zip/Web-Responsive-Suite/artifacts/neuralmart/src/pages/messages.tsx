import React from 'react';
import { useListConversations, useGetMe } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { MessageSquare, Plus, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';

export default function Messages() {
  const { data: user } = useGetMe();
  const { data: conversations, isLoading } = useListConversations({
    query: { queryKey: ['conversations'] }
  });

  return (
    <div className="h-[calc(100vh-6rem)] md:h-[calc(100vh-4rem)] flex flex-col md:flex-row gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Left sidebar - Conversation list */}
      <div className="w-full md:w-80 lg:w-96 flex flex-col bg-card rounded-2xl border border-border overflow-hidden h-full shadow-sm">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-serif font-bold">Messages</h1>
            <Button size="icon" variant="ghost" className="rounded-full bg-primary/10 text-primary hover:bg-primary/20">
              <Plus className="w-5 h-5" />
            </Button>
          </div>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search messages..." className="pl-9 bg-muted/50 border-transparent focus-visible:border-primary" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {isLoading ? (
            Array(5).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-4 p-3">
                <Skeleton className="w-12 h-12 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-full" />
                </div>
              </div>
            ))
          ) : !conversations?.length ? (
            <div className="text-center p-8">
              <MessageSquare className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">No messages yet.</p>
            </div>
          ) : (
            conversations.map((conv: any) => {
              const otherParticipant = conv.participants?.find((p: any) => p.id !== user?.id);
              return (
                <Link key={conv.id} href={`/messages/${conv.id}`}>
                  <div className="flex items-center gap-4 p-3 rounded-xl hover:bg-accent/10 cursor-pointer transition-colors group">
                    <Avatar className="w-12 h-12 border border-border group-hover:border-accent/50 transition-colors">
                      <AvatarImage src={otherParticipant?.avatarUrl} />
                      <AvatarFallback className="bg-accent/10 text-accent font-semibold">{otherParticipant?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-semibold text-sm truncate">{otherParticipant?.displayName || 'Unknown'}</h4>
                        <span className="text-[10px] text-muted-foreground whitespace-nowrap ml-2">
                          {formatDistanceToNow(new Date(conv.lastMessageAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {conv.lastMessage || 'Sent a file'}
                      </p>
                    </div>
                    {conv.unreadCount > 0 && (
                      <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center text-[10px] font-bold text-primary-foreground">
                        {conv.unreadCount}
                      </div>
                    )}
                  </div>
                </Link>
              );
            })
          )}
        </div>
      </div>

      {/* Right side - Message thread placeholder */}
      <div className="hidden md:flex flex-1 bg-card rounded-2xl border border-border items-center justify-center flex-col text-center p-8 shadow-sm">
        <div className="w-20 h-20 bg-primary/5 rounded-full flex items-center justify-center mb-6">
          <MessageSquare className="w-10 h-10 text-primary/40" />
        </div>
        <h3 className="text-2xl font-serif font-bold mb-2">Select a conversation</h3>
        <p className="text-muted-foreground max-w-sm">
          Choose a chat from the left or start a new conversation to discuss projects, services, or complete transactions.
        </p>
      </div>
    </div>
  );
}