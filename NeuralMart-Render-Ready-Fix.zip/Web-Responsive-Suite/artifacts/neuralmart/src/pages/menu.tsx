import React from 'react';
import { useGetMe, useGetWallet, useLogout } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Link } from 'wouter';
import { 
  Wallet as WalletIcon, 
  Settings, 
  Shield, 
  Bell, 
  Lock, 
  HelpCircle, 
  FileText, 
  LogOut,
  ChevronRight,
  Plus,
  ArrowDownToLine
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function Menu() {
  const { data: user, isLoading: isUserLoading } = useGetMe();
  const { data: wallet, isLoading: isWalletLoading } = useGetWallet({
    query: { queryKey: ['wallet'], enabled: !!user }
  });
  const logoutMutation = useLogout();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        window.location.href = import.meta.env.BASE_URL + 'login';
      }
    });
  };

  if (isUserLoading) return <MenuSkeleton />;
  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <h1 className="text-4xl font-serif font-bold tracking-tight">Menu</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Left Column */}
        <div className="space-y-8">
          {/* Profile Card */}
          <Link href={`/creators/${user.id}`}>
            <Card className="hover:border-primary/40 transition-colors cursor-pointer group bg-card overflow-hidden">
              <CardContent className="p-6 flex items-center gap-4">
                <Avatar className="w-16 h-16 border-2 border-border group-hover:border-primary transition-colors">
                  <AvatarImage src={user.avatarUrl || ''} />
                  <AvatarFallback className="text-xl bg-primary/10 text-primary">{user.displayName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-xl group-hover:text-primary transition-colors truncate">{user.displayName}</h3>
                  <p className="text-sm text-muted-foreground capitalize">{user.role} Account</p>
                </div>
                <ChevronRight className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
              </CardContent>
            </Card>
          </Link>

          {/* Financial Card */}
          <Card className="bg-gradient-to-br from-primary/10 via-card to-card border-primary/20 overflow-hidden relative">
            <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
              <WalletIcon className="w-32 h-32 text-primary" />
            </div>
            <CardContent className="p-6 relative z-10">
              <div className="flex items-center gap-2 mb-6">
                <WalletIcon className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-lg">Wallet & Earnings</h3>
              </div>
              
              {isWalletLoading ? (
                <Skeleton className="h-12 w-32 mb-6" />
              ) : (
                <div className="mb-6">
                  <div className="text-sm text-muted-foreground mb-1">Available Balance</div>
                  <div className="text-4xl font-serif font-bold text-foreground">
                    ${wallet?.balance.toFixed(2) || '0.00'}
                  </div>
                  {(wallet?.pendingBalance ?? 0) > 0 && (
                    <div className="text-sm text-muted-foreground mt-1">
                      + ${wallet?.pendingBalance?.toFixed(2)} pending
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <Button variant="default" className="w-full gap-2">
                  <Plus className="w-4 h-4" /> Add Funds
                </Button>
                <Button variant="outline" className="w-full gap-2">
                  <ArrowDownToLine className="w-4 h-4" /> Withdraw
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <MenuSection title="Account Settings">
            <MenuItem icon={Settings} label="Profile Settings" href="/profile/edit" />
            <MenuItem icon={Shield} label="Security & Password" href="#" />
            <MenuItem icon={Bell} label="Notifications" href="#" />
            <MenuItem icon={Lock} label="Privacy" href="#" />
          </MenuSection>

          <MenuSection title="Support & Legal">
            <MenuItem icon={HelpCircle} label="Help Center" href="#" />
            <MenuItem icon={FileText} label="Terms of Service" href="#" />
            <MenuItem icon={FileText} label="Privacy Policy" href="#" />
          </MenuSection>

          <Button 
            variant="ghost" 
            className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10 h-14 rounded-xl font-medium text-lg px-6 mt-4"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="w-6 h-6 mr-4" />
            Sign Out
          </Button>
        </div>

      </div>
    </div>
  );
}

function MenuSection({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
      <div className="p-4 bg-muted/30 border-b border-border">
        <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">{title}</h4>
      </div>
      <div className="divide-y divide-border">
        {children}
      </div>
    </div>
  );
}

function MenuItem({ icon: Icon, label, href }: { icon: any, label: string, href: string }) {
  return (
    <Link href={href}>
      <div className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors cursor-pointer group">
        <div className="flex items-center gap-4">
          <div className="p-2 rounded-lg bg-secondary text-secondary-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
            <Icon className="w-5 h-5" />
          </div>
          <span className="font-medium text-foreground">{label}</span>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground transition-colors" />
      </div>
    </Link>
  );
}

function MenuSkeleton() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <Skeleton className="h-10 w-32" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-8">
          <Skeleton className="h-32 w-full rounded-2xl" />
          <Skeleton className="h-64 w-full rounded-2xl" />
        </div>
        <div className="space-y-6">
          <Skeleton className="h-48 w-full rounded-2xl" />
          <Skeleton className="h-48 w-full rounded-2xl" />
        </div>
      </div>
    </div>
  );
}