import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useRegister } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Hexagon, Mail, Lock, User, Briefcase, ShoppingBag, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

const registerSchema = z.object({
  displayName: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  role: z.enum(['buyer', 'creator']),
});

type RegisterFormValues = z.infer<typeof registerSchema>;

export default function Register() {
  const { toast } = useToast();
  const registerMutation = useRegister();
  
  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: { 
      displayName: '', 
      email: '', 
      password: '',
      role: 'buyer' 
    },
  });

  const onSubmit = (data: RegisterFormValues) => {
    registerMutation.mutate({ data }, {
      onSuccess: () => {
        window.location.href = import.meta.env.BASE_URL;
      },
      onError: (err) => {
        toast({
          title: "Registration failed",
          description: err.message || "An error occurred during registration.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 bg-background relative overflow-hidden">
      <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-primary/20 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-accent/10 blur-[120px] pointer-events-none" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-10"
      >
        <div className="flex justify-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-card border border-border shadow-xl flex items-center justify-center">
            <Hexagon className="w-8 h-8 text-primary fill-primary/20" />
          </div>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif font-bold tracking-tight text-foreground mb-2">Create an Account</h1>
          <p className="text-muted-foreground">Join the next-generation creator marketplace</p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 sm:p-8 shadow-2xl">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <Label className="text-sm font-medium">I want to...</Label>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-2 gap-4"
                      >
                        <Label
                          htmlFor="role-buyer"
                          className={`flex flex-col items-center justify-between rounded-xl border-2 p-4 cursor-pointer hover:bg-muted/50 transition-colors ${
                            field.value === 'buyer' ? 'border-primary bg-primary/5' : 'border-border bg-transparent'
                          }`}
                        >
                          <RadioGroupItem value="buyer" id="role-buyer" className="sr-only" />
                          <ShoppingBag className={`mb-3 h-6 w-6 ${field.value === 'buyer' ? 'text-primary' : 'text-muted-foreground'}`} />
                          <span className={`font-semibold ${field.value === 'buyer' ? 'text-primary' : 'text-foreground'}`}>Hire / Buy</span>
                        </Label>
                        <Label
                          htmlFor="role-creator"
                          className={`flex flex-col items-center justify-between rounded-xl border-2 p-4 cursor-pointer hover:bg-muted/50 transition-colors ${
                            field.value === 'creator' ? 'border-primary bg-primary/5' : 'border-border bg-transparent'
                          }`}
                        >
                          <RadioGroupItem value="creator" id="role-creator" className="sr-only" />
                          <Briefcase className={`mb-3 h-6 w-6 ${field.value === 'creator' ? 'text-primary' : 'text-muted-foreground'}`} />
                          <span className={`font-semibold ${field.value === 'creator' ? 'text-primary' : 'text-foreground'}`}>Sell / Earn</span>
                        </Label>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="displayName"
                  render={({ field }) => (
                    <FormItem>
                      <Label className="text-sm font-medium">Full Name</Label>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-muted-foreground">
                            <User className="h-5 w-5" />
                          </div>
                          <Input placeholder="John Doe" className="pl-10 h-12 bg-background" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <Label className="text-sm font-medium">Email address</Label>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-muted-foreground">
                            <Mail className="h-5 w-5" />
                          </div>
                          <Input placeholder="name@example.com" className="pl-10 h-12 bg-background" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <Label className="text-sm font-medium">Password</Label>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-muted-foreground">
                            <Lock className="h-5 w-5" />
                          </div>
                          <Input type="password" placeholder="Min. 8 characters" className="pl-10 h-12 bg-background" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 text-base font-semibold" 
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>
          </Form>
        </div>

        <p className="text-center mt-8 text-sm text-muted-foreground">
          Already have an account?{' '}
          <Link href="/login" className="text-primary font-semibold hover:underline">
            Sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
}