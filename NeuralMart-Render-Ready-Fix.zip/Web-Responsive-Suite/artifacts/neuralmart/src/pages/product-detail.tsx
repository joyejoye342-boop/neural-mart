import React from 'react';
import { useParams, Link } from 'wouter';
import { useGetProduct, usePurchaseProduct, useGetMe } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { ShoppingBag, Star, ShieldCheck, Download, ChevronRight, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ProductDetail() {
  const { id } = useParams();
  const productId = parseInt(id || '0');
  const { toast } = useToast();
  const { data: user } = useGetMe();
  
  const { data: product, isLoading } = useGetProduct(productId, { query: { enabled: !!productId } as any });

  const purchaseMutation = usePurchaseProduct();

  const handlePurchase = () => {
    purchaseMutation.mutate({ id: productId }, {
      onSuccess: () => {
        toast({
          title: "Purchase successful!",
          description: "You can now download your product.",
        });
        // Could redirect to orders or reveal download link
      },
      onError: (err) => {
        toast({
          title: "Purchase failed",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  if (isLoading) return <ProductSkeleton />;
  if (!product) return <div className="text-center py-20">Product not found.</div>;

  const isOwner = user?.id === product.creatorId;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-16">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6 pt-4">
        <Link href="/products" className="hover:text-foreground transition-colors">Products</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground">{product.category || 'Digital'}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left: Images & Description */}
        <div className="lg:col-span-2 space-y-8">
          <div className="aspect-[16/9] w-full bg-muted rounded-3xl overflow-hidden border border-border shadow-md">
            {product.previewImageUrl ? (
              <img src={product.previewImageUrl} alt={product.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-primary/5">
                <ShoppingBag className="w-24 h-24 text-primary/20" />
              </div>
            )}
          </div>

          <div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold tracking-tight mb-4">{product.title}</h1>
            <div className="flex flex-wrap items-center gap-4 mb-8">
              {product.rating > 0 && (
                <div className="flex items-center gap-1 text-accent font-bold bg-accent/10 px-3 py-1 rounded-md">
                  <Star className="w-4 h-4 fill-accent" />
                  {product.rating.toFixed(1)} ({product.reviewCount} reviews)
                </div>
              )}
              <div className="text-muted-foreground font-medium flex items-center gap-1">
                <ShoppingBag className="w-4 h-4" />
                {product.salesCount} sales
              </div>
              {product.category && (
                <Badge variant="secondary">{product.category}</Badge>
              )}
            </div>

            <div className="prose prose-neutral dark:prose-invert max-w-none">
              <h3 className="font-serif text-2xl mb-4">About this product</h3>
              <p className="whitespace-pre-wrap text-muted-foreground leading-relaxed">
                {product.description}
              </p>
            </div>

            {product.tags && product.tags.length > 0 && (
              <div className="mt-8 pt-8 border-t border-border">
                <h4 className="font-semibold mb-4">Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {product.tags.map((tag: string) => (
                    <Badge key={tag} variant="outline">{tag}</Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Sticky Buy Box */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-6">
            <Card className="bg-card border-border shadow-lg border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-6">
                  <div className="text-4xl font-serif font-bold text-foreground mb-1">
                    ${product.price.toFixed(2)}
                  </div>
                  <div className="text-sm text-muted-foreground">One-time payment</div>
                </div>

                {!isOwner ? (
                  <Button 
                    className="w-full h-14 text-lg font-bold shadow-md shadow-primary/20 mb-4" 
                    onClick={handlePurchase}
                    disabled={purchaseMutation.isPending}
                  >
                    {purchaseMutation.isPending ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      'Buy Now'
                    )}
                  </Button>
                ) : (
                  <Button variant="secondary" className="w-full h-14 font-bold mb-4" asChild>
                    <Link href={`/products/${product.id}/edit`}>Edit Product</Link>
                  </Button>
                )}

                <div className="space-y-4 text-sm text-muted-foreground border-t border-border pt-4">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-5 h-5 text-emerald-500" />
                    <span>Secure payment via NeuralMart</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Download className="w-5 h-5 text-primary" />
                    <span>Instant access after purchase</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Created By</h4>
                <Link href={`/creators/${product.creatorId}`}>
                  <div className="flex items-center gap-4 group cursor-pointer">
                    <Avatar className="w-14 h-14 border border-border group-hover:border-primary transition-colors">
                      <AvatarImage src={product.creator?.avatarUrl ?? undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary">{product.creator?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-bold group-hover:text-primary transition-colors">{product.creator?.displayName}</h4>
                      <p className="text-sm text-muted-foreground">{(product.creator as any)?.category || 'Creator'}</p>
                    </div>
                  </div>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

      </div>
    </div>
  );
}

function ProductSkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-8">
      <div className="lg:col-span-2 space-y-8">
        <Skeleton className="aspect-[16/9] w-full rounded-3xl" />
        <div className="space-y-4">
          <Skeleton className="h-10 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
          <Skeleton className="h-32 w-full mt-8" />
        </div>
      </div>
      <div className="lg:col-span-1">
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    </div>
  );
}