import React from 'react';
import { useListContests } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Filter, Trophy, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

export default function Contests() {
  const { data: contestsData, isLoading } = useListContests();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-8 mb-8">
        <div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-4">Contests</h1>
          <p className="text-lg text-muted-foreground">Compete in creative challenges to win prizes and build your portfolio.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" /> Filter
          </Button>
          <Button asChild>
            <Link href="/contests/new">Start a Contest</Link>
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      ) : !contestsData?.contests.length ? (
        <div className="text-center py-20 bg-card rounded-2xl border border-border">
          <Trophy className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">No active contests</h3>
          <p className="text-muted-foreground">Check back later or host your own contest.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {contestsData.contests.map((contest: any) => (
            <Link key={contest.id} href={`/contests/${contest.id}`}>
              <Card className="hover:border-accent/50 transition-all cursor-pointer group bg-card border-border shadow-sm hover:shadow-md h-full flex flex-col">
                <CardContent className="p-6 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10 border border-border">
                        <AvatarImage src={contest.host?.avatarUrl} />
                        <AvatarFallback className="bg-accent/10 text-accent font-bold">{contest.host?.displayName?.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <span className="text-sm font-bold text-foreground block leading-tight">{contest.host?.displayName}</span>
                        <span className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(contest.createdAt), { addSuffix: true })}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground font-semibold uppercase tracking-wider mb-1">Prize</div>
                      <div className="font-bold text-2xl text-accent leading-none">${contest.prizeAmount}</div>
                    </div>
                  </div>
                  
                  <h3 className="font-serif font-bold text-2xl mb-2 group-hover:text-accent transition-colors line-clamp-1">{contest.title}</h3>
                  <p className="text-muted-foreground line-clamp-2 mb-6 flex-1">{contest.brief}</p>
                  
                  <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
                    <div className="flex gap-2">
                      <Badge variant="outline" className="font-normal border-border bg-muted/50">
                        {contest.category}
                      </Badge>
                      <Badge variant={contest.status === 'open' ? 'default' : 'secondary'} className={contest.status === 'open' ? 'bg-accent hover:bg-accent/90 text-accent-foreground' : ''}>
                        {contest.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm font-medium text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {formatDistanceToNow(new Date(contest.deadline))} left
                      </span>
                      <span>{contest.submissionCount} entries</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}