import React from 'react';
import { useGetMe, useGetOpportunitiesFeed } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Trophy, Briefcase, ArrowRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'wouter';
import { motion } from 'framer-motion';

export default function ContestFeed() {
  const { data: user } = useGetMe();
  const { data: feedData, isLoading } = useGetOpportunitiesFeed();

  const isBuyer = user?.role === 'buyer' || user?.role === 'both';

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="max-w-2xl mx-auto pt-6 mb-5">
        <div className="flex items-center gap-3 mb-1">
          <div className="p-2 bg-accent/10 rounded-xl">
            <Trophy className="w-5 h-5 text-accent" />
          </div>
          <h1 className="text-2xl font-serif font-bold tracking-tight">Contest Feed</h1>
        </div>
        <p className="text-sm text-muted-foreground ml-[52px]">
          Open projects, contests, and hiring opportunities from buyers.
        </p>
      </div>

      {/* Buyer Composer */}
      {isBuyer && user && (
        <div className="max-w-2xl mx-auto mb-5">
          <BuyerComposer user={user} />
        </div>
      )}

      {/* Contest Feed */}
      {isLoading ? (
        <ContestFeedSkeleton />
      ) : (
        <div className="max-w-2xl mx-auto space-y-4 pb-12">
          {feedData?.items.map((item) => (
            <OpportunityCard key={`${item.type}-${item.id}`} item={item} />
          ))}

          {!feedData?.items.length && (
            <div className="text-center py-20 bg-card rounded-2xl border border-border">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-8 h-8 text-accent/60" />
              </div>
              <h3 className="text-xl font-bold mb-2">No open opportunities</h3>
              <p className="text-muted-foreground mb-6">
                {isBuyer
                  ? 'Post a project or host a contest to find top creators.'
                  : 'Check back soon — new projects and contests are posted daily.'}
              </p>
              {isBuyer && (
                <div className="flex justify-center gap-3">
                  <Link href="/projects/new?returnTo=/contest-feed">
                    <Button variant="outline" className="gap-2">
                      <Briefcase className="w-4 h-4" /> Post a Project
                    </Button>
                  </Link>
                  <Link href="/contests/new?returnTo=/contest-feed">
                    <Button className="gap-2">
                      <Trophy className="w-4 h-4" /> Host a Contest
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Buyer Composer ───────────────────────────────────────────────────────────

function BuyerComposer({ user }: { user: any }) {
  return (
    <Card className="border-border bg-card shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-9 w-9 border border-border flex-shrink-0">
            <AvatarImage src={user.avatarUrl || ''} />
            <AvatarFallback className="bg-muted text-muted-foreground text-sm">
              {user.displayName?.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 h-9 rounded-full bg-muted/60 border border-border flex items-center px-4 text-sm text-muted-foreground">
            What do you need help with?
          </div>
        </div>
        <div className="flex items-center gap-2 pt-1 border-t border-border/60">
          <Link href="/projects/new?returnTo=/contest-feed" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-foreground hover:bg-muted h-9">
              <Briefcase className="w-4 h-4" />
              Post Project
            </Button>
          </Link>
          <Link href="/contests/new?returnTo=/contest-feed" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-accent hover:bg-accent/10 h-9">
              <Trophy className="w-4 h-4" />
              Host Contest
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Opportunity Card ─────────────────────────────────────────────────────────

function OpportunityCard({ item }: { item: any }) {
  const isProject = item.type === 'project';
  const isContest = item.type === 'contest';
  const data = isProject ? item.project : item.contest;

  if (!data) return null;

  return (
    <Card className="border-border bg-card hover:border-accent/30 transition-colors">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className={`p-2 rounded-xl flex-shrink-0 mt-0.5 ${isProject ? 'bg-blue-500/10 text-blue-400' : 'bg-accent/10 text-accent'}`}>
              {isProject ? <Briefcase className="w-4 h-4" /> : <Trophy className="w-4 h-4" />}
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                {isProject ? 'Project' : 'Contest'}
              </span>
              <h3 className="font-serif font-bold text-base leading-tight mt-0.5 truncate">{data.title}</h3>
              {/* Poster info */}
              {(isProject ? item.project?.buyer : item.contest?.host) && (
                <div className="flex items-center gap-1.5 mt-1.5">
                  <Avatar className="w-4 h-4">
                    <AvatarImage src={(isProject ? item.project?.buyer : item.contest?.host)?.avatarUrl} />
                    <AvatarFallback className="text-[8px]">
                      {(isProject ? item.project?.buyer : item.contest?.host)?.displayName?.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground">
                    {(isProject ? item.project?.buyer : item.contest?.host)?.displayName}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="text-right flex-shrink-0">
            <div className={`font-bold text-base ${isContest ? 'text-accent' : 'text-foreground'}`}>
              {isProject
                ? `$${data.budgetMin}–$${data.budgetMax}`
                : `$${data.prizeAmount}`}
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">
              {data.deadline ? `Due ${formatDistanceToNow(new Date(data.deadline))}` : 'Open'}
            </div>
          </div>
        </div>

        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {isProject ? data.description : data.brief}
        </p>

        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {isProject
              ? `${data.proposalCount ?? 0} proposals`
              : `${data.submissionCount ?? 0} entries`}
          </span>
          <Link href={`/${isProject ? 'projects' : 'contests'}/${data.id}`}>
            <Button size="sm" variant={isContest ? 'default' : 'secondary'} className={`gap-1.5 ${isContest ? 'bg-accent hover:bg-accent/90 text-accent-foreground' : ''}`}>
              {isProject ? 'View Brief' : 'Enter Contest'}
              <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function ContestFeedSkeleton() {
  return (
    <div className="max-w-2xl mx-auto space-y-4 pb-12">
      {[1, 2, 3, 4].map((i) => (
        <Card key={i} className="border-border">
          <CardContent className="p-5">
            <div className="flex items-start gap-3 mb-3">
              <Skeleton className="w-8 h-8 rounded-xl flex-shrink-0" />
              <div className="flex-1 space-y-1.5">
                <Skeleton className="h-3 w-16" />
                <Skeleton className="h-4 w-48" />
              </div>
              <Skeleton className="h-4 w-16" />
            </div>
            <Skeleton className="h-3.5 w-full mb-1.5" />
            <Skeleton className="h-3.5 w-3/4 mb-4" />
            <div className="flex justify-between items-center">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="h-8 w-28 rounded-md" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
