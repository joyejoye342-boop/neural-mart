import React from 'react';
import { useGetCreatorDashboard } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { DollarSign, Briefcase, Star, Eye, TrendingUp, Users, Heart, MessageCircle, FileImage } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

export default function CreatorDashboard() {
  const { data: dashboard, isLoading } = useGetCreatorDashboard({
    query: { queryKey: ['creator-dashboard'] }
  });

  if (isLoading) return <DashboardSkeleton />;
  if (!dashboard) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-serif font-bold tracking-tight mb-2">Creator Hub</h1>
          <p className="text-lg text-muted-foreground">Manage your business, track earnings, and grow your audience.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" asChild><Link href="/profile/edit">Edit Profile</Link></Button>
          <Button asChild><Link href="/products/new">New Product</Link></Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4">
        <StatCard title="Total Earnings" value={`$${dashboard.totalEarnings.toFixed(2)}`} icon={DollarSign} trend="+12% this month" />
        <StatCard title="Active Orders" value={dashboard.activeOrders} icon={Briefcase} trend={`${dashboard.completedOrders} completed`} />
        <StatCard title="Published Posts" value={(dashboard as any).postCount ?? 0} icon={FileImage} trend={`${(dashboard as any).mediaPosts ?? 0} with media`} />
        <StatCard title="Post Likes" value={(dashboard as any).postLikes ?? 0} icon={Heart} trend="Across your posts" />
        <StatCard title="Comments" value={(dashboard as any).postComments ?? 0} icon={MessageCircle} trend="Community engagement" />
        <StatCard title="Followers" value={dashboard.followerCount} icon={Users} trend="Current followers" />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Chart Column */}
        <div className="lg:col-span-2 space-y-8">
          <Card className="bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif text-xl flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Revenue Over Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={dashboard.earningsByPeriod} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis 
                      dataKey="period" 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(value) => `$${value}`} 
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      itemStyle={{ color: 'hsl(var(--primary))' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="amount" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3} 
                      dot={{ r: 4, strokeWidth: 2, fill: 'hsl(var(--background))' }} 
                      activeDot={{ r: 6, fill: 'hsl(var(--primary))' }} 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="font-serif text-xl">Recent Orders</CardTitle>
              <Button variant="ghost" size="sm" asChild><Link href="/orders">View All</Link></Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mt-4">
                {!dashboard.recentOrders?.length ? (
                  <div className="text-center py-8 text-muted-foreground">No recent orders.</div>
                ) : (
                  dashboard.recentOrders.map((order: any) => (
                    <div key={order.id} className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/20 hover:bg-muted/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                          {order.buyer?.displayName?.charAt(0) || 'U'}
                        </div>
                        <div>
                          <div className="font-semibold">{order.buyer?.displayName || 'Unknown Buyer'}</div>
                          <div className="text-xs text-muted-foreground flex items-center gap-2">
                            <span className="capitalize">{order.type}</span>
                            <span>•</span>
                            {formatDistanceToNow(new Date(order.createdAt), { addSuffix: true })}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">${order.amount.toFixed(2)}</div>
                        <Badge variant={order.status === 'completed' ? 'default' : 'secondary'} className="mt-1 capitalize text-[10px]">
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Column */}
        <div className="space-y-8">
          <Card className="bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif text-xl flex items-center gap-2">
                <Star className="w-5 h-5 text-accent" />
                Reputation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-end gap-2">
                <span className="text-5xl font-bold">{dashboard.rating.toFixed(1)}</span>
                <span className="text-muted-foreground mb-1">/ 5.0</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Completion Rate</span>
                  <span className="font-semibold">{(dashboard as any).completionRate || 100}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${(dashboard as any).completionRate || 100}%` }} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Proposal Win Rate</span>
                  <span className="font-semibold">{dashboard.proposalWinRate || 0}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-accent" style={{ width: `${dashboard.proposalWinRate || 0}%` }} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif text-xl">Badges</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {!dashboard.badges?.length ? (
                  <p className="text-sm text-muted-foreground">Keep completing orders to earn badges.</p>
                ) : (
                  dashboard.badges.map((userBadge: any) => (
                    <div key={userBadge.id} className="flex flex-col items-center gap-1 p-3 bg-muted rounded-xl border border-border">
                      <div className="text-2xl">{userBadge.badge.icon}</div>
                      <span className="text-xs font-semibold text-center">{userBadge.badge.name}</span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, trend }: { title: string, value: string | number, icon: any, trend: string }) {
  return (
    <Card className="bg-card border-border shadow-sm hover:border-primary/20 transition-colors">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-primary/10 text-primary rounded-xl">
            <Icon className="w-5 h-5" />
          </div>
          <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-md">{trend}</span>
        </div>
        <div className="text-muted-foreground text-sm font-medium mb-1">{title}</div>
        <div className="text-3xl font-bold text-foreground">{value}</div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between">
        <div className="space-y-2">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-5 w-96" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Skeleton className="h-[400px] w-full rounded-xl" />
          <Skeleton className="h-[300px] w-full rounded-xl" />
        </div>
        <div className="space-y-8">
          <Skeleton className="h-[250px] w-full rounded-xl" />
          <Skeleton className="h-[200px] w-full rounded-xl" />
        </div>
      </div>
    </div>
  );
}