import React from 'react';
import { useParams, Link } from 'wouter';
import { useGetContest, useListContestSubmissions, useSubmitContestEntry, useGetMe, useSelectContestWinner } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Trophy, Calendar, ChevronRight, Loader2, Clock, Upload, Crown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { formatDistanceToNow, format } from 'date-fns';

const submissionSchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters'),
  description: z.string().min(20, 'Please provide a brief description'),
  previewUrl: z.string().url('Must be a valid URL to your preview image').optional().or(z.literal('')),
});

type SubmissionFormValues = z.infer<typeof submissionSchema>;

export default function ContestDetail() {
  const { id } = useParams();
  const contestId = parseInt(id || '0');
  const { toast } = useToast();
  const { data: user } = useGetMe();
  
  const { data: contest, isLoading: isContestLoading } = useGetContest(contestId, {
    query: { enabled: !!contestId }
  } as any);

  const { data: submissionsData, isLoading: isSubmissionsLoading } = useListContestSubmissions(contestId, {
    query: { enabled: !!contestId }
  } as any);

  const submitEntryMutation = useSubmitContestEntry();
  const selectWinnerMutation = useSelectContestWinner();

  const form = useForm<SubmissionFormValues>({
    resolver: zodResolver(submissionSchema),
    defaultValues: { title: '', description: '', previewUrl: '' },
  });

  const onSubmit = (data: SubmissionFormValues) => {
    submitEntryMutation.mutate({ id: contestId, data }, {
      onSuccess: () => {
        toast({
          title: "Entry submitted!",
          description: "Your submission has been entered into the contest.",
        });
        form.reset();
      },
      onError: (err) => {
        toast({
          title: "Failed to submit",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  const handleSelectWinner = (submissionId: number) => {
    selectWinnerMutation.mutate({ id: contestId, data: { submissionId } }, {
      onSuccess: () => {
        toast({
          title: "Winner selected!",
          description: "The prize will be awarded to the winner.",
        });
      },
      onError: (err) => {
        toast({
          title: "Error selecting winner",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  if (isContestLoading) return <ContestSkeleton />;
  if (!contest) return <div className="text-center py-20">Contest not found.</div>;

  const isOwner = user?.id === contest.hostId;
  const isCreator = user?.role === 'creator' || user?.role === 'both';

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-16">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6 pt-4">
        <Link href="/contests" className="hover:text-foreground transition-colors">Contests</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground">{contest.category}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Contest Details & Submissions */}
        <div className="lg:col-span-2 space-y-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold tracking-tight mb-4">{contest.title}</h1>
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <Badge variant={contest.status === 'open' ? 'default' : 'secondary'} className={`capitalize ${contest.status === 'open' ? 'bg-accent text-accent-foreground hover:bg-accent/90' : ''}`}>
                {contest.status}
              </Badge>
              <span className="text-muted-foreground text-sm flex items-center gap-1">
                <Clock className="w-4 h-4" /> Posted {formatDistanceToNow(new Date(contest.createdAt), { addSuffix: true })}
              </span>
              {contest.deadline && (
                <span className="text-muted-foreground text-sm flex items-center gap-1">
                  <Calendar className="w-4 h-4" /> Ends: {format(new Date(contest.deadline), 'MMM d, yyyy')}
                </span>
              )}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-sm">
            <h3 className="font-serif text-2xl mb-4">The Brief</h3>
            <p className="whitespace-pre-wrap text-muted-foreground leading-relaxed">
              {contest.brief}
            </p>
          </div>

          {/* Submissions Grid */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-2xl">Submissions ({contest.submissionCount})</h3>
            </div>
            
            {isSubmissionsLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Skeleton className="h-64 rounded-xl" />
                <Skeleton className="h-64 rounded-xl" />
              </div>
            ) : !submissionsData?.length ? (
              <div className="text-center py-12 bg-muted/50 border border-dashed border-border rounded-2xl text-muted-foreground">
                No submissions yet. Be the first!
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {submissionsData.map((sub: any) => (
                  <Card key={sub.id} className={`bg-card border-border shadow-sm overflow-hidden ${sub.isWinner ? 'ring-2 ring-accent' : ''}`}>
                    <div className="aspect-[4/3] bg-muted relative">
                      {sub.previewUrl ? (
                        <img src={sub.previewUrl} className="w-full h-full object-cover" alt="Submission preview" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-muted">
                          <span className="text-muted-foreground text-sm">No preview provided</span>
                        </div>
                      )}
                      {sub.isWinner && (
                        <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1 shadow-md">
                          <Crown className="w-4 h-4" /> Winner
                        </div>
                      )}
                    </div>
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <Link href={`/creators/${sub.creatorId}`}>
                          <Avatar className="w-8 h-8 border border-border cursor-pointer">
                            <AvatarImage src={sub.creator?.avatarUrl} />
                            <AvatarFallback>{sub.creator?.displayName?.charAt(0)}</AvatarFallback>
                          </Avatar>
                        </Link>
                        <Link href={`/creators/${sub.creatorId}`}>
                          <span className="text-sm font-medium hover:text-primary transition-colors cursor-pointer">{sub.creator?.displayName}</span>
                        </Link>
                      </div>
                      <h4 className="font-bold mb-1 truncate">{sub.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{sub.description}</p>
                      
                      {isOwner && contest.status === 'judging' && !sub.isWinner && !contest.winnerId && (
                        <Button 
                          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground mt-2" 
                          onClick={() => handleSelectWinner(sub.id)}
                          disabled={selectWinnerMutation.isPending}
                        >
                          Select as Winner
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Prize & Submit Box */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-6">
            <Card className="bg-card border-border shadow-lg border-t-4 border-t-accent">
              <CardContent className="p-6">
                <div className="mb-6 text-center pb-6 border-b border-border">
                  <div className="text-sm text-muted-foreground uppercase font-semibold tracking-wider mb-2">Prize Amount</div>
                  <div className="text-5xl font-serif font-bold text-accent">
                    ${contest.prizeAmount}
                  </div>
                </div>

                <div className="mb-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="w-12 h-12 border border-border">
                      <AvatarImage src={contest.host?.avatarUrl ?? undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary">{contest.host?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm text-muted-foreground">Hosted by</div>
                      <div className="font-bold">{contest.host?.displayName}</div>
                    </div>
                  </div>
                </div>

                {!isOwner && isCreator && contest.status === 'open' && (
                  <div className="pt-6 border-t border-border">
                    <h4 className="font-bold mb-4">Submit your Entry</h4>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Submission Title</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. Modern Logo Concept V1" className="bg-background" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description / Concept</FormLabel>
                              <FormControl>
                                <Textarea placeholder="Explain your design decisions..." className="resize-none bg-background h-24" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="previewUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preview Image URL</FormLabel>
                              <FormControl>
                                <Input type="url" placeholder="https://..." className="bg-background" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full h-12 font-bold"
                          disabled={submitEntryMutation.isPending}
                        >
                          {submitEntryMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Upload className="w-4 h-4 mr-2" /> Upload Entry</>}
                        </Button>
                      </form>
                    </Form>
                  </div>
                )}
                
                {!isCreator && !isOwner && (
                  <div className="p-4 bg-muted/50 rounded-xl text-center text-sm text-muted-foreground">
                    You must have a Creator account to submit entries.
                  </div>
                )}
                
                {isOwner && contest.status === 'open' && (
                  <div className="pt-6 border-t border-border">
                    <Button variant="outline" className="w-full h-12 font-bold">
                      Close Submissions & Start Judging
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

      </div>
    </div>
  );
}

function ContestSkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-8">
      <div className="lg:col-span-2 space-y-6">
        <Skeleton className="h-12 w-3/4" />
        <Skeleton className="h-6 w-1/2" />
        <Skeleton className="h-48 w-full rounded-2xl" />
        <Skeleton className="h-8 w-48 mt-8" />
        <div className="grid grid-cols-2 gap-4">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
      <div className="lg:col-span-1">
        <Skeleton className="h-[400px] w-full rounded-xl" />
      </div>
    </div>
  );
}