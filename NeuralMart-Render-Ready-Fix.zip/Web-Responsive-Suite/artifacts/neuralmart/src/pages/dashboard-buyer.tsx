import React from 'react';
import { useGetBuyerDashboard } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Briefcase, ShoppingBag, Trophy, FileText, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

export default function BuyerDashboard() {
  const { data: dashboard, isLoading } = useGetBuyerDashboard({
    query: { queryKey: ['buyer-dashboard'] }
  });

  if (isLoading) return <DashboardSkeleton />;
  if (!dashboard) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-serif font-bold tracking-tight mb-2">Buyer Hub</h1>
          <p className="text-lg text-muted-foreground">Manage your projects, track orders, and hire creators.</p>
        </div>
        <div className="flex gap-3">
          <Button asChild><Link href="/projects/new">Post Project</Link></Button>
          <Button variant="secondary" asChild><Link href="/contests/new">Start Contest</Link></Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Active Projects" value={dashboard.activeProjects} icon={Briefcase} />
        <StatCard title="Total Spent" value={`$${dashboard.totalSpent.toFixed(2)}`} icon={FileText} />
        <StatCard title="Products Owned" value={dashboard.purchasedProducts} icon={ShoppingBag} />
        <StatCard title="Active Contests" value={dashboard.activeContests} icon={Trophy} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
        
        {/* Active Projects */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="font-serif text-xl">Recent Projects</CardTitle>
            <Button variant="ghost" size="sm" asChild><Link href="/projects">View All</Link></Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 mt-4">
              {!dashboard.recentProjects?.length ? (
                <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-xl">
                  No recent projects. <Link href="/projects/new" className="text-primary hover:underline">Post one now</Link>.
                </div>
              ) : (
                dashboard.recentProjects.map((project: any) => (
                  <Link key={project.id} href={`/projects/${project.id}`}>
                    <div className="group flex items-start justify-between p-4 rounded-xl border border-border hover:border-primary/50 bg-muted/20 hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="flex-1 min-w-0 pr-4">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-foreground group-hover:text-primary transition-colors truncate">{project.title}</h4>
                          <Badge variant={project.status === 'open' ? 'default' : 'secondary'} className="capitalize text-[10px]">
                            {project.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2 line-clamp-1">{project.description}</p>
                        <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground">
                          <span>${project.budgetMin} - ${project.budgetMax}</span>
                          <span>•</span>
                          <span>{project.proposalCount} proposals</span>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-transform group-hover:translate-x-1 mt-1" />
                    </div>
                  </Link>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Orders */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="font-serif text-xl">Recent Orders</CardTitle>
            <Button variant="ghost" size="sm" asChild><Link href="/orders">View All</Link></Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 mt-4">
              {!dashboard.recentOrders?.length ? (
                <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-xl">
                  No orders yet.
                </div>
              ) : (
                dashboard.recentOrders.map((order: any) => (
                  <div key={order.id} className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/20 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center text-accent font-bold">
                        {order.seller?.displayName?.charAt(0) || 'C'}
                      </div>
                      <div>
                        <div className="font-semibold">{order.seller?.displayName || 'Unknown Creator'}</div>
                        <div className="text-xs text-muted-foreground flex items-center gap-2">
                          <span className="capitalize">{order.type}</span>
                          <span>•</span>
                          {formatDistanceToNow(new Date(order.createdAt), { addSuffix: true })}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">${order.amount.toFixed(2)}</div>
                      <Badge variant={order.status === 'completed' ? 'default' : 'secondary'} className="mt-1 capitalize text-[10px]">
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon }: { title: string, value: string | number, icon: any }) {
  return (
    <Card className="bg-card border-border shadow-sm hover:border-primary/20 transition-colors">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-primary/10 text-primary rounded-xl">
            <Icon className="w-5 h-5" />
          </div>
        </div>
        <div className="text-muted-foreground text-sm font-medium mb-1">{title}</div>
        <div className="text-3xl font-bold text-foreground">{value}</div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between">
        <div className="space-y-2">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-5 w-96" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Skeleton className="h-[400px] w-full rounded-xl" />
        <Skeleton className="h-[400px] w-full rounded-xl" />
      </div>
    </div>
  );
}