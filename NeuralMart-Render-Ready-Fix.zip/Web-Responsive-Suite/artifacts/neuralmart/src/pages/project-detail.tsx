import React from 'react';
import { useParams, Link } from 'wouter';
import { useGetProject, useListProjectProposals, useCreateProposal, useGetMe } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Briefcase, Calendar, ChevronRight, FileText, Loader2, DollarSign, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { formatDistanceToNow, format } from 'date-fns';

const proposalSchema = z.object({
  coverLetter: z.string().min(50, 'Cover letter must be at least 50 characters'),
  proposedPrice: z.coerce.number().min(1, 'Price must be greater than 0'),
  deliveryDays: z.coerce.number().min(1, 'Delivery days must be greater than 0'),
});

type ProposalFormValues = z.infer<typeof proposalSchema>;

export default function ProjectDetail() {
  const { id } = useParams();
  const projectId = parseInt(id || '0');
  const { toast } = useToast();
  const { data: user } = useGetMe();
  
  const { data: project, isLoading: isProjectLoading } = useGetProject(projectId, { query: { enabled: !!projectId } as any });

  const { data: proposalsData, isLoading: isProposalsLoading } = useListProjectProposals(projectId, { query: { enabled: !!projectId } as any });

  const createProposalMutation = useCreateProposal();

  const form = useForm<ProposalFormValues>({
    resolver: zodResolver(proposalSchema),
    defaultValues: { coverLetter: '', proposedPrice: project?.budgetMin || 0, deliveryDays: 7 },
  });

  const onSubmit = (data: ProposalFormValues) => {
    createProposalMutation.mutate({ id: projectId, data }, {
      onSuccess: () => {
        toast({
          title: "Proposal submitted!",
          description: "The buyer will review your proposal.",
        });
        form.reset();
      },
      onError: (err) => {
        toast({
          title: "Failed to submit",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  if (isProjectLoading) return <ProjectSkeleton />;
  if (!project) return <div className="text-center py-20">Project not found.</div>;

  const isOwner = user?.id === project.buyerId;
  const isCreator = user?.role === 'creator' || user?.role === 'both';

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-16">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6 pt-4">
        <Link href="/projects" className="hover:text-foreground transition-colors">Projects</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground">{project.category}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Project Details */}
        <div className="lg:col-span-2 space-y-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold tracking-tight mb-4">{project.title}</h1>
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <Badge variant={project.status === 'open' ? 'default' : 'secondary'} className="capitalize">
                {project.status.replace('_', ' ')}
              </Badge>
              <span className="text-muted-foreground text-sm flex items-center gap-1">
                <Clock className="w-4 h-4" /> Posted {formatDistanceToNow(new Date(project.createdAt), { addSuffix: true })}
              </span>
              {project.deadline && (
                <span className="text-muted-foreground text-sm flex items-center gap-1">
                  <Calendar className="w-4 h-4" /> Deadline: {format(new Date(project.deadline), 'MMM d, yyyy')}
                </span>
              )}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-sm">
            <h3 className="font-serif text-2xl mb-4">Project Details</h3>
            <p className="whitespace-pre-wrap text-muted-foreground leading-relaxed">
              {project.description}
            </p>
            
            {project.attachmentUrl && (
              <div className="mt-8 pt-6 border-t border-border">
                <h4 className="font-semibold mb-3">Attachments</h4>
                <a href={project.attachmentUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-primary hover:underline">
                  <FileText className="w-5 h-5" /> View Brief Document
                </a>
              </div>
            )}
          </div>

          {/* Proposals Section (for owner) */}
          {isOwner && (
            <div className="space-y-6">
              <h3 className="font-serif text-2xl">Proposals ({project.proposalCount})</h3>
              {isProposalsLoading ? (
                <Skeleton className="h-32 w-full rounded-xl" />
              ) : !proposalsData?.length ? (
                <div className="text-center py-12 bg-muted/50 border border-dashed border-border rounded-2xl text-muted-foreground">
                  No proposals yet.
                </div>
              ) : (
                proposalsData.map((prop: any) => (
                  <Card key={prop.id} className="bg-card border-border shadow-sm">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <Link href={`/creators/${prop.creatorId}`}>
                          <div className="flex items-center gap-3 group cursor-pointer">
                            <Avatar className="w-10 h-10 border border-border group-hover:border-primary">
                              <AvatarImage src={prop.creator?.avatarUrl} />
                              <AvatarFallback>{prop.creator?.displayName?.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="font-bold group-hover:text-primary transition-colors">{prop.creator?.displayName}</h4>
                              <p className="text-xs text-muted-foreground">{prop.creator?.category}</p>
                            </div>
                          </div>
                        </Link>
                        <div className="text-right">
                          <div className="font-bold text-lg">${prop.proposedPrice}</div>
                          <div className="text-xs text-muted-foreground">{prop.deliveryDays} days delivery</div>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap bg-muted/30 p-4 rounded-xl mb-4">
                        {prop.coverLetter}
                      </p>
                      <div className="flex justify-end gap-3">
                        <Button variant="outline" size="sm">Message</Button>
                        <Button size="sm">Accept Proposal</Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          )}
        </div>

        {/* Right: Budget & Apply Box */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-6">
            <Card className="bg-card border-border shadow-lg border-t-4 border-t-accent">
              <CardContent className="p-6">
                <div className="mb-6 text-center pb-6 border-b border-border">
                  <div className="text-sm text-muted-foreground uppercase font-semibold tracking-wider mb-2">Budget Range</div>
                  <div className="text-3xl font-serif font-bold text-foreground">
                    ${project.budgetMin} <span className="text-muted-foreground text-xl mx-1">-</span> ${project.budgetMax}
                  </div>
                </div>

                <div className="mb-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="w-12 h-12 border border-border">
                      <AvatarImage src={project.buyer?.avatarUrl ?? undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary">{project.buyer?.displayName?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm text-muted-foreground">Posted by</div>
                      <div className="font-bold">{project.buyer?.displayName}</div>
                    </div>
                  </div>
                </div>

                {!isOwner && isCreator && project.status === 'open' && (
                  <div className="pt-6 border-t border-border">
                    <h4 className="font-bold mb-4">Submit a Proposal</h4>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="proposedPrice"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Bid ($)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <DollarSign className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                                  <Input type="number" className="pl-9" {...field} />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="deliveryDays"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Delivery Time (Days)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Clock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                                  <Input type="number" className="pl-9" {...field} />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="coverLetter"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cover Letter</FormLabel>
                              <FormControl>
                                <Textarea placeholder="Why are you the best fit for this project?" className="min-h-[120px] resize-none" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full h-12 font-bold"
                          disabled={createProposalMutation.isPending}
                        >
                          {createProposalMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Submit Proposal'}
                        </Button>
                      </form>
                    </Form>
                  </div>
                )}
                
                {!isCreator && !isOwner && (
                  <div className="p-4 bg-muted/50 rounded-xl text-center text-sm text-muted-foreground">
                    You must have a Creator account to submit proposals.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

      </div>
    </div>
  );
}

function ProjectSkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-8">
      <div className="lg:col-span-2 space-y-6">
        <Skeleton className="h-12 w-3/4" />
        <Skeleton className="h-6 w-1/2" />
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
      <div className="lg:col-span-1">
        <Skeleton className="h-[400px] w-full rounded-xl" />
      </div>
    </div>
  );
}