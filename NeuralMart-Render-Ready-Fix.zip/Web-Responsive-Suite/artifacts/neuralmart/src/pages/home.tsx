import React from 'react';
import { useGetMe, useGetShowcaseFeed } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ShoppingBag, Trophy, Plus, Layers, Briefcase, ArrowRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { PostInteractions } from '@/components/posts/PostInteractions';

export default function Home() {
  const { data: user, isLoading: isUserLoading } = useGetMe();

  if (isUserLoading) return <HomeSkeleton />;
  if (!user) return null;

  const isCreator = user.role === 'creator' || user.role === 'both';
  const isBuyer = user.role === 'buyer' || user.role === 'both';

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Composer — role-aware, always at top */}
      <div className="max-w-2xl mx-auto mb-6 pt-4">
        {isCreator && <CreatorComposer user={user} />}
        {isBuyer && !isCreator && <BuyerComposer user={user} />}
        {isCreator && isBuyer && <BuyerComposerSecondary />}
      </div>

      {/* Showcase Feed — same for everyone */}
      <ShowcaseFeed />
    </div>
  );
}

// ─── Creator Composer ────────────────────────────────────────────────────────

function CreatorComposer({ user }: { user: any }) {
  return (
    <Card className="border-border bg-card shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <Link href={`/creators/${user.id}`} aria-label="Open your profile">
            <Avatar className="h-9 w-9 border border-border flex-shrink-0">
              <AvatarImage src={user.avatarUrl || ''} />
              <AvatarFallback className="bg-primary/10 text-primary text-sm">
                {user.displayName?.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </Link>
          <Link href="/posts" className="flex-1 h-9 rounded-full bg-muted/60 border border-border flex items-center px-4 text-sm text-muted-foreground hover:bg-muted transition-colors">
            Share your latest work…
          </Link>
        </div>
        <div className="flex items-center gap-2 pt-1 border-t border-border/60">
          <Link href="/posts" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-primary hover:bg-primary/10 h-9">
              <Plus className="w-4 h-4" />
              Post
            </Button>
          </Link>
          <Link href="/products/new" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-primary hover:bg-primary/10 h-9">
              <ShoppingBag className="w-4 h-4" />
              Product
            </Button>
          </Link>
          <Link href="/services/new" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-primary hover:bg-primary/10 h-9">
              <Layers className="w-4 h-4" />
              Service
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Buyer Composer (buyer-only role) ────────────────────────────────────────

function BuyerComposer({ user }: { user: any }) {
  return (
    <Card className="border-border bg-card shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <Link href={`/creators/${user.id}`} aria-label="Open your profile">
            <Avatar className="h-9 w-9 border border-border flex-shrink-0">
              <AvatarImage src={user.avatarUrl || ''} />
              <AvatarFallback className="bg-muted text-muted-foreground text-sm">
                {user.displayName?.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </Link>
          <div className="flex-1 h-9 rounded-full bg-muted/60 border border-border flex items-center px-4 text-sm text-muted-foreground cursor-pointer hover:bg-muted transition-colors">
            What do you need help with?
          </div>
        </div>
        <div className="flex items-center gap-2 pt-1 border-t border-border/60">
          <Link href="/projects/new?returnTo=/" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-foreground hover:bg-muted h-9">
              <Briefcase className="w-4 h-4" />
              Post Project
            </Button>
          </Link>
          <Link href="/contests/new?returnTo=/" className="flex-1">
            <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground hover:text-accent hover:bg-accent/10 h-9">
              <Trophy className="w-4 h-4" />
              Host Contest
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Buyer action strip for "both" users (below creator composer) ─────────────

function BuyerComposerSecondary() {
  return (
    <div className="flex gap-2 mt-3">
      <Link href="/projects/new?returnTo=/" className="flex-1">
        <Button variant="outline" size="sm" className="w-full gap-2 text-muted-foreground hover:text-foreground h-9">
          <Briefcase className="w-4 h-4" />
          Post a Project
        </Button>
      </Link>
      <Link href="/contests/new?returnTo=/" className="flex-1">
        <Button variant="outline" size="sm" className="w-full gap-2 text-muted-foreground hover:text-accent hover:border-accent/40 h-9">
          <Trophy className="w-4 h-4" />
          Host a Contest
        </Button>
      </Link>
    </div>
  );
}

// ─── Showcase Feed ────────────────────────────────────────────────────────────

function ShowcaseFeed() {
  const { data: feedData, isLoading } = useGetShowcaseFeed();

  if (isLoading) return <FeedSkeleton />;

  return (
    <div className="max-w-2xl mx-auto space-y-5 pb-12">
      {feedData?.items.map((item) => (
        <PostCard key={item.id} post={item.post} />
      ))}
      {!feedData?.items.length && (
        <div className="text-center py-20 bg-card rounded-2xl border border-border">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-bold mb-2">No posts yet</h3>
          <p className="text-muted-foreground mb-6">Follow creators to see their latest work here.</p>
          <Link href="/explore">
            <Button>Explore Creators</Button>
          </Link>
        </div>
      )}
    </div>
  );
}

// ─── Cards ────────────────────────────────────────────────────────────────────

export function PostCard({ post }: { post: any }) {
  if (!post) return null;
  return (
    <Card className="overflow-hidden border-border bg-card hover:border-primary/20 transition-colors">
      <CardHeader className="flex flex-row items-center gap-3 p-4 pb-2">
        <Link href={`/creators/${post.creatorId}`} aria-label={`Open ${post.creator?.displayName ?? "creator"} profile`}>
          <Avatar className="w-10 h-10 border border-border cursor-pointer flex-shrink-0">
            <AvatarImage src={post.creator?.avatarUrl} />
            <AvatarFallback className="text-xs">{post.creator?.displayName?.charAt(0)}</AvatarFallback>
          </Avatar>
        </Link>
        <div className="flex-1 min-w-0">
          <Link href={`/creators/${post.creatorId}`}>
            <p className="font-semibold text-sm cursor-pointer hover:underline truncate">{post.creator?.displayName}</p>
          </Link>
          <p className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(post.createdAt))} ago</p>
        </div>
      </CardHeader>

      <CardContent className="p-4 pt-2">
        <p className="text-sm whitespace-pre-wrap leading-relaxed mb-3">{post.content}</p>
        {post.mediaUrl && (
          <div className="rounded-xl overflow-hidden bg-muted aspect-video">
            <img src={post.mediaUrl} alt="Post media" className="w-full h-full object-cover" />
          </div>
        )}
      </CardContent>

      <PostInteractions post={post} />
    </Card>
  );
}

export function ProductCard({ product }: { product: any }) {
  return (
    <Card className="overflow-hidden border-border bg-card group">
      <div className="aspect-[21/9] bg-muted relative overflow-hidden">
        {product.previewImageUrl ? (
          <img src={product.previewImageUrl} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/5">
            <ShoppingBag className="w-12 h-12 text-primary/20" />
          </div>
        )}
        <div className="absolute top-3 right-3 bg-background/90 backdrop-blur-sm px-2.5 py-1 rounded-full text-sm font-bold">
          ${product.price}
        </div>
      </div>
      <CardContent className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Avatar className="w-5 h-5">
            <AvatarImage src={product.creator?.avatarUrl} />
            <AvatarFallback className="text-[10px]">{product.creator?.displayName?.charAt(0)}</AvatarFallback>
          </Avatar>
          <span className="text-xs font-medium text-muted-foreground">{product.creator?.displayName}</span>
        </div>
        <h3 className="font-serif font-bold text-lg mb-1.5 leading-tight">{product.title}</h3>
        <p className="text-muted-foreground text-sm line-clamp-2 mb-4">{product.description}</p>
        <Link href={`/products/${product.id}`}>
          <Button className="w-full gap-2 group/btn" size="sm">
            View Product
            <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

// ─── Skeletons ────────────────────────────────────────────────────────────────

function HomeSkeleton() {
  return (
    <div className="max-w-2xl mx-auto space-y-5 pt-4 pb-12">
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="flex-1 h-9 rounded-full" />
          </div>
          <Skeleton className="h-9 w-full rounded-lg" />
        </CardContent>
      </Card>
      {[1, 2, 3].map((i) => (
        <Card key={i} className="border-border">
          <CardHeader className="flex flex-row items-center gap-3 p-4 pb-2">
            <Skeleton className="w-10 h-10 rounded-full" />
            <div className="space-y-1.5 flex-1">
              <Skeleton className="h-3.5 w-28" />
              <Skeleton className="h-3 w-16" />
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-2 space-y-2">
            <Skeleton className="h-3.5 w-full" />
            <Skeleton className="h-3.5 w-4/5" />
            <Skeleton className="h-48 w-full rounded-xl mt-3" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function FeedSkeleton() {
  return (
    <div className="max-w-2xl mx-auto space-y-5 pb-12">
      {[1, 2, 3].map((i) => (
        <Card key={i} className="border-border">
          <CardHeader className="flex flex-row items-center gap-3 p-4 pb-2">
            <Skeleton className="w-10 h-10 rounded-full" />
            <div className="space-y-1.5 flex-1">
              <Skeleton className="h-3.5 w-28" />
              <Skeleton className="h-3 w-16" />
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-2 space-y-2">
            <Skeleton className="h-3.5 w-full" />
            <Skeleton className="h-3.5 w-4/5" />
            <Skeleton className="h-48 w-full rounded-xl mt-3" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
