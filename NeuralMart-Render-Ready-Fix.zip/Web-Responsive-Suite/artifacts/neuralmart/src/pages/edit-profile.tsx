import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useGetMe, useUpdateUser, useUpdateCreator } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Camera, User } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const profileSchema = z.object({
  displayName: z.string().min(2, 'Name must be at least 2 characters'),
  bio: z.string().max(500, 'Bio must be less than 500 characters').optional().or(z.literal('')),
  category: z.string().optional().or(z.literal('')),
  avatarUrl: z.string().url('Must be a valid URL').optional().or(z.literal('')),
  coverUrl: z.string().url('Must be a valid URL').optional().or(z.literal('')),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function EditProfile() {
  const { toast } = useToast();
  const { data: user, isLoading } = useGetMe();
  const updateUserMutation = useUpdateUser();
  const updateCreatorMutation = useUpdateCreator();

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    values: {
      displayName: user?.displayName || '',
      bio: user?.bio || '',
      category: '', // Actually needs fetching full creator profile for this, but using empty for now
      avatarUrl: user?.avatarUrl || '',
      coverUrl: user?.coverUrl || '',
    },
  });

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto py-8 space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-[500px] w-full rounded-2xl" />
      </div>
    );
  }

  if (!user) return null;

  const isCreator = user.role === 'creator' || user.role === 'both';

  const onSubmit = (data: ProfileFormValues) => {
    // Update base user info
    updateUserMutation.mutate({ 
      id: user.id, 
      data: { 
        displayName: data.displayName,
        avatarUrl: data.avatarUrl || undefined,
        coverUrl: data.coverUrl || undefined,
        bio: data.bio || undefined,
      }
    }, {
      onSuccess: () => {
        // If creator, also update creator-specific info
        if (isCreator && data.category) {
          updateCreatorMutation.mutate({
            id: user.id, // Assuming creator ID matches user ID in this context for simplicity
            data: { category: data.category, bio: data.bio || undefined }
          });
        }
        toast({
          title: "Profile updated",
          description: "Your profile has been saved successfully.",
        });
      },
      onError: (err) => {
        toast({
          title: "Error updating profile",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  const isPending = updateUserMutation.isPending || updateCreatorMutation.isPending;

  return (
    <div className="max-w-3xl mx-auto py-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="mb-8">
        <h1 className="text-4xl font-serif font-bold tracking-tight mb-2">Edit Profile</h1>
        <p className="text-lg text-muted-foreground">Update your personal information and how you appear to others.</p>
      </div>

      <Card className="bg-card border-border shadow-sm">
        <CardContent className="p-0">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              
              {/* Cover Image Preview */}
              <div className="h-48 w-full bg-muted relative border-b border-border group overflow-hidden rounded-t-xl">
                {form.watch('coverUrl') ? (
                  <img src={form.watch('coverUrl')} alt="Cover preview" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-tr from-primary/20 to-accent/20" />
                )}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="text-white flex items-center gap-2 font-medium">
                    <Camera className="w-5 h-5" /> Change Cover
                  </div>
                </div>
              </div>

              <div className="px-6 md:px-8 pb-8">
                {/* Avatar Preview */}
                <div className="relative -mt-16 mb-8 w-max group">
                  <Avatar className="w-32 h-32 border-4 border-card bg-muted shadow-lg">
                    <AvatarImage src={form.watch('avatarUrl') || ''} />
                    <AvatarFallback className="text-4xl bg-primary/10 text-primary">{form.watch('displayName')?.charAt(0) || <User className="w-12 h-12" />}</AvatarFallback>
                  </Avatar>
                  <div className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                    <Camera className="w-6 h-6 text-white" />
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="avatarUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Avatar Image URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://..." className="bg-background" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="coverUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cover Image URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://..." className="bg-background" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="displayName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Display Name</FormLabel>
                          <FormControl>
                            <Input className="bg-background" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    {isCreator && (
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Primary Category</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. 3D Artist" className="bg-background" {...field} />
                            </FormControl>
                            <FormDescription>What best describes your work?</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bio</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Tell the community about yourself..." 
                            className="min-h-[120px] resize-y bg-background" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>Brief description for your profile. URLs are hyperlinked.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end pt-8 mt-8 border-t border-border gap-4">
                  <Button variant="ghost" type="button" onClick={() => window.history.back()}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="font-bold px-8"
                    disabled={isPending}
                  >
                    {isPending ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : null}
                    Save Changes
                  </Button>
                </div>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}