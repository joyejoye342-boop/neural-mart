import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useCreateContest } from '@workspace/api-client-react';
import { Link, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ArrowLeft, Trophy } from 'lucide-react';

const contestSchema = z.object({
  title: z.string().min(10, 'Title must be at least 10 characters'),
  category: z.string().min(2, 'Category is required'),
  brief: z.string().min(50, 'Brief must be detailed enough (min 50 characters)'),
  prizeAmount: z.coerce.number().min(50, 'Minimum prize is $50'),
  deadline: z.string().min(1, 'Deadline is required'),
});

type ContestFormValues = z.infer<typeof contestSchema>;

export default function NewContest() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const createContestMutation = useCreateContest();

  // Support ?returnTo=/ or ?returnTo=/contest-feed so the feed composer can
  // return the user to the right feed after publishing.
  const returnTo = new URLSearchParams(window.location.search).get('returnTo');

  const form = useForm<ContestFormValues>({
    resolver: zodResolver(contestSchema),
    defaultValues: {
      title: '',
      category: '',
      brief: '',
      prizeAmount: 150,
      deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days from now
    },
  });

  const onSubmit = (data: ContestFormValues) => {
    const payload = {
      ...data,
      deadline: new Date(data.deadline).toISOString()
    };

    createContestMutation.mutate({ data: payload }, {
      onSuccess: (res) => {
        toast({
          title: "Contest launched!",
          description: "Your contest is now live for creators to enter.",
        });
        setLocation(returnTo || `/contests/${res.id}`);
      },
      onError: (err) => {
        toast({
          title: "Error launching contest",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="max-w-3xl mx-auto py-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <Button variant="ghost" className="mb-6 -ml-4 text-muted-foreground hover:text-foreground" onClick={() => window.history.back()}>
        <ArrowLeft className="w-4 h-4 mr-2" /> Back
      </Button>

      <div className="mb-8">
        <h1 className="text-4xl font-serif font-bold tracking-tight mb-2">Host a Contest</h1>
        <p className="text-lg text-muted-foreground">Get dozens of creative submissions and only pay for the winner.</p>
      </div>

      <Card className="bg-card border-border shadow-lg">
        <CardHeader className="bg-muted/30 border-b border-border p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-accent/10 text-accent rounded-xl">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Contest Brief</CardTitle>
              <CardDescription>Provide clear instructions to get the best entries.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">Contest Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Logo Design for a Tech Startup" className="h-12 text-lg bg-background" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Graphic Design" className="h-12 bg-background" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deadline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contest Deadline</FormLabel>
                      <FormControl>
                        <Input type="date" className="h-12 bg-background" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="p-6 bg-muted/50 rounded-xl border border-border">
                <FormField
                  control={form.control}
                  name="prizeAmount"
                  render={({ field }) => (
                    <FormItem>
                      <div>
                        <FormLabel className="text-base">Prize Amount (USD)</FormLabel>
                        <p className="text-sm text-muted-foreground mb-3">Higher prizes attract more experienced creators.</p>
                      </div>
                      <FormControl>
                        <Input type="number" className="h-12 bg-background text-lg font-bold" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="brief"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">Creative Brief</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe your brand, target audience, style preferences, and what exactly needs to be delivered..." 
                        className="min-h-[200px] text-base resize-y bg-background" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end pt-6 border-t border-border">
                <Button 
                  type="submit" 
                  size="lg" 
                  className="font-bold px-8 h-14 bg-accent hover:bg-accent/90 text-accent-foreground"
                  disabled={createContestMutation.isPending}
                >
                  {createContestMutation.isPending ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : null}
                  Launch Contest
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}