import React from 'react';
import { Link, useLocation } from 'wouter';
import { useGetMe } from '@workspace/api-client-react';
import {
  Home,
  Search,
  MessageSquare,
  LayoutDashboard,
  Menu as MenuIcon,
  Bell,
  Hexagon,
  Trophy,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { motion } from 'framer-motion';

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: user, isLoading } = useGetMe({ query: { retry: false } } as any);

  const isAuthPage = location === '/login' || location === '/register';

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}
        >
          <Hexagon className="w-8 h-8 text-primary" />
        </motion.div>
      </div>
    );
  }

  if (!user && !isAuthPage) {
    window.location.href = import.meta.env.BASE_URL + 'login';
    return null;
  }

  if (user && isAuthPage) {
    window.location.href = import.meta.env.BASE_URL;
    return null;
  }

  if (isAuthPage) return <>{children}</>;

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Search, label: 'Explore', path: '/explore' },
    { icon: MessageSquare, label: 'Messages', path: '/messages' },
    {
      icon: LayoutDashboard,
      label: 'Dashboard',
      path:
        user?.role === 'creator' || user?.role === 'both'
          ? '/dashboard/creator'
          : '/dashboard/buyer',
    },
    { icon: MenuIcon, label: 'Menu', path: '/menu' },
  ];

  const isContestFeed = location === '/contest-feed';

  return (
    <div className="flex min-h-[100dvh] bg-background">
      {/* ── Desktop Sidebar ─────────────────────────────────────────── */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border bg-card fixed h-full z-10">
        {/* Logo */}
        <div className="p-6 pb-4">
          <Link href="/" className="flex items-center gap-2 text-primary">
            <Hexagon className="w-8 h-8 fill-primary/20" />
            <span className="font-serif font-bold text-2xl tracking-tight text-foreground">
              NeuralMart
            </span>
          </Link>
        </div>

        {/* Main Nav */}
        <nav className="flex-1 px-4 space-y-1 mt-2">
          {navItems.map((item) => {
            const isActive =
              location === item.path ||
              (item.path !== '/' && location.startsWith(item.path));
            return (
              <Link key={item.path} href={item.path} className="block">
                <Button
                  variant={isActive ? 'secondary' : 'ghost'}
                  className={cn(
                    'w-full justify-start gap-3 h-11 text-sm font-medium rounded-xl transition-all',
                    isActive
                      ? 'bg-primary/10 text-primary hover:bg-primary/20'
                      : 'text-muted-foreground hover:text-foreground hover:bg-accent/10',
                  )}
                >
                  <item.icon className={cn('w-5 h-5', isActive ? 'text-primary' : '')} />
                  {item.label}
                </Button>
              </Link>
            );
          })}

          {/* Contest Feed — secondary nav item */}
          <div className="pt-2 mt-2 border-t border-border/60">
            <Link href="/contest-feed" className="block">
              <Button
                variant={isContestFeed ? 'secondary' : 'ghost'}
                className={cn(
                  'w-full justify-start gap-3 h-11 text-sm font-medium rounded-xl transition-all',
                  isContestFeed
                    ? 'bg-accent/15 text-accent hover:bg-accent/20'
                    : 'text-muted-foreground hover:text-accent hover:bg-accent/10',
                )}
              >
                <Trophy
                  className={cn('w-5 h-5', isContestFeed ? 'text-accent' : '')}
                />
                Contest Feed
              </Button>
            </Link>
          </div>
        </nav>

        {/* User Card */}
        <div className="p-4 border-t border-border mt-auto">
          <Link href={`/creators/${user?.id}`} className="block">
            <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted transition-colors cursor-pointer">
              <Avatar className="h-9 w-9 border border-border flex-shrink-0">
                <AvatarImage src={user?.avatarUrl || ''} />
                <AvatarFallback className="bg-primary/10 text-primary text-sm">
                  {user?.displayName?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="overflow-hidden">
                <p className="text-sm font-semibold truncate">{user?.displayName}</p>
                <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
              </div>
            </div>
          </Link>
        </div>
      </aside>

      {/* ── Main Content ─────────────────────────────────────────────── */}
      <main className="flex-1 md:pl-64 flex flex-col min-h-screen relative pb-16 md:pb-0">
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 z-20 flex items-center justify-between px-4 h-14 bg-background/80 backdrop-blur-md border-b border-border">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 text-primary">
            <Hexagon className="w-6 h-6 fill-primary/20" />
            <span className="font-serif font-bold text-xl tracking-tight text-foreground">
              NeuralMart
            </span>
          </Link>

          {/* Right cluster: Contest Feed · Bell · Avatar */}
          <div className="flex items-center gap-1">
            {/* Contest Feed toggle */}
            <Link href={isContestFeed ? '/' : '/contest-feed'}>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  'rounded-full h-9 w-9 relative',
                  isContestFeed
                    ? 'bg-accent/15 text-accent hover:bg-accent/20'
                    : 'text-muted-foreground hover:text-accent hover:bg-accent/10',
                )}
                aria-label="Contest Feed"
              >
                <Trophy className="w-5 h-5" />
                {/* Future: unread badge dot */}
              </Button>
            </Link>

            <Button
              variant="ghost"
              size="icon"
              className="rounded-full h-9 w-9 text-muted-foreground"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
            </Button>

            <Link href={`/creators/${user?.id}`}>
              <Avatar className="h-8 w-8 border border-border cursor-pointer">
                <AvatarImage src={user?.avatarUrl || ''} />
                <AvatarFallback className="bg-primary/10 text-primary text-xs">
                  {user?.displayName?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </Link>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 w-full max-w-5xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>

      {/* ── Mobile Bottom Nav ────────────────────────────────────────── */}
      <nav className="md:hidden fixed bottom-0 w-full bg-card border-t border-border z-20 pb-safe">
        <div className="flex justify-around items-center h-14">
          {navItems.map((item) => {
            const isActive =
              location === item.path ||
              (item.path !== '/' && location.startsWith(item.path));
            return (
              <Link key={item.path} href={item.path} className="flex-1 flex justify-center">
                <div
                  className={cn(
                    'flex flex-col items-center justify-center w-full h-full gap-0.5 transition-colors',
                    isActive ? 'text-primary' : 'text-muted-foreground',
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-[9px] font-medium">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
