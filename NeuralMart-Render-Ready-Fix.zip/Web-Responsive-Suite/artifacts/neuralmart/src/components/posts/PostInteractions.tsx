import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageCircle, Share2, Loader2, Trash2 } from "lucide-react";
import {
  getGetHomeFeedQueryKey,
  getGetShowcaseFeedQueryKey,
  getListPostCommentsQueryKey,
  getListPostsQueryKey,
  useCreatePostComment,
  useDeletePostComment,
  useGetMe,
  useListPostComments,
  useTogglePostLike,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const commentSchema = z.object({
  content: z.string().trim().min(1, "Write a comment before submitting.").max(2000, "Comments must be 2,000 characters or fewer."),
});

type CommentFormValues = z.infer<typeof commentSchema>;

function getErrorMessage(error: unknown, fallback: string) {
  const apiError = error as { data?: { error?: string }; message?: string } | null;
  return apiError?.data?.error || apiError?.message || fallback;
}

function PostCommentList({ post, comments, currentUserId, onDelete, deletingId }: {
  post: any;
  comments: any[];
  currentUserId?: number;
  onDelete: (commentId: number) => void;
  deletingId?: number;
}) {
  if (!comments.length) {
    return <p className="py-4 text-sm text-muted-foreground">No comments yet. Be the first to comment.</p>;
  }

  return (
    <div className="space-y-4 py-4">
      {comments.map((comment) => {
        const canDelete = currentUserId === comment.userId || currentUserId === post.creatorId;
        return (
          <div key={comment.id} className="flex gap-3" data-testid={`comment-${comment.id}`}>
            <Link href={`/creators/${comment.author?.id}`} aria-label={`Open ${comment.author?.displayName ?? "user"} profile`}>
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarImage src={comment.author?.avatarUrl ?? ""} />
                <AvatarFallback>{comment.author?.displayName?.charAt(0)?.toUpperCase() ?? "U"}</AvatarFallback>
              </Avatar>
            </Link>
            <div className="min-w-0 flex-1 rounded-xl bg-muted/60 px-3 py-2">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <Link href={`/creators/${comment.author?.id}`} className="text-sm font-semibold hover:underline">
                    {comment.author?.displayName ?? "NeuralMart member"}
                  </Link>
                  <p className="mt-1 whitespace-pre-wrap break-words text-sm">{comment.content}</p>
                  <time className="mt-1 block text-xs text-muted-foreground" dateTime={new Date(comment.createdAt).toISOString()}>
                    {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                  </time>
                </div>
                {canDelete && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label="Delete comment"
                    data-testid={`button-delete-comment-${comment.id}`}
                    disabled={deletingId === comment.id}
                    onClick={() => onDelete(comment.id)}
                    className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                  >
                    {deletingId === comment.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                  </Button>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function PostInteractions({ post }: { post: any }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: currentUser, isLoading: isUserLoading } = useGetMe({ query: { retry: false } });
  const [isLiked, setIsLiked] = useState(Boolean(post.isLiked));
  const [likesCount, setLikesCount] = useState(Number(post.likesCount ?? 0));
  const [commentsCount, setCommentsCount] = useState(Number(post.commentsCount ?? 0));
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number>();
  const likeMutation = useTogglePostLike();
  const commentMutation = useCreatePostComment();
  const deleteCommentMutation = useDeletePostComment();
  const commentsQuery = useListPostComments(post.id, {
    query: {
      enabled: commentsOpen,
      queryKey: getListPostCommentsQueryKey(post.id),
    },
  });

  const form = useForm<CommentFormValues>({
    resolver: zodResolver(commentSchema),
    defaultValues: { content: "" },
  });

  useEffect(() => {
    setIsLiked(Boolean(post.isLiked));
    setLikesCount(Number(post.likesCount ?? 0));
    setCommentsCount(Number(post.commentsCount ?? 0));
  }, [post.id, post.isLiked, post.likesCount, post.commentsCount]);

  const refreshPostLists = () => {
    void queryClient.invalidateQueries({ queryKey: getGetShowcaseFeedQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getGetHomeFeedQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
  };

  const handleLike = () => {
    if (!currentUser) {
      toast({ title: "Sign in to like posts", description: "Your likes are saved to your account." });
      return;
    }
    if (likeMutation.isPending) return;

    const previousLiked = isLiked;
    const previousCount = likesCount;
    setIsLiked(!previousLiked);
    setLikesCount(Math.max(0, previousCount + (previousLiked ? -1 : 1)));

    likeMutation.mutate({ id: post.id }, {
      onSuccess: (result) => {
        setIsLiked(result.isLiked);
        setLikesCount(result.likesCount);
        refreshPostLists();
      },
      onError: (error) => {
        setIsLiked(previousLiked);
        setLikesCount(previousCount);
        toast({
          title: "Couldn't update your like",
          description: getErrorMessage(error, "Please try again."),
          variant: "destructive",
        });
      },
    });
  };

  const handleCommentSubmit = (values: CommentFormValues) => {
    if (!currentUser) {
      toast({ title: "Sign in to comment", description: "Sign in to join the conversation." });
      return;
    }
    commentMutation.mutate({ id: post.id, data: { content: values.content } }, {
      onSuccess: (createdComment) => {
        queryClient.setQueryData(getListPostCommentsQueryKey(post.id), (cached: any) => cached
          ? { ...cached, comments: [createdComment, ...cached.comments], total: cached.total + 1 }
          : cached);
        setCommentsCount((count) => count + 1);
        form.reset({ content: "" });
        refreshPostLists();
        toast({ title: "Comment posted" });
      },
      onError: (error) => {
        toast({
          title: "Couldn't post your comment",
          description: getErrorMessage(error, "Please check your connection and try again."),
          variant: "destructive",
        });
      },
    });
  };

  const handleDeleteComment = (commentId: number) => {
    setDeletingId(commentId);
    deleteCommentMutation.mutate({ id: post.id, commentId }, {
      onSuccess: () => {
        queryClient.setQueryData(getListPostCommentsQueryKey(post.id), (cached: any) => cached
          ? {
              ...cached,
              comments: cached.comments.filter((comment: any) => comment.id !== commentId),
              total: Math.max(0, cached.total - 1),
            }
          : cached);
        setCommentsCount((count) => Math.max(0, count - 1));
        refreshPostLists();
        toast({ title: "Comment deleted" });
      },
      onError: (error) => {
        toast({
          title: "Couldn't delete this comment",
          description: getErrorMessage(error, "You may only delete your own comment."),
          variant: "destructive",
        });
      },
      onSettled: () => setDeletingId(undefined),
    });
  };

  const handleShare = async () => {
    const profileUrl = new URL(
      `creators/${post.creatorId}`,
      new URL(import.meta.env.BASE_URL, window.location.origin),
    ).toString();
    const shareText = `Check out this work from ${post.creator?.displayName ?? "a NeuralMart creator"}: ${post.content}\n${profileUrl}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "NeuralMart creator work", text: shareText });
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareText);
        toast({ title: "Post details copied", description: "Share them in a message or post." });
      } else {
        toast({ title: "Sharing isn't available in this browser", variant: "destructive" });
      }
    } catch (error) {
      if ((error as DOMException)?.name !== "AbortError") {
        toast({ title: "Couldn't share this post", description: "Please try again.", variant: "destructive" });
      }
    }
  };

  return (
    <>
      <CardFooter className="flex flex-col items-stretch border-t border-border/50 px-4 pb-3 pt-0">
        <div className="flex items-center justify-between">
          <div className="mt-3 flex items-center gap-1">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              data-testid={`button-like-post-${post.id}`}
              aria-label={isLiked ? "Unlike post" : "Like post"}
              aria-pressed={isLiked}
              disabled={isUserLoading || likeMutation.isPending}
              onClick={handleLike}
              className={`gap-1.5 px-2 ${isLiked ? "text-primary" : "text-muted-foreground hover:text-primary"}`}
            >
              {likeMutation.isPending
                ? <Loader2 className="h-4 w-4 animate-spin" />
                : <Heart className={`h-4 w-4 ${isLiked ? "fill-primary text-primary" : ""}`} />}
              <span data-testid={`text-likes-count-${post.id}`}>{likesCount}</span>
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              data-testid={`button-toggle-comments-${post.id}`}
              aria-expanded={commentsOpen}
              onClick={() => setCommentsOpen((open) => !open)}
              className="mt-3 gap-1.5 px-2 text-muted-foreground hover:text-foreground"
            >
              <MessageCircle className="h-4 w-4" />
              <span data-testid={`text-comments-count-${post.id}`}>{commentsCount}</span>
            </Button>
          </div>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            data-testid={`button-share-post-${post.id}`}
            aria-label="Share post details"
            onClick={() => void handleShare()}
            className="mt-3 h-8 w-8 text-muted-foreground hover:text-foreground"
          >
            <Share2 className="h-4 w-4" />
          </Button>
        </div>

        {commentsOpen && (
          <section className="mt-2 border-t border-border/50" aria-label="Post comments" data-testid={`section-comments-${post.id}`}>
            {commentsQuery.isLoading ? (
              <p className="py-4 text-sm text-muted-foreground" role="status">Loading comments…</p>
            ) : commentsQuery.isError ? (
              <div className="flex items-center justify-between gap-3 py-4">
                <p className="text-sm text-destructive">Comments couldn't be loaded.</p>
                <Button type="button" size="sm" variant="outline" onClick={() => void commentsQuery.refetch()}>
                  Try again
                </Button>
              </div>
            ) : (
              <PostCommentList
                post={post}
                comments={commentsQuery.data?.comments ?? []}
                currentUserId={currentUser?.id}
                onDelete={handleDeleteComment}
                deletingId={deletingId}
              />
            )}

            {currentUser ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleCommentSubmit)} className="flex items-start gap-3 border-t border-border/50 pt-3">
                  <Avatar className="mt-1 h-8 w-8 shrink-0">
                    <AvatarImage src={currentUser.avatarUrl ?? ""} />
                    <AvatarFallback>{currentUser.displayName?.charAt(0)?.toUpperCase() ?? "U"}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Textarea
                              {...field}
                              data-testid={`input-comment-${post.id}`}
                              aria-label="Write a comment"
                              placeholder="Write a comment…"
                              maxLength={2000}
                              rows={2}
                              className="min-h-16 resize-y bg-background"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="mt-2 flex items-center justify-between gap-3">
                      <span className="text-xs text-muted-foreground">{form.watch("content").length}/2000</span>
                      <Button
                        type="submit"
                        size="sm"
                        data-testid={`button-submit-comment-${post.id}`}
                        disabled={commentMutation.isPending || !form.watch("content").trim()}
                      >
                        {commentMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Comment
                      </Button>
                    </div>
                  </div>
                </form>
              </Form>
            ) : (
              <p className="border-t border-border/50 py-3 text-sm text-muted-foreground">
                <Link href="/login" className="font-medium text-primary hover:underline">Sign in</Link> to comment.
              </p>
            )}
          </section>
        )}
      </CardFooter>
    </>
  );
}
