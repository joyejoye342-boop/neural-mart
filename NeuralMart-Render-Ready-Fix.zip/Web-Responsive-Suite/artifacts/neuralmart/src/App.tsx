import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { AppLayout } from '@/components/layout/AppLayout';

// Pages
import Home from '@/pages/home';
import Login from '@/pages/login';
import Register from '@/pages/register';
import Explore from '@/pages/explore';
import Messages from '@/pages/messages';
import Menu from '@/pages/menu';
import CreatorDashboard from '@/pages/dashboard-creator';
import BuyerDashboard from '@/pages/dashboard-buyer';
import CreatorProfile from '@/pages/creator-profile';
import Creators from '@/pages/creators';
import Products from '@/pages/products';
import ProductDetail from '@/pages/product-detail';
import Services from '@/pages/services';
import ServiceDetail from '@/pages/service-detail';
import Projects from '@/pages/projects';
import ProjectDetail from '@/pages/project-detail';
import NewProject from '@/pages/new-project';
import Contests from '@/pages/contests';
import NewContest from '@/pages/new-contest';
import ContestDetail from '@/pages/contest-detail';
import Orders from '@/pages/orders';
import EditProfile from '@/pages/edit-profile';
import Posts from '@/pages/posts';
import ContestFeed from '@/pages/contest-feed';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      staleTime: 30_000,
    },
  },
});

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/explore" component={Explore} />
        <Route path="/messages" component={Messages} />
        <Route path="/menu" component={Menu} />
        <Route path="/creators" component={Creators} />
        <Route path="/creators/:id" component={CreatorProfile} />
        <Route path="/dashboard/creator" component={CreatorDashboard} />
        <Route path="/dashboard/buyer" component={BuyerDashboard} />
        <Route path="/posts" component={Posts} />
        <Route path="/products" component={Products} />
        <Route path="/products/:id" component={ProductDetail} />
        <Route path="/services" component={Services} />
        <Route path="/services/:id" component={ServiceDetail} />
        <Route path="/projects" component={Projects} />
        <Route path="/projects/new" component={NewProject} />
        <Route path="/projects/:id" component={ProjectDetail} />
        <Route path="/contests" component={Contests} />
        <Route path="/contests/new" component={NewContest} />
        <Route path="/contests/:id" component={ContestDetail} />
        <Route path="/orders" component={Orders} />
        <Route path="/contest-feed" component={ContestFeed} />
        <Route path="/profile/edit" component={EditProfile} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
