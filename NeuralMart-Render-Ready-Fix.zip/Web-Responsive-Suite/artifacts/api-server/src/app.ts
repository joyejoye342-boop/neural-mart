import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import session from "express-session";
import path from "node:path";
import fs from "node:fs";
import connectPgSimple from "connect-pg-simple";
import { pool } from "@workspace/db";
import router from "./routes";
import { logger } from "./lib/logger";

declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

const PgSession = connectPgSimple(session);

const app: Express = express();

if (process.env.NODE_ENV === "production" && !process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET environment variable is required in production");
}

// Trust the first proxy hop (Replit's TLS-terminating reverse proxy) so that
// `secure` cookies are correctly set/read behind the proxy in production.
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
  }),
);

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    store: new PgSession({ pool, createTableIfMissing: true }),
    secret: process.env.SESSION_SECRET || "neuralmart-dev-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      // Same-origin deployment (frontend and API share the same domain via the
      // artifact proxy), so "lax" is sufficient and avoids the CSRF exposure
      // that "none" would introduce — no cross-site cookie use case here.
      sameSite: "lax",
    },
  }),
);

app.use("/uploads", express.static(path.resolve(process.env.UPLOAD_DIR || path.join(process.cwd(), "uploads")), { fallthrough: false, maxAge: "7d", immutable: true }));
app.use("/api", router);

// Serve the built React frontend from the same Render service in production.
const frontendDist = path.resolve(process.cwd(), "artifacts/neuralmart/dist/public");
if (process.env.NODE_ENV === "production" && fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist, { index: false, maxAge: "1h" }));
  app.get(/^(?!\/api(?:\/|$)|\/uploads(?:\/|$)).*/, (_req, res) => {
    res.sendFile(path.join(frontendDist, "index.html"));
  });
}

export default app;
