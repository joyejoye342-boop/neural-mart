import { and, eq, inArray, sql } from "drizzle-orm";
import { db, postCommentsTable, postLikesTable } from "@workspace/db";

export async function loadPostInteractions(postIds: number[], userId?: number) {
  const likesCount = new Map<number, number>();
  const commentsCount = new Map<number, number>();
  const likedPostIds = new Set<number>();

  if (!postIds.length) return { likesCount, commentsCount, likedPostIds };

  const [likes, comments, userLikes] = await Promise.all([
    db.select({
      postId: postLikesTable.postId,
      count: sql<number>`count(*)::int`,
    })
      .from(postLikesTable)
      .where(inArray(postLikesTable.postId, postIds))
      .groupBy(postLikesTable.postId),
    db.select({
      postId: postCommentsTable.postId,
      count: sql<number>`count(*)::int`,
    })
      .from(postCommentsTable)
      .where(inArray(postCommentsTable.postId, postIds))
      .groupBy(postCommentsTable.postId),
    userId
      ? db.select({ postId: postLikesTable.postId })
          .from(postLikesTable)
          .where(and(eq(postLikesTable.userId, userId), inArray(postLikesTable.postId, postIds)))
      : Promise.resolve([] as { postId: number }[]),
  ]);

  likes.forEach((row) => likesCount.set(row.postId, Number(row.count)));
  comments.forEach((row) => commentsCount.set(row.postId, Number(row.count)));
  userLikes.forEach((row) => likedPostIds.add(row.postId));

  return { likesCount, commentsCount, likedPostIds };
}
