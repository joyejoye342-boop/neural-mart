import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, creatorProfilesTable, userBadgesTable, badgesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";

const router = Router();

function safeUser(user: any) {
  const { passwordHash, ...rest } = user;
  return { ...rest, walletBalance: Number(rest.walletBalance) };
}

router.get("/users/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id)).limit(1);
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    res.json(toPublicUser(user));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/users/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (req.session!.userId !== id) { res.status(403).json({ error: "Forbidden" }); return; }
    const { displayName, avatarUrl, coverUrl, bio, role } = req.body;
    const updates: any = {};
    if (displayName) updates.displayName = displayName;
    if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl;
    if (coverUrl !== undefined) updates.coverUrl = coverUrl;
    if (bio !== undefined) updates.bio = bio;
    if (role) updates.role = role;
    const [updated] = await db.update(usersTable).set(updates).where(eq(usersTable.id, id)).returning();
    if (!updated) { res.status(404).json({ error: "User not found" }); return; }
    // If switching to creator, ensure profile exists
    if (role === "creator" || role === "both") {
      await db.insert(creatorProfilesTable).values({ userId: id }).onConflictDoNothing();
    }
    res.json(safeUser(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/users/:id/badges", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const rows = await db
      .select({ ub: userBadgesTable, b: badgesTable })
      .from(userBadgesTable)
      .innerJoin(badgesTable, eq(userBadgesTable.badgeId, badgesTable.id))
      .where(eq(userBadgesTable.userId, id));
    res.json(rows.map(r => ({ ...r.ub, badge: r.b })));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
