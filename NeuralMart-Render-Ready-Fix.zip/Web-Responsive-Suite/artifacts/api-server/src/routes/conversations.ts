import { Router } from "express";
import { db } from "@workspace/db";
import { conversationsTable, conversationParticipantsTable, messagesTable, usersTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";

const router = Router();

router.get("/conversations", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const myParticipations = await db.select()
      .from(conversationParticipantsTable)
      .where(eq(conversationParticipantsTable.userId, userId));
    const convIds = myParticipations.map(p => p.conversationId);
    if (!convIds.length) { res.json([]); return; }
    const convs = await db.select().from(conversationsTable)
      .where(sql`id = ANY(${convIds})`)
      .orderBy(desc(conversationsTable.lastMessageAt));
    const result = await Promise.all(convs.map(async (conv) => {
      const parts = await db.select({ cp: conversationParticipantsTable, u: usersTable })
        .from(conversationParticipantsTable)
        .innerJoin(usersTable, eq(conversationParticipantsTable.userId, usersTable.id))
        .where(eq(conversationParticipantsTable.conversationId, conv.id));
      const myPart = myParticipations.find(p => p.conversationId === conv.id);
      return {
        ...conv,
        participantIds: parts.map(p => p.cp.userId),
        participants: parts.map(p => toPublicUser(p.u)),
        unreadCount: myPart?.unreadCount ?? 0,
      };
    }));
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/conversations", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const { recipientId, initialMessage, orderId } = req.body;
    if (!recipientId) { res.status(400).json({ error: "recipientId required" }); return; }
    const existing = await db.select({ cp: conversationParticipantsTable })
      .from(conversationParticipantsTable)
      .where(eq(conversationParticipantsTable.userId, userId));
    for (const e of existing) {
      const other = await db.select().from(conversationParticipantsTable)
        .where(and(eq(conversationParticipantsTable.conversationId, e.cp.conversationId), eq(conversationParticipantsTable.userId, recipientId)));
      if (other.length) {
        const [conv] = await db.select().from(conversationsTable).where(eq(conversationsTable.id, e.cp.conversationId));
        res.json({ ...conv, participantIds: [userId, recipientId], unreadCount: 0 });
        return;
      }
    }
    const [conv] = await db.insert(conversationsTable).values({ orderId }).returning();
    await db.insert(conversationParticipantsTable).values([
      { conversationId: conv.id, userId },
      { conversationId: conv.id, userId: recipientId },
    ]);
    if (initialMessage) {
      await db.insert(messagesTable).values({ conversationId: conv.id, senderId: userId, type: "text", content: initialMessage });
      await db.update(conversationsTable).set({ lastMessage: initialMessage, lastMessageAt: new Date() }).where(eq(conversationsTable.id, conv.id));
    }
    res.status(201).json({ ...conv, participantIds: [userId, recipientId], unreadCount: 0 });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/conversations/:id/messages", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const rows = await db.select({ msg: messagesTable, user: usersTable })
      .from(messagesTable).innerJoin(usersTable, eq(messagesTable.senderId, usersTable.id))
      .where(eq(messagesTable.conversationId, id))
      .orderBy(messagesTable.createdAt);
    await db.update(conversationParticipantsTable)
      .set({ unreadCount: 0 })
      .where(and(eq(conversationParticipantsTable.conversationId, id), eq(conversationParticipantsTable.userId, req.session!.userId!)));
    res.json(rows.map(r => {
      return { ...r.msg, paymentAmount: r.msg.paymentAmount ? Number(r.msg.paymentAmount) : null, isRead: !!r.msg.isRead, sender: toPublicUser(r.user) };
    }));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/conversations/:id/messages", requireAuth, async (req, res) => {
  try {
    const conversationId = Number(req.params.id);
    const { content, fileUrl, fileName } = req.body;
    const [msg] = await db.insert(messagesTable).values({
      conversationId, senderId: req.session!.userId!, type: "text", content, fileUrl, fileName
    }).returning();
    await db.update(conversationsTable).set({ lastMessage: content ?? "File", lastMessageAt: new Date() }).where(eq(conversationsTable.id, conversationId));
    await db.update(conversationParticipantsTable)
      .set({ unreadCount: sql`unread_count + 1` })
      .where(and(eq(conversationParticipantsTable.conversationId, conversationId), sql`user_id != ${req.session!.userId!}`));
    res.status(201).json({ ...msg, paymentAmount: null, isRead: false });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/conversations/:id/payment-request", requireAuth, async (req, res) => {
  try {
    const conversationId = Number(req.params.id);
    const { amount, description, fileUrl } = req.body;
    const [msg] = await db.insert(messagesTable).values({
      conversationId, senderId: req.session!.userId!, type: "payment_request",
      content: description, paymentAmount: String(amount), paymentStatus: "pending", fileUrl
    }).returning();
    await db.update(conversationsTable).set({ lastMessage: `Payment request: $${amount}`, lastMessageAt: new Date() }).where(eq(conversationsTable.id, conversationId));
    res.status(201).json({ ...msg, paymentAmount: Number(msg.paymentAmount), isRead: false });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
