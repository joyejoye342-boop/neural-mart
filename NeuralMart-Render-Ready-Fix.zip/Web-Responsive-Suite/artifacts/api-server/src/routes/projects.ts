import { Router } from "express";
import { db } from "@workspace/db";
import { projectsTable, proposalsTable, usersTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";

const router = Router();

function fmtProject(p: any, user?: any) {
  return {
    ...p,
    budgetMin: p.budgetMin ? Number(p.budgetMin) : null,
    budgetMax: p.budgetMax ? Number(p.budgetMax) : null,
    buyer: toPublicUser(user),
  };
}

function fmtProposal(p: any, user?: any) {
  return {
    ...p,
    proposedPrice: Number(p.proposedPrice),
    creator: toPublicUser(user),
  };
}

router.get("/projects", async (req, res) => {
  try {
    const { category, status, search, page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const rows = await db.select({ project: projectsTable, user: usersTable })
      .from(projectsTable).innerJoin(usersTable, eq(projectsTable.buyerId, usersTable.id))
      .orderBy(desc(projectsTable.createdAt)).limit(Number(limit)).offset(offset);
    res.json({ projects: rows.map(r => fmtProject(r.project, r.user)), total: rows.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/projects", requireAuth, async (req, res) => {
  try {
    const { title, description, category, budgetMin, budgetMax, deadline, attachmentUrl } = req.body;
    if (!title || !description || !category) { res.status(400).json({ error: "Missing required fields" }); return; }
    const [project] = await db.insert(projectsTable).values({
      buyerId: req.session!.userId!, title, description, category,
      budgetMin: budgetMin ? String(budgetMin) : null,
      budgetMax: budgetMax ? String(budgetMax) : null,
      deadline: deadline ? new Date(deadline) : null,
      attachmentUrl
    }).returning();
    res.status(201).json(fmtProject(project));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/projects/:id", async (req, res) => {
  try {
    const [row] = await db.select({ project: projectsTable, user: usersTable })
      .from(projectsTable).innerJoin(usersTable, eq(projectsTable.buyerId, usersTable.id))
      .where(eq(projectsTable.id, Number(req.params.id)));
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    res.json(fmtProject(row.project, row.user));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/projects/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [p] = await db.select().from(projectsTable).where(eq(projectsTable.id, id));
    if (!p || p.buyerId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    const { title, description, status } = req.body;
    const updates: any = {};
    if (title) updates.title = title;
    if (description) updates.description = description;
    if (status) updates.status = status;
    const [updated] = await db.update(projectsTable).set(updates).where(eq(projectsTable.id, id)).returning();
    res.json(fmtProject(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/projects/:id/proposals", async (req, res) => {
  try {
    const projectId = Number(req.params.id);
    const rows = await db.select({ proposal: proposalsTable, user: usersTable })
      .from(proposalsTable).innerJoin(usersTable, eq(proposalsTable.creatorId, usersTable.id))
      .where(eq(proposalsTable.projectId, projectId))
      .orderBy(desc(proposalsTable.createdAt));
    res.json(rows.map(r => fmtProposal(r.proposal, r.user)));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/projects/:id/proposals", requireAuth, async (req, res) => {
  try {
    const projectId = Number(req.params.id);
    const { coverLetter, proposedPrice, deliveryDays } = req.body;
    if (!coverLetter || !proposedPrice || !deliveryDays) { res.status(400).json({ error: "Missing fields" }); return; }
    const [proposal] = await db.insert(proposalsTable).values({
      projectId, creatorId: req.session!.userId!, coverLetter,
      proposedPrice: String(proposedPrice), deliveryDays
    }).returning();
    await db.update(projectsTable).set({ proposalCount: sql`proposal_count + 1` }).where(eq(projectsTable.id, projectId));
    res.status(201).json(fmtProposal(proposal));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/proposals/:id", async (req, res) => {
  try {
    const [row] = await db.select({ proposal: proposalsTable, user: usersTable })
      .from(proposalsTable).innerJoin(usersTable, eq(proposalsTable.creatorId, usersTable.id))
      .where(eq(proposalsTable.id, Number(req.params.id)));
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    res.json(fmtProposal(row.proposal, row.user));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/proposals/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { status } = req.body;
    if (!["accepted", "rejected"].includes(status)) { res.status(400).json({ error: "Invalid status" }); return; }
    const [proposal] = await db.select().from(proposalsTable).where(eq(proposalsTable.id, id));
    if (!proposal) { res.status(404).json({ error: "Not found" }); return; }
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, proposal.projectId));
    if (project.buyerId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    const [updated] = await db.update(proposalsTable).set({ status }).where(eq(proposalsTable.id, id)).returning();
    if (status === "accepted") {
      await db.update(projectsTable).set({ status: "in_progress" }).where(eq(projectsTable.id, proposal.projectId));
    }
    res.json(fmtProposal(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
