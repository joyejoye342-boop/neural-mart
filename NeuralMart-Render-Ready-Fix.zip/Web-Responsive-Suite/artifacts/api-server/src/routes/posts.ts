import { Router } from "express";
import multer from "multer";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { db } from "@workspace/db";
import { postsTable, postLikesTable, postCommentsTable, usersTable } from "@workspace/db";
import { eq, and, desc, inArray, sql } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";
import { loadPostInteractions } from "../lib/post-interactions";

const router = Router();

// Local uploads are suitable for development/single-instance deployments. For
// multi-instance production, point uploads at durable object storage (S3/R2).
const uploadDir = path.resolve(process.env.UPLOAD_DIR || path.join(process.cwd(), "uploads"));
fs.mkdirSync(uploadDir, { recursive: true });
const allowedMime = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "video/mp4", "video/webm", "video/quicktime"]);
const uploader = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase().slice(0, 10);
      cb(null, `${Date.now()}-${crypto.randomBytes(12).toString("hex")}${ext}`);
    },
  }),
  limits: { fileSize: 200 * 1024 * 1024, files: 10 },
  fileFilter: (_req, file, cb) => cb(null, allowedMime.has(file.mimetype)),
});

router.post("/uploads", requireAuth, (req, res) => {
  uploader.array("files", 10)(req, res, (error: any) => {
    if (error) {
      res.status(error.code === "LIMIT_FILE_SIZE" ? 413 : 400).json({ error: error.code === "LIMIT_FILE_SIZE" ? "Each file must be 200 MB or smaller." : "Upload failed. Use JPG, PNG, WEBP, GIF, MP4, WEBM or MOV files." });
      return;
    }
    const files = (req.files as Express.Multer.File[] | undefined) ?? [];
    if (!files.length) { res.status(400).json({ error: "Choose at least one supported image or video." }); return; }
    res.status(201).json({ files: files.map((file) => ({ url: `/uploads/${file.filename}`, name: file.originalname, mimeType: file.mimetype, size: file.size })) });
  });
});

function formatPost(post: any, user: any, isLiked = false) {
  return {
    ...post,
    mediaUrls: post.mediaUrls ?? [],
    isLiked,
    creator: toPublicUser(user),
  };
}

router.get("/posts", async (req, res) => {
  try {
    const { creatorId, type, page = "1", limit = "20" } = req.query as any;
    const parsedPage = Number(page);
    const parsedLimit = Number(limit);
    const parsedCreatorId = creatorId === undefined ? undefined : Number(creatorId);
    if (!Number.isInteger(parsedPage) || parsedPage < 1 ||
      !Number.isInteger(parsedLimit) || parsedLimit < 1 || parsedLimit > 100 ||
      (parsedCreatorId !== undefined && (!Number.isInteger(parsedCreatorId) || parsedCreatorId < 1))) {
      res.status(400).json({ error: "Invalid page, limit, or creatorId" });
      return;
    }
    const offset = (parsedPage - 1) * parsedLimit;
    const conditions = [];
    if (parsedCreatorId !== undefined) conditions.push(eq(postsTable.creatorId, parsedCreatorId));
    if (type) conditions.push(eq(postsTable.type, type));
    const rows = await db.select({ post: postsTable, user: usersTable })
      .from(postsTable)
      .innerJoin(usersTable, eq(postsTable.creatorId, usersTable.id))
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(postsTable.createdAt))
      .limit(parsedLimit)
      .offset(offset);
    const postIds = rows.map((row) => row.post.id);
    const interactions = await loadPostInteractions(postIds, req.session?.userId);
    const posts = rows.map((row) => formatPost(
      {
        ...row.post,
        likesCount: interactions.likesCount.get(row.post.id) ?? 0,
        commentsCount: interactions.commentsCount.get(row.post.id) ?? 0,
      },
      row.user,
      interactions.likedPostIds.has(row.post.id),
    ));
    res.json({ posts, total: posts.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/posts/:id/comments", async (req, res) => {
  try {
    const postId = Number(req.params.id);
    const page = Number(req.query.page ?? 1);
    const limit = Number(req.query.limit ?? 20);
    if (!Number.isInteger(postId) || postId < 1 ||
      !Number.isInteger(page) || page < 1 ||
      !Number.isInteger(limit) || limit < 1 || limit > 100) {
      res.status(400).json({ error: "Invalid post id, page, or limit" });
      return;
    }
    const [post] = await db.select({ id: postsTable.id })
      .from(postsTable).where(eq(postsTable.id, postId)).limit(1);
    if (!post) {
      res.status(404).json({ error: "Post not found" });
      return;
    }
    const [countRow, rows] = await Promise.all([
      db.select({ count: sql<number>`count(*)::int` })
        .from(postCommentsTable)
        .where(eq(postCommentsTable.postId, postId)),
      db.select({ comment: postCommentsTable, author: usersTable })
        .from(postCommentsTable)
        .innerJoin(usersTable, eq(postCommentsTable.userId, usersTable.id))
        .where(eq(postCommentsTable.postId, postId))
        .orderBy(desc(postCommentsTable.createdAt), desc(postCommentsTable.id))
        .limit(limit)
        .offset((page - 1) * limit),
    ]);
    res.json({
      comments: rows.map(({ comment, author }) => ({
        ...comment,
        author: toPublicUser(author),
      })),
      total: Number(countRow[0]?.count ?? 0),
      page,
      limit,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Could not load comments. Please try again." });
  }
});

router.post("/posts/:id/comments", requireAuth, async (req, res) => {
  try {
    const postId = Number(req.params.id);
    const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
    if (!Number.isInteger(postId) || postId < 1) {
      res.status(400).json({ error: "Invalid post id" });
      return;
    }
    if (!content || content.length > 2000) {
      res.status(400).json({ error: "Comment must contain 1–2000 characters" });
      return;
    }

    const result = await db.transaction(async (tx) => {
      const [post] = await tx.select({ id: postsTable.id })
        .from(postsTable)
        .where(eq(postsTable.id, postId))
        .for("update");
      if (!post) return null;

      const [comment] = await tx.insert(postCommentsTable).values({
        postId,
        userId: req.session!.userId!,
        content,
      }).returning();
      const [counts] = await tx.select({
        count: sql<number>`count(*)::int`,
      }).from(postCommentsTable).where(eq(postCommentsTable.postId, postId));
      await tx.update(postsTable)
        .set({ commentsCount: Number(counts?.count ?? 0) })
        .where(eq(postsTable.id, postId));
      const [author] = await tx.select().from(usersTable)
        .where(eq(usersTable.id, req.session!.userId!));
      return { comment, author };
    });

    if (!result) {
      res.status(404).json({ error: "Post not found" });
      return;
    }
    res.status(201).json({ ...result.comment, author: toPublicUser(result.author) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Could not submit comment. Please try again." });
  }
});

router.delete("/posts/:id/comments/:commentId", requireAuth, async (req, res) => {
  try {
    const postId = Number(req.params.id);
    const commentId = Number(req.params.commentId);
    if (!Number.isInteger(postId) || postId < 1 || !Number.isInteger(commentId) || commentId < 1) {
      res.status(400).json({ error: "Invalid post or comment id" });
      return;
    }

    const result = await db.transaction(async (tx) => {
      const [post] = await tx.select({ id: postsTable.id, creatorId: postsTable.creatorId })
        .from(postsTable)
        .where(eq(postsTable.id, postId))
        .for("update");
      if (!post) return { kind: "missing-post" as const };
      const [comment] = await tx.select().from(postCommentsTable)
        .where(and(eq(postCommentsTable.id, commentId), eq(postCommentsTable.postId, postId)));
      if (!comment) return { kind: "missing-comment" as const };
      if (comment.userId !== req.session!.userId && post.creatorId !== req.session!.userId) {
        return { kind: "forbidden" as const };
      }
      await tx.delete(postCommentsTable).where(eq(postCommentsTable.id, commentId));
      const [counts] = await tx.select({
        count: sql<number>`count(*)::int`,
      }).from(postCommentsTable).where(eq(postCommentsTable.postId, postId));
      await tx.update(postsTable)
        .set({ commentsCount: Number(counts?.count ?? 0) })
        .where(eq(postsTable.id, postId));
      return { kind: "deleted" as const };
    });

    if (result.kind === "missing-post") {
      res.status(404).json({ error: "Post not found" });
      return;
    }
    if (result.kind === "missing-comment") {
      res.status(404).json({ error: "Comment not found" });
      return;
    }
    if (result.kind === "forbidden") {
      res.status(403).json({ error: "You can delete only your own comment" });
      return;
    }
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Could not delete comment. Please try again." });
  }
});

router.post("/posts", requireAuth, async (req, res) => {
  try {
    const { type, content, mediaUrl, mediaUrls, linkedProductId, linkedServiceId } = req.body;
    if (!type || (!(typeof content === "string" && content.trim()) && !(mediaUrl || (Array.isArray(mediaUrls) && mediaUrls.length)))) { res.status(400).json({ error: "Add text or attach an image/video before publishing." }); return; }
    const allowedTypes = new Set(["image", "video", "reel", "text", "product", "service"]);
    if (!allowedTypes.has(type)) { res.status(400).json({ error: "Invalid post type." }); return; }
    const normalizedMedia = Array.isArray(mediaUrls) ? mediaUrls.filter((url: unknown) => typeof url === "string" && url.startsWith("/uploads/")) : [];
    if (normalizedMedia.length > 10) { res.status(400).json({ error: "You can attach up to 10 files per post." }); return; }
    const [post] = await db.insert(postsTable).values({
      creatorId: req.session!.userId!, type, content: String(content ?? "").trim(), mediaUrl: mediaUrl ?? normalizedMedia[0] ?? null, mediaUrls: normalizedMedia, linkedProductId, linkedServiceId
    }).returning();
    res.status(201).json(formatPost(post, null));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/posts/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) { res.status(400).json({ error: "Invalid post id" }); return; }
    const [row] = await db.select({ post: postsTable, user: usersTable })
      .from(postsTable).innerJoin(usersTable, eq(postsTable.creatorId, usersTable.id))
      .where(eq(postsTable.id, id));
    if (!row) { res.status(404).json({ error: "Post not found" }); return; }
    const interactions = await loadPostInteractions([id], req.session?.userId);
    res.json(formatPost({
      ...row.post,
      likesCount: interactions.likesCount.get(id) ?? 0,
      commentsCount: interactions.commentsCount.get(id) ?? 0,
    }, row.user, interactions.likedPostIds.has(id)));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.delete("/posts/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [post] = await db.select().from(postsTable).where(eq(postsTable.id, id));
    if (!post) { res.status(404).json({ error: "Post not found" }); return; }
    if (post.creatorId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    await db.delete(postsTable).where(eq(postsTable.id, id));
    res.json({ success: true });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/posts/:id/like", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) { res.status(400).json({ error: "Invalid post id" }); return; }
    const userId = req.session!.userId!;
    const result = await db.transaction(async (tx) => {
      const [post] = await tx.select({ id: postsTable.id })
        .from(postsTable)
        .where(eq(postsTable.id, id))
        .for("update");
      if (!post) return null;
      const [existing] = await tx.select({ id: postLikesTable.id })
        .from(postLikesTable)
        .where(and(eq(postLikesTable.postId, id), eq(postLikesTable.userId, userId)));
      let isLiked: boolean;
      if (existing) {
        await tx.delete(postLikesTable).where(eq(postLikesTable.id, existing.id));
        isLiked = false;
      } else {
        await tx.insert(postLikesTable).values({ postId: id, userId }).onConflictDoNothing();
        isLiked = true;
      }
      const [counts] = await tx.select({
        count: sql<number>`count(*)::int`,
      }).from(postLikesTable).where(eq(postLikesTable.postId, id));
      const likesCount = Number(counts?.count ?? 0);
      await tx.update(postsTable).set({ likesCount }).where(eq(postsTable.id, id));
      return { isLiked, likesCount };
    });
    if (!result) { res.status(404).json({ error: "Post not found" }); return; }
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Could not update like. Please try again." });
  }
});

export default router;
