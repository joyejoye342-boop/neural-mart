import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, usersTable } from "@workspace/db";
import { eq, or, desc } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";

const router = Router();

router.get("/orders", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const { page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const rows = await db.select().from(ordersTable)
      .where(or(eq(ordersTable.buyerId, userId), eq(ordersTable.sellerId, userId)))
      .orderBy(desc(ordersTable.createdAt)).limit(Number(limit)).offset(offset);
    const orders = rows.map(o => ({ ...o, amount: Number(o.amount) }));
    res.json({ orders, total: orders.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/orders/:id", requireAuth, async (req, res) => {
  try {
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, Number(req.params.id)));
    if (!order) { res.status(404).json({ error: "Not found" }); return; }
    if (order.buyerId !== req.session!.userId && order.sellerId !== req.session!.userId) {
      res.status(403).json({ error: "Forbidden" }); return;
    }
    res.json({ ...order, amount: Number(order.amount) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/orders/:id/complete", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
    if (!order) { res.status(404).json({ error: "Not found" }); return; }
    if (order.buyerId !== req.session!.userId) { res.status(403).json({ error: "Only buyer can complete" }); return; }
    const [updated] = await db.update(ordersTable).set({ status: "completed" }).where(eq(ordersTable.id, id)).returning();
    res.json({ ...updated, amount: Number(updated.amount) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
