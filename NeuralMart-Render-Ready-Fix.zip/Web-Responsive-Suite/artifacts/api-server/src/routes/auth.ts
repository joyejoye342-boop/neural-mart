import { Router } from "express";
import bcrypt from "bcrypt";
import { db } from "@workspace/db";
import { usersTable, creatorProfilesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.post("/auth/register", async (req, res) => {
  try {
    const { email, password, displayName, role = "buyer" } = req.body;
    if (!email || !password || !displayName) {
      res.status(400).json({ error: "email, password and displayName are required" });
      return;
    }
    const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
    if (existing.length > 0) {
      res.status(400).json({ error: "Email already registered" });
      return;
    }
    const passwordHash = await bcrypt.hash(password, 10);
    const [user] = await db.insert(usersTable).values({ email, passwordHash, displayName, role }).returning();
    if (role === "creator" || role === "both") {
      await db.insert(creatorProfilesTable).values({ userId: user.id }).onConflictDoNothing();
    }
    req.session!.userId = user.id;
    const { passwordHash: _, ...safeUser } = user;
    res.status(201).json({ user: { ...safeUser, walletBalance: Number(safeUser.walletBalance) } });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Registration failed" });
  }
});

router.post("/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "email and password are required" });
      return;
    }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
    if (!user) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    req.session!.userId = user.id;
    const { passwordHash: _, ...safeUser } = user;
    res.json({ user: { ...safeUser, walletBalance: Number(safeUser.walletBalance) } });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

router.post("/auth/logout", (req, res) => {
  req.session?.destroy(() => {});
  res.json({ success: true });
});

router.get("/auth/me", async (req, res) => {
  if (!req.session?.userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId)).limit(1);
    if (!user) {
      res.status(401).json({ error: "Not authenticated" });
      return;
    }
    const { passwordHash: _, ...safeUser } = user;
    res.json({ ...safeUser, walletBalance: Number(safeUser.walletBalance) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get current user" });
  }
});

export default router;
