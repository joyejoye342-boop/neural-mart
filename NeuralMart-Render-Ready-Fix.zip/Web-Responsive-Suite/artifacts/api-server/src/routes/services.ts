import { Router } from "express";
import { db } from "@workspace/db";
import { servicesTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";

const router = Router();

function fmtTier(s: any, prefix: string) {
  const p = (k: string) => s[`${prefix}${k.charAt(0).toUpperCase()}${k.slice(1)}`];
  if (!p("name") && !p("price")) return undefined;
  return {
    name: p("name") ?? prefix.charAt(0).toUpperCase() + prefix.slice(1),
    description: p("description") ?? "",
    price: Number(p("price") ?? 0),
    deliveryDays: p("deliveryDays") ?? 3,
    revisions: p("revisions") ?? 1,
    features: p("features") ?? [],
  };
}

function fmt(s: any, user?: any) {
  return {
    ...s,
    rating: Number(s.rating),
    tags: s.tags ?? [],
    basic: fmtTier(s, "basic"),
    standard: fmtTier(s, "standard"),
    premium: fmtTier(s, "premium"),
    creator: toPublicUser(user),
  };
}

router.get("/services", async (req, res) => {
  try {
    const { page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const rows = await db.select({ service: servicesTable, user: usersTable })
      .from(servicesTable).innerJoin(usersTable, eq(servicesTable.creatorId, usersTable.id))
      .where(eq(servicesTable.isActive, true))
      .orderBy(desc(servicesTable.createdAt)).limit(Number(limit)).offset(offset);
    res.json({ services: rows.map(r => fmt(r.service, r.user)), total: rows.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/services", requireAuth, async (req, res) => {
  try {
    const { title, description, category, previewImageUrl, tags, basic, standard, premium } = req.body;
    if (!title || !description || !category || !basic) { res.status(400).json({ error: "Missing required fields" }); return; }
    const [service] = await db.insert(servicesTable).values({
      creatorId: req.session!.userId!, title, description, category, previewImageUrl, tags: tags ?? [],
      basicName: basic.name, basicDescription: basic.description, basicPrice: String(basic.price),
      basicDeliveryDays: basic.deliveryDays, basicRevisions: basic.revisions, basicFeatures: basic.features ?? [],
      standardName: standard?.name, standardDescription: standard?.description,
      standardPrice: standard ? String(standard.price) : null, standardDeliveryDays: standard?.deliveryDays,
      standardRevisions: standard?.revisions, standardFeatures: standard?.features ?? [],
      premiumName: premium?.name, premiumDescription: premium?.description,
      premiumPrice: premium ? String(premium.price) : null, premiumDeliveryDays: premium?.deliveryDays,
      premiumRevisions: premium?.revisions, premiumFeatures: premium?.features ?? [],
    }).returning();
    res.status(201).json(fmt(service));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/services/:id", async (req, res) => {
  try {
    const [row] = await db.select({ service: servicesTable, user: usersTable })
      .from(servicesTable).innerJoin(usersTable, eq(servicesTable.creatorId, usersTable.id))
      .where(eq(servicesTable.id, Number(req.params.id)));
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    res.json(fmt(row.service, row.user));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/services/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [s] = await db.select().from(servicesTable).where(eq(servicesTable.id, id));
    if (!s) { res.status(404).json({ error: "Not found" }); return; }
    if (s.creatorId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    const updates: any = {};
    const { title, description, category, isActive } = req.body;
    if (title) updates.title = title;
    if (description) updates.description = description;
    if (category) updates.category = category;
    if (isActive !== undefined) updates.isActive = isActive;
    const [updated] = await db.update(servicesTable).set(updates).where(eq(servicesTable.id, id)).returning();
    res.json(fmt(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.delete("/services/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [s] = await db.select().from(servicesTable).where(eq(servicesTable.id, id));
    if (!s) { res.status(404).json({ error: "Not found" }); return; }
    if (s.creatorId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    await db.update(servicesTable).set({ isActive: false }).where(eq(servicesTable.id, id));
    res.json({ success: true });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
