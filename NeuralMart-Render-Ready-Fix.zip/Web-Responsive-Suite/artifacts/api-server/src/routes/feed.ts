import { Router } from "express";
import { db } from "@workspace/db";
import { postsTable, projectsTable, contestsTable, usersTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";
import { toPublicUser } from "../lib/public-user";
import { loadPostInteractions } from "../lib/post-interactions";

const router = Router();

router.get("/feed/showcase", async (req, res) => {
  try {
    const { page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const postRows = await db.select({ post: postsTable, user: usersTable })
      .from(postsTable).innerJoin(usersTable, eq(postsTable.creatorId, usersTable.id))
      .orderBy(desc(postsTable.createdAt)).limit(Number(limit)).offset(offset);
    const interactions = await loadPostInteractions(postRows.map((row) => row.post.id), req.session?.userId);
    const items = postRows.map(r => {
      return {
        id: r.post.id, type: "post" as const, createdAt: r.post.createdAt,
        post: {
          ...r.post,
          mediaUrls: r.post.mediaUrls ?? [],
          likesCount: interactions.likesCount.get(r.post.id) ?? 0,
          commentsCount: interactions.commentsCount.get(r.post.id) ?? 0,
          isLiked: interactions.likedPostIds.has(r.post.id),
          creator: toPublicUser(r.user),
        }
      };
    });
    res.json({ items, total: items.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/feed/opportunities", async (req, res) => {
  try {
    const { type = "all", page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const items: any[] = [];
    if (type === "all" || type === "project") {
      const projects = await db.select({ project: projectsTable, user: usersTable })
        .from(projectsTable).innerJoin(usersTable, eq(projectsTable.buyerId, usersTable.id))
        .where(eq(projectsTable.status, "open"))
        .orderBy(desc(projectsTable.createdAt)).limit(Number(limit));
      projects.forEach(r => {
        items.push({ id: r.project.id, type: "project", createdAt: r.project.createdAt,
          project: { ...r.project, budgetMin: r.project.budgetMin ? Number(r.project.budgetMin) : null, budgetMax: r.project.budgetMax ? Number(r.project.budgetMax) : null, buyer: toPublicUser(r.user) } });
      });
    }
    if (type === "all" || type === "contest") {
      const contests = await db.select({ contest: contestsTable, user: usersTable })
        .from(contestsTable).innerJoin(usersTable, eq(contestsTable.hostId, usersTable.id))
        .where(eq(contestsTable.status, "open"))
        .orderBy(desc(contestsTable.createdAt)).limit(Number(limit));
      contests.forEach(r => {
        items.push({ id: r.contest.id, type: "contest", createdAt: r.contest.createdAt,
          contest: { ...r.contest, prizeAmount: Number(r.contest.prizeAmount), host: toPublicUser(r.user) } });
      });
    }
    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const sliced = items.slice(offset, offset + Number(limit));
    res.json({ items: sliced, total: items.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/feed/home", async (req, res) => {
  try {
    const { page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const postRows = await db.select({ post: postsTable, user: usersTable })
      .from(postsTable).innerJoin(usersTable, eq(postsTable.creatorId, usersTable.id))
      .orderBy(desc(postsTable.createdAt)).limit(10);
    const projectRows = await db.select({ project: projectsTable, user: usersTable })
      .from(projectsTable).innerJoin(usersTable, eq(projectsTable.buyerId, usersTable.id))
      .where(eq(projectsTable.status, "open"))
      .orderBy(desc(projectsTable.createdAt)).limit(10);
    const interactions = await loadPostInteractions(postRows.map((row) => row.post.id), req.session?.userId);
    const items: any[] = [];
    postRows.forEach(r => {
      items.push({ id: r.post.id, type: "post", createdAt: r.post.createdAt,
        post: {
          ...r.post,
          mediaUrls: r.post.mediaUrls ?? [],
          likesCount: interactions.likesCount.get(r.post.id) ?? 0,
          commentsCount: interactions.commentsCount.get(r.post.id) ?? 0,
          isLiked: interactions.likedPostIds.has(r.post.id),
          creator: toPublicUser(r.user),
        } });
    });
    projectRows.forEach(r => {
      items.push({ id: r.project.id, type: "project", createdAt: r.project.createdAt,
        project: { ...r.project, budgetMin: r.project.budgetMin ? Number(r.project.budgetMin) : null, budgetMax: r.project.budgetMax ? Number(r.project.budgetMax) : null, buyer: toPublicUser(r.user) } });
    });
    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const sliced = items.slice(offset, offset + Number(limit));
    res.json({ items: sliced, total: items.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
