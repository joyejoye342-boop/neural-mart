import { Router } from "express";
import { db } from "@workspace/db";
import { badgesTable, userBadgesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/badges", async (req, res) => {
  try {
    const badges = await db.select().from(badgesTable);
    res.json(badges);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/users/:id/badges", async (req, res) => {
  try {
    const rows = await db.select({ ub: userBadgesTable, b: badgesTable })
      .from(userBadgesTable).innerJoin(badgesTable, eq(userBadgesTable.badgeId, badgesTable.id))
      .where(eq(userBadgesTable.userId, Number(req.params.id)));
    res.json(rows.map(r => ({ ...r.ub, badge: r.b })));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
