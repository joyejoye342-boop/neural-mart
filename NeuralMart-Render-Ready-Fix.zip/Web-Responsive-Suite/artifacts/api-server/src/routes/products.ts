import { Router } from "express";
import { db } from "@workspace/db";
import { productsTable, usersTable, ordersTable, walletTransactionsTable } from "@workspace/db";
import { eq, and, desc, gte, lte, ilike } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";

const router = Router();

function fmt(p: any, user?: any) {
  return {
    ...p,
    price: Number(p.price),
    rating: Number(p.rating),
    tags: p.tags ?? [],
    creator: toPublicUser(user),
  };
}

router.get("/products", async (req, res) => {
  try {
    const { category, creatorId, search, minPrice, maxPrice, page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    let q = db.select({ product: productsTable, user: usersTable })
      .from(productsTable).innerJoin(usersTable, eq(productsTable.creatorId, usersTable.id))
      .where(eq(productsTable.isActive, true))
      .$dynamic();
    const rows = await q.orderBy(desc(productsTable.createdAt)).limit(Number(limit)).offset(offset);
    res.json({ products: rows.map(r => fmt(r.product, r.user)), total: rows.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/products", requireAuth, async (req, res) => {
  try {
    const { title, description, price, category, previewImageUrl, fileUrl, tags } = req.body;
    if (!title || !description || !price || !category) { res.status(400).json({ error: "Missing required fields" }); return; }
    const [product] = await db.insert(productsTable).values({
      creatorId: req.session!.userId!, title, description, price: String(price), category, previewImageUrl, fileUrl, tags: tags ?? []
    }).returning();
    res.status(201).json(fmt(product));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/products/:id", async (req, res) => {
  try {
    const [row] = await db.select({ product: productsTable, user: usersTable })
      .from(productsTable).innerJoin(usersTable, eq(productsTable.creatorId, usersTable.id))
      .where(eq(productsTable.id, Number(req.params.id)));
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    res.json(fmt(row.product, row.user));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/products/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [p] = await db.select().from(productsTable).where(eq(productsTable.id, id));
    if (!p) { res.status(404).json({ error: "Not found" }); return; }
    if (p.creatorId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    const { title, description, price, category, previewImageUrl, fileUrl, tags, isActive } = req.body;
    const updates: any = {};
    if (title) updates.title = title;
    if (description) updates.description = description;
    if (price !== undefined) updates.price = String(price);
    if (category) updates.category = category;
    if (previewImageUrl !== undefined) updates.previewImageUrl = previewImageUrl;
    if (fileUrl !== undefined) updates.fileUrl = fileUrl;
    if (tags !== undefined) updates.tags = tags;
    if (isActive !== undefined) updates.isActive = isActive;
    const [updated] = await db.update(productsTable).set(updates).where(eq(productsTable.id, id)).returning();
    res.json(fmt(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.delete("/products/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [p] = await db.select().from(productsTable).where(eq(productsTable.id, id));
    if (!p) { res.status(404).json({ error: "Not found" }); return; }
    if (p.creatorId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    await db.update(productsTable).set({ isActive: false }).where(eq(productsTable.id, id));
    res.json({ success: true });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/products/:id/purchase", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const buyerId = req.session!.userId!;
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, id));
    if (!product) { res.status(404).json({ error: "Not found" }); return; }
    const [buyer] = await db.select().from(usersTable).where(eq(usersTable.id, buyerId));
    if (Number(buyer.walletBalance) < Number(product.price)) {
      res.status(400).json({ error: "Insufficient wallet balance" }); return;
    }
    const newBuyerBalance = Number(buyer.walletBalance) - Number(product.price);
    const [seller] = await db.select().from(usersTable).where(eq(usersTable.id, product.creatorId));
    const newSellerBalance = Number(seller.walletBalance) + Number(product.price) * 0.9;
    await db.update(usersTable).set({ walletBalance: String(newBuyerBalance) }).where(eq(usersTable.id, buyerId));
    await db.update(usersTable).set({ walletBalance: String(newSellerBalance) }).where(eq(usersTable.id, product.creatorId));
    await db.update(productsTable).set({ salesCount: product.salesCount + 1 }).where(eq(productsTable.id, id));
    const [order] = await db.insert(ordersTable).values({
      buyerId, sellerId: product.creatorId, type: "product", productId: id,
      amount: String(product.price), status: "completed", downloadUrl: product.fileUrl ?? undefined
    }).returning();
    await db.insert(walletTransactionsTable).values({
      userId: buyerId, type: "purchase", amount: String(-Number(product.price)),
      description: `Purchased: ${product.title}`, orderId: order.id, balanceAfter: String(newBuyerBalance)
    });
    await db.insert(walletTransactionsTable).values({
      userId: product.creatorId, type: "earning", amount: String(Number(product.price) * 0.9),
      description: `Sale: ${product.title}`, orderId: order.id, balanceAfter: String(newSellerBalance)
    });
    res.json({ ...order, amount: Number(order.amount) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
