import { Router } from "express";
import { db } from "@workspace/db";
import { productsTable, servicesTable, usersTable, creatorProfilesTable } from "@workspace/db";
import { eq, desc, ilike } from "drizzle-orm";
import { toPublicUser } from "../lib/public-user";

const router = Router();

router.get("/explore/search", async (req, res) => {
  try {
    const { q, type = "all", page = "1", limit = "20" } = req.query as any;
    if (!q) { res.status(400).json({ error: "q is required" }); return; }
    const results: any[] = [];
    if (type === "all" || type === "creator") {
      const rows = await db.select({ user: usersTable, profile: creatorProfilesTable })
        .from(creatorProfilesTable).innerJoin(usersTable, eq(creatorProfilesTable.userId, usersTable.id))
        .where(ilike(usersTable.displayName, `%${q}%`)).limit(5);
      rows.forEach(r => {
        results.push({ type: "creator", id: r.profile.id,
          creator: { ...r.profile, ...toPublicUser(r.user), rating: Number(r.profile.rating), completionRate: Number(r.profile.completionRate), skills: r.profile.skills ?? [], badges: [], products: [], services: [], isFollowing: false } });
      });
    }
    if (type === "all" || type === "product") {
      const rows = await db.select({ product: productsTable, user: usersTable })
        .from(productsTable).innerJoin(usersTable, eq(productsTable.creatorId, usersTable.id))
        .where(ilike(productsTable.title, `%${q}%`)).limit(5);
      rows.forEach(r => {
        results.push({ type: "product", id: r.product.id, product: { ...r.product, price: Number(r.product.price), rating: Number(r.product.rating), tags: r.product.tags ?? [], creator: toPublicUser(r.user) } });
      });
    }
    if (type === "all" || type === "service") {
      const rows = await db.select({ service: servicesTable, user: usersTable })
        .from(servicesTable).innerJoin(usersTable, eq(servicesTable.creatorId, usersTable.id))
        .where(ilike(servicesTable.title, `%${q}%`)).limit(5);
      rows.forEach(r => {
        results.push({ type: "service", id: r.service.id, service: { ...r.service, rating: Number(r.service.rating), tags: r.service.tags ?? [], creator: toPublicUser(r.user) } });
      });
    }
    res.json({ results, total: results.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/explore/trending", async (req, res) => {
  try {
    const creatorRows = await db.select({ user: usersTable, profile: creatorProfilesTable })
      .from(creatorProfilesTable).innerJoin(usersTable, eq(creatorProfilesTable.userId, usersTable.id))
      .orderBy(desc(usersTable.followersCount)).limit(6);
    const products = await db.select({ product: productsTable, user: usersTable })
      .from(productsTable).innerJoin(usersTable, eq(productsTable.creatorId, usersTable.id))
      .where(eq(productsTable.isActive, true))
      .orderBy(desc(productsTable.salesCount)).limit(6);
    const categories = ["Design", "Development", "Writing", "Video", "Music", "Photography", "Marketing", "Data"];
    res.json({
      creators: creatorRows.map(r => {
        return { growthRate: Math.random() * 20, creator: { ...r.profile, ...toPublicUser(r.user), rating: Number(r.profile.rating), completionRate: Number(r.profile.completionRate), skills: r.profile.skills ?? [], badges: [], products: [], services: [], isFollowing: false } };
      }),
      products: products.map(r => ({ ...r.product, price: Number(r.product.price), rating: Number(r.product.rating), tags: r.product.tags ?? [], creator: toPublicUser(r.user) })),
      categories,
    });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
