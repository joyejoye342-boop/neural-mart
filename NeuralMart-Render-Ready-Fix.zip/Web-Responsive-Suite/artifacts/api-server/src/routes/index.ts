import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import creatorsRouter from "./creators";
import postsRouter from "./posts";
import productsRouter from "./products";
import servicesRouter from "./services";
import projectsRouter from "./projects";
import contestsRouter from "./contests";
import ordersRouter from "./orders";
import conversationsRouter from "./conversations";
import walletRouter from "./wallet";
import badgesRouter from "./badges";
import feedRouter from "./feed";
import exploreRouter from "./explore";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(creatorsRouter);
router.use(postsRouter);
router.use(productsRouter);
router.use(servicesRouter);
router.use(projectsRouter);
router.use(contestsRouter);
router.use(ordersRouter);
router.use(conversationsRouter);
router.use(walletRouter);
router.use(badgesRouter);
router.use(feedRouter);
router.use(exploreRouter);
router.use(dashboardRouter);

export default router;
