import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, walletTransactionsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";

const router = Router();

router.get("/wallet", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    const allTx = await db.select().from(walletTransactionsTable).where(eq(walletTransactionsTable.userId, userId));
    const totalEarnings = allTx.filter(t => ["earning", "credit"].includes(t.type)).reduce((s, t) => s + Number(t.amount), 0);
    const totalSpent = allTx.filter(t => ["purchase", "debit"].includes(t.type)).reduce((s, t) => s + Math.abs(Number(t.amount)), 0);
    res.json({ balance: Number(user.walletBalance), pendingBalance: 0, totalEarnings, totalSpent, currency: "USD" });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/wallet/transactions", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const { page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const rows = await db.select().from(walletTransactionsTable).where(eq(walletTransactionsTable.userId, userId))
      .orderBy(desc(walletTransactionsTable.createdAt)).limit(Number(limit)).offset(offset);
    const transactions = rows.map(t => ({ ...t, amount: Number(t.amount), balanceAfter: Number(t.balanceAfter) }));
    res.json({ transactions, total: transactions.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/wallet/add-funds", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const { amount } = req.body;
    if (!amount || Number(amount) < 1) { res.status(400).json({ error: "Minimum $1" }); return; }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    const newBalance = Number(user.walletBalance) + Number(amount);
    await db.update(usersTable).set({ walletBalance: String(newBalance) }).where(eq(usersTable.id, userId));
    await db.insert(walletTransactionsTable).values({
      userId, type: "credit", amount: String(amount),
      description: `Added funds via card`, balanceAfter: String(newBalance)
    });
    res.json({ balance: newBalance, pendingBalance: 0, totalEarnings: 0, totalSpent: 0, currency: "USD" });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/wallet/withdraw", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const { amount, method, accountDetails } = req.body;
    if (!amount || Number(amount) < 10) { res.status(400).json({ error: "Minimum withdrawal is $10" }); return; }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (Number(user.walletBalance) < Number(amount)) { res.status(400).json({ error: "Insufficient balance" }); return; }
    const newBalance = Number(user.walletBalance) - Number(amount);
    await db.update(usersTable).set({ walletBalance: String(newBalance) }).where(eq(usersTable.id, userId));
    await db.insert(walletTransactionsTable).values({
      userId, type: "withdrawal", amount: String(-Number(amount)),
      description: `Withdrawal via ${method}`, balanceAfter: String(newBalance)
    });
    res.json({ success: true, message: "Withdrawal request submitted" });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
