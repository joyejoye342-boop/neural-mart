import { Router } from "express";
import { db } from "@workspace/db";
import { contestsTable, contestSubmissionsTable, usersTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { toPublicUser } from "../lib/public-user";

const router = Router();

function fmtContest(c: any, user?: any) {
  return {
    ...c,
    prizeAmount: Number(c.prizeAmount),
    host: toPublicUser(user),
  };
}

router.get("/contests", async (req, res) => {
  try {
    const { page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    const rows = await db.select({ contest: contestsTable, user: usersTable })
      .from(contestsTable).innerJoin(usersTable, eq(contestsTable.hostId, usersTable.id))
      .orderBy(desc(contestsTable.createdAt)).limit(Number(limit)).offset(offset);
    res.json({ contests: rows.map(r => fmtContest(r.contest, r.user)), total: rows.length, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/contests", requireAuth, async (req, res) => {
  try {
    const { title, brief, category, prizeAmount, deadline } = req.body;
    if (!title || !brief || !category || !prizeAmount || !deadline) { res.status(400).json({ error: "Missing required fields" }); return; }
    const [contest] = await db.insert(contestsTable).values({
      hostId: req.session!.userId!, title, brief, category,
      prizeAmount: String(prizeAmount), deadline: new Date(deadline)
    }).returning();
    res.status(201).json(fmtContest(contest));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/contests/:id", async (req, res) => {
  try {
    const [row] = await db.select({ contest: contestsTable, user: usersTable })
      .from(contestsTable).innerJoin(usersTable, eq(contestsTable.hostId, usersTable.id))
      .where(eq(contestsTable.id, Number(req.params.id)));
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    res.json(fmtContest(row.contest, row.user));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/contests/:id/submissions", async (req, res) => {
  try {
    const rows = await db.select({ sub: contestSubmissionsTable, user: usersTable })
      .from(contestSubmissionsTable).innerJoin(usersTable, eq(contestSubmissionsTable.creatorId, usersTable.id))
      .where(eq(contestSubmissionsTable.contestId, Number(req.params.id)))
      .orderBy(desc(contestSubmissionsTable.createdAt));
    res.json(rows.map(r => {
      return { ...r.sub, creator: toPublicUser(r.user) };
    }));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/contests/:id/submissions", requireAuth, async (req, res) => {
  try {
    const contestId = Number(req.params.id);
    const { title, description, fileUrl, previewUrl } = req.body;
    if (!title || !description) { res.status(400).json({ error: "Missing required fields" }); return; }
    const [sub] = await db.insert(contestSubmissionsTable).values({
      contestId, creatorId: req.session!.userId!, title, description, fileUrl, previewUrl
    }).returning();
    await db.update(contestsTable).set({ submissionCount: sql`submission_count + 1` }).where(eq(contestsTable.id, contestId));
    res.status(201).json(sub);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/contests/:id/winner", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { submissionId } = req.body;
    const [contest] = await db.select().from(contestsTable).where(eq(contestsTable.id, id));
    if (!contest || contest.hostId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    await db.update(contestSubmissionsTable).set({ isWinner: true }).where(eq(contestSubmissionsTable.id, submissionId));
    const [updated] = await db.update(contestsTable).set({ status: "completed", winnerId: submissionId }).where(eq(contestsTable.id, id)).returning();
    res.json(fmtContest(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
