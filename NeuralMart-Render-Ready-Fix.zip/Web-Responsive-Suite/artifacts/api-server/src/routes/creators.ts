import { Router } from "express";
import { db } from "@workspace/db";
import {
  usersTable, creatorProfilesTable, followsTable,
  userBadgesTable, badgesTable, productsTable, servicesTable
} from "@workspace/db";
import { eq, ilike, and, sql } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";

const router = Router();

function formatCreator(user: any, profile: any, badges: any[], products: any[], services: any[], isFollowing = false) {
  const { passwordHash, ...safeUser } = user;
  return {
    id: profile.id,
    userId: profile.userId,
    displayName: safeUser.displayName,
    avatarUrl: safeUser.avatarUrl,
    coverUrl: safeUser.coverUrl,
    bio: safeUser.bio,
    category: profile.category,
    skills: profile.skills ?? [],
    totalSales: profile.totalSales,
    rating: Number(profile.rating),
    reviewCount: profile.reviewCount,
    responseTime: profile.responseTime,
    completionRate: Number(profile.completionRate),
    followersCount: safeUser.followersCount,
    isFollowing,
    badges,
    products: products.map(p => ({ ...p, price: Number(p.price), rating: Number(p.rating) })),
    services: services.map(s => ({ ...s, basicPrice: Number(s.basicPrice), rating: Number(s.rating) })),
    createdAt: safeUser.createdAt,
  };
}

router.get("/creators", async (req, res) => {
  try {
    const { category, search, page = "1", limit = "20" } = req.query as any;
    const offset = (Number(page) - 1) * Number(limit);
    let q = db.select({ user: usersTable, profile: creatorProfilesTable })
      .from(creatorProfilesTable)
      .innerJoin(usersTable, eq(creatorProfilesTable.userId, usersTable.id));
    const conditions: any[] = [];
    if (category) conditions.push(eq(creatorProfilesTable.category, category));
    if (search) conditions.push(ilike(usersTable.displayName, `%${search}%`));
    if (conditions.length) (q as any).where(and(...conditions));
    const rows = await q.limit(Number(limit)).offset(offset);
    const total = rows.length;
    const creators = rows.map(r => formatCreator(r.user, r.profile, [], [], []));
    res.json({ creators, total, page: Number(page), limit: Number(limit) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/creators/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [row] = await db.select({ user: usersTable, profile: creatorProfilesTable })
      .from(creatorProfilesTable)
      .innerJoin(usersTable, eq(creatorProfilesTable.userId, usersTable.id))
      .where(eq(creatorProfilesTable.userId, id));
    if (!row) { res.status(404).json({ error: "Creator not found" }); return; }
    const badgeRows = await db.select({ ub: userBadgesTable, b: badgesTable })
      .from(userBadgesTable).innerJoin(badgesTable, eq(userBadgesTable.badgeId, badgesTable.id))
      .where(eq(userBadgesTable.userId, row.user.id));
    const products = await db.select().from(productsTable).where(and(eq(productsTable.creatorId, row.user.id), eq(productsTable.isActive, true))).limit(6);
    const services = await db.select().from(servicesTable).where(and(eq(servicesTable.creatorId, row.user.id), eq(servicesTable.isActive, true))).limit(6);
    let isFollowing = false;
    const userId = req.session?.userId;
    if (userId) {
      const [follow] = await db.select().from(followsTable)
        .where(and(eq(followsTable.followerId, userId), eq(followsTable.followingId, row.user.id)));
      isFollowing = !!follow;
    }
    const badges = badgeRows.map(r => ({ ...r.ub, badge: r.b }));
    res.json(formatCreator(row.user, row.profile, badges, products, services, isFollowing));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.patch("/creators/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [profile] = await db.select().from(creatorProfilesTable).where(eq(creatorProfilesTable.userId, id));
    if (!profile) { res.status(404).json({ error: "Creator not found" }); return; }
    if (profile.userId !== req.session!.userId) { res.status(403).json({ error: "Forbidden" }); return; }
    const { bio, category, skills, avatarUrl, coverUrl } = req.body;
    const profileUpdates: any = {};
    const userUpdates: any = {};
    if (category !== undefined) profileUpdates.category = category;
    if (skills !== undefined) profileUpdates.skills = skills;
    if (bio !== undefined) userUpdates.bio = bio;
    if (avatarUrl !== undefined) userUpdates.avatarUrl = avatarUrl;
    if (coverUrl !== undefined) userUpdates.coverUrl = coverUrl;
    const [updatedProfile] = await db.update(creatorProfilesTable).set(profileUpdates).where(eq(creatorProfilesTable.id, id)).returning();
    if (Object.keys(userUpdates).length) {
      await db.update(usersTable).set(userUpdates).where(eq(usersTable.id, profile.userId));
    }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, profile.userId));
    res.json(formatCreator(user, updatedProfile, [], [], []));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.post("/creators/:id/follow", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [profile] = await db.select().from(creatorProfilesTable).where(eq(creatorProfilesTable.userId, id));
    if (!profile) { res.status(404).json({ error: "Creator not found" }); return; }
    const followerId = req.session!.userId!;
    const targetUserId = profile.userId;
    const [existing] = await db.select().from(followsTable)
      .where(and(eq(followsTable.followerId, followerId), eq(followsTable.followingId, targetUserId)));
    if (existing) {
      await db.delete(followsTable).where(eq(followsTable.id, existing.id));
      await db.update(usersTable).set({ followersCount: sql`followers_count - 1` }).where(eq(usersTable.id, targetUserId));
      await db.update(usersTable).set({ followingCount: sql`following_count - 1` }).where(eq(usersTable.id, followerId));
      const [target] = await db.select().from(usersTable).where(eq(usersTable.id, targetUserId));
      res.json({ isFollowing: false, followersCount: target.followersCount });
    } else {
      await db.insert(followsTable).values({ followerId, followingId: targetUserId });
      await db.update(usersTable).set({ followersCount: sql`followers_count + 1` }).where(eq(usersTable.id, targetUserId));
      await db.update(usersTable).set({ followingCount: sql`following_count + 1` }).where(eq(usersTable.id, followerId));
      const [target] = await db.select().from(usersTable).where(eq(usersTable.id, targetUserId));
      res.json({ isFollowing: true, followersCount: target.followersCount });
    }
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
