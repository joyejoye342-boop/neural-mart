import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, ordersTable, proposalsTable, walletTransactionsTable, userBadgesTable, badgesTable, projectsTable, productsTable, postsTable } from "@workspace/db";
import { eq, and, or, desc } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";

const router = Router();

router.get("/dashboard/creator", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    const creatorPosts = await db.select().from(postsTable).where(eq(postsTable.creatorId, userId));
    const postLikes = creatorPosts.reduce((sum, post) => sum + Number(post.likesCount || 0), 0);
    const postComments = creatorPosts.reduce((sum, post) => sum + Number(post.commentsCount || 0), 0);
    const mediaPosts = creatorPosts.filter(post => post.mediaUrl || (post.mediaUrls?.length ?? 0) > 0).length;
    const recentOrders = await db.select().from(ordersTable)
      .where(eq(ordersTable.sellerId, userId)).orderBy(desc(ordersTable.createdAt)).limit(5);
    const allOrders = await db.select().from(ordersTable).where(eq(ordersTable.sellerId, userId));
    const totalEarnings = allOrders.filter(o => o.status === "completed").reduce((s, o) => s + Number(o.amount), 0);
    const activeOrders = allOrders.filter(o => ["active", "pending"].includes(o.status)).length;
    const completedOrders = allOrders.filter(o => o.status === "completed").length;
    const proposals = await db.select().from(proposalsTable).where(eq(proposalsTable.creatorId, userId));
    const acceptedProposals = proposals.filter(p => p.status === "accepted").length;
    const winRate = proposals.length > 0 ? (acceptedProposals / proposals.length) * 100 : 0;
    const txs = await db.select().from(walletTransactionsTable).where(eq(walletTransactionsTable.userId, userId)).orderBy(walletTransactionsTable.createdAt);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const earningsByPeriod = months.slice(0, 7).map((m, i) => ({
      period: m,
      amount: txs.filter(t => t.type === "earning" && new Date(t.createdAt).getMonth() === i).reduce((s, t) => s + Number(t.amount), 0)
    }));
    const badgeRows = await db.select({ ub: userBadgesTable, b: badgesTable })
      .from(userBadgesTable).innerJoin(badgesTable, eq(userBadgesTable.badgeId, badgesTable.id))
      .where(eq(userBadgesTable.userId, userId));
    res.json({
      totalEarnings,
      pendingEarnings: 0,
      activeOrders,
      completedOrders,
      totalSales: completedOrders,
      rating: 4.9,
      profileViews: null,
      postCount: creatorPosts.length,
      postLikes,
      postComments,
      mediaPosts,
      followerCount: user.followersCount,
      recentOrders: recentOrders.map(o => ({ ...o, amount: Number(o.amount) })),
      earningsByPeriod,
      badges: badgeRows.map(r => ({ ...r.ub, badge: r.b })),
      proposalWinRate: Math.round(winRate),
      activeProposals: proposals.filter(p => p.status === "pending").length,
    });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

router.get("/dashboard/buyer", requireAuth, async (req, res) => {
  try {
    const userId = req.session!.userId!;
    const recentOrders = await db.select().from(ordersTable)
      .where(eq(ordersTable.buyerId, userId)).orderBy(desc(ordersTable.createdAt)).limit(5);
    const allOrders = await db.select().from(ordersTable).where(eq(ordersTable.buyerId, userId));
    const totalSpent = allOrders.reduce((s, o) => s + Number(o.amount), 0);
    const purchasedProducts = allOrders.filter(o => o.type === "product").length;
    const recentProjects = await db.select().from(projectsTable)
      .where(eq(projectsTable.buyerId, userId)).orderBy(desc(projectsTable.createdAt)).limit(5);
    const activeProjects = recentProjects.filter(p => p.status === "open" || p.status === "in_progress").length;
    res.json({
      activeProjects,
      totalSpent,
      purchasedProducts,
      activeContests: 0,
      recentOrders: recentOrders.map(o => ({ ...o, amount: Number(o.amount) })),
      recentProjects: recentProjects.map(p => ({ ...p, budgetMin: p.budgetMin ? Number(p.budgetMin) : null, budgetMax: p.budgetMax ? Number(p.budgetMax) : null })),
    });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
