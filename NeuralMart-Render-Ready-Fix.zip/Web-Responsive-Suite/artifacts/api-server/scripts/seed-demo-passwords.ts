/**
 * Ensures NeuralMart's seeded demo accounts have a working password.
 *
 * Background: the original seed data inserted a copy-pasted bcrypt hash for
 * all demo users that did not actually correspond to "password123", which
 * silently locked every demo account out of login (bcrypt.compare returned
 * false). This script re-hashes the known demo password and idempotently
 * updates the affected accounts, so the fix can be re-applied on any
 * environment (fresh DB, staging, etc.) instead of living only as a one-off
 * manual SQL run.
 *
 * Usage: pnpm --filter @workspace/api-server run seed:demo-passwords
 */
import bcrypt from "bcrypt";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { inArray } from "drizzle-orm";

const DEMO_PASSWORD = "password123";
const DEMO_EMAILS = [
  "alex@neuralmart.com",
  "maya@neuralmart.com",
  "sam@neuralmart.com",
  "priya@neuralmart.com",
  "jordan@neuralmart.com",
  "demo@neuralmart.com",
];

async function main() {
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);

  const updated = await db
    .update(usersTable)
    .set({ passwordHash })
    .where(inArray(usersTable.email, DEMO_EMAILS))
    .returning({ email: usersTable.email });

  console.log(`Updated ${updated.length} demo account password(s):`, updated.map((u) => u.email));
  process.exit(0);
}

main().catch((err) => {
  console.error("Failed to seed demo passwords:", err);
  process.exit(1);
});
